"""Declarative anomaly detection with Great Expectations (GX 1.x API).

Where the statistical rules in :mod:`etl_benchmark.quality.rules` reason
over distributions, this detector encodes a small *expectation suite* — a
declarative contract the data is supposed to satisfy. A row is flagged as
anomalous when it violates at least one expectation.

The default suite learned in :meth:`fit` is:
    - ``expect_column_values_to_not_be_null`` on every column;
    - ``expect_column_values_to_be_between`` on each numeric column, with
      bounds taken from the ``bounds_quantiles`` percentiles of the fit data.

Using inner quantiles (rather than the absolute min/max) turns the range
check into a usable outlier rule instead of a no-op when fit and predict
run on the same frame.

Tested against great_expectations 1.18.
"""

from __future__ import annotations

from typing import Self

import numpy as np
import pandas as pd

from etl_benchmark.quality.base import Detector

_ROW_ID = "__row_id__"


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_xǁGreatExpectationsDetectorǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁGreatExpectationsDetectorǁfit__mutmut: MutantDict = {}  # type: ignore
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut: MutantDict = {}  # type: ignore
mutants_xǁGreatExpectationsDetectorǁpredict__mutmut: MutantDict = {}  # type: ignore
mutants_xǁGreatExpectationsDetectorǁscore__mutmut: MutantDict = {}  # type: ignore


class GreatExpectationsDetector(Detector):
    name = "great_expectations"

    @_mutmut_mutated(mutants_xǁGreatExpectationsDetectorǁ__init____mutmut)
    def __init__(
        self,
        columns: list[str] | None = None,
        bounds_quantiles: tuple[float, float] = (0.001, 0.999),
        check_nulls: bool = True,
    ) -> None:
        self.columns = columns
        self.bounds_quantiles = bounds_quantiles
        self.check_nulls = check_nulls
        self._null_columns: list[str] = []
        self._bounds: dict[str, tuple[float, float]] = {}
        self._n_expectations: int = 0

    def xǁGreatExpectationsDetectorǁ__init____mutmut_orig(
        self,
        columns: list[str] | None = None,
        bounds_quantiles: tuple[float, float] = (0.001, 0.999),
        check_nulls: bool = True,
    ) -> None:
        self.columns = columns
        self.bounds_quantiles = bounds_quantiles
        self.check_nulls = check_nulls
        self._null_columns: list[str] = []
        self._bounds: dict[str, tuple[float, float]] = {}
        self._n_expectations: int = 0

    def xǁGreatExpectationsDetectorǁ__init____mutmut_1(
        self,
        columns: list[str] | None = None,
        bounds_quantiles: tuple[float, float] = (0.001, 0.999),
        check_nulls: bool = False,
    ) -> None:
        self.columns = columns
        self.bounds_quantiles = bounds_quantiles
        self.check_nulls = check_nulls
        self._null_columns: list[str] = []
        self._bounds: dict[str, tuple[float, float]] = {}
        self._n_expectations: int = 0

    def xǁGreatExpectationsDetectorǁ__init____mutmut_2(
        self,
        columns: list[str] | None = None,
        bounds_quantiles: tuple[float, float] = (0.001, 0.999),
        check_nulls: bool = True,
    ) -> None:
        self.columns = None
        self.bounds_quantiles = bounds_quantiles
        self.check_nulls = check_nulls
        self._null_columns: list[str] = []
        self._bounds: dict[str, tuple[float, float]] = {}
        self._n_expectations: int = 0

    def xǁGreatExpectationsDetectorǁ__init____mutmut_3(
        self,
        columns: list[str] | None = None,
        bounds_quantiles: tuple[float, float] = (0.001, 0.999),
        check_nulls: bool = True,
    ) -> None:
        self.columns = columns
        self.bounds_quantiles = None
        self.check_nulls = check_nulls
        self._null_columns: list[str] = []
        self._bounds: dict[str, tuple[float, float]] = {}
        self._n_expectations: int = 0

    def xǁGreatExpectationsDetectorǁ__init____mutmut_4(
        self,
        columns: list[str] | None = None,
        bounds_quantiles: tuple[float, float] = (0.001, 0.999),
        check_nulls: bool = True,
    ) -> None:
        self.columns = columns
        self.bounds_quantiles = bounds_quantiles
        self.check_nulls = None
        self._null_columns: list[str] = []
        self._bounds: dict[str, tuple[float, float]] = {}
        self._n_expectations: int = 0

    def xǁGreatExpectationsDetectorǁ__init____mutmut_5(
        self,
        columns: list[str] | None = None,
        bounds_quantiles: tuple[float, float] = (0.001, 0.999),
        check_nulls: bool = True,
    ) -> None:
        self.columns = columns
        self.bounds_quantiles = bounds_quantiles
        self.check_nulls = check_nulls
        self._null_columns: list[str] = None
        self._bounds: dict[str, tuple[float, float]] = {}
        self._n_expectations: int = 0

    def xǁGreatExpectationsDetectorǁ__init____mutmut_6(
        self,
        columns: list[str] | None = None,
        bounds_quantiles: tuple[float, float] = (0.001, 0.999),
        check_nulls: bool = True,
    ) -> None:
        self.columns = columns
        self.bounds_quantiles = bounds_quantiles
        self.check_nulls = check_nulls
        self._null_columns: list[str] = []
        self._bounds: dict[str, tuple[float, float]] = None
        self._n_expectations: int = 0

    def xǁGreatExpectationsDetectorǁ__init____mutmut_7(
        self,
        columns: list[str] | None = None,
        bounds_quantiles: tuple[float, float] = (0.001, 0.999),
        check_nulls: bool = True,
    ) -> None:
        self.columns = columns
        self.bounds_quantiles = bounds_quantiles
        self.check_nulls = check_nulls
        self._null_columns: list[str] = []
        self._bounds: dict[str, tuple[float, float]] = {}
        self._n_expectations: int = None

    def xǁGreatExpectationsDetectorǁ__init____mutmut_8(
        self,
        columns: list[str] | None = None,
        bounds_quantiles: tuple[float, float] = (0.001, 0.999),
        check_nulls: bool = True,
    ) -> None:
        self.columns = columns
        self.bounds_quantiles = bounds_quantiles
        self.check_nulls = check_nulls
        self._null_columns: list[str] = []
        self._bounds: dict[str, tuple[float, float]] = {}
        self._n_expectations: int = 1

    @_mutmut_mutated(mutants_xǁGreatExpectationsDetectorǁfit__mutmut)
    def fit(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_orig(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_1(self, df: pd.DataFrame) -> Self:
        numeric = None
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_2(self, df: pd.DataFrame) -> Self:
        numeric = self.columns and df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_3(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=None).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_4(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = None

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_5(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if (self.check_nulls) and False else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_6(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if (self.check_nulls) or True else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_7(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(None) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_8(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = None
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_9(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = None
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_10(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = None
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_11(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(None)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_12(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = None
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_13(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(None)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_14(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) or lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_15(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) or pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_16(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(None) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_17(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(None) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_18(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo <= hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_19(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = None

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_20(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(None), float(hi))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_21(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(None))

        self._n_expectations = len(self._null_columns) + len(self._bounds)
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_22(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = None
        return self

    def xǁGreatExpectationsDetectorǁfit__mutmut_23(self, df: pd.DataFrame) -> Self:
        numeric = self.columns or df.select_dtypes(include=np.number).columns.tolist()
        self._null_columns = list(df.columns) if self.check_nulls else []

        lo_q, hi_q = self.bounds_quantiles
        self._bounds = {}
        for col in numeric:
            lo = df[col].quantile(lo_q)
            hi = df[col].quantile(hi_q)
            if pd.notna(lo) and pd.notna(hi) and lo < hi:
                self._bounds[col] = (float(lo), float(hi))

        self._n_expectations = len(self._null_columns) - len(self._bounds)
        return self

    @_mutmut_mutated(mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut)
    def _failures_per_row(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations != 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 1:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_3(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(None)

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_4(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = None
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_5(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=None)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_6(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=False)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_7(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = None

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_8(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = None
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_9(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode=None)
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_10(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="XXephemeralXX")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_11(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="EPHEMERAL")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_12(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = None
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_13(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters=None)
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_14(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name=None)
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_15(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name=None)
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_16(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name=None)
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_17(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="XXpandasXX")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_18(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="PANDAS")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_19(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="XXassetXX")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_20(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="ASSET")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_21(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="XXbatchXX")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_22(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="BATCH")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_23(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"XXdataframeXX": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_24(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"DATAFRAME": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_25(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = None

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_26(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"XXresult_formatXX": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_27(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"RESULT_FORMAT": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_28(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "XXCOMPLETEXX", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_29(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "complete", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_30(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "XXunexpected_index_column_namesXX": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_31(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "UNEXPECTED_INDEX_COLUMN_NAMES": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_32(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = None
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_33(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(None, dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_34(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=None)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_35(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_36(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), )
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_37(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = None

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_38(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] - [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_39(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=None) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_40(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=None, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_41(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=None, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_42(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=None)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_43(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_44(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_45(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, )
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_46(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = None
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_47(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(None, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_48(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=None).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_49(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_50(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, ).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_51(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") and []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_52(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get(None) or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_53(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("XXunexpected_index_listXX") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_54(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("UNEXPECTED_INDEX_LIST") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_55(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] = 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_56(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] -= 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_57(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(None)] += 1

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_58(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 2

        return pd.Series(failures, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_59(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(None, index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_60(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, index=None)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_61(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(index=df.index)

    def xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_62(self, df: pd.DataFrame) -> pd.Series:
        """Number of violated expectations for each row (index-aligned)."""
        if self._n_expectations == 0:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

        # Import lazily so importing the package never pulls in GX.
        import great_expectations as gx
        from great_expectations import expectations as gxe

        work = df.reset_index(drop=True)
        work[_ROW_ID] = work.index

        context = gx.get_context(mode="ephemeral")
        batch = (
            context.data_sources.add_pandas(name="pandas")
            .add_dataframe_asset(name="asset")
            .add_batch_definition_whole_dataframe(name="batch")
            .get_batch(batch_parameters={"dataframe": work})
        )
        result_format = {"result_format": "COMPLETE", "unexpected_index_column_names": [_ROW_ID]}

        failures = np.zeros(len(work), dtype=np.int64)
        expectations = [
            gxe.ExpectColumnValuesToNotBeNull(column=col) for col in self._null_columns
        ] + [
            gxe.ExpectColumnValuesToBeBetween(column=col, min_value=lo, max_value=hi)
            for col, (lo, hi) in self._bounds.items()
        ]

        for exp in expectations:
            res = batch.validate(exp, result_format=result_format).result
            for row in res.get("unexpected_index_list") or []:
                failures[int(row[_ROW_ID])] += 1

        return pd.Series(failures, )

    @_mutmut_mutated(mutants_xǁGreatExpectationsDetectorǁpredict__mutmut)
    def predict(self, df: pd.DataFrame) -> pd.Series:
        return self._failures_per_row(df) > 0

    def xǁGreatExpectationsDetectorǁpredict__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        return self._failures_per_row(df) > 0

    def xǁGreatExpectationsDetectorǁpredict__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        return self._failures_per_row(None) > 0

    def xǁGreatExpectationsDetectorǁpredict__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        return self._failures_per_row(df) >= 0

    def xǁGreatExpectationsDetectorǁpredict__mutmut_3(self, df: pd.DataFrame) -> pd.Series:
        return self._failures_per_row(df) > 1

    @_mutmut_mutated(mutants_xǁGreatExpectationsDetectorǁscore__mutmut)
    def score(self, df: pd.DataFrame) -> pd.Series:
        # Fraction of the suite each row violates: a graded severity in [0, 1].
        return self._failures_per_row(df) / self._n_expectations

    def xǁGreatExpectationsDetectorǁscore__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        # Fraction of the suite each row violates: a graded severity in [0, 1].
        return self._failures_per_row(df) / self._n_expectations

    def xǁGreatExpectationsDetectorǁscore__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        # Fraction of the suite each row violates: a graded severity in [0, 1].
        return self._failures_per_row(df) * self._n_expectations

    def xǁGreatExpectationsDetectorǁscore__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        # Fraction of the suite each row violates: a graded severity in [0, 1].
        return self._failures_per_row(None) / self._n_expectations

mutants_xǁGreatExpectationsDetectorǁ__init____mutmut['_mutmut_orig'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ__init____mutmut['xǁGreatExpectationsDetectorǁ__init____mutmut_1'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ__init____mutmut['xǁGreatExpectationsDetectorǁ__init____mutmut_2'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ__init____mutmut['xǁGreatExpectationsDetectorǁ__init____mutmut_3'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ__init____mutmut['xǁGreatExpectationsDetectorǁ__init____mutmut_4'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ__init____mutmut['xǁGreatExpectationsDetectorǁ__init____mutmut_5'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ__init____mutmut['xǁGreatExpectationsDetectorǁ__init____mutmut_6'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ__init____mutmut_6 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ__init____mutmut['xǁGreatExpectationsDetectorǁ__init____mutmut_7'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ__init____mutmut_7 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ__init____mutmut['xǁGreatExpectationsDetectorǁ__init____mutmut_8'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ__init____mutmut_8 # type: ignore # mutmut generated

mutants_xǁGreatExpectationsDetectorǁfit__mutmut['_mutmut_orig'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_orig # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_1'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_1 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_2'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_2 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_3'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_3 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_4'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_4 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_5'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_5 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_6'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_6 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_7'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_7 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_8'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_8 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_9'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_9 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_10'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_10 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_11'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_11 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_12'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_12 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_13'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_13 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_14'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_14 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_15'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_15 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_16'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_16 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_17'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_17 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_18'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_18 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_19'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_19 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_20'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_20 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_21'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_21 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_22'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_22 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁfit__mutmut['xǁGreatExpectationsDetectorǁfit__mutmut_23'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁfit__mutmut_23 # type: ignore # mutmut generated

mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['_mutmut_orig'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_orig # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_1'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_1 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_2'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_2 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_3'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_3 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_4'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_4 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_5'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_5 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_6'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_6 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_7'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_7 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_8'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_8 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_9'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_9 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_10'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_10 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_11'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_11 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_12'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_12 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_13'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_13 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_14'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_14 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_15'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_15 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_16'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_16 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_17'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_17 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_18'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_18 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_19'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_19 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_20'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_20 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_21'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_21 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_22'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_22 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_23'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_23 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_24'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_24 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_25'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_25 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_26'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_26 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_27'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_27 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_28'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_28 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_29'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_29 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_30'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_30 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_31'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_31 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_32'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_32 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_33'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_33 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_34'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_34 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_35'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_35 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_36'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_36 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_37'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_37 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_38'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_38 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_39'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_39 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_40'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_40 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_41'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_41 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_42'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_42 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_43'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_43 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_44'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_44 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_45'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_45 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_46'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_46 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_47'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_47 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_48'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_48 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_49'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_49 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_50'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_50 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_51'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_51 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_52'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_52 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_53'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_53 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_54'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_54 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_55'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_55 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_56'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_56 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_57'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_57 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_58'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_58 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_59'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_59 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_60'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_60 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_61'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_61 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut['xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_62'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁ_failures_per_row__mutmut_62 # type: ignore # mutmut generated

mutants_xǁGreatExpectationsDetectorǁpredict__mutmut['_mutmut_orig'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁpredict__mutmut_orig # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁpredict__mutmut['xǁGreatExpectationsDetectorǁpredict__mutmut_1'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁpredict__mutmut_1 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁpredict__mutmut['xǁGreatExpectationsDetectorǁpredict__mutmut_2'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁpredict__mutmut_2 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁpredict__mutmut['xǁGreatExpectationsDetectorǁpredict__mutmut_3'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁpredict__mutmut_3 # type: ignore # mutmut generated

mutants_xǁGreatExpectationsDetectorǁscore__mutmut['_mutmut_orig'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁscore__mutmut_orig # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁscore__mutmut['xǁGreatExpectationsDetectorǁscore__mutmut_1'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁscore__mutmut_1 # type: ignore # mutmut generated
mutants_xǁGreatExpectationsDetectorǁscore__mutmut['xǁGreatExpectationsDetectorǁscore__mutmut_2'] = GreatExpectationsDetector.xǁGreatExpectationsDetectorǁscore__mutmut_2 # type: ignore # mutmut generated
