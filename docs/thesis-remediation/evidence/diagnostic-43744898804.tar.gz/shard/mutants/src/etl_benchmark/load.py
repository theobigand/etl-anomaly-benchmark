"""Load stage: persist results to disk."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from etl_benchmark.atomic import atomic_path


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_write_csv__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_write_csv__mutmut)
def write_csv(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(partial, index=False)
    return path


def x_write_csv__mutmut_orig(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(partial, index=False)
    return path


def x_write_csv__mutmut_1(df: pd.DataFrame, path: str | Path) -> Path:
    path = None
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(partial, index=False)
    return path


def x_write_csv__mutmut_2(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(None)
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(partial, index=False)
    return path


def x_write_csv__mutmut_3(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=None, exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(partial, index=False)
    return path


def x_write_csv__mutmut_4(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=None)
    with atomic_path(path) as partial:
        df.to_csv(partial, index=False)
    return path


def x_write_csv__mutmut_5(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(partial, index=False)
    return path


def x_write_csv__mutmut_6(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, )
    with atomic_path(path) as partial:
        df.to_csv(partial, index=False)
    return path


def x_write_csv__mutmut_7(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=False, exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(partial, index=False)
    return path


def x_write_csv__mutmut_8(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=False)
    with atomic_path(path) as partial:
        df.to_csv(partial, index=False)
    return path


def x_write_csv__mutmut_9(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(None) as partial:
        df.to_csv(partial, index=False)
    return path


def x_write_csv__mutmut_10(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(None, index=False)
    return path


def x_write_csv__mutmut_11(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(partial, index=None)
    return path


def x_write_csv__mutmut_12(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(index=False)
    return path


def x_write_csv__mutmut_13(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(partial, )
    return path


def x_write_csv__mutmut_14(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        df.to_csv(partial, index=True)
    return path

mutants_x_write_csv__mutmut['_mutmut_orig'] = x_write_csv__mutmut_orig # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_1'] = x_write_csv__mutmut_1 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_2'] = x_write_csv__mutmut_2 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_3'] = x_write_csv__mutmut_3 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_4'] = x_write_csv__mutmut_4 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_5'] = x_write_csv__mutmut_5 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_6'] = x_write_csv__mutmut_6 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_7'] = x_write_csv__mutmut_7 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_8'] = x_write_csv__mutmut_8 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_9'] = x_write_csv__mutmut_9 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_10'] = x_write_csv__mutmut_10 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_11'] = x_write_csv__mutmut_11 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_12'] = x_write_csv__mutmut_12 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_13'] = x_write_csv__mutmut_13 # type: ignore # mutmut generated
mutants_x_write_csv__mutmut['x_write_csv__mutmut_14'] = x_write_csv__mutmut_14 # type: ignore # mutmut generated
