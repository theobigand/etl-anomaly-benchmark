"""Reconstruction-error detector: a small autoencoder trained on the fit rows.

A multilayer perceptron is trained to reproduce the standardized features
through a bottleneck. A row that breaks the structure learned on the fit
data is reproduced badly, so its mean squared reconstruction error is the
anomaly score. The flag threshold is the ``1 - contamination`` quantile of
the training scores, which keeps every statistic tied to the fit rows.

The network is scikit-learn's ``MLPRegressor`` on CPU: it needs no
additional dependency and is deterministic for a given seed. It reuses the
imputation, scaling and input checks of :class:`PyODDetector`, so it follows
the same fit / predict / score contract as the other learned detectors. It is
registered as an opt-in detector and is not part of the default sweep.
"""

from __future__ import annotations

import warnings
from importlib.metadata import version
from typing import Self

import numpy as np
from sklearn.exceptions import ConvergenceWarning
from sklearn.neural_network import MLPRegressor

from etl_benchmark import config
from etl_benchmark.quality.ml import PyODDetector


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_xǁReconstructionModelǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁReconstructionModelǁlayers__mutmut: MutantDict = {}  # type: ignore
mutants_xǁReconstructionModelǁfit__mutmut: MutantDict = {}  # type: ignore
mutants_xǁReconstructionModelǁdecision_function__mutmut: MutantDict = {}  # type: ignore
mutants_xǁReconstructionModelǁpredict__mutmut: MutantDict = {}  # type: ignore


class ReconstructionModel:
    """PyOD-style estimator (``fit``, ``decision_function``, ``predict``)."""

    @_mutmut_mutated(mutants_xǁReconstructionModelǁ__init____mutmut)
    def __init__(self, contamination: float, random_state: int, max_iter: int) -> None:
        self.contamination = contamination
        self.random_state = random_state
        self.max_iter = max_iter
        self.threshold_: float | None = None
        self.network_: MLPRegressor | None = None

    def xǁReconstructionModelǁ__init____mutmut_orig(self, contamination: float, random_state: int, max_iter: int) -> None:
        self.contamination = contamination
        self.random_state = random_state
        self.max_iter = max_iter
        self.threshold_: float | None = None
        self.network_: MLPRegressor | None = None

    def xǁReconstructionModelǁ__init____mutmut_1(self, contamination: float, random_state: int, max_iter: int) -> None:
        self.contamination = None
        self.random_state = random_state
        self.max_iter = max_iter
        self.threshold_: float | None = None
        self.network_: MLPRegressor | None = None

    def xǁReconstructionModelǁ__init____mutmut_2(self, contamination: float, random_state: int, max_iter: int) -> None:
        self.contamination = contamination
        self.random_state = None
        self.max_iter = max_iter
        self.threshold_: float | None = None
        self.network_: MLPRegressor | None = None

    def xǁReconstructionModelǁ__init____mutmut_3(self, contamination: float, random_state: int, max_iter: int) -> None:
        self.contamination = contamination
        self.random_state = random_state
        self.max_iter = None
        self.threshold_: float | None = None
        self.network_: MLPRegressor | None = None

    def xǁReconstructionModelǁ__init____mutmut_4(self, contamination: float, random_state: int, max_iter: int) -> None:
        self.contamination = contamination
        self.random_state = random_state
        self.max_iter = max_iter
        self.threshold_: float | None = ""
        self.network_: MLPRegressor | None = None

    def xǁReconstructionModelǁ__init____mutmut_5(self, contamination: float, random_state: int, max_iter: int) -> None:
        self.contamination = contamination
        self.random_state = random_state
        self.max_iter = max_iter
        self.threshold_: float | None = None
        self.network_: MLPRegressor | None = ""

    @staticmethod
    @_mutmut_mutated(mutants_xǁReconstructionModelǁlayers__mutmut)
    def layers(width: int) -> list[int]:
        return [max(width, 2), max(width // 2, 1), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_orig(width: int) -> list[int]:
        return [max(width, 2), max(width // 2, 1), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_1(width: int) -> list[int]:
        return [max(None, 2), max(width // 2, 1), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_2(width: int) -> list[int]:
        return [max(width, None), max(width // 2, 1), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_3(width: int) -> list[int]:
        return [max(2), max(width // 2, 1), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_4(width: int) -> list[int]:
        return [max(width, ), max(width // 2, 1), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_5(width: int) -> list[int]:
        return [max(width, 3), max(width // 2, 1), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_6(width: int) -> list[int]:
        return [max(width, 2), max(None, 1), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_7(width: int) -> list[int]:
        return [max(width, 2), max(width // 2, None), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_8(width: int) -> list[int]:
        return [max(width, 2), max(1), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_9(width: int) -> list[int]:
        return [max(width, 2), max(width // 2, ), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_10(width: int) -> list[int]:
        return [max(width, 2), max(width / 2, 1), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_11(width: int) -> list[int]:
        return [max(width, 2), max(width // 3, 1), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_12(width: int) -> list[int]:
        return [max(width, 2), max(width // 2, 2), max(width, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_13(width: int) -> list[int]:
        return [max(width, 2), max(width // 2, 1), max(None, 2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_14(width: int) -> list[int]:
        return [max(width, 2), max(width // 2, 1), max(width, None)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_15(width: int) -> list[int]:
        return [max(width, 2), max(width // 2, 1), max(2)]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_16(width: int) -> list[int]:
        return [max(width, 2), max(width // 2, 1), max(width, )]

    @staticmethod
    def xǁReconstructionModelǁlayers__mutmut_17(width: int) -> list[int]:
        return [max(width, 2), max(width // 2, 1), max(width, 3)]

    @_mutmut_mutated(mutants_xǁReconstructionModelǁfit__mutmut)
    def fit(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_orig(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_1(self, x: np.ndarray) -> Self:
        network = None
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_2(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=None,
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_3(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=None,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_4(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=None,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_5(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_6(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_7(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_8(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(None),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_9(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(None)),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_10(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[2])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_11(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter(None, ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_12(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", None)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_13(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter(ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_14(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", )
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_15(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("XXignoreXX", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_16(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("IGNORE", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_17(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(None, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_18(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, None)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_19(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_20(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, )
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_21(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if (x.shape[1] == 1) and False else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_22(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if (x.shape[1] == 1) or True else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_23(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[2] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_24(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] != 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_25(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 2 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_26(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = None
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_27(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = None
        return self

    def xǁReconstructionModelǁfit__mutmut_28(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(None)
        return self

    def xǁReconstructionModelǁfit__mutmut_29(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(None, 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_30(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), None))
        return self

    def xǁReconstructionModelǁfit__mutmut_31(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_32(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), ))
        return self

    def xǁReconstructionModelǁfit__mutmut_33(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(None), 1.0 - self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_34(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 + self.contamination))
        return self

    def xǁReconstructionModelǁfit__mutmut_35(self, x: np.ndarray) -> Self:
        network = MLPRegressor(
            hidden_layer_sizes=tuple(self.layers(x.shape[1])),
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        with warnings.catch_warnings():
            # A fixed training budget is part of the protocol; whether it ran
            # out is reported through ``settings()`` instead of a warning.
            warnings.simplefilter("ignore", ConvergenceWarning)
            network.fit(x, x.ravel() if x.shape[1] == 1 else x)
        self.network_ = network
        self.threshold_ = float(np.quantile(self.decision_function(x), 2.0 - self.contamination))
        return self

    @_mutmut_mutated(mutants_xǁReconstructionModelǁdecision_function__mutmut)
    def decision_function(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(x).reshape(x.shape)
        return np.mean((x - reconstruction) ** 2, axis=1)

    def xǁReconstructionModelǁdecision_function__mutmut_orig(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(x).reshape(x.shape)
        return np.mean((x - reconstruction) ** 2, axis=1)

    def xǁReconstructionModelǁdecision_function__mutmut_1(self, x: np.ndarray) -> np.ndarray:
        reconstruction = None
        return np.mean((x - reconstruction) ** 2, axis=1)

    def xǁReconstructionModelǁdecision_function__mutmut_2(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(x).reshape(None)
        return np.mean((x - reconstruction) ** 2, axis=1)

    def xǁReconstructionModelǁdecision_function__mutmut_3(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(None).reshape(x.shape)
        return np.mean((x - reconstruction) ** 2, axis=1)

    def xǁReconstructionModelǁdecision_function__mutmut_4(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(x).reshape(x.shape)
        return np.mean(None, axis=1)

    def xǁReconstructionModelǁdecision_function__mutmut_5(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(x).reshape(x.shape)
        return np.mean((x - reconstruction) ** 2, axis=None)

    def xǁReconstructionModelǁdecision_function__mutmut_6(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(x).reshape(x.shape)
        return np.mean(axis=1)

    def xǁReconstructionModelǁdecision_function__mutmut_7(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(x).reshape(x.shape)
        return np.mean((x - reconstruction) ** 2, )

    def xǁReconstructionModelǁdecision_function__mutmut_8(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(x).reshape(x.shape)
        return np.mean((x - reconstruction) * 2, axis=1)

    def xǁReconstructionModelǁdecision_function__mutmut_9(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(x).reshape(x.shape)
        return np.mean((x + reconstruction) ** 2, axis=1)

    def xǁReconstructionModelǁdecision_function__mutmut_10(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(x).reshape(x.shape)
        return np.mean((x - reconstruction) ** 3, axis=1)

    def xǁReconstructionModelǁdecision_function__mutmut_11(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.network_.predict(x).reshape(x.shape)
        return np.mean((x - reconstruction) ** 2, axis=2)

    @_mutmut_mutated(mutants_xǁReconstructionModelǁpredict__mutmut)
    def predict(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) > self.threshold_).astype(int)

    def xǁReconstructionModelǁpredict__mutmut_orig(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) > self.threshold_).astype(int)

    def xǁReconstructionModelǁpredict__mutmut_1(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) > self.threshold_).astype(None)

    def xǁReconstructionModelǁpredict__mutmut_2(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(None) > self.threshold_).astype(int)

    def xǁReconstructionModelǁpredict__mutmut_3(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) >= self.threshold_).astype(int)

mutants_xǁReconstructionModelǁ__init____mutmut['_mutmut_orig'] = ReconstructionModel.xǁReconstructionModelǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁ__init____mutmut['xǁReconstructionModelǁ__init____mutmut_1'] = ReconstructionModel.xǁReconstructionModelǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁ__init____mutmut['xǁReconstructionModelǁ__init____mutmut_2'] = ReconstructionModel.xǁReconstructionModelǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁ__init____mutmut['xǁReconstructionModelǁ__init____mutmut_3'] = ReconstructionModel.xǁReconstructionModelǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁ__init____mutmut['xǁReconstructionModelǁ__init____mutmut_4'] = ReconstructionModel.xǁReconstructionModelǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁ__init____mutmut['xǁReconstructionModelǁ__init____mutmut_5'] = ReconstructionModel.xǁReconstructionModelǁ__init____mutmut_5 # type: ignore # mutmut generated

mutants_xǁReconstructionModelǁlayers__mutmut['_mutmut_orig'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_orig # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_1'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_1 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_2'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_2 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_3'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_3 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_4'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_4 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_5'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_5 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_6'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_6 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_7'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_7 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_8'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_8 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_9'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_9 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_10'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_10 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_11'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_11 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_12'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_12 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_13'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_13 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_14'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_14 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_15'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_15 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_16'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_16 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁlayers__mutmut['xǁReconstructionModelǁlayers__mutmut_17'] = ReconstructionModel.xǁReconstructionModelǁlayers__mutmut_17 # type: ignore # mutmut generated

mutants_xǁReconstructionModelǁfit__mutmut['_mutmut_orig'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_orig # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_1'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_1 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_2'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_2 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_3'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_3 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_4'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_4 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_5'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_5 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_6'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_6 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_7'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_7 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_8'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_8 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_9'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_9 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_10'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_10 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_11'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_11 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_12'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_12 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_13'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_13 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_14'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_14 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_15'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_15 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_16'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_16 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_17'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_17 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_18'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_18 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_19'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_19 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_20'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_20 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_21'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_21 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_22'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_22 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_23'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_23 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_24'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_24 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_25'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_25 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_26'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_26 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_27'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_27 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_28'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_28 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_29'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_29 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_30'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_30 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_31'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_31 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_32'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_32 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_33'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_33 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_34'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_34 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁfit__mutmut['xǁReconstructionModelǁfit__mutmut_35'] = ReconstructionModel.xǁReconstructionModelǁfit__mutmut_35 # type: ignore # mutmut generated

mutants_xǁReconstructionModelǁdecision_function__mutmut['_mutmut_orig'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_orig # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁdecision_function__mutmut['xǁReconstructionModelǁdecision_function__mutmut_1'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_1 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁdecision_function__mutmut['xǁReconstructionModelǁdecision_function__mutmut_2'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_2 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁdecision_function__mutmut['xǁReconstructionModelǁdecision_function__mutmut_3'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_3 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁdecision_function__mutmut['xǁReconstructionModelǁdecision_function__mutmut_4'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_4 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁdecision_function__mutmut['xǁReconstructionModelǁdecision_function__mutmut_5'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_5 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁdecision_function__mutmut['xǁReconstructionModelǁdecision_function__mutmut_6'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_6 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁdecision_function__mutmut['xǁReconstructionModelǁdecision_function__mutmut_7'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_7 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁdecision_function__mutmut['xǁReconstructionModelǁdecision_function__mutmut_8'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_8 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁdecision_function__mutmut['xǁReconstructionModelǁdecision_function__mutmut_9'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_9 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁdecision_function__mutmut['xǁReconstructionModelǁdecision_function__mutmut_10'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_10 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁdecision_function__mutmut['xǁReconstructionModelǁdecision_function__mutmut_11'] = ReconstructionModel.xǁReconstructionModelǁdecision_function__mutmut_11 # type: ignore # mutmut generated

mutants_xǁReconstructionModelǁpredict__mutmut['_mutmut_orig'] = ReconstructionModel.xǁReconstructionModelǁpredict__mutmut_orig # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁpredict__mutmut['xǁReconstructionModelǁpredict__mutmut_1'] = ReconstructionModel.xǁReconstructionModelǁpredict__mutmut_1 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁpredict__mutmut['xǁReconstructionModelǁpredict__mutmut_2'] = ReconstructionModel.xǁReconstructionModelǁpredict__mutmut_2 # type: ignore # mutmut generated
mutants_xǁReconstructionModelǁpredict__mutmut['xǁReconstructionModelǁpredict__mutmut_3'] = ReconstructionModel.xǁReconstructionModelǁpredict__mutmut_3 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁAutoencoderDetectorǁ_build_estimator__mutmut: MutantDict = {}  # type: ignore
mutants_xǁAutoencoderDetectorǁsettings__mutmut: MutantDict = {}  # type: ignore


class AutoencoderDetector(PyODDetector):
    name = "autoencoder"

    @_mutmut_mutated(mutants_xǁAutoencoderDetectorǁ__init____mutmut)
    def __init__(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        max_iter: int = 300,
        random_state: int = config.RANDOM_SEED,
    ) -> None:
        super().__init__(contamination=contamination, columns=columns)
        self.max_iter = max_iter
        self.random_state = random_state

    def xǁAutoencoderDetectorǁ__init____mutmut_orig(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        max_iter: int = 300,
        random_state: int = config.RANDOM_SEED,
    ) -> None:
        super().__init__(contamination=contamination, columns=columns)
        self.max_iter = max_iter
        self.random_state = random_state

    def xǁAutoencoderDetectorǁ__init____mutmut_1(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        max_iter: int = 301,
        random_state: int = config.RANDOM_SEED,
    ) -> None:
        super().__init__(contamination=contamination, columns=columns)
        self.max_iter = max_iter
        self.random_state = random_state

    def xǁAutoencoderDetectorǁ__init____mutmut_2(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        max_iter: int = 300,
        random_state: int = config.RANDOM_SEED,
    ) -> None:
        super().__init__(contamination=None, columns=columns)
        self.max_iter = max_iter
        self.random_state = random_state

    def xǁAutoencoderDetectorǁ__init____mutmut_3(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        max_iter: int = 300,
        random_state: int = config.RANDOM_SEED,
    ) -> None:
        super().__init__(contamination=contamination, columns=None)
        self.max_iter = max_iter
        self.random_state = random_state

    def xǁAutoencoderDetectorǁ__init____mutmut_4(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        max_iter: int = 300,
        random_state: int = config.RANDOM_SEED,
    ) -> None:
        super().__init__(columns=columns)
        self.max_iter = max_iter
        self.random_state = random_state

    def xǁAutoencoderDetectorǁ__init____mutmut_5(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        max_iter: int = 300,
        random_state: int = config.RANDOM_SEED,
    ) -> None:
        super().__init__(contamination=contamination, )
        self.max_iter = max_iter
        self.random_state = random_state

    def xǁAutoencoderDetectorǁ__init____mutmut_6(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        max_iter: int = 300,
        random_state: int = config.RANDOM_SEED,
    ) -> None:
        super().__init__(contamination=contamination, columns=columns)
        self.max_iter = None
        self.random_state = random_state

    def xǁAutoencoderDetectorǁ__init____mutmut_7(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        max_iter: int = 300,
        random_state: int = config.RANDOM_SEED,
    ) -> None:
        super().__init__(contamination=contamination, columns=columns)
        self.max_iter = max_iter
        self.random_state = None

    @_mutmut_mutated(mutants_xǁAutoencoderDetectorǁ_build_estimator__mutmut)
    def _build_estimator(self) -> ReconstructionModel:
        return ReconstructionModel(self.contamination, self.random_state, self.max_iter)

    def xǁAutoencoderDetectorǁ_build_estimator__mutmut_orig(self) -> ReconstructionModel:
        return ReconstructionModel(self.contamination, self.random_state, self.max_iter)

    def xǁAutoencoderDetectorǁ_build_estimator__mutmut_1(self) -> ReconstructionModel:
        return ReconstructionModel(None, self.random_state, self.max_iter)

    def xǁAutoencoderDetectorǁ_build_estimator__mutmut_2(self) -> ReconstructionModel:
        return ReconstructionModel(self.contamination, None, self.max_iter)

    def xǁAutoencoderDetectorǁ_build_estimator__mutmut_3(self) -> ReconstructionModel:
        return ReconstructionModel(self.contamination, self.random_state, None)

    def xǁAutoencoderDetectorǁ_build_estimator__mutmut_4(self) -> ReconstructionModel:
        return ReconstructionModel(self.random_state, self.max_iter)

    def xǁAutoencoderDetectorǁ_build_estimator__mutmut_5(self) -> ReconstructionModel:
        return ReconstructionModel(self.contamination, self.max_iter)

    def xǁAutoencoderDetectorǁ_build_estimator__mutmut_6(self) -> ReconstructionModel:
        return ReconstructionModel(self.contamination, self.random_state, )

    @_mutmut_mutated(mutants_xǁAutoencoderDetectorǁsettings__mutmut)
    def settings(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_orig(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_1(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = None
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_2(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "XXcontaminationXX": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_3(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "CONTAMINATION": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_4(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "XXhidden_layer_sizesXX": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_5(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "HIDDEN_LAYER_SIZES": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_6(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(None),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_7(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "XXmax_iterXX": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_8(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "MAX_ITER": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_9(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "XXn_iterXX": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_10(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "N_ITER": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_11(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(None),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_12(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "XXconvergedXX": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_13(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "CONVERGED": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_14(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(None),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_15(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ <= self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_16(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "XXrandom_stateXX": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_17(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "RANDOM_STATE": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_18(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "XXdeviceXX": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_19(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "DEVICE": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_20(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "XXcpuXX",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_21(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "CPU",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_22(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "XXversionsXX": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_23(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "VERSIONS": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_24(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "XXscikit-learnXX": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_25(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "SCIKIT-LEARN": version("scikit-learn"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_26(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version(None),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_27(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("XXscikit-learnXX"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_28(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("SCIKIT-LEARN"),
                "numpy": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_29(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "XXnumpyXX": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_30(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "NUMPY": version("numpy"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_31(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version(None),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_32(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("XXnumpyXX"),
            },
        }

    def xǁAutoencoderDetectorǁsettings__mutmut_33(self) -> dict[str, object]:
        """Hyper-parameters, seed, budget and versions to store with a run."""
        network = self._fitted_model().network_
        return {
            "contamination": self.contamination,
            "hidden_layer_sizes": list(network.hidden_layer_sizes),
            "max_iter": self.max_iter,
            "n_iter": int(network.n_iter_),
            "converged": bool(network.n_iter_ < self.max_iter),
            "random_state": self.random_state,
            "device": "cpu",
            "versions": {
                "scikit-learn": version("scikit-learn"),
                "numpy": version("NUMPY"),
            },
        }

mutants_xǁAutoencoderDetectorǁ__init____mutmut['_mutmut_orig'] = AutoencoderDetector.xǁAutoencoderDetectorǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ__init____mutmut['xǁAutoencoderDetectorǁ__init____mutmut_1'] = AutoencoderDetector.xǁAutoencoderDetectorǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ__init____mutmut['xǁAutoencoderDetectorǁ__init____mutmut_2'] = AutoencoderDetector.xǁAutoencoderDetectorǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ__init____mutmut['xǁAutoencoderDetectorǁ__init____mutmut_3'] = AutoencoderDetector.xǁAutoencoderDetectorǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ__init____mutmut['xǁAutoencoderDetectorǁ__init____mutmut_4'] = AutoencoderDetector.xǁAutoencoderDetectorǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ__init____mutmut['xǁAutoencoderDetectorǁ__init____mutmut_5'] = AutoencoderDetector.xǁAutoencoderDetectorǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ__init____mutmut['xǁAutoencoderDetectorǁ__init____mutmut_6'] = AutoencoderDetector.xǁAutoencoderDetectorǁ__init____mutmut_6 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ__init____mutmut['xǁAutoencoderDetectorǁ__init____mutmut_7'] = AutoencoderDetector.xǁAutoencoderDetectorǁ__init____mutmut_7 # type: ignore # mutmut generated

mutants_xǁAutoencoderDetectorǁ_build_estimator__mutmut['_mutmut_orig'] = AutoencoderDetector.xǁAutoencoderDetectorǁ_build_estimator__mutmut_orig # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ_build_estimator__mutmut['xǁAutoencoderDetectorǁ_build_estimator__mutmut_1'] = AutoencoderDetector.xǁAutoencoderDetectorǁ_build_estimator__mutmut_1 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ_build_estimator__mutmut['xǁAutoencoderDetectorǁ_build_estimator__mutmut_2'] = AutoencoderDetector.xǁAutoencoderDetectorǁ_build_estimator__mutmut_2 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ_build_estimator__mutmut['xǁAutoencoderDetectorǁ_build_estimator__mutmut_3'] = AutoencoderDetector.xǁAutoencoderDetectorǁ_build_estimator__mutmut_3 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ_build_estimator__mutmut['xǁAutoencoderDetectorǁ_build_estimator__mutmut_4'] = AutoencoderDetector.xǁAutoencoderDetectorǁ_build_estimator__mutmut_4 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ_build_estimator__mutmut['xǁAutoencoderDetectorǁ_build_estimator__mutmut_5'] = AutoencoderDetector.xǁAutoencoderDetectorǁ_build_estimator__mutmut_5 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁ_build_estimator__mutmut['xǁAutoencoderDetectorǁ_build_estimator__mutmut_6'] = AutoencoderDetector.xǁAutoencoderDetectorǁ_build_estimator__mutmut_6 # type: ignore # mutmut generated

mutants_xǁAutoencoderDetectorǁsettings__mutmut['_mutmut_orig'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_orig # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_1'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_1 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_2'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_2 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_3'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_3 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_4'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_4 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_5'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_5 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_6'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_6 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_7'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_7 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_8'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_8 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_9'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_9 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_10'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_10 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_11'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_11 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_12'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_12 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_13'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_13 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_14'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_14 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_15'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_15 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_16'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_16 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_17'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_17 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_18'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_18 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_19'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_19 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_20'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_20 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_21'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_21 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_22'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_22 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_23'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_23 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_24'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_24 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_25'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_25 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_26'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_26 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_27'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_27 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_28'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_28 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_29'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_29 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_30'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_30 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_31'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_31 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_32'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_32 # type: ignore # mutmut generated
mutants_xǁAutoencoderDetectorǁsettings__mutmut['xǁAutoencoderDetectorǁsettings__mutmut_33'] = AutoencoderDetector.xǁAutoencoderDetectorǁsettings__mutmut_33 # type: ignore # mutmut generated
