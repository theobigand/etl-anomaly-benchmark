"""Evaluation metrics shared by the real and synthetic benchmarks."""

from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_compute_metrics__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_compute_metrics__mutmut)
def compute_metrics(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_orig(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_1(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = None
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_2(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(None)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_3(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = None
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_4(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(None)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_5(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = None
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_6(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(None)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_7(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 and scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_8(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 and flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_9(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim == 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_10(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 2 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_11(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim == 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_12(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 2 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_13(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim == 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_14(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 2:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_15(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError(None)
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_16(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("XXlabels, flags and scores must be one-dimensionalXX")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_17(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("LABELS, FLAGS AND SCORES MUST BE ONE-DIMENSIONAL")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_18(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) and len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_19(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 and len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_20(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) != 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_21(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 1 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_22(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) == len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_23(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) == len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_24(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError(None)
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_25(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("XXlabels, flags and scores must have equal nonzero lengthXX")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_26(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("LABELS, FLAGS AND SCORES MUST HAVE EQUAL NONZERO LENGTH")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_27(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(None) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_28(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(None)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_29(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) == {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_30(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {1, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_31(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 2}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_32(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError(None)
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_33(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("XXROC-AUC and average precision require both binary classesXX")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_34(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("roc-auc and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_35(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC AND AVERAGE PRECISION REQUIRE BOTH BINARY CLASSES")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_36(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind == "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_37(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "XXbXX":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_38(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "B":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_39(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError(None)
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_40(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("XXflags must be booleanXX")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_41(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("FLAGS MUST BE BOOLEAN")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_42(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_43(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(None).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_44(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(None)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_45(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError(None)
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_46(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("XXscores must be finiteXX")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_47(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("SCORES MUST BE FINITE")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_48(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "XXprecisionXX": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_49(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "PRECISION": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_50(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(None),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_51(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(None, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_52(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, None, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_53(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=None)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_54(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_55(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_56(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, )),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_57(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=1)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_58(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "XXrecallXX": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_59(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "RECALL": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_60(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(None),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_61(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(None, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_62(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, None)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_63(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_64(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, )),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_65(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "XXf1XX": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_66(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "F1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_67(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(None),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_68(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(None, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_69(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, None)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_70(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_71(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, )),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_72(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "XXroc_aucXX": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_73(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "ROC_AUC": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_74(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(None),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_75(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(None, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_76(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, None)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_77(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_78(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, )),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_79(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "XXpr_aucXX": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_80(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "PR_AUC": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_81(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(None),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_82(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(None, scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_83(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, None)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_84(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(scores)),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_85(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, )),
        "flagged_pct": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_86(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "XXflagged_pctXX": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_87(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "FLAGGED_PCT": 100.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_88(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 / float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_89(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 101.0 * float(np.mean(flags)),
    }


def x_compute_metrics__mutmut_90(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(None),
    }


def x_compute_metrics__mutmut_91(y, flags, scores) -> dict[str, float]:
    """Return held-out metrics; reject undefined or malformed evaluations.

    ``pr_auc`` is average precision, not trapezoidal PR area. Higher scores
    must indicate more anomalous observations.
    """
    y = np.asarray(y)
    flags = np.asarray(flags)
    scores = np.asarray(scores)
    if y.ndim != 1 or flags.ndim != 1 or scores.ndim != 1:
        raise ValueError("labels, flags and scores must be one-dimensional")
    if len(y) == 0 or len(y) != len(flags) or len(y) != len(scores):
        raise ValueError("labels, flags and scores must have equal nonzero length")
    if set(np.unique(y)) != {0, 1}:
        raise ValueError("ROC-AUC and average precision require both binary classes")
    if flags.dtype.kind != "b":
        raise ValueError("flags must be boolean")
    if not np.isfinite(scores.astype(float)).all():
        raise ValueError("scores must be finite")
    return {
        "precision": float(precision_score(y, flags, zero_division=0)),
        "recall": float(recall_score(y, flags)),
        "f1": float(f1_score(y, flags)),
        "roc_auc": float(roc_auc_score(y, scores)),
        "pr_auc": float(average_precision_score(y, scores)),
        "flagged_pct": 100.0 * float(np.mean(None)),
    }

mutants_x_compute_metrics__mutmut['_mutmut_orig'] = x_compute_metrics__mutmut_orig # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_1'] = x_compute_metrics__mutmut_1 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_2'] = x_compute_metrics__mutmut_2 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_3'] = x_compute_metrics__mutmut_3 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_4'] = x_compute_metrics__mutmut_4 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_5'] = x_compute_metrics__mutmut_5 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_6'] = x_compute_metrics__mutmut_6 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_7'] = x_compute_metrics__mutmut_7 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_8'] = x_compute_metrics__mutmut_8 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_9'] = x_compute_metrics__mutmut_9 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_10'] = x_compute_metrics__mutmut_10 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_11'] = x_compute_metrics__mutmut_11 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_12'] = x_compute_metrics__mutmut_12 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_13'] = x_compute_metrics__mutmut_13 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_14'] = x_compute_metrics__mutmut_14 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_15'] = x_compute_metrics__mutmut_15 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_16'] = x_compute_metrics__mutmut_16 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_17'] = x_compute_metrics__mutmut_17 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_18'] = x_compute_metrics__mutmut_18 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_19'] = x_compute_metrics__mutmut_19 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_20'] = x_compute_metrics__mutmut_20 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_21'] = x_compute_metrics__mutmut_21 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_22'] = x_compute_metrics__mutmut_22 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_23'] = x_compute_metrics__mutmut_23 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_24'] = x_compute_metrics__mutmut_24 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_25'] = x_compute_metrics__mutmut_25 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_26'] = x_compute_metrics__mutmut_26 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_27'] = x_compute_metrics__mutmut_27 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_28'] = x_compute_metrics__mutmut_28 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_29'] = x_compute_metrics__mutmut_29 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_30'] = x_compute_metrics__mutmut_30 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_31'] = x_compute_metrics__mutmut_31 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_32'] = x_compute_metrics__mutmut_32 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_33'] = x_compute_metrics__mutmut_33 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_34'] = x_compute_metrics__mutmut_34 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_35'] = x_compute_metrics__mutmut_35 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_36'] = x_compute_metrics__mutmut_36 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_37'] = x_compute_metrics__mutmut_37 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_38'] = x_compute_metrics__mutmut_38 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_39'] = x_compute_metrics__mutmut_39 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_40'] = x_compute_metrics__mutmut_40 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_41'] = x_compute_metrics__mutmut_41 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_42'] = x_compute_metrics__mutmut_42 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_43'] = x_compute_metrics__mutmut_43 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_44'] = x_compute_metrics__mutmut_44 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_45'] = x_compute_metrics__mutmut_45 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_46'] = x_compute_metrics__mutmut_46 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_47'] = x_compute_metrics__mutmut_47 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_48'] = x_compute_metrics__mutmut_48 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_49'] = x_compute_metrics__mutmut_49 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_50'] = x_compute_metrics__mutmut_50 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_51'] = x_compute_metrics__mutmut_51 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_52'] = x_compute_metrics__mutmut_52 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_53'] = x_compute_metrics__mutmut_53 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_54'] = x_compute_metrics__mutmut_54 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_55'] = x_compute_metrics__mutmut_55 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_56'] = x_compute_metrics__mutmut_56 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_57'] = x_compute_metrics__mutmut_57 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_58'] = x_compute_metrics__mutmut_58 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_59'] = x_compute_metrics__mutmut_59 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_60'] = x_compute_metrics__mutmut_60 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_61'] = x_compute_metrics__mutmut_61 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_62'] = x_compute_metrics__mutmut_62 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_63'] = x_compute_metrics__mutmut_63 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_64'] = x_compute_metrics__mutmut_64 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_65'] = x_compute_metrics__mutmut_65 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_66'] = x_compute_metrics__mutmut_66 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_67'] = x_compute_metrics__mutmut_67 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_68'] = x_compute_metrics__mutmut_68 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_69'] = x_compute_metrics__mutmut_69 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_70'] = x_compute_metrics__mutmut_70 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_71'] = x_compute_metrics__mutmut_71 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_72'] = x_compute_metrics__mutmut_72 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_73'] = x_compute_metrics__mutmut_73 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_74'] = x_compute_metrics__mutmut_74 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_75'] = x_compute_metrics__mutmut_75 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_76'] = x_compute_metrics__mutmut_76 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_77'] = x_compute_metrics__mutmut_77 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_78'] = x_compute_metrics__mutmut_78 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_79'] = x_compute_metrics__mutmut_79 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_80'] = x_compute_metrics__mutmut_80 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_81'] = x_compute_metrics__mutmut_81 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_82'] = x_compute_metrics__mutmut_82 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_83'] = x_compute_metrics__mutmut_83 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_84'] = x_compute_metrics__mutmut_84 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_85'] = x_compute_metrics__mutmut_85 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_86'] = x_compute_metrics__mutmut_86 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_87'] = x_compute_metrics__mutmut_87 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_88'] = x_compute_metrics__mutmut_88 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_89'] = x_compute_metrics__mutmut_89 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_90'] = x_compute_metrics__mutmut_90 # type: ignore # mutmut generated
mutants_x_compute_metrics__mutmut['x_compute_metrics__mutmut_91'] = x_compute_metrics__mutmut_91 # type: ignore # mutmut generated
