"""Common interface for all anomaly detectors.

Rule-based, classical ML and deep learning detectors share the same
``fit`` / ``predict`` contract, which mirrors PyOD's ``BaseDetector``
to ease later integration of ``pyod`` estimators.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Self

import numpy as np
import pandas as pd


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_numeric_features__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_numeric_features__mutmut)
def numeric_features(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_orig(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_1(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_2(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError(None)
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_3(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("XXat least one numeric feature is requiredXX")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_4(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("AT LEAST ONE NUMERIC FEATURE IS REQUIRED")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_5(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = None
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_6(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_7(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(None)
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_8(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = None
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_9(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(None):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_10(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_11(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(None) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_12(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError(None)
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_13(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("XXfeature columns must be numericXX")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_14(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("FEATURE COLUMNS MUST BE NUMERIC")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_15(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = None
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_16(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=None)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_17(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(None).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_18(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError(None)
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_19(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("XXnonfinite feature valueXX")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_20(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("NONFINITE FEATURE VALUE")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_21(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training or np.isnan(values).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_22(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=None).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_23(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(None).all(axis=0).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_24(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=1).any():
        raise ValueError("all-missing training feature")
    return selected


def x_numeric_features__mutmut_25(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError(None)
    return selected


def x_numeric_features__mutmut_26(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("XXall-missing training featureXX")
    return selected


def x_numeric_features__mutmut_27(df: pd.DataFrame, columns: list[str], *, training: bool) -> pd.DataFrame:
    """Reject unusable numeric inputs before a detector computes statistics."""
    if not columns:
        raise ValueError("at least one numeric feature is required")
    missing = [column for column in columns if column not in df]
    if missing:
        raise ValueError(f"missing feature columns: {missing}")
    selected = df[columns]
    if any(not pd.api.types.is_numeric_dtype(dtype) for dtype in selected.dtypes):
        raise ValueError("feature columns must be numeric")
    values = selected.to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("nonfinite feature value")
    if training and np.isnan(values).all(axis=0).any():
        raise ValueError("ALL-MISSING TRAINING FEATURE")
    return selected

mutants_x_numeric_features__mutmut['_mutmut_orig'] = x_numeric_features__mutmut_orig # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_1'] = x_numeric_features__mutmut_1 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_2'] = x_numeric_features__mutmut_2 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_3'] = x_numeric_features__mutmut_3 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_4'] = x_numeric_features__mutmut_4 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_5'] = x_numeric_features__mutmut_5 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_6'] = x_numeric_features__mutmut_6 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_7'] = x_numeric_features__mutmut_7 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_8'] = x_numeric_features__mutmut_8 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_9'] = x_numeric_features__mutmut_9 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_10'] = x_numeric_features__mutmut_10 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_11'] = x_numeric_features__mutmut_11 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_12'] = x_numeric_features__mutmut_12 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_13'] = x_numeric_features__mutmut_13 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_14'] = x_numeric_features__mutmut_14 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_15'] = x_numeric_features__mutmut_15 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_16'] = x_numeric_features__mutmut_16 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_17'] = x_numeric_features__mutmut_17 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_18'] = x_numeric_features__mutmut_18 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_19'] = x_numeric_features__mutmut_19 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_20'] = x_numeric_features__mutmut_20 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_21'] = x_numeric_features__mutmut_21 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_22'] = x_numeric_features__mutmut_22 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_23'] = x_numeric_features__mutmut_23 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_24'] = x_numeric_features__mutmut_24 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_25'] = x_numeric_features__mutmut_25 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_26'] = x_numeric_features__mutmut_26 # type: ignore # mutmut generated
mutants_x_numeric_features__mutmut['x_numeric_features__mutmut_27'] = x_numeric_features__mutmut_27 # type: ignore # mutmut generated
mutants_xǁDetectorǁscore__mutmut: MutantDict = {}  # type: ignore
mutants_xǁDetectorǁfit_predict__mutmut: MutantDict = {}  # type: ignore


class Detector(ABC):
    name: str

    @abstractmethod
    def fit(self, df: pd.DataFrame) -> Self:
        """Learn detector parameters from ``df``."""

    @abstractmethod
    def predict(self, df: pd.DataFrame) -> pd.Series:
        """Return a boolean Series: ``True`` where the row is anomalous."""

    @_mutmut_mutated(mutants_xǁDetectorǁscore__mutmut)
    def score(self, df: pd.DataFrame) -> pd.Series:
        """Continuous anomaly score, higher meaning more anomalous.

        Used for threshold-independent metrics (ROC-AUC, PR-AUC). The
        default derives a 0/1 score from :meth:`predict`; detectors that
        can expose a graded score should override this.
        """
        return self.predict(df).astype(float)

    def xǁDetectorǁscore__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        """Continuous anomaly score, higher meaning more anomalous.

        Used for threshold-independent metrics (ROC-AUC, PR-AUC). The
        default derives a 0/1 score from :meth:`predict`; detectors that
        can expose a graded score should override this.
        """
        return self.predict(df).astype(float)

    def xǁDetectorǁscore__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        """Continuous anomaly score, higher meaning more anomalous.

        Used for threshold-independent metrics (ROC-AUC, PR-AUC). The
        default derives a 0/1 score from :meth:`predict`; detectors that
        can expose a graded score should override this.
        """
        return self.predict(df).astype(None)

    def xǁDetectorǁscore__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        """Continuous anomaly score, higher meaning more anomalous.

        Used for threshold-independent metrics (ROC-AUC, PR-AUC). The
        default derives a 0/1 score from :meth:`predict`; detectors that
        can expose a graded score should override this.
        """
        return self.predict(None).astype(float)

    @_mutmut_mutated(mutants_xǁDetectorǁfit_predict__mutmut)
    def fit_predict(self, df: pd.DataFrame) -> pd.Series:
        return self.fit(df).predict(df)

    def xǁDetectorǁfit_predict__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        return self.fit(df).predict(df)

    def xǁDetectorǁfit_predict__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        return self.fit(df).predict(None)

    def xǁDetectorǁfit_predict__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        return self.fit(None).predict(df)

mutants_xǁDetectorǁscore__mutmut['_mutmut_orig'] = Detector.xǁDetectorǁscore__mutmut_orig # type: ignore # mutmut generated
mutants_xǁDetectorǁscore__mutmut['xǁDetectorǁscore__mutmut_1'] = Detector.xǁDetectorǁscore__mutmut_1 # type: ignore # mutmut generated
mutants_xǁDetectorǁscore__mutmut['xǁDetectorǁscore__mutmut_2'] = Detector.xǁDetectorǁscore__mutmut_2 # type: ignore # mutmut generated

mutants_xǁDetectorǁfit_predict__mutmut['_mutmut_orig'] = Detector.xǁDetectorǁfit_predict__mutmut_orig # type: ignore # mutmut generated
mutants_xǁDetectorǁfit_predict__mutmut['xǁDetectorǁfit_predict__mutmut_1'] = Detector.xǁDetectorǁfit_predict__mutmut_1 # type: ignore # mutmut generated
mutants_xǁDetectorǁfit_predict__mutmut['xǁDetectorǁfit_predict__mutmut_2'] = Detector.xǁDetectorǁfit_predict__mutmut_2 # type: ignore # mutmut generated
