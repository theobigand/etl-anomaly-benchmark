"""Shared logging configuration."""

from __future__ import annotations

import logging


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_setup_logging__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_setup_logging__mutmut)
def setup_logging(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )


def x_setup_logging__mutmut_orig(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )


def x_setup_logging__mutmut_1(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=None,
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )


def x_setup_logging__mutmut_2(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format=None,
        datefmt="%H:%M:%S",
    )


def x_setup_logging__mutmut_3(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
        datefmt=None,
    )


def x_setup_logging__mutmut_4(level: int = logging.INFO) -> None:
    logging.basicConfig(
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )


def x_setup_logging__mutmut_5(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        datefmt="%H:%M:%S",
    )


def x_setup_logging__mutmut_6(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
        )


def x_setup_logging__mutmut_7(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format="XX%(asctime)s [%(name)s] %(levelname)s %(message)sXX",
        datefmt="%H:%M:%S",
    )


def x_setup_logging__mutmut_8(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format="%(ASCTIME)S [%(NAME)S] %(LEVELNAME)S %(MESSAGE)S",
        datefmt="%H:%M:%S",
    )


def x_setup_logging__mutmut_9(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
        datefmt="XX%H:%M:%SXX",
    )


def x_setup_logging__mutmut_10(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
        datefmt="%h:%m:%s",
    )

mutants_x_setup_logging__mutmut['_mutmut_orig'] = x_setup_logging__mutmut_orig # type: ignore # mutmut generated
mutants_x_setup_logging__mutmut['x_setup_logging__mutmut_1'] = x_setup_logging__mutmut_1 # type: ignore # mutmut generated
mutants_x_setup_logging__mutmut['x_setup_logging__mutmut_2'] = x_setup_logging__mutmut_2 # type: ignore # mutmut generated
mutants_x_setup_logging__mutmut['x_setup_logging__mutmut_3'] = x_setup_logging__mutmut_3 # type: ignore # mutmut generated
mutants_x_setup_logging__mutmut['x_setup_logging__mutmut_4'] = x_setup_logging__mutmut_4 # type: ignore # mutmut generated
mutants_x_setup_logging__mutmut['x_setup_logging__mutmut_5'] = x_setup_logging__mutmut_5 # type: ignore # mutmut generated
mutants_x_setup_logging__mutmut['x_setup_logging__mutmut_6'] = x_setup_logging__mutmut_6 # type: ignore # mutmut generated
mutants_x_setup_logging__mutmut['x_setup_logging__mutmut_7'] = x_setup_logging__mutmut_7 # type: ignore # mutmut generated
mutants_x_setup_logging__mutmut['x_setup_logging__mutmut_8'] = x_setup_logging__mutmut_8 # type: ignore # mutmut generated
mutants_x_setup_logging__mutmut['x_setup_logging__mutmut_9'] = x_setup_logging__mutmut_9 # type: ignore # mutmut generated
mutants_x_setup_logging__mutmut['x_setup_logging__mutmut_10'] = x_setup_logging__mutmut_10 # type: ignore # mutmut generated
