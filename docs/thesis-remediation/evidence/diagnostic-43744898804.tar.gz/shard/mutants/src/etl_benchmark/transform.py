"""Transform stage: light cleaning before quality checks."""

from __future__ import annotations

import pandas as pd


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_clean__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_clean__mutmut)
def clean(df: pd.DataFrame) -> pd.DataFrame:
    return df.drop_duplicates().reset_index(drop=True)


def x_clean__mutmut_orig(df: pd.DataFrame) -> pd.DataFrame:
    return df.drop_duplicates().reset_index(drop=True)


def x_clean__mutmut_1(df: pd.DataFrame) -> pd.DataFrame:
    return df.drop_duplicates().reset_index(drop=None)


def x_clean__mutmut_2(df: pd.DataFrame) -> pd.DataFrame:
    return df.drop_duplicates().reset_index(drop=False)

mutants_x_clean__mutmut['_mutmut_orig'] = x_clean__mutmut_orig # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_1'] = x_clean__mutmut_1 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_2'] = x_clean__mutmut_2 # type: ignore # mutmut generated
