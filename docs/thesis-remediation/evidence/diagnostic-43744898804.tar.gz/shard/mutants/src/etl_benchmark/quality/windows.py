"""Causal sliding windows for sequence models.

A sequence detector scores one event from a window of the rows that precede
it. The window of event ``k`` holds rows ``k - size + 1 .. k`` in time order,
so it never contains a later row. Rows before the start of the partition are
filled by repeating the first row. Windows are built one partition at a time,
which keeps a test window from reaching into the training rows. Events with
equal timestamps keep their input order.
"""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd

from etl_benchmark.quality.window_drift import _numeric, _times


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_causal_windows__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_causal_windows__mutmut)
def causal_windows(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_orig(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_1(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) and size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_2(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) and not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_3(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_4(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size <= 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_5(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 2:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_6(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError(None)
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_7(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("XXwindow size must be a positive integerXX")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_8(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("WINDOW SIZE MUST BE A POSITIVE INTEGER")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_9(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = None
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_10(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(None, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_11(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, None)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_12(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_13(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, )
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_14(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = None
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_15(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=None)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_16(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(None, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_17(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, None).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_18(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_19(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, ).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_20(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = None
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_21(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(None, kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_22(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind=None)
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_23(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_24(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), )
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_25(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="XXstableXX")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_26(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="STABLE")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_27(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = None
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_28(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = None
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_29(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] - np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_30(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(None)[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_31(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(None, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_32(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, None)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_33(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_34(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, )[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_35(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 + size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_36(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(2 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_37(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 2)[None, :]
    return ordered[np.clip(positions, 0, None)], order


def x_causal_windows__mutmut_38(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(None, 0, None)], order


def x_causal_windows__mutmut_39(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, None, None)], order


def x_causal_windows__mutmut_40(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(0, None)], order


def x_causal_windows__mutmut_41(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, None)], order


def x_causal_windows__mutmut_42(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 0, )], order


def x_causal_windows__mutmut_43(
    frame: pd.DataFrame, time_column: str, columns: Sequence[str], size: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(windows, order)``.

    ``windows`` has shape ``(n_events, size, n_features)`` in time order and
    ``order[k]`` is the position, in ``frame``, of the event closing window
    ``k``.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 1:
        raise ValueError("window size must be a positive integer")
    times = _times(frame, time_column)
    values = _numeric(frame, columns).to_numpy(dtype=float)
    order = np.argsort(times.to_numpy(), kind="stable")
    ordered = values[order]
    positions = np.arange(len(ordered))[:, None] + np.arange(1 - size, 1)[None, :]
    return ordered[np.clip(positions, 1, None)], order

mutants_x_causal_windows__mutmut['_mutmut_orig'] = x_causal_windows__mutmut_orig # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_1'] = x_causal_windows__mutmut_1 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_2'] = x_causal_windows__mutmut_2 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_3'] = x_causal_windows__mutmut_3 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_4'] = x_causal_windows__mutmut_4 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_5'] = x_causal_windows__mutmut_5 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_6'] = x_causal_windows__mutmut_6 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_7'] = x_causal_windows__mutmut_7 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_8'] = x_causal_windows__mutmut_8 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_9'] = x_causal_windows__mutmut_9 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_10'] = x_causal_windows__mutmut_10 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_11'] = x_causal_windows__mutmut_11 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_12'] = x_causal_windows__mutmut_12 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_13'] = x_causal_windows__mutmut_13 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_14'] = x_causal_windows__mutmut_14 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_15'] = x_causal_windows__mutmut_15 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_16'] = x_causal_windows__mutmut_16 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_17'] = x_causal_windows__mutmut_17 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_18'] = x_causal_windows__mutmut_18 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_19'] = x_causal_windows__mutmut_19 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_20'] = x_causal_windows__mutmut_20 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_21'] = x_causal_windows__mutmut_21 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_22'] = x_causal_windows__mutmut_22 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_23'] = x_causal_windows__mutmut_23 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_24'] = x_causal_windows__mutmut_24 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_25'] = x_causal_windows__mutmut_25 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_26'] = x_causal_windows__mutmut_26 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_27'] = x_causal_windows__mutmut_27 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_28'] = x_causal_windows__mutmut_28 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_29'] = x_causal_windows__mutmut_29 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_30'] = x_causal_windows__mutmut_30 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_31'] = x_causal_windows__mutmut_31 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_32'] = x_causal_windows__mutmut_32 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_33'] = x_causal_windows__mutmut_33 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_34'] = x_causal_windows__mutmut_34 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_35'] = x_causal_windows__mutmut_35 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_36'] = x_causal_windows__mutmut_36 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_37'] = x_causal_windows__mutmut_37 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_38'] = x_causal_windows__mutmut_38 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_39'] = x_causal_windows__mutmut_39 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_40'] = x_causal_windows__mutmut_40 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_41'] = x_causal_windows__mutmut_41 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_42'] = x_causal_windows__mutmut_42 # type: ignore # mutmut generated
mutants_x_causal_windows__mutmut['x_causal_windows__mutmut_43'] = x_causal_windows__mutmut_43 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_scores_to_events__mutmut)
def scores_to_events(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(len(scores), dtype=float)
    aligned[order] = scores
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_orig(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(len(scores), dtype=float)
    aligned[order] = scores
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_1(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) == len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(len(scores), dtype=float)
    aligned[order] = scores
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_2(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError(None)
    aligned = np.empty(len(scores), dtype=float)
    aligned[order] = scores
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_3(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("XXscores and positions must have the same lengthXX")
    aligned = np.empty(len(scores), dtype=float)
    aligned[order] = scores
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_4(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("SCORES AND POSITIONS MUST HAVE THE SAME LENGTH")
    aligned = np.empty(len(scores), dtype=float)
    aligned[order] = scores
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_5(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = None
    aligned[order] = scores
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_6(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(None, dtype=float)
    aligned[order] = scores
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_7(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(len(scores), dtype=None)
    aligned[order] = scores
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_8(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(dtype=float)
    aligned[order] = scores
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_9(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(len(scores), )
    aligned[order] = scores
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_10(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(len(scores), dtype=float)
    aligned[order] = None
    return pd.Series(aligned, index=index)


def x_scores_to_events__mutmut_11(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(len(scores), dtype=float)
    aligned[order] = scores
    return pd.Series(None, index=index)


def x_scores_to_events__mutmut_12(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(len(scores), dtype=float)
    aligned[order] = scores
    return pd.Series(aligned, index=None)


def x_scores_to_events__mutmut_13(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(len(scores), dtype=float)
    aligned[order] = scores
    return pd.Series(index=index)


def x_scores_to_events__mutmut_14(scores: np.ndarray, order: np.ndarray, index: pd.Index) -> pd.Series:
    """Give each window score back to the event that closes it."""
    if len(scores) != len(order):
        raise ValueError("scores and positions must have the same length")
    aligned = np.empty(len(scores), dtype=float)
    aligned[order] = scores
    return pd.Series(aligned, )

mutants_x_scores_to_events__mutmut['_mutmut_orig'] = x_scores_to_events__mutmut_orig # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_1'] = x_scores_to_events__mutmut_1 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_2'] = x_scores_to_events__mutmut_2 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_3'] = x_scores_to_events__mutmut_3 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_4'] = x_scores_to_events__mutmut_4 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_5'] = x_scores_to_events__mutmut_5 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_6'] = x_scores_to_events__mutmut_6 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_7'] = x_scores_to_events__mutmut_7 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_8'] = x_scores_to_events__mutmut_8 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_9'] = x_scores_to_events__mutmut_9 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_10'] = x_scores_to_events__mutmut_10 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_11'] = x_scores_to_events__mutmut_11 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_12'] = x_scores_to_events__mutmut_12 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_13'] = x_scores_to_events__mutmut_13 # type: ignore # mutmut generated
mutants_x_scores_to_events__mutmut['x_scores_to_events__mutmut_14'] = x_scores_to_events__mutmut_14 # type: ignore # mutmut generated
