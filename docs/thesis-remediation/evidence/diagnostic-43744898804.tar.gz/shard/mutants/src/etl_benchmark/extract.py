"""Extract stage: load raw data into a DataFrame."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_read_csv__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_read_csv__mutmut)
def read_csv(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}. See data/README.md for download instructions."
        )
    return pd.read_csv(path)


def x_read_csv__mutmut_orig(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}. See data/README.md for download instructions."
        )
    return pd.read_csv(path)


def x_read_csv__mutmut_1(path: str | Path) -> pd.DataFrame:
    path = None
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}. See data/README.md for download instructions."
        )
    return pd.read_csv(path)


def x_read_csv__mutmut_2(path: str | Path) -> pd.DataFrame:
    path = Path(None)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}. See data/README.md for download instructions."
        )
    return pd.read_csv(path)


def x_read_csv__mutmut_3(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}. See data/README.md for download instructions."
        )
    return pd.read_csv(path)


def x_read_csv__mutmut_4(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            None
        )
    return pd.read_csv(path)


def x_read_csv__mutmut_5(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}. See data/README.md for download instructions."
        )
    return pd.read_csv(None)

mutants_x_read_csv__mutmut['_mutmut_orig'] = x_read_csv__mutmut_orig # type: ignore # mutmut generated
mutants_x_read_csv__mutmut['x_read_csv__mutmut_1'] = x_read_csv__mutmut_1 # type: ignore # mutmut generated
mutants_x_read_csv__mutmut['x_read_csv__mutmut_2'] = x_read_csv__mutmut_2 # type: ignore # mutmut generated
mutants_x_read_csv__mutmut['x_read_csv__mutmut_3'] = x_read_csv__mutmut_3 # type: ignore # mutmut generated
mutants_x_read_csv__mutmut['x_read_csv__mutmut_4'] = x_read_csv__mutmut_4 # type: ignore # mutmut generated
mutants_x_read_csv__mutmut['x_read_csv__mutmut_5'] = x_read_csv__mutmut_5 # type: ignore # mutmut generated
