"""Deep anomaly detectors wrapped from PyOD (PyTorch, CPU).

These models learn a representation of the standardized features and score a
row by how badly it fits it:

    - :class:`VAEDetector` — variational autoencoder, reconstruction error;
    - :class:`DeepSVDDDetector` — network trained to map normal rows into a
      small hypersphere, distance to its centre;
    - :class:`DIFDetector` — isolation forest on random neural
      representations;
    - :class:`AE1SVMDetector` — autoencoder with a one-class SVM objective on
      the code;
    - :class:`LUNARDetector` — network on the distances to the nearest
      neighbours.

They reuse the preparation and the fit / predict / score contract of
:class:`PyODDetector`, keep the PyOD defaults, and only fix what the
protocol needs: no second standardization, no progress output, CPU, and a
seed. They are opt-in, like the MLP autoencoder: PyTorch is an optional
dependency, imported when a model is fitted.
"""

from __future__ import annotations

import contextlib
import io
from importlib.metadata import version
from typing import ClassVar, Self

import numpy as np
import pandas as pd

from etl_benchmark import config
from etl_benchmark.quality.ml import PyODDetector


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x__default_device__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__default_device__mutmut)
def _default_device() -> str:
    """The device PyOD picks when none is passed: CUDA if present, else the CPU."""
    import torch

    return "cuda" if torch.cuda.is_available() else "cpu"


def x__default_device__mutmut_orig() -> str:
    """The device PyOD picks when none is passed: CUDA if present, else the CPU."""
    import torch

    return "cuda" if torch.cuda.is_available() else "cpu"


def x__default_device__mutmut_1() -> str:
    """The device PyOD picks when none is passed: CUDA if present, else the CPU."""
    import torch

    return "cuda" if (torch.cuda.is_available()) and False else "cpu"


def x__default_device__mutmut_2() -> str:
    """The device PyOD picks when none is passed: CUDA if present, else the CPU."""
    import torch

    return "cuda" if (torch.cuda.is_available()) or True else "cpu"


def x__default_device__mutmut_3() -> str:
    """The device PyOD picks when none is passed: CUDA if present, else the CPU."""
    import torch

    return "XXcudaXX" if torch.cuda.is_available() else "cpu"


def x__default_device__mutmut_4() -> str:
    """The device PyOD picks when none is passed: CUDA if present, else the CPU."""
    import torch

    return "CUDA" if torch.cuda.is_available() else "cpu"


def x__default_device__mutmut_5() -> str:
    """The device PyOD picks when none is passed: CUDA if present, else the CPU."""
    import torch

    return "cuda" if torch.cuda.is_available() else "XXcpuXX"


def x__default_device__mutmut_6() -> str:
    """The device PyOD picks when none is passed: CUDA if present, else the CPU."""
    import torch

    return "cuda" if torch.cuda.is_available() else "CPU"

mutants_x__default_device__mutmut['_mutmut_orig'] = x__default_device__mutmut_orig # type: ignore # mutmut generated
mutants_x__default_device__mutmut['x__default_device__mutmut_1'] = x__default_device__mutmut_1 # type: ignore # mutmut generated
mutants_x__default_device__mutmut['x__default_device__mutmut_2'] = x__default_device__mutmut_2 # type: ignore # mutmut generated
mutants_x__default_device__mutmut['x__default_device__mutmut_3'] = x__default_device__mutmut_3 # type: ignore # mutmut generated
mutants_x__default_device__mutmut['x__default_device__mutmut_4'] = x__default_device__mutmut_4 # type: ignore # mutmut generated
mutants_x__default_device__mutmut['x__default_device__mutmut_5'] = x__default_device__mutmut_5 # type: ignore # mutmut generated
mutants_x__default_device__mutmut['x__default_device__mutmut_6'] = x__default_device__mutmut_6 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁTorchDetectorǁ_build_estimator__mutmut: MutantDict = {}  # type: ignore
mutants_xǁTorchDetectorǁfit__mutmut: MutantDict = {}  # type: ignore
mutants_xǁTorchDetectorǁsettings__mutmut: MutantDict = {}  # type: ignore


class TorchDetector(PyODDetector):
    """A PyOD estimator that needs PyTorch and a seed."""

    #: Arguments fixed by the protocol, on top of the PyOD defaults.
    fixed_kwargs: ClassVar[dict[str, object]] = {}
    #: Name of the estimator argument that takes the seed, when it has one.
    seed_argument: ClassVar[str | None] = "random_state"

    @_mutmut_mutated(mutants_xǁTorchDetectorǁ__init____mutmut)
    def __init__(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        random_state: int = config.RANDOM_SEED,
        **estimator_kwargs: object,
    ) -> None:
        super().__init__(contamination=contamination, columns=columns, **estimator_kwargs)
        self.random_state = random_state

    def xǁTorchDetectorǁ__init____mutmut_orig(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        random_state: int = config.RANDOM_SEED,
        **estimator_kwargs: object,
    ) -> None:
        super().__init__(contamination=contamination, columns=columns, **estimator_kwargs)
        self.random_state = random_state

    def xǁTorchDetectorǁ__init____mutmut_1(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        random_state: int = config.RANDOM_SEED,
        **estimator_kwargs: object,
    ) -> None:
        super().__init__(contamination=None, columns=columns, **estimator_kwargs)
        self.random_state = random_state

    def xǁTorchDetectorǁ__init____mutmut_2(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        random_state: int = config.RANDOM_SEED,
        **estimator_kwargs: object,
    ) -> None:
        super().__init__(contamination=contamination, columns=None, **estimator_kwargs)
        self.random_state = random_state

    def xǁTorchDetectorǁ__init____mutmut_3(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        random_state: int = config.RANDOM_SEED,
        **estimator_kwargs: object,
    ) -> None:
        super().__init__(columns=columns, **estimator_kwargs)
        self.random_state = random_state

    def xǁTorchDetectorǁ__init____mutmut_4(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        random_state: int = config.RANDOM_SEED,
        **estimator_kwargs: object,
    ) -> None:
        super().__init__(contamination=contamination, **estimator_kwargs)
        self.random_state = random_state

    def xǁTorchDetectorǁ__init____mutmut_5(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        random_state: int = config.RANDOM_SEED,
        **estimator_kwargs: object,
    ) -> None:
        super().__init__(contamination=contamination, columns=columns, )
        self.random_state = random_state

    def xǁTorchDetectorǁ__init____mutmut_6(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        random_state: int = config.RANDOM_SEED,
        **estimator_kwargs: object,
    ) -> None:
        super().__init__(contamination=contamination, columns=columns, **estimator_kwargs)
        self.random_state = None

    def _extra_kwargs(self) -> dict[str, object]:
        """Arguments that depend on the fitted columns."""
        return {}

    @_mutmut_mutated(mutants_xǁTorchDetectorǁ_build_estimator__mutmut)
    def _build_estimator(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_orig(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_1(self):
        module_name, class_name = None
        cls = getattr(__import__(module_name, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_2(self):
        module_name, class_name = self.estimator_path
        cls = None
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_3(self):
        module_name, class_name = self.estimator_path
        cls = getattr(None, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_4(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), None)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_5(self):
        module_name, class_name = self.estimator_path
        cls = getattr(class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_6(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), )
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_7(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(None, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_8(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=None), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_9(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_10(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, ), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_11(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = None
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_12(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "XXcontaminationXX": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_13(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "CONTAMINATION": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_14(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is None:
            kwargs.setdefault(self.seed_argument, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_15(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(None, self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_16(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, None)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_17(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.random_state)
        return cls(**kwargs)

    def xǁTorchDetectorǁ_build_estimator__mutmut_18(self):
        module_name, class_name = self.estimator_path
        cls = getattr(__import__(module_name, fromlist=[class_name]), class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self.fixed_kwargs,
            **self._extra_kwargs(),
            **self._estimator_kwargs,
        }
        if self.seed_argument is not None:
            kwargs.setdefault(self.seed_argument, )
        return cls(**kwargs)

    @_mutmut_mutated(mutants_xǁTorchDetectorǁfit__mutmut)
    def fit(self, df: pd.DataFrame) -> Self:
        try:
            import torch
        except ImportError as exc:
            raise RuntimeError(
                f"{self.name} detector needs torch; install it (see environment.yml)"
            ) from exc
        torch.manual_seed(self.random_state)
        # AE1SVM prints its loss every ten epochs and has no verbosity argument.
        with contextlib.redirect_stdout(io.StringIO()):
            return super().fit(df)

    def xǁTorchDetectorǁfit__mutmut_orig(self, df: pd.DataFrame) -> Self:
        try:
            import torch
        except ImportError as exc:
            raise RuntimeError(
                f"{self.name} detector needs torch; install it (see environment.yml)"
            ) from exc
        torch.manual_seed(self.random_state)
        # AE1SVM prints its loss every ten epochs and has no verbosity argument.
        with contextlib.redirect_stdout(io.StringIO()):
            return super().fit(df)

    def xǁTorchDetectorǁfit__mutmut_1(self, df: pd.DataFrame) -> Self:
        try:
            import torch
        except ImportError as exc:
            raise RuntimeError(
                None
            ) from exc
        torch.manual_seed(self.random_state)
        # AE1SVM prints its loss every ten epochs and has no verbosity argument.
        with contextlib.redirect_stdout(io.StringIO()):
            return super().fit(df)

    def xǁTorchDetectorǁfit__mutmut_2(self, df: pd.DataFrame) -> Self:
        try:
            import torch
        except ImportError as exc:
            raise RuntimeError(
                f"{self.name} detector needs torch; install it (see environment.yml)"
            ) from exc
        torch.manual_seed(None)
        # AE1SVM prints its loss every ten epochs and has no verbosity argument.
        with contextlib.redirect_stdout(io.StringIO()):
            return super().fit(df)

    def xǁTorchDetectorǁfit__mutmut_3(self, df: pd.DataFrame) -> Self:
        try:
            import torch
        except ImportError as exc:
            raise RuntimeError(
                f"{self.name} detector needs torch; install it (see environment.yml)"
            ) from exc
        torch.manual_seed(self.random_state)
        # AE1SVM prints its loss every ten epochs and has no verbosity argument.
        with contextlib.redirect_stdout(None):
            return super().fit(df)

    def xǁTorchDetectorǁfit__mutmut_4(self, df: pd.DataFrame) -> Self:
        try:
            import torch
        except ImportError as exc:
            raise RuntimeError(
                f"{self.name} detector needs torch; install it (see environment.yml)"
            ) from exc
        torch.manual_seed(self.random_state)
        # AE1SVM prints its loss every ten epochs and has no verbosity argument.
        with contextlib.redirect_stdout(io.StringIO()):
            return super().fit(None)

    @_mutmut_mutated(mutants_xǁTorchDetectorǁsettings__mutmut)
    def settings(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_orig(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_1(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "XXcontaminationXX": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_2(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "CONTAMINATION": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_3(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "XXrandom_stateXX": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_4(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "RANDOM_STATE": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_5(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "XXdeviceXX": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_6(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "DEVICE": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_7(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") and _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_8(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get(None) or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_9(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("XXdeviceXX") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_10(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("DEVICE") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_11(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "XXargumentsXX": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_12(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "ARGUMENTS": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_13(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "XXversionsXX": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_14(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "VERSIONS": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_15(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "XXtorchXX": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_16(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "TORCH": version("torch"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_17(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version(None),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_18(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("XXtorchXX"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_19(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("TORCH"),
                "pyod": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_20(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "XXpyodXX": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_21(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "PYOD": version("pyod"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_22(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version(None),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_23(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("XXpyodXX"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_24(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("PYOD"),
                "numpy": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_25(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "XXnumpyXX": np.__version__,
            },
        }

    def xǁTorchDetectorǁsettings__mutmut_26(self) -> dict[str, object]:
        """Hyper-parameters, seed and versions to store with a run."""
        return {
            "contamination": self.contamination,
            "random_state": self.random_state,
            "device": self.fixed_kwargs.get("device") or _default_device(),
            "arguments": {**self.fixed_kwargs, **self._estimator_kwargs},
            "versions": {
                "torch": version("torch"),
                "pyod": version("pyod"),
                "NUMPY": np.__version__,
            },
        }

mutants_xǁTorchDetectorǁ__init____mutmut['_mutmut_orig'] = TorchDetector.xǁTorchDetectorǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ__init____mutmut['xǁTorchDetectorǁ__init____mutmut_1'] = TorchDetector.xǁTorchDetectorǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ__init____mutmut['xǁTorchDetectorǁ__init____mutmut_2'] = TorchDetector.xǁTorchDetectorǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ__init____mutmut['xǁTorchDetectorǁ__init____mutmut_3'] = TorchDetector.xǁTorchDetectorǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ__init____mutmut['xǁTorchDetectorǁ__init____mutmut_4'] = TorchDetector.xǁTorchDetectorǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ__init____mutmut['xǁTorchDetectorǁ__init____mutmut_5'] = TorchDetector.xǁTorchDetectorǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ__init____mutmut['xǁTorchDetectorǁ__init____mutmut_6'] = TorchDetector.xǁTorchDetectorǁ__init____mutmut_6 # type: ignore # mutmut generated

mutants_xǁTorchDetectorǁ_build_estimator__mutmut['_mutmut_orig'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_1'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_2'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_2 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_3'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_3 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_4'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_4 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_5'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_5 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_6'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_6 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_7'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_7 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_8'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_8 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_9'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_9 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_10'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_10 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_11'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_11 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_12'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_12 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_13'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_13 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_14'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_14 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_15'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_15 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_16'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_16 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_17'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_17 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁ_build_estimator__mutmut['xǁTorchDetectorǁ_build_estimator__mutmut_18'] = TorchDetector.xǁTorchDetectorǁ_build_estimator__mutmut_18 # type: ignore # mutmut generated

mutants_xǁTorchDetectorǁfit__mutmut['_mutmut_orig'] = TorchDetector.xǁTorchDetectorǁfit__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁfit__mutmut['xǁTorchDetectorǁfit__mutmut_1'] = TorchDetector.xǁTorchDetectorǁfit__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁfit__mutmut['xǁTorchDetectorǁfit__mutmut_2'] = TorchDetector.xǁTorchDetectorǁfit__mutmut_2 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁfit__mutmut['xǁTorchDetectorǁfit__mutmut_3'] = TorchDetector.xǁTorchDetectorǁfit__mutmut_3 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁfit__mutmut['xǁTorchDetectorǁfit__mutmut_4'] = TorchDetector.xǁTorchDetectorǁfit__mutmut_4 # type: ignore # mutmut generated

mutants_xǁTorchDetectorǁsettings__mutmut['_mutmut_orig'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_1'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_2'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_2 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_3'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_3 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_4'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_4 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_5'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_5 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_6'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_6 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_7'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_7 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_8'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_8 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_9'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_9 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_10'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_10 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_11'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_11 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_12'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_12 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_13'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_13 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_14'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_14 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_15'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_15 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_16'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_16 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_17'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_17 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_18'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_18 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_19'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_19 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_20'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_20 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_21'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_21 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_22'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_22 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_23'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_23 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_24'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_24 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_25'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_25 # type: ignore # mutmut generated
mutants_xǁTorchDetectorǁsettings__mutmut['xǁTorchDetectorǁsettings__mutmut_26'] = TorchDetector.xǁTorchDetectorǁsettings__mutmut_26 # type: ignore # mutmut generated


class VAEDetector(TorchDetector):
    name = "vae"
    estimator_path = ("etl_benchmark.quality._torch_models", "MeanVAE")
    fixed_kwargs: ClassVar[dict[str, object]] = {
        "preprocessing": False,
        "verbose": 0,
        "device": "cpu",
    }
mutants_xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut: MutantDict = {}  # type: ignore


class DeepSVDDDetector(TorchDetector):
    name = "deep_svdd"
    estimator_path = ("pyod.models.deep_svdd", "DeepSVDD")
    fixed_kwargs: ClassVar[dict[str, object]] = {"preprocessing": False, "verbose": 0}

    @_mutmut_mutated(mutants_xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut)
    def _extra_kwargs(self) -> dict[str, object]:
        return {"n_features": len(self.feature_names_ or [])}

    def xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut_orig(self) -> dict[str, object]:
        return {"n_features": len(self.feature_names_ or [])}

    def xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut_1(self) -> dict[str, object]:
        return {"XXn_featuresXX": len(self.feature_names_ or [])}

    def xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut_2(self) -> dict[str, object]:
        return {"N_FEATURES": len(self.feature_names_ or [])}

mutants_xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut['_mutmut_orig'] = DeepSVDDDetector.xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut_orig # type: ignore # mutmut generated
mutants_xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut['xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut_1'] = DeepSVDDDetector.xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut_1 # type: ignore # mutmut generated
mutants_xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut['xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut_2'] = DeepSVDDDetector.xǁDeepSVDDDetectorǁ_extra_kwargs__mutmut_2 # type: ignore # mutmut generated


class DIFDetector(TorchDetector):
    name = "dif"
    estimator_path = ("etl_benchmark.quality._torch_models", "FitScalerDIF")
    fixed_kwargs: ClassVar[dict[str, object]] = {"device": "cpu"}


class AE1SVMDetector(TorchDetector):
    name = "ae1svm"
    estimator_path = ("etl_benchmark.quality._torch_models", "PaddedAE1SVM")
    fixed_kwargs: ClassVar[dict[str, object]] = {"preprocessing": False}
    seed_argument = None


class LUNARDetector(TorchDetector):
    name = "lunar"
    estimator_path = ("pyod.models.lunar", "LUNAR")
    fixed_kwargs: ClassVar[dict[str, object]] = {"verbose": 0}
