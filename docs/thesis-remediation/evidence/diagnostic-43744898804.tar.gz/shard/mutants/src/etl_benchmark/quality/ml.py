"""Classical machine-learning anomaly detectors, wrapped from PyOD.

Where the rule-based detectors in :mod:`etl_benchmark.quality.rules` and
:mod:`etl_benchmark.quality.gx` define a per-column band of normal values,
these detectors learn a joint model of the feature space and score a row
by how poorly it fits that model. Three unsupervised estimators are
exposed, all wrapped from PyOD so the reference implementation is reused
rather than reimplemented:

    - :class:`IsolationForestDetector` — random-partition isolation depth;
    - :class:`LOFDetector` — local outlier factor (density relative to
      neighbours);
    - :class:`OneClassSVMDetector` — an SVM boundary around the bulk of
      the data;
    - :class:`ECODDetector` and :class:`COPODDetector` — empirical tail
      probabilities of each column, combined across columns (computed on the
      fit rows only, see :class:`TailProbabilityModel`);
    - :class:`HBOSDetector` — histogram of each column, scored by inverse
      density;
    - :class:`KNNDetector` — distance to the k-th nearest neighbour;
    - :class:`PCADetector` — reconstruction error after a linear projection
      that keeps 95% of the variance.

ECOD, COPOD and HBOS model each column separately, so they see no
dependency between columns; KNN and PCA look at the joint distribution. All
of them share the same preparation: non-numeric columns are dropped,
missing values are median-imputed, and every feature is standardized
(LOF and One-Class SVM are distance-based and scale-sensitive). The
PyOD ``decision_function`` is used as the continuous anomaly score and
``predict`` as the boolean flag; the flag threshold is set by
``contamination``, the expected share of anomalies.

Tested against pyod 3.x.
"""

from __future__ import annotations

from typing import ClassVar, Self

import numpy as np
import pandas as pd
from scipy.stats import skew
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

from etl_benchmark import config
from etl_benchmark.quality.base import Detector, numeric_features


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_xǁPyODDetectorǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁPyODDetectorǁ_build_estimator__mutmut: MutantDict = {}  # type: ignore
mutants_xǁPyODDetectorǁ_numeric_columns__mutmut: MutantDict = {}  # type: ignore
mutants_xǁPyODDetectorǁ_matrix__mutmut: MutantDict = {}  # type: ignore
mutants_xǁPyODDetectorǁ_fitted_model__mutmut: MutantDict = {}  # type: ignore
mutants_xǁPyODDetectorǁfit__mutmut: MutantDict = {}  # type: ignore
mutants_xǁPyODDetectorǁpredict__mutmut: MutantDict = {}  # type: ignore
mutants_xǁPyODDetectorǁscore__mutmut: MutantDict = {}  # type: ignore


class PyODDetector(Detector):
    """Adapt a PyOD ``BaseDetector`` to the project detector interface."""

    #: Import path of the wrapped PyOD estimator, ``("module", "class")``.
    estimator_path: ClassVar[tuple[str, str]]
    #: Whether the wrapped estimator accepts a ``random_state`` argument.
    supports_random_state: ClassVar[bool] = False

    @_mutmut_mutated(mutants_xǁPyODDetectorǁ__init____mutmut)
    def __init__(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        **estimator_kwargs: object,
    ) -> None:
        self.contamination = contamination
        self._user_columns = columns
        self._estimator_kwargs = estimator_kwargs
        self.feature_names_: list[str] | None = None
        self._imputer: SimpleImputer | None = None
        self._scaler: StandardScaler | None = None
        self._model: object | None = None

    def xǁPyODDetectorǁ__init____mutmut_orig(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        **estimator_kwargs: object,
    ) -> None:
        self.contamination = contamination
        self._user_columns = columns
        self._estimator_kwargs = estimator_kwargs
        self.feature_names_: list[str] | None = None
        self._imputer: SimpleImputer | None = None
        self._scaler: StandardScaler | None = None
        self._model: object | None = None

    def xǁPyODDetectorǁ__init____mutmut_1(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        **estimator_kwargs: object,
    ) -> None:
        self.contamination = None
        self._user_columns = columns
        self._estimator_kwargs = estimator_kwargs
        self.feature_names_: list[str] | None = None
        self._imputer: SimpleImputer | None = None
        self._scaler: StandardScaler | None = None
        self._model: object | None = None

    def xǁPyODDetectorǁ__init____mutmut_2(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        **estimator_kwargs: object,
    ) -> None:
        self.contamination = contamination
        self._user_columns = None
        self._estimator_kwargs = estimator_kwargs
        self.feature_names_: list[str] | None = None
        self._imputer: SimpleImputer | None = None
        self._scaler: StandardScaler | None = None
        self._model: object | None = None

    def xǁPyODDetectorǁ__init____mutmut_3(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        **estimator_kwargs: object,
    ) -> None:
        self.contamination = contamination
        self._user_columns = columns
        self._estimator_kwargs = None
        self.feature_names_: list[str] | None = None
        self._imputer: SimpleImputer | None = None
        self._scaler: StandardScaler | None = None
        self._model: object | None = None

    def xǁPyODDetectorǁ__init____mutmut_4(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        **estimator_kwargs: object,
    ) -> None:
        self.contamination = contamination
        self._user_columns = columns
        self._estimator_kwargs = estimator_kwargs
        self.feature_names_: list[str] | None = ""
        self._imputer: SimpleImputer | None = None
        self._scaler: StandardScaler | None = None
        self._model: object | None = None

    def xǁPyODDetectorǁ__init____mutmut_5(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        **estimator_kwargs: object,
    ) -> None:
        self.contamination = contamination
        self._user_columns = columns
        self._estimator_kwargs = estimator_kwargs
        self.feature_names_: list[str] | None = None
        self._imputer: SimpleImputer | None = ""
        self._scaler: StandardScaler | None = None
        self._model: object | None = None

    def xǁPyODDetectorǁ__init____mutmut_6(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        **estimator_kwargs: object,
    ) -> None:
        self.contamination = contamination
        self._user_columns = columns
        self._estimator_kwargs = estimator_kwargs
        self.feature_names_: list[str] | None = None
        self._imputer: SimpleImputer | None = None
        self._scaler: StandardScaler | None = ""
        self._model: object | None = None

    def xǁPyODDetectorǁ__init____mutmut_7(
        self,
        contamination: float = config.ML_CONTAMINATION,
        columns: list[str] | None = None,
        **estimator_kwargs: object,
    ) -> None:
        self.contamination = contamination
        self._user_columns = columns
        self._estimator_kwargs = estimator_kwargs
        self.feature_names_: list[str] | None = None
        self._imputer: SimpleImputer | None = None
        self._scaler: StandardScaler | None = None
        self._model: object | None = ""

    @_mutmut_mutated(mutants_xǁPyODDetectorǁ_build_estimator__mutmut)
    def _build_estimator(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_orig(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_1(self):
        module_name, class_name = None
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_2(self):
        module_name, class_name = self.estimator_path
        module = None
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_3(self):
        module_name, class_name = self.estimator_path
        module = __import__(None, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_4(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=None)
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_5(self):
        module_name, class_name = self.estimator_path
        module = __import__(fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_6(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, )
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_7(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = None
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_8(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(None, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_9(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, None)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_10(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_11(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, )
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_12(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = None
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_13(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "XXcontaminationXX": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_14(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "CONTAMINATION": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_15(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault(None, config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_16(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", None)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_17(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault(config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_18(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("random_state", )
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_19(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("XXrandom_stateXX", config.RANDOM_SEED)
        return cls(**kwargs)

    def xǁPyODDetectorǁ_build_estimator__mutmut_20(self):
        module_name, class_name = self.estimator_path
        module = __import__(module_name, fromlist=[class_name])
        cls = getattr(module, class_name)
        kwargs: dict[str, object] = {
            "contamination": self.contamination,
            **self._estimator_kwargs,
        }
        if self.supports_random_state:
            kwargs.setdefault("RANDOM_STATE", config.RANDOM_SEED)
        return cls(**kwargs)

    @_mutmut_mutated(mutants_xǁPyODDetectorǁ_numeric_columns__mutmut)
    def _numeric_columns(self, df: pd.DataFrame) -> list[str]:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        if not cols:
            raise ValueError(
                f"{self.name} detector needs at least one numeric column; got {list(df.columns)}"
            )
        return cols

    def xǁPyODDetectorǁ_numeric_columns__mutmut_orig(self, df: pd.DataFrame) -> list[str]:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        if not cols:
            raise ValueError(
                f"{self.name} detector needs at least one numeric column; got {list(df.columns)}"
            )
        return cols

    def xǁPyODDetectorǁ_numeric_columns__mutmut_1(self, df: pd.DataFrame) -> list[str]:
        cols = None
        if not cols:
            raise ValueError(
                f"{self.name} detector needs at least one numeric column; got {list(df.columns)}"
            )
        return cols

    def xǁPyODDetectorǁ_numeric_columns__mutmut_2(self, df: pd.DataFrame) -> list[str]:
        cols = self._user_columns and df.select_dtypes(include=np.number).columns.tolist()
        if not cols:
            raise ValueError(
                f"{self.name} detector needs at least one numeric column; got {list(df.columns)}"
            )
        return cols

    def xǁPyODDetectorǁ_numeric_columns__mutmut_3(self, df: pd.DataFrame) -> list[str]:
        cols = self._user_columns or df.select_dtypes(include=None).columns.tolist()
        if not cols:
            raise ValueError(
                f"{self.name} detector needs at least one numeric column; got {list(df.columns)}"
            )
        return cols

    def xǁPyODDetectorǁ_numeric_columns__mutmut_4(self, df: pd.DataFrame) -> list[str]:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        if cols:
            raise ValueError(
                f"{self.name} detector needs at least one numeric column; got {list(df.columns)}"
            )
        return cols

    def xǁPyODDetectorǁ_numeric_columns__mutmut_5(self, df: pd.DataFrame) -> list[str]:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        if not cols:
            raise ValueError(
                None
            )
        return cols

    def xǁPyODDetectorǁ_numeric_columns__mutmut_6(self, df: pd.DataFrame) -> list[str]:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        if not cols:
            raise ValueError(
                f"{self.name} detector needs at least one numeric column; got {list(None)}"
            )
        return cols

    @_mutmut_mutated(mutants_xǁPyODDetectorǁ_matrix__mutmut)
    def _matrix(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_orig(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_1(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None and self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_2(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None and self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_3(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is not None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_4(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is not None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_5(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is not None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_6(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(None)
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_7(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = None
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_8(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=None)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_9(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(None, self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_10(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, None, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_11(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=None).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_12(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_13(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_14(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, ).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_15(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(x))

    def xǁPyODDetectorǁ_matrix__mutmut_16(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(None)

    def xǁPyODDetectorǁ_matrix__mutmut_17(self, df: pd.DataFrame) -> np.ndarray:
        if self._model is None or self._imputer is None or self._scaler is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=float)
        return self._scaler.transform(self._imputer.transform(None))

    @_mutmut_mutated(mutants_xǁPyODDetectorǁ_fitted_model__mutmut)
    def _fitted_model(self):
        if self._model is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        return self._model

    def xǁPyODDetectorǁ_fitted_model__mutmut_orig(self):
        if self._model is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        return self._model

    def xǁPyODDetectorǁ_fitted_model__mutmut_1(self):
        if self._model is not None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        return self._model

    def xǁPyODDetectorǁ_fitted_model__mutmut_2(self):
        if self._model is None:
            raise RuntimeError(None)
        return self._model

    @_mutmut_mutated(mutants_xǁPyODDetectorǁfit__mutmut)
    def fit(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_orig(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_1(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = None
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_2(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(None)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_3(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = None

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_4(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=None)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_5(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(None, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_6(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, None, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_7(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=None).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_8(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_9(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_10(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, ).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_11(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=False).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_12(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = None
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_13(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(None)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_14(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy=None).fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_15(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="XXmedianXX").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_16(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="MEDIAN").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_17(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = None

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_18(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(None)

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_19(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(None))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_20(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = None
        self._model.fit(self._scaler.transform(self._imputer.transform(x)))
        return self

    def xǁPyODDetectorǁfit__mutmut_21(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(None)
        return self

    def xǁPyODDetectorǁfit__mutmut_22(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(None))
        return self

    def xǁPyODDetectorǁfit__mutmut_23(self, df: pd.DataFrame) -> Self:
        self.feature_names_ = self._numeric_columns(df)
        x = numeric_features(df, self.feature_names_, training=True).to_numpy(dtype=float)

        self._imputer = SimpleImputer(strategy="median").fit(x)
        self._scaler = StandardScaler().fit(self._imputer.transform(x))

        self._model = self._build_estimator()
        self._model.fit(self._scaler.transform(self._imputer.transform(None)))
        return self

    @_mutmut_mutated(mutants_xǁPyODDetectorǁpredict__mutmut)
    def predict(self, df: pd.DataFrame) -> pd.Series:
        flags = self._fitted_model().predict(self._matrix(df)).astype(bool)
        return pd.Series(flags, index=df.index)

    def xǁPyODDetectorǁpredict__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        flags = self._fitted_model().predict(self._matrix(df)).astype(bool)
        return pd.Series(flags, index=df.index)

    def xǁPyODDetectorǁpredict__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        flags = None
        return pd.Series(flags, index=df.index)

    def xǁPyODDetectorǁpredict__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        flags = self._fitted_model().predict(self._matrix(df)).astype(None)
        return pd.Series(flags, index=df.index)

    def xǁPyODDetectorǁpredict__mutmut_3(self, df: pd.DataFrame) -> pd.Series:
        flags = self._fitted_model().predict(None).astype(bool)
        return pd.Series(flags, index=df.index)

    def xǁPyODDetectorǁpredict__mutmut_4(self, df: pd.DataFrame) -> pd.Series:
        flags = self._fitted_model().predict(self._matrix(None)).astype(bool)
        return pd.Series(flags, index=df.index)

    def xǁPyODDetectorǁpredict__mutmut_5(self, df: pd.DataFrame) -> pd.Series:
        flags = self._fitted_model().predict(self._matrix(df)).astype(bool)
        return pd.Series(None, index=df.index)

    def xǁPyODDetectorǁpredict__mutmut_6(self, df: pd.DataFrame) -> pd.Series:
        flags = self._fitted_model().predict(self._matrix(df)).astype(bool)
        return pd.Series(flags, index=None)

    def xǁPyODDetectorǁpredict__mutmut_7(self, df: pd.DataFrame) -> pd.Series:
        flags = self._fitted_model().predict(self._matrix(df)).astype(bool)
        return pd.Series(index=df.index)

    def xǁPyODDetectorǁpredict__mutmut_8(self, df: pd.DataFrame) -> pd.Series:
        flags = self._fitted_model().predict(self._matrix(df)).astype(bool)
        return pd.Series(flags, )

    @_mutmut_mutated(mutants_xǁPyODDetectorǁscore__mutmut)
    def score(self, df: pd.DataFrame) -> pd.Series:
        scores = self._fitted_model().decision_function(self._matrix(df))
        return pd.Series(scores, index=df.index, dtype=float)

    def xǁPyODDetectorǁscore__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        scores = self._fitted_model().decision_function(self._matrix(df))
        return pd.Series(scores, index=df.index, dtype=float)

    def xǁPyODDetectorǁscore__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        scores = None
        return pd.Series(scores, index=df.index, dtype=float)

    def xǁPyODDetectorǁscore__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        scores = self._fitted_model().decision_function(None)
        return pd.Series(scores, index=df.index, dtype=float)

    def xǁPyODDetectorǁscore__mutmut_3(self, df: pd.DataFrame) -> pd.Series:
        scores = self._fitted_model().decision_function(self._matrix(None))
        return pd.Series(scores, index=df.index, dtype=float)

    def xǁPyODDetectorǁscore__mutmut_4(self, df: pd.DataFrame) -> pd.Series:
        scores = self._fitted_model().decision_function(self._matrix(df))
        return pd.Series(None, index=df.index, dtype=float)

    def xǁPyODDetectorǁscore__mutmut_5(self, df: pd.DataFrame) -> pd.Series:
        scores = self._fitted_model().decision_function(self._matrix(df))
        return pd.Series(scores, index=None, dtype=float)

    def xǁPyODDetectorǁscore__mutmut_6(self, df: pd.DataFrame) -> pd.Series:
        scores = self._fitted_model().decision_function(self._matrix(df))
        return pd.Series(scores, index=df.index, dtype=None)

    def xǁPyODDetectorǁscore__mutmut_7(self, df: pd.DataFrame) -> pd.Series:
        scores = self._fitted_model().decision_function(self._matrix(df))
        return pd.Series(index=df.index, dtype=float)

    def xǁPyODDetectorǁscore__mutmut_8(self, df: pd.DataFrame) -> pd.Series:
        scores = self._fitted_model().decision_function(self._matrix(df))
        return pd.Series(scores, dtype=float)

    def xǁPyODDetectorǁscore__mutmut_9(self, df: pd.DataFrame) -> pd.Series:
        scores = self._fitted_model().decision_function(self._matrix(df))
        return pd.Series(scores, index=df.index, )

mutants_xǁPyODDetectorǁ__init____mutmut['_mutmut_orig'] = PyODDetector.xǁPyODDetectorǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ__init____mutmut['xǁPyODDetectorǁ__init____mutmut_1'] = PyODDetector.xǁPyODDetectorǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ__init____mutmut['xǁPyODDetectorǁ__init____mutmut_2'] = PyODDetector.xǁPyODDetectorǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ__init____mutmut['xǁPyODDetectorǁ__init____mutmut_3'] = PyODDetector.xǁPyODDetectorǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ__init____mutmut['xǁPyODDetectorǁ__init____mutmut_4'] = PyODDetector.xǁPyODDetectorǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ__init____mutmut['xǁPyODDetectorǁ__init____mutmut_5'] = PyODDetector.xǁPyODDetectorǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ__init____mutmut['xǁPyODDetectorǁ__init____mutmut_6'] = PyODDetector.xǁPyODDetectorǁ__init____mutmut_6 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ__init____mutmut['xǁPyODDetectorǁ__init____mutmut_7'] = PyODDetector.xǁPyODDetectorǁ__init____mutmut_7 # type: ignore # mutmut generated

mutants_xǁPyODDetectorǁ_build_estimator__mutmut['_mutmut_orig'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_1'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_1 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_2'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_2 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_3'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_3 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_4'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_4 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_5'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_5 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_6'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_6 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_7'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_7 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_8'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_8 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_9'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_9 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_10'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_10 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_11'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_11 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_12'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_12 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_13'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_13 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_14'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_14 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_15'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_15 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_16'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_16 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_17'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_17 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_18'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_18 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_19'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_19 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_build_estimator__mutmut['xǁPyODDetectorǁ_build_estimator__mutmut_20'] = PyODDetector.xǁPyODDetectorǁ_build_estimator__mutmut_20 # type: ignore # mutmut generated

mutants_xǁPyODDetectorǁ_numeric_columns__mutmut['_mutmut_orig'] = PyODDetector.xǁPyODDetectorǁ_numeric_columns__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_numeric_columns__mutmut['xǁPyODDetectorǁ_numeric_columns__mutmut_1'] = PyODDetector.xǁPyODDetectorǁ_numeric_columns__mutmut_1 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_numeric_columns__mutmut['xǁPyODDetectorǁ_numeric_columns__mutmut_2'] = PyODDetector.xǁPyODDetectorǁ_numeric_columns__mutmut_2 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_numeric_columns__mutmut['xǁPyODDetectorǁ_numeric_columns__mutmut_3'] = PyODDetector.xǁPyODDetectorǁ_numeric_columns__mutmut_3 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_numeric_columns__mutmut['xǁPyODDetectorǁ_numeric_columns__mutmut_4'] = PyODDetector.xǁPyODDetectorǁ_numeric_columns__mutmut_4 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_numeric_columns__mutmut['xǁPyODDetectorǁ_numeric_columns__mutmut_5'] = PyODDetector.xǁPyODDetectorǁ_numeric_columns__mutmut_5 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_numeric_columns__mutmut['xǁPyODDetectorǁ_numeric_columns__mutmut_6'] = PyODDetector.xǁPyODDetectorǁ_numeric_columns__mutmut_6 # type: ignore # mutmut generated

mutants_xǁPyODDetectorǁ_matrix__mutmut['_mutmut_orig'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_1'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_1 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_2'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_2 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_3'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_3 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_4'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_4 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_5'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_5 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_6'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_6 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_7'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_7 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_8'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_8 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_9'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_9 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_10'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_10 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_11'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_11 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_12'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_12 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_13'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_13 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_14'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_14 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_15'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_15 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_16'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_16 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_matrix__mutmut['xǁPyODDetectorǁ_matrix__mutmut_17'] = PyODDetector.xǁPyODDetectorǁ_matrix__mutmut_17 # type: ignore # mutmut generated

mutants_xǁPyODDetectorǁ_fitted_model__mutmut['_mutmut_orig'] = PyODDetector.xǁPyODDetectorǁ_fitted_model__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_fitted_model__mutmut['xǁPyODDetectorǁ_fitted_model__mutmut_1'] = PyODDetector.xǁPyODDetectorǁ_fitted_model__mutmut_1 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁ_fitted_model__mutmut['xǁPyODDetectorǁ_fitted_model__mutmut_2'] = PyODDetector.xǁPyODDetectorǁ_fitted_model__mutmut_2 # type: ignore # mutmut generated

mutants_xǁPyODDetectorǁfit__mutmut['_mutmut_orig'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_1'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_1 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_2'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_2 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_3'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_3 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_4'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_4 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_5'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_5 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_6'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_6 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_7'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_7 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_8'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_8 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_9'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_9 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_10'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_10 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_11'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_11 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_12'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_12 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_13'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_13 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_14'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_14 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_15'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_15 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_16'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_16 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_17'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_17 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_18'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_18 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_19'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_19 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_20'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_20 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_21'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_21 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_22'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_22 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁfit__mutmut['xǁPyODDetectorǁfit__mutmut_23'] = PyODDetector.xǁPyODDetectorǁfit__mutmut_23 # type: ignore # mutmut generated

mutants_xǁPyODDetectorǁpredict__mutmut['_mutmut_orig'] = PyODDetector.xǁPyODDetectorǁpredict__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁpredict__mutmut['xǁPyODDetectorǁpredict__mutmut_1'] = PyODDetector.xǁPyODDetectorǁpredict__mutmut_1 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁpredict__mutmut['xǁPyODDetectorǁpredict__mutmut_2'] = PyODDetector.xǁPyODDetectorǁpredict__mutmut_2 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁpredict__mutmut['xǁPyODDetectorǁpredict__mutmut_3'] = PyODDetector.xǁPyODDetectorǁpredict__mutmut_3 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁpredict__mutmut['xǁPyODDetectorǁpredict__mutmut_4'] = PyODDetector.xǁPyODDetectorǁpredict__mutmut_4 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁpredict__mutmut['xǁPyODDetectorǁpredict__mutmut_5'] = PyODDetector.xǁPyODDetectorǁpredict__mutmut_5 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁpredict__mutmut['xǁPyODDetectorǁpredict__mutmut_6'] = PyODDetector.xǁPyODDetectorǁpredict__mutmut_6 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁpredict__mutmut['xǁPyODDetectorǁpredict__mutmut_7'] = PyODDetector.xǁPyODDetectorǁpredict__mutmut_7 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁpredict__mutmut['xǁPyODDetectorǁpredict__mutmut_8'] = PyODDetector.xǁPyODDetectorǁpredict__mutmut_8 # type: ignore # mutmut generated

mutants_xǁPyODDetectorǁscore__mutmut['_mutmut_orig'] = PyODDetector.xǁPyODDetectorǁscore__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁscore__mutmut['xǁPyODDetectorǁscore__mutmut_1'] = PyODDetector.xǁPyODDetectorǁscore__mutmut_1 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁscore__mutmut['xǁPyODDetectorǁscore__mutmut_2'] = PyODDetector.xǁPyODDetectorǁscore__mutmut_2 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁscore__mutmut['xǁPyODDetectorǁscore__mutmut_3'] = PyODDetector.xǁPyODDetectorǁscore__mutmut_3 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁscore__mutmut['xǁPyODDetectorǁscore__mutmut_4'] = PyODDetector.xǁPyODDetectorǁscore__mutmut_4 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁscore__mutmut['xǁPyODDetectorǁscore__mutmut_5'] = PyODDetector.xǁPyODDetectorǁscore__mutmut_5 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁscore__mutmut['xǁPyODDetectorǁscore__mutmut_6'] = PyODDetector.xǁPyODDetectorǁscore__mutmut_6 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁscore__mutmut['xǁPyODDetectorǁscore__mutmut_7'] = PyODDetector.xǁPyODDetectorǁscore__mutmut_7 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁscore__mutmut['xǁPyODDetectorǁscore__mutmut_8'] = PyODDetector.xǁPyODDetectorǁscore__mutmut_8 # type: ignore # mutmut generated
mutants_xǁPyODDetectorǁscore__mutmut['xǁPyODDetectorǁscore__mutmut_9'] = PyODDetector.xǁPyODDetectorǁscore__mutmut_9 # type: ignore # mutmut generated


class IsolationForestDetector(PyODDetector):
    name = "isolation_forest"
    estimator_path = ("pyod.models.iforest", "IForest")
    supports_random_state = True


class LOFDetector(PyODDetector):
    name = "lof"
    estimator_path = ("pyod.models.lof", "LOF")


class OneClassSVMDetector(PyODDetector):
    name = "ocsvm"
    estimator_path = ("pyod.models.ocsvm", "OCSVM")
mutants_xǁTailProbabilityModelǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁTailProbabilityModelǁfit__mutmut: MutantDict = {}  # type: ignore
mutants_xǁTailProbabilityModelǁdecision_function__mutmut: MutantDict = {}  # type: ignore
mutants_xǁTailProbabilityModelǁpredict__mutmut: MutantDict = {}  # type: ignore


class TailProbabilityModel:
    """PyOD-style estimator for ECOD and COPOD that reads only the fit rows.

    Both methods turn each column into left and right empirical tail
    probabilities and sum their negative logarithms across columns. PyOD
    recomputes these distributions on the fit rows plus the rows being scored,
    so a row's score would depend on the other rows of its batch. Here the
    distributions are those of the fit rows alone: a row is ranked among the
    fit rows as if it were added to them, which is what PyOD computes for a
    batch of one row. The skew that picks the heavier tail is also fixed at fit.
    The flag threshold is the ``1 - contamination`` quantile of the training
    scores.
    """

    #: Combination of the two tails: ``"ecod"`` keeps the larger, ``"copod"`` their mean.
    method = "ecod"

    @_mutmut_mutated(mutants_xǁTailProbabilityModelǁ__init____mutmut)
    def __init__(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty((0, 0))
        self.skew_sign_ = np.empty(0)
        self.threshold_ = float("nan")

    def xǁTailProbabilityModelǁ__init____mutmut_orig(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty((0, 0))
        self.skew_sign_ = np.empty(0)
        self.threshold_ = float("nan")

    def xǁTailProbabilityModelǁ__init____mutmut_1(self, contamination: float, method: str) -> None:
        self.contamination = None
        self.method = method
        self.sorted_ = np.empty((0, 0))
        self.skew_sign_ = np.empty(0)
        self.threshold_ = float("nan")

    def xǁTailProbabilityModelǁ__init____mutmut_2(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = None
        self.sorted_ = np.empty((0, 0))
        self.skew_sign_ = np.empty(0)
        self.threshold_ = float("nan")

    def xǁTailProbabilityModelǁ__init____mutmut_3(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = None
        self.skew_sign_ = np.empty(0)
        self.threshold_ = float("nan")

    def xǁTailProbabilityModelǁ__init____mutmut_4(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty(None)
        self.skew_sign_ = np.empty(0)
        self.threshold_ = float("nan")

    def xǁTailProbabilityModelǁ__init____mutmut_5(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty((1, 0))
        self.skew_sign_ = np.empty(0)
        self.threshold_ = float("nan")

    def xǁTailProbabilityModelǁ__init____mutmut_6(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty((0, 1))
        self.skew_sign_ = np.empty(0)
        self.threshold_ = float("nan")

    def xǁTailProbabilityModelǁ__init____mutmut_7(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty((0, 0))
        self.skew_sign_ = None
        self.threshold_ = float("nan")

    def xǁTailProbabilityModelǁ__init____mutmut_8(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty((0, 0))
        self.skew_sign_ = np.empty(None)
        self.threshold_ = float("nan")

    def xǁTailProbabilityModelǁ__init____mutmut_9(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty((0, 0))
        self.skew_sign_ = np.empty(1)
        self.threshold_ = float("nan")

    def xǁTailProbabilityModelǁ__init____mutmut_10(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty((0, 0))
        self.skew_sign_ = np.empty(0)
        self.threshold_ = None

    def xǁTailProbabilityModelǁ__init____mutmut_11(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty((0, 0))
        self.skew_sign_ = np.empty(0)
        self.threshold_ = float(None)

    def xǁTailProbabilityModelǁ__init____mutmut_12(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty((0, 0))
        self.skew_sign_ = np.empty(0)
        self.threshold_ = float("XXnanXX")

    def xǁTailProbabilityModelǁ__init____mutmut_13(self, contamination: float, method: str) -> None:
        self.contamination = contamination
        self.method = method
        self.sorted_ = np.empty((0, 0))
        self.skew_sign_ = np.empty(0)
        self.threshold_ = float("NAN")

    @_mutmut_mutated(mutants_xǁTailProbabilityModelǁfit__mutmut)
    def fit(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_orig(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_1(self, x: np.ndarray) -> Self:
        self.sorted_ = None
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_2(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(None, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_3(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=None)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_4(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_5(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, )
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_6(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=1)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_7(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = None
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_8(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(None)
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_9(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(None))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_10(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(None, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_11(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=None)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_12(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_13(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, )))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_14(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=1)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_15(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = None
        return self

    def xǁTailProbabilityModelǁfit__mutmut_16(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(None)
        return self

    def xǁTailProbabilityModelǁfit__mutmut_17(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(None, 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_18(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), None))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_19(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_20(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), ))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_21(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(None), 1.0 - self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_22(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 + self.contamination))
        return self

    def xǁTailProbabilityModelǁfit__mutmut_23(self, x: np.ndarray) -> Self:
        self.sorted_ = np.sort(x, axis=0)
        # a constant column has no skew; it then counts both tails
        self.skew_sign_ = np.sign(np.nan_to_num(skew(x, axis=0)))
        self.threshold_ = float(np.quantile(self.decision_function(x), 2.0 - self.contamination))
        return self

    @_mutmut_mutated(mutants_xǁTailProbabilityModelǁdecision_function__mutmut)
    def decision_function(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_orig(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_1(self, x: np.ndarray) -> np.ndarray:
        n = None
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_2(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[1]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_3(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = None
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_4(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(None)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_5(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = None
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_6(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(None)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_7(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(None):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_8(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[2]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_9(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = None
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_10(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = None
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_11(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(None, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_12(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, None, side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_13(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side=None)
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_14(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_15(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_16(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], )
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_17(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="XXrightXX")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_18(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="RIGHT")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_19(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = None
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_20(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n + np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_21(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(None, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_22(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, None, side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_23(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side=None)
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_24(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_25(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_26(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], )
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_27(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="XXleftXX")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_28(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="LEFT")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_29(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = None
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_30(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = +np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_31(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log(None)
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_32(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) * (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_33(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left - 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_34(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 2) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_35(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n - 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_36(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 2))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_37(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = None
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_38(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = +np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_39(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log(None)
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_40(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) * (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_41(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right - 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_42(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 2) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_43(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n - 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_44(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 2))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_45(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = None
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_46(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) - u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_47(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 / np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_48(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left / -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_49(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * +1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_50(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -2 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_51(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(None) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_52(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ + 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_53(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 2) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_54(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right / np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_55(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(None)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_56(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ - 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_57(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 2)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_58(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method != "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_59(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "XXcopodXX":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_60(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "COPOD":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_61(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = None
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_62(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(None, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_63(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, None)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_64(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum((u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_65(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, )
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_66(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) * 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_67(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left - u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_68(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 3)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_69(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = None
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_70(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(None, np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_71(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, None)
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_72(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(np.maximum(u_left, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_73(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, )
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_74(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(None, u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_75(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, None))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_76(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_right))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_77(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, ))
        return combined.sum(axis=1)

    def xǁTailProbabilityModelǁdecision_function__mutmut_78(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=None)

    def xǁTailProbabilityModelǁdecision_function__mutmut_79(self, x: np.ndarray) -> np.ndarray:
        n = self.sorted_.shape[0]
        left = np.empty(x.shape)
        right = np.empty(x.shape)
        for j in range(x.shape[1]):
            column = self.sorted_[:, j]
            left[:, j] = np.searchsorted(column, x[:, j], side="right")
            right[:, j] = n - np.searchsorted(column, x[:, j], side="left")
        u_left = -np.log((left + 1) / (n + 1))
        u_right = -np.log((right + 1) / (n + 1))
        u_skew = u_left * -1 * np.sign(self.skew_sign_ - 1) + u_right * np.sign(self.skew_sign_ + 1)
        if self.method == "copod":
            combined = np.maximum(u_skew, (u_left + u_right) / 2)
        else:
            combined = np.maximum(u_skew, np.maximum(u_left, u_right))
        return combined.sum(axis=2)

    @_mutmut_mutated(mutants_xǁTailProbabilityModelǁpredict__mutmut)
    def predict(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) > self.threshold_).astype(int)

    def xǁTailProbabilityModelǁpredict__mutmut_orig(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) > self.threshold_).astype(int)

    def xǁTailProbabilityModelǁpredict__mutmut_1(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) > self.threshold_).astype(None)

    def xǁTailProbabilityModelǁpredict__mutmut_2(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(None) > self.threshold_).astype(int)

    def xǁTailProbabilityModelǁpredict__mutmut_3(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) >= self.threshold_).astype(int)

mutants_xǁTailProbabilityModelǁ__init____mutmut['_mutmut_orig'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_1'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_2'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_3'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_4'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_5'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_6'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_6 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_7'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_7 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_8'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_8 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_9'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_9 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_10'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_10 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_11'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_11 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_12'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_12 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁ__init____mutmut['xǁTailProbabilityModelǁ__init____mutmut_13'] = TailProbabilityModel.xǁTailProbabilityModelǁ__init____mutmut_13 # type: ignore # mutmut generated

mutants_xǁTailProbabilityModelǁfit__mutmut['_mutmut_orig'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_1'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_2'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_2 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_3'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_3 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_4'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_4 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_5'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_5 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_6'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_6 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_7'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_7 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_8'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_8 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_9'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_9 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_10'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_10 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_11'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_11 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_12'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_12 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_13'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_13 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_14'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_14 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_15'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_15 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_16'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_16 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_17'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_17 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_18'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_18 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_19'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_19 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_20'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_20 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_21'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_21 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_22'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_22 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁfit__mutmut['xǁTailProbabilityModelǁfit__mutmut_23'] = TailProbabilityModel.xǁTailProbabilityModelǁfit__mutmut_23 # type: ignore # mutmut generated

mutants_xǁTailProbabilityModelǁdecision_function__mutmut['_mutmut_orig'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_1'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_2'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_2 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_3'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_3 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_4'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_4 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_5'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_5 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_6'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_6 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_7'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_7 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_8'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_8 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_9'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_9 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_10'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_10 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_11'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_11 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_12'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_12 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_13'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_13 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_14'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_14 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_15'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_15 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_16'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_16 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_17'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_17 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_18'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_18 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_19'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_19 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_20'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_20 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_21'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_21 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_22'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_22 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_23'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_23 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_24'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_24 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_25'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_25 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_26'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_26 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_27'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_27 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_28'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_28 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_29'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_29 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_30'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_30 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_31'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_31 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_32'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_32 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_33'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_33 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_34'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_34 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_35'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_35 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_36'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_36 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_37'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_37 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_38'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_38 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_39'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_39 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_40'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_40 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_41'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_41 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_42'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_42 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_43'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_43 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_44'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_44 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_45'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_45 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_46'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_46 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_47'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_47 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_48'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_48 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_49'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_49 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_50'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_50 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_51'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_51 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_52'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_52 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_53'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_53 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_54'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_54 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_55'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_55 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_56'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_56 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_57'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_57 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_58'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_58 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_59'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_59 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_60'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_60 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_61'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_61 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_62'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_62 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_63'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_63 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_64'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_64 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_65'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_65 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_66'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_66 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_67'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_67 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_68'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_68 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_69'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_69 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_70'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_70 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_71'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_71 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_72'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_72 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_73'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_73 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_74'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_74 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_75'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_75 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_76'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_76 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_77'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_77 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_78'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_78 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁdecision_function__mutmut['xǁTailProbabilityModelǁdecision_function__mutmut_79'] = TailProbabilityModel.xǁTailProbabilityModelǁdecision_function__mutmut_79 # type: ignore # mutmut generated

mutants_xǁTailProbabilityModelǁpredict__mutmut['_mutmut_orig'] = TailProbabilityModel.xǁTailProbabilityModelǁpredict__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁpredict__mutmut['xǁTailProbabilityModelǁpredict__mutmut_1'] = TailProbabilityModel.xǁTailProbabilityModelǁpredict__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁpredict__mutmut['xǁTailProbabilityModelǁpredict__mutmut_2'] = TailProbabilityModel.xǁTailProbabilityModelǁpredict__mutmut_2 # type: ignore # mutmut generated
mutants_xǁTailProbabilityModelǁpredict__mutmut['xǁTailProbabilityModelǁpredict__mutmut_3'] = TailProbabilityModel.xǁTailProbabilityModelǁpredict__mutmut_3 # type: ignore # mutmut generated
mutants_xǁECODDetectorǁ_build_estimator__mutmut: MutantDict = {}  # type: ignore


class ECODDetector(PyODDetector):
    name = "ecod"

    @_mutmut_mutated(mutants_xǁECODDetectorǁ_build_estimator__mutmut)
    def _build_estimator(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, "ecod")

    def xǁECODDetectorǁ_build_estimator__mutmut_orig(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, "ecod")

    def xǁECODDetectorǁ_build_estimator__mutmut_1(self) -> TailProbabilityModel:
        return TailProbabilityModel(None, "ecod")

    def xǁECODDetectorǁ_build_estimator__mutmut_2(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, None)

    def xǁECODDetectorǁ_build_estimator__mutmut_3(self) -> TailProbabilityModel:
        return TailProbabilityModel("ecod")

    def xǁECODDetectorǁ_build_estimator__mutmut_4(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, )

    def xǁECODDetectorǁ_build_estimator__mutmut_5(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, "XXecodXX")

    def xǁECODDetectorǁ_build_estimator__mutmut_6(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, "ECOD")

mutants_xǁECODDetectorǁ_build_estimator__mutmut['_mutmut_orig'] = ECODDetector.xǁECODDetectorǁ_build_estimator__mutmut_orig # type: ignore # mutmut generated
mutants_xǁECODDetectorǁ_build_estimator__mutmut['xǁECODDetectorǁ_build_estimator__mutmut_1'] = ECODDetector.xǁECODDetectorǁ_build_estimator__mutmut_1 # type: ignore # mutmut generated
mutants_xǁECODDetectorǁ_build_estimator__mutmut['xǁECODDetectorǁ_build_estimator__mutmut_2'] = ECODDetector.xǁECODDetectorǁ_build_estimator__mutmut_2 # type: ignore # mutmut generated
mutants_xǁECODDetectorǁ_build_estimator__mutmut['xǁECODDetectorǁ_build_estimator__mutmut_3'] = ECODDetector.xǁECODDetectorǁ_build_estimator__mutmut_3 # type: ignore # mutmut generated
mutants_xǁECODDetectorǁ_build_estimator__mutmut['xǁECODDetectorǁ_build_estimator__mutmut_4'] = ECODDetector.xǁECODDetectorǁ_build_estimator__mutmut_4 # type: ignore # mutmut generated
mutants_xǁECODDetectorǁ_build_estimator__mutmut['xǁECODDetectorǁ_build_estimator__mutmut_5'] = ECODDetector.xǁECODDetectorǁ_build_estimator__mutmut_5 # type: ignore # mutmut generated
mutants_xǁECODDetectorǁ_build_estimator__mutmut['xǁECODDetectorǁ_build_estimator__mutmut_6'] = ECODDetector.xǁECODDetectorǁ_build_estimator__mutmut_6 # type: ignore # mutmut generated
mutants_xǁCOPODDetectorǁ_build_estimator__mutmut: MutantDict = {}  # type: ignore


class COPODDetector(PyODDetector):
    name = "copod"

    @_mutmut_mutated(mutants_xǁCOPODDetectorǁ_build_estimator__mutmut)
    def _build_estimator(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, "copod")

    def xǁCOPODDetectorǁ_build_estimator__mutmut_orig(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, "copod")

    def xǁCOPODDetectorǁ_build_estimator__mutmut_1(self) -> TailProbabilityModel:
        return TailProbabilityModel(None, "copod")

    def xǁCOPODDetectorǁ_build_estimator__mutmut_2(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, None)

    def xǁCOPODDetectorǁ_build_estimator__mutmut_3(self) -> TailProbabilityModel:
        return TailProbabilityModel("copod")

    def xǁCOPODDetectorǁ_build_estimator__mutmut_4(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, )

    def xǁCOPODDetectorǁ_build_estimator__mutmut_5(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, "XXcopodXX")

    def xǁCOPODDetectorǁ_build_estimator__mutmut_6(self) -> TailProbabilityModel:
        return TailProbabilityModel(self.contamination, "COPOD")

mutants_xǁCOPODDetectorǁ_build_estimator__mutmut['_mutmut_orig'] = COPODDetector.xǁCOPODDetectorǁ_build_estimator__mutmut_orig # type: ignore # mutmut generated
mutants_xǁCOPODDetectorǁ_build_estimator__mutmut['xǁCOPODDetectorǁ_build_estimator__mutmut_1'] = COPODDetector.xǁCOPODDetectorǁ_build_estimator__mutmut_1 # type: ignore # mutmut generated
mutants_xǁCOPODDetectorǁ_build_estimator__mutmut['xǁCOPODDetectorǁ_build_estimator__mutmut_2'] = COPODDetector.xǁCOPODDetectorǁ_build_estimator__mutmut_2 # type: ignore # mutmut generated
mutants_xǁCOPODDetectorǁ_build_estimator__mutmut['xǁCOPODDetectorǁ_build_estimator__mutmut_3'] = COPODDetector.xǁCOPODDetectorǁ_build_estimator__mutmut_3 # type: ignore # mutmut generated
mutants_xǁCOPODDetectorǁ_build_estimator__mutmut['xǁCOPODDetectorǁ_build_estimator__mutmut_4'] = COPODDetector.xǁCOPODDetectorǁ_build_estimator__mutmut_4 # type: ignore # mutmut generated
mutants_xǁCOPODDetectorǁ_build_estimator__mutmut['xǁCOPODDetectorǁ_build_estimator__mutmut_5'] = COPODDetector.xǁCOPODDetectorǁ_build_estimator__mutmut_5 # type: ignore # mutmut generated
mutants_xǁCOPODDetectorǁ_build_estimator__mutmut['xǁCOPODDetectorǁ_build_estimator__mutmut_6'] = COPODDetector.xǁCOPODDetectorǁ_build_estimator__mutmut_6 # type: ignore # mutmut generated


class HBOSDetector(PyODDetector):
    name = "hbos"
    estimator_path = ("pyod.models.hbos", "HBOS")


class KNNDetector(PyODDetector):
    name = "knn"
    estimator_path = ("pyod.models.knn", "KNN")
mutants_xǁPCAReconstructionǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁPCAReconstructionǁfit__mutmut: MutantDict = {}  # type: ignore
mutants_xǁPCAReconstructionǁdecision_function__mutmut: MutantDict = {}  # type: ignore
mutants_xǁPCAReconstructionǁpredict__mutmut: MutantDict = {}  # type: ignore


class PCAReconstruction:
    """PyOD-style estimator: mean squared error of a PCA reconstruction.

    PyOD's own ``PCA`` scores a weighted distance to the eigenvectors, which
    is not a reconstruction error, so the projection comes from scikit-learn.
    The flag threshold is the ``1 - contamination`` quantile of the training
    scores.
    """

    #: Share of the variance the kept components must explain.
    variance = 0.95

    @_mutmut_mutated(mutants_xǁPCAReconstructionǁ__init____mutmut)
    def __init__(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(n_components=self.variance, svd_solver="full")
        self.threshold_ = float("nan")

    def xǁPCAReconstructionǁ__init____mutmut_orig(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(n_components=self.variance, svd_solver="full")
        self.threshold_ = float("nan")

    def xǁPCAReconstructionǁ__init____mutmut_1(self, contamination: float) -> None:
        self.contamination = None
        self.pca_ = PCA(n_components=self.variance, svd_solver="full")
        self.threshold_ = float("nan")

    def xǁPCAReconstructionǁ__init____mutmut_2(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = None
        self.threshold_ = float("nan")

    def xǁPCAReconstructionǁ__init____mutmut_3(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(n_components=None, svd_solver="full")
        self.threshold_ = float("nan")

    def xǁPCAReconstructionǁ__init____mutmut_4(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(n_components=self.variance, svd_solver=None)
        self.threshold_ = float("nan")

    def xǁPCAReconstructionǁ__init____mutmut_5(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(svd_solver="full")
        self.threshold_ = float("nan")

    def xǁPCAReconstructionǁ__init____mutmut_6(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(n_components=self.variance, )
        self.threshold_ = float("nan")

    def xǁPCAReconstructionǁ__init____mutmut_7(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(n_components=self.variance, svd_solver="XXfullXX")
        self.threshold_ = float("nan")

    def xǁPCAReconstructionǁ__init____mutmut_8(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(n_components=self.variance, svd_solver="FULL")
        self.threshold_ = float("nan")

    def xǁPCAReconstructionǁ__init____mutmut_9(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(n_components=self.variance, svd_solver="full")
        self.threshold_ = None

    def xǁPCAReconstructionǁ__init____mutmut_10(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(n_components=self.variance, svd_solver="full")
        self.threshold_ = float(None)

    def xǁPCAReconstructionǁ__init____mutmut_11(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(n_components=self.variance, svd_solver="full")
        self.threshold_ = float("XXnanXX")

    def xǁPCAReconstructionǁ__init____mutmut_12(self, contamination: float) -> None:
        self.contamination = contamination
        self.pca_ = PCA(n_components=self.variance, svd_solver="full")
        self.threshold_ = float("NAN")

    @_mutmut_mutated(mutants_xǁPCAReconstructionǁfit__mutmut)
    def fit(self, x: np.ndarray) -> Self:
        self.pca_.fit(x)
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁPCAReconstructionǁfit__mutmut_orig(self, x: np.ndarray) -> Self:
        self.pca_.fit(x)
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁPCAReconstructionǁfit__mutmut_1(self, x: np.ndarray) -> Self:
        self.pca_.fit(None)
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 - self.contamination))
        return self

    def xǁPCAReconstructionǁfit__mutmut_2(self, x: np.ndarray) -> Self:
        self.pca_.fit(x)
        self.threshold_ = None
        return self

    def xǁPCAReconstructionǁfit__mutmut_3(self, x: np.ndarray) -> Self:
        self.pca_.fit(x)
        self.threshold_ = float(None)
        return self

    def xǁPCAReconstructionǁfit__mutmut_4(self, x: np.ndarray) -> Self:
        self.pca_.fit(x)
        self.threshold_ = float(np.quantile(None, 1.0 - self.contamination))
        return self

    def xǁPCAReconstructionǁfit__mutmut_5(self, x: np.ndarray) -> Self:
        self.pca_.fit(x)
        self.threshold_ = float(np.quantile(self.decision_function(x), None))
        return self

    def xǁPCAReconstructionǁfit__mutmut_6(self, x: np.ndarray) -> Self:
        self.pca_.fit(x)
        self.threshold_ = float(np.quantile(1.0 - self.contamination))
        return self

    def xǁPCAReconstructionǁfit__mutmut_7(self, x: np.ndarray) -> Self:
        self.pca_.fit(x)
        self.threshold_ = float(np.quantile(self.decision_function(x), ))
        return self

    def xǁPCAReconstructionǁfit__mutmut_8(self, x: np.ndarray) -> Self:
        self.pca_.fit(x)
        self.threshold_ = float(np.quantile(self.decision_function(None), 1.0 - self.contamination))
        return self

    def xǁPCAReconstructionǁfit__mutmut_9(self, x: np.ndarray) -> Self:
        self.pca_.fit(x)
        self.threshold_ = float(np.quantile(self.decision_function(x), 1.0 + self.contamination))
        return self

    def xǁPCAReconstructionǁfit__mutmut_10(self, x: np.ndarray) -> Self:
        self.pca_.fit(x)
        self.threshold_ = float(np.quantile(self.decision_function(x), 2.0 - self.contamination))
        return self

    @_mutmut_mutated(mutants_xǁPCAReconstructionǁdecision_function__mutmut)
    def decision_function(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(self.pca_.transform(x))
        return np.mean((x - reconstruction) ** 2, axis=1)

    def xǁPCAReconstructionǁdecision_function__mutmut_orig(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(self.pca_.transform(x))
        return np.mean((x - reconstruction) ** 2, axis=1)

    def xǁPCAReconstructionǁdecision_function__mutmut_1(self, x: np.ndarray) -> np.ndarray:
        reconstruction = None
        return np.mean((x - reconstruction) ** 2, axis=1)

    def xǁPCAReconstructionǁdecision_function__mutmut_2(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(None)
        return np.mean((x - reconstruction) ** 2, axis=1)

    def xǁPCAReconstructionǁdecision_function__mutmut_3(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(self.pca_.transform(None))
        return np.mean((x - reconstruction) ** 2, axis=1)

    def xǁPCAReconstructionǁdecision_function__mutmut_4(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(self.pca_.transform(x))
        return np.mean(None, axis=1)

    def xǁPCAReconstructionǁdecision_function__mutmut_5(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(self.pca_.transform(x))
        return np.mean((x - reconstruction) ** 2, axis=None)

    def xǁPCAReconstructionǁdecision_function__mutmut_6(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(self.pca_.transform(x))
        return np.mean(axis=1)

    def xǁPCAReconstructionǁdecision_function__mutmut_7(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(self.pca_.transform(x))
        return np.mean((x - reconstruction) ** 2, )

    def xǁPCAReconstructionǁdecision_function__mutmut_8(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(self.pca_.transform(x))
        return np.mean((x - reconstruction) * 2, axis=1)

    def xǁPCAReconstructionǁdecision_function__mutmut_9(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(self.pca_.transform(x))
        return np.mean((x + reconstruction) ** 2, axis=1)

    def xǁPCAReconstructionǁdecision_function__mutmut_10(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(self.pca_.transform(x))
        return np.mean((x - reconstruction) ** 3, axis=1)

    def xǁPCAReconstructionǁdecision_function__mutmut_11(self, x: np.ndarray) -> np.ndarray:
        reconstruction = self.pca_.inverse_transform(self.pca_.transform(x))
        return np.mean((x - reconstruction) ** 2, axis=2)

    @_mutmut_mutated(mutants_xǁPCAReconstructionǁpredict__mutmut)
    def predict(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) > self.threshold_).astype(int)

    def xǁPCAReconstructionǁpredict__mutmut_orig(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) > self.threshold_).astype(int)

    def xǁPCAReconstructionǁpredict__mutmut_1(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) > self.threshold_).astype(None)

    def xǁPCAReconstructionǁpredict__mutmut_2(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(None) > self.threshold_).astype(int)

    def xǁPCAReconstructionǁpredict__mutmut_3(self, x: np.ndarray) -> np.ndarray:
        return (self.decision_function(x) >= self.threshold_).astype(int)

mutants_xǁPCAReconstructionǁ__init____mutmut['_mutmut_orig'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_1'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_2'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_3'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_4'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_5'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_6'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_6 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_7'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_7 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_8'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_8 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_9'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_9 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_10'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_10 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_11'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_11 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁ__init____mutmut['xǁPCAReconstructionǁ__init____mutmut_12'] = PCAReconstruction.xǁPCAReconstructionǁ__init____mutmut_12 # type: ignore # mutmut generated

mutants_xǁPCAReconstructionǁfit__mutmut['_mutmut_orig'] = PCAReconstruction.xǁPCAReconstructionǁfit__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁfit__mutmut['xǁPCAReconstructionǁfit__mutmut_1'] = PCAReconstruction.xǁPCAReconstructionǁfit__mutmut_1 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁfit__mutmut['xǁPCAReconstructionǁfit__mutmut_2'] = PCAReconstruction.xǁPCAReconstructionǁfit__mutmut_2 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁfit__mutmut['xǁPCAReconstructionǁfit__mutmut_3'] = PCAReconstruction.xǁPCAReconstructionǁfit__mutmut_3 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁfit__mutmut['xǁPCAReconstructionǁfit__mutmut_4'] = PCAReconstruction.xǁPCAReconstructionǁfit__mutmut_4 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁfit__mutmut['xǁPCAReconstructionǁfit__mutmut_5'] = PCAReconstruction.xǁPCAReconstructionǁfit__mutmut_5 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁfit__mutmut['xǁPCAReconstructionǁfit__mutmut_6'] = PCAReconstruction.xǁPCAReconstructionǁfit__mutmut_6 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁfit__mutmut['xǁPCAReconstructionǁfit__mutmut_7'] = PCAReconstruction.xǁPCAReconstructionǁfit__mutmut_7 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁfit__mutmut['xǁPCAReconstructionǁfit__mutmut_8'] = PCAReconstruction.xǁPCAReconstructionǁfit__mutmut_8 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁfit__mutmut['xǁPCAReconstructionǁfit__mutmut_9'] = PCAReconstruction.xǁPCAReconstructionǁfit__mutmut_9 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁfit__mutmut['xǁPCAReconstructionǁfit__mutmut_10'] = PCAReconstruction.xǁPCAReconstructionǁfit__mutmut_10 # type: ignore # mutmut generated

mutants_xǁPCAReconstructionǁdecision_function__mutmut['_mutmut_orig'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁdecision_function__mutmut['xǁPCAReconstructionǁdecision_function__mutmut_1'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_1 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁdecision_function__mutmut['xǁPCAReconstructionǁdecision_function__mutmut_2'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_2 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁdecision_function__mutmut['xǁPCAReconstructionǁdecision_function__mutmut_3'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_3 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁdecision_function__mutmut['xǁPCAReconstructionǁdecision_function__mutmut_4'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_4 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁdecision_function__mutmut['xǁPCAReconstructionǁdecision_function__mutmut_5'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_5 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁdecision_function__mutmut['xǁPCAReconstructionǁdecision_function__mutmut_6'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_6 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁdecision_function__mutmut['xǁPCAReconstructionǁdecision_function__mutmut_7'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_7 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁdecision_function__mutmut['xǁPCAReconstructionǁdecision_function__mutmut_8'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_8 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁdecision_function__mutmut['xǁPCAReconstructionǁdecision_function__mutmut_9'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_9 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁdecision_function__mutmut['xǁPCAReconstructionǁdecision_function__mutmut_10'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_10 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁdecision_function__mutmut['xǁPCAReconstructionǁdecision_function__mutmut_11'] = PCAReconstruction.xǁPCAReconstructionǁdecision_function__mutmut_11 # type: ignore # mutmut generated

mutants_xǁPCAReconstructionǁpredict__mutmut['_mutmut_orig'] = PCAReconstruction.xǁPCAReconstructionǁpredict__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁpredict__mutmut['xǁPCAReconstructionǁpredict__mutmut_1'] = PCAReconstruction.xǁPCAReconstructionǁpredict__mutmut_1 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁpredict__mutmut['xǁPCAReconstructionǁpredict__mutmut_2'] = PCAReconstruction.xǁPCAReconstructionǁpredict__mutmut_2 # type: ignore # mutmut generated
mutants_xǁPCAReconstructionǁpredict__mutmut['xǁPCAReconstructionǁpredict__mutmut_3'] = PCAReconstruction.xǁPCAReconstructionǁpredict__mutmut_3 # type: ignore # mutmut generated
mutants_xǁPCADetectorǁ_build_estimator__mutmut: MutantDict = {}  # type: ignore


class PCADetector(PyODDetector):
    name = "pca"

    @_mutmut_mutated(mutants_xǁPCADetectorǁ_build_estimator__mutmut)
    def _build_estimator(self) -> PCAReconstruction:
        return PCAReconstruction(self.contamination)

    def xǁPCADetectorǁ_build_estimator__mutmut_orig(self) -> PCAReconstruction:
        return PCAReconstruction(self.contamination)

    def xǁPCADetectorǁ_build_estimator__mutmut_1(self) -> PCAReconstruction:
        return PCAReconstruction(None)

mutants_xǁPCADetectorǁ_build_estimator__mutmut['_mutmut_orig'] = PCADetector.xǁPCADetectorǁ_build_estimator__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPCADetectorǁ_build_estimator__mutmut['xǁPCADetectorǁ_build_estimator__mutmut_1'] = PCADetector.xǁPCADetectorǁ_build_estimator__mutmut_1 # type: ignore # mutmut generated
