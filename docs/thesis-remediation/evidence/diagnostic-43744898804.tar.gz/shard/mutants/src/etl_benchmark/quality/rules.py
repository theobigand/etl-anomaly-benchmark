"""Rule-based anomaly detectors.

Implemented:
    - :class:`ZScoreDetector` — flags rows where any numeric column
      exceeds the configured z-score threshold.
    - :class:`IQRDetector` — Tukey's fences on numeric columns.

The declarative Great Expectations detector lives in
:mod:`etl_benchmark.quality.gx`.
"""

from __future__ import annotations

from typing import Self

import numpy as np
import pandas as pd

from etl_benchmark.quality.base import Detector, numeric_features


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_xǁZScoreDetectorǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁZScoreDetectorǁfit__mutmut: MutantDict = {}  # type: ignore
mutants_xǁZScoreDetectorǁ_zscores__mutmut: MutantDict = {}  # type: ignore
mutants_xǁZScoreDetectorǁpredict__mutmut: MutantDict = {}  # type: ignore
mutants_xǁZScoreDetectorǁscore__mutmut: MutantDict = {}  # type: ignore


class ZScoreDetector(Detector):
    name = "zscore"

    @_mutmut_mutated(mutants_xǁZScoreDetectorǁ__init____mutmut)
    def __init__(self, threshold: float = 3.0, columns: list[str] | None = None) -> None:
        self.threshold = threshold
        self._user_columns = columns
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁZScoreDetectorǁ__init____mutmut_orig(self, threshold: float = 3.0, columns: list[str] | None = None) -> None:
        self.threshold = threshold
        self._user_columns = columns
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁZScoreDetectorǁ__init____mutmut_1(self, threshold: float = 4.0, columns: list[str] | None = None) -> None:
        self.threshold = threshold
        self._user_columns = columns
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁZScoreDetectorǁ__init____mutmut_2(self, threshold: float = 3.0, columns: list[str] | None = None) -> None:
        self.threshold = None
        self._user_columns = columns
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁZScoreDetectorǁ__init____mutmut_3(self, threshold: float = 3.0, columns: list[str] | None = None) -> None:
        self.threshold = threshold
        self._user_columns = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁZScoreDetectorǁ__init____mutmut_4(self, threshold: float = 3.0, columns: list[str] | None = None) -> None:
        self.threshold = threshold
        self._user_columns = columns
        self._means: pd.Series | None = ""
        self._stds: pd.Series | None = None

    def xǁZScoreDetectorǁ__init____mutmut_5(self, threshold: float = 3.0, columns: list[str] | None = None) -> None:
        self.threshold = threshold
        self._user_columns = columns
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = ""

    @_mutmut_mutated(mutants_xǁZScoreDetectorǁfit__mutmut)
    def fit(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_orig(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_1(self, df: pd.DataFrame) -> Self:
        cols = None
        values = numeric_features(df, cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_2(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns and df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_3(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=None).columns.tolist()
        values = numeric_features(df, cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_4(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = None
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_5(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(None, cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_6(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, None, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_7(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=None)
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_8(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_9(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_10(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, )
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_11(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=False)
        self._means = values.mean()
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_12(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        self._means = None
        self._stds = values.std().replace(0, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_13(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        self._means = values.mean()
        self._stds = None
        return self

    def xǁZScoreDetectorǁfit__mutmut_14(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(None, np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_15(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(0, None)
        return self

    def xǁZScoreDetectorǁfit__mutmut_16(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(np.nan)
        return self

    def xǁZScoreDetectorǁfit__mutmut_17(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(0, )
        return self

    def xǁZScoreDetectorǁfit__mutmut_18(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        self._means = values.mean()
        self._stds = values.std().replace(1, np.nan)
        return self

    @_mutmut_mutated(mutants_xǁZScoreDetectorǁ_zscores__mutmut)
    def _zscores(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, list(self._means.index), training=False)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_orig(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, list(self._means.index), training=False)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_1(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None and self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, list(self._means.index), training=False)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_2(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is not None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, list(self._means.index), training=False)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_3(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is not None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, list(self._means.index), training=False)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_4(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(None)
        values = numeric_features(df, list(self._means.index), training=False)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_5(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = None
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_6(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(None, list(self._means.index), training=False)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_7(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, None, training=False)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_8(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, list(self._means.index), training=None)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_9(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(list(self._means.index), training=False)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_10(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, training=False)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_11(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, list(self._means.index), )
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_12(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, list(None), training=False)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_13(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, list(self._means.index), training=True)
        return (values - self._means).abs() / self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_14(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, list(self._means.index), training=False)
        return (values - self._means).abs() * self._stds

    def xǁZScoreDetectorǁ_zscores__mutmut_15(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._means is None or self._stds is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        values = numeric_features(df, list(self._means.index), training=False)
        return (values + self._means).abs() / self._stds

    @_mutmut_mutated(mutants_xǁZScoreDetectorǁpredict__mutmut)
    def predict(self, df: pd.DataFrame) -> pd.Series:
        return self._zscores(df).gt(self.threshold).any(axis=1)

    def xǁZScoreDetectorǁpredict__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        return self._zscores(df).gt(self.threshold).any(axis=1)

    def xǁZScoreDetectorǁpredict__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        return self._zscores(df).gt(self.threshold).any(axis=None)

    def xǁZScoreDetectorǁpredict__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        return self._zscores(df).gt(None).any(axis=1)

    def xǁZScoreDetectorǁpredict__mutmut_3(self, df: pd.DataFrame) -> pd.Series:
        return self._zscores(None).gt(self.threshold).any(axis=1)

    def xǁZScoreDetectorǁpredict__mutmut_4(self, df: pd.DataFrame) -> pd.Series:
        return self._zscores(df).gt(self.threshold).any(axis=2)

    @_mutmut_mutated(mutants_xǁZScoreDetectorǁscore__mutmut)
    def score(self, df: pd.DataFrame) -> pd.Series:
        # Worst standardized deviation across columns; NaN (constant column) -> 0.
        return self._zscores(df).max(axis=1).fillna(0.0)

    def xǁZScoreDetectorǁscore__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        # Worst standardized deviation across columns; NaN (constant column) -> 0.
        return self._zscores(df).max(axis=1).fillna(0.0)

    def xǁZScoreDetectorǁscore__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        # Worst standardized deviation across columns; NaN (constant column) -> 0.
        return self._zscores(df).max(axis=1).fillna(None)

    def xǁZScoreDetectorǁscore__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        # Worst standardized deviation across columns; NaN (constant column) -> 0.
        return self._zscores(df).max(axis=None).fillna(0.0)

    def xǁZScoreDetectorǁscore__mutmut_3(self, df: pd.DataFrame) -> pd.Series:
        # Worst standardized deviation across columns; NaN (constant column) -> 0.
        return self._zscores(None).max(axis=1).fillna(0.0)

    def xǁZScoreDetectorǁscore__mutmut_4(self, df: pd.DataFrame) -> pd.Series:
        # Worst standardized deviation across columns; NaN (constant column) -> 0.
        return self._zscores(df).max(axis=2).fillna(0.0)

    def xǁZScoreDetectorǁscore__mutmut_5(self, df: pd.DataFrame) -> pd.Series:
        # Worst standardized deviation across columns; NaN (constant column) -> 0.
        return self._zscores(df).max(axis=1).fillna(1.0)

mutants_xǁZScoreDetectorǁ__init____mutmut['_mutmut_orig'] = ZScoreDetector.xǁZScoreDetectorǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ__init____mutmut['xǁZScoreDetectorǁ__init____mutmut_1'] = ZScoreDetector.xǁZScoreDetectorǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ__init____mutmut['xǁZScoreDetectorǁ__init____mutmut_2'] = ZScoreDetector.xǁZScoreDetectorǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ__init____mutmut['xǁZScoreDetectorǁ__init____mutmut_3'] = ZScoreDetector.xǁZScoreDetectorǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ__init____mutmut['xǁZScoreDetectorǁ__init____mutmut_4'] = ZScoreDetector.xǁZScoreDetectorǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ__init____mutmut['xǁZScoreDetectorǁ__init____mutmut_5'] = ZScoreDetector.xǁZScoreDetectorǁ__init____mutmut_5 # type: ignore # mutmut generated

mutants_xǁZScoreDetectorǁfit__mutmut['_mutmut_orig'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_orig # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_1'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_1 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_2'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_2 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_3'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_3 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_4'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_4 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_5'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_5 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_6'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_6 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_7'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_7 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_8'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_8 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_9'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_9 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_10'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_10 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_11'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_11 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_12'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_12 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_13'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_13 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_14'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_14 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_15'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_15 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_16'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_16 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_17'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_17 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁfit__mutmut['xǁZScoreDetectorǁfit__mutmut_18'] = ZScoreDetector.xǁZScoreDetectorǁfit__mutmut_18 # type: ignore # mutmut generated

mutants_xǁZScoreDetectorǁ_zscores__mutmut['_mutmut_orig'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_orig # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_1'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_1 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_2'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_2 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_3'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_3 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_4'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_4 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_5'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_5 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_6'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_6 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_7'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_7 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_8'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_8 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_9'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_9 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_10'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_10 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_11'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_11 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_12'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_12 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_13'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_13 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_14'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_14 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁ_zscores__mutmut['xǁZScoreDetectorǁ_zscores__mutmut_15'] = ZScoreDetector.xǁZScoreDetectorǁ_zscores__mutmut_15 # type: ignore # mutmut generated

mutants_xǁZScoreDetectorǁpredict__mutmut['_mutmut_orig'] = ZScoreDetector.xǁZScoreDetectorǁpredict__mutmut_orig # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁpredict__mutmut['xǁZScoreDetectorǁpredict__mutmut_1'] = ZScoreDetector.xǁZScoreDetectorǁpredict__mutmut_1 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁpredict__mutmut['xǁZScoreDetectorǁpredict__mutmut_2'] = ZScoreDetector.xǁZScoreDetectorǁpredict__mutmut_2 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁpredict__mutmut['xǁZScoreDetectorǁpredict__mutmut_3'] = ZScoreDetector.xǁZScoreDetectorǁpredict__mutmut_3 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁpredict__mutmut['xǁZScoreDetectorǁpredict__mutmut_4'] = ZScoreDetector.xǁZScoreDetectorǁpredict__mutmut_4 # type: ignore # mutmut generated

mutants_xǁZScoreDetectorǁscore__mutmut['_mutmut_orig'] = ZScoreDetector.xǁZScoreDetectorǁscore__mutmut_orig # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁscore__mutmut['xǁZScoreDetectorǁscore__mutmut_1'] = ZScoreDetector.xǁZScoreDetectorǁscore__mutmut_1 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁscore__mutmut['xǁZScoreDetectorǁscore__mutmut_2'] = ZScoreDetector.xǁZScoreDetectorǁscore__mutmut_2 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁscore__mutmut['xǁZScoreDetectorǁscore__mutmut_3'] = ZScoreDetector.xǁZScoreDetectorǁscore__mutmut_3 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁscore__mutmut['xǁZScoreDetectorǁscore__mutmut_4'] = ZScoreDetector.xǁZScoreDetectorǁscore__mutmut_4 # type: ignore # mutmut generated
mutants_xǁZScoreDetectorǁscore__mutmut['xǁZScoreDetectorǁscore__mutmut_5'] = ZScoreDetector.xǁZScoreDetectorǁscore__mutmut_5 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁIQRDetectorǁfit__mutmut: MutantDict = {}  # type: ignore
mutants_xǁIQRDetectorǁ_exceedance__mutmut: MutantDict = {}  # type: ignore
mutants_xǁIQRDetectorǁpredict__mutmut: MutantDict = {}  # type: ignore
mutants_xǁIQRDetectorǁscore__mutmut: MutantDict = {}  # type: ignore


class IQRDetector(Detector):
    """Tukey's fences: flag values outside ``[Q1 - k*IQR, Q3 + k*IQR]``."""

    name = "iqr"

    @_mutmut_mutated(mutants_xǁIQRDetectorǁ__init____mutmut)
    def __init__(self, multiplier: float = 1.5, columns: list[str] | None = None) -> None:
        self.multiplier = multiplier
        self._user_columns = columns
        self._lower: pd.Series | None = None
        self._upper: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁIQRDetectorǁ__init____mutmut_orig(self, multiplier: float = 1.5, columns: list[str] | None = None) -> None:
        self.multiplier = multiplier
        self._user_columns = columns
        self._lower: pd.Series | None = None
        self._upper: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁIQRDetectorǁ__init____mutmut_1(self, multiplier: float = 2.5, columns: list[str] | None = None) -> None:
        self.multiplier = multiplier
        self._user_columns = columns
        self._lower: pd.Series | None = None
        self._upper: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁIQRDetectorǁ__init____mutmut_2(self, multiplier: float = 1.5, columns: list[str] | None = None) -> None:
        self.multiplier = None
        self._user_columns = columns
        self._lower: pd.Series | None = None
        self._upper: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁIQRDetectorǁ__init____mutmut_3(self, multiplier: float = 1.5, columns: list[str] | None = None) -> None:
        self.multiplier = multiplier
        self._user_columns = None
        self._lower: pd.Series | None = None
        self._upper: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁIQRDetectorǁ__init____mutmut_4(self, multiplier: float = 1.5, columns: list[str] | None = None) -> None:
        self.multiplier = multiplier
        self._user_columns = columns
        self._lower: pd.Series | None = ""
        self._upper: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁIQRDetectorǁ__init____mutmut_5(self, multiplier: float = 1.5, columns: list[str] | None = None) -> None:
        self.multiplier = multiplier
        self._user_columns = columns
        self._lower: pd.Series | None = None
        self._upper: pd.Series | None = ""
        self._scale: pd.Series | None = None

    def xǁIQRDetectorǁ__init____mutmut_6(self, multiplier: float = 1.5, columns: list[str] | None = None) -> None:
        self.multiplier = multiplier
        self._user_columns = columns
        self._lower: pd.Series | None = None
        self._upper: pd.Series | None = None
        self._scale: pd.Series | None = ""

    @_mutmut_mutated(mutants_xǁIQRDetectorǁfit__mutmut)
    def fit(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_orig(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_1(self, df: pd.DataFrame) -> Self:
        cols = None
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_2(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns and df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_3(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=None).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_4(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = None
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_5(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(None, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_6(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, None, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_7(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=None)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_8(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_9(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_10(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, )
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_11(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=False)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_12(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = None
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_13(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(None)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_14(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(1.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_15(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = None
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_16(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(None)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_17(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(1.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_18(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = None
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_19(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 + q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_20(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = None
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_21(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 + self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_22(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier / iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_23(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = None
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_24(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 - self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_25(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier / iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_26(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = None
        return self

    def xǁIQRDetectorǁfit__mutmut_27(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(None, np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_28(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, None)
        return self

    def xǁIQRDetectorǁfit__mutmut_29(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(np.nan)
        return self

    def xǁIQRDetectorǁfit__mutmut_30(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(0, )
        return self

    def xǁIQRDetectorǁfit__mutmut_31(self, df: pd.DataFrame) -> Self:
        cols = self._user_columns or df.select_dtypes(include=np.number).columns.tolist()
        values = numeric_features(df, cols, training=True)
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        self._lower = q1 - self.multiplier * iqr
        self._upper = q3 + self.multiplier * iqr
        # Column width used to normalize exceedances into a comparable score.
        self._scale = iqr.replace(1, np.nan)
        return self

    @_mutmut_mutated(mutants_xǁIQRDetectorǁ_exceedance__mutmut)
    def _exceedance(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_orig(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_1(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None and self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_2(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is not None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_3(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is not None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_4(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(None)
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_5(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = None
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_6(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = None
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_7(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(None, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_8(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, None, training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_9(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=None)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_10(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_11(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_12(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), )
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_13(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(None), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_14(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=True)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_15(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = None
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_16(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower + values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_17(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = None
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_18(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values + self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_19(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, above).div(None)

    def xǁIQRDetectorǁ_exceedance__mutmut_20(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(None, above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_21(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, None).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_22(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(above).div(self._scale)

    def xǁIQRDetectorǁ_exceedance__mutmut_23(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._lower is None or self._upper is None:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")
        cols = self._lower.index
        values = numeric_features(df, list(cols), training=False)
        below = self._lower - values
        above = values - self._upper
        # How far outside the fence, in IQR units; <=0 when inside.
        return np.maximum(below, ).div(self._scale)

    @_mutmut_mutated(mutants_xǁIQRDetectorǁpredict__mutmut)
    def predict(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).gt(0).any(axis=1)

    def xǁIQRDetectorǁpredict__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).gt(0).any(axis=1)

    def xǁIQRDetectorǁpredict__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).gt(0).any(axis=None)

    def xǁIQRDetectorǁpredict__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).gt(None).any(axis=1)

    def xǁIQRDetectorǁpredict__mutmut_3(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(None).gt(0).any(axis=1)

    def xǁIQRDetectorǁpredict__mutmut_4(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).gt(1).any(axis=1)

    def xǁIQRDetectorǁpredict__mutmut_5(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).gt(0).any(axis=2)

    @_mutmut_mutated(mutants_xǁIQRDetectorǁscore__mutmut)
    def score(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).clip(lower=0).max(axis=1).fillna(0.0)

    def xǁIQRDetectorǁscore__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).clip(lower=0).max(axis=1).fillna(0.0)

    def xǁIQRDetectorǁscore__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).clip(lower=0).max(axis=1).fillna(None)

    def xǁIQRDetectorǁscore__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).clip(lower=0).max(axis=None).fillna(0.0)

    def xǁIQRDetectorǁscore__mutmut_3(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).clip(lower=None).max(axis=1).fillna(0.0)

    def xǁIQRDetectorǁscore__mutmut_4(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(None).clip(lower=0).max(axis=1).fillna(0.0)

    def xǁIQRDetectorǁscore__mutmut_5(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).clip(lower=1).max(axis=1).fillna(0.0)

    def xǁIQRDetectorǁscore__mutmut_6(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).clip(lower=0).max(axis=2).fillna(0.0)

    def xǁIQRDetectorǁscore__mutmut_7(self, df: pd.DataFrame) -> pd.Series:
        return self._exceedance(df).clip(lower=0).max(axis=1).fillna(1.0)

mutants_xǁIQRDetectorǁ__init____mutmut['_mutmut_orig'] = IQRDetector.xǁIQRDetectorǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ__init____mutmut['xǁIQRDetectorǁ__init____mutmut_1'] = IQRDetector.xǁIQRDetectorǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ__init____mutmut['xǁIQRDetectorǁ__init____mutmut_2'] = IQRDetector.xǁIQRDetectorǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ__init____mutmut['xǁIQRDetectorǁ__init____mutmut_3'] = IQRDetector.xǁIQRDetectorǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ__init____mutmut['xǁIQRDetectorǁ__init____mutmut_4'] = IQRDetector.xǁIQRDetectorǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ__init____mutmut['xǁIQRDetectorǁ__init____mutmut_5'] = IQRDetector.xǁIQRDetectorǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ__init____mutmut['xǁIQRDetectorǁ__init____mutmut_6'] = IQRDetector.xǁIQRDetectorǁ__init____mutmut_6 # type: ignore # mutmut generated

mutants_xǁIQRDetectorǁfit__mutmut['_mutmut_orig'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_orig # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_1'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_1 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_2'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_2 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_3'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_3 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_4'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_4 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_5'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_5 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_6'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_6 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_7'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_7 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_8'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_8 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_9'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_9 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_10'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_10 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_11'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_11 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_12'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_12 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_13'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_13 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_14'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_14 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_15'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_15 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_16'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_16 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_17'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_17 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_18'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_18 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_19'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_19 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_20'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_20 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_21'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_21 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_22'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_22 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_23'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_23 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_24'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_24 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_25'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_25 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_26'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_26 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_27'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_27 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_28'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_28 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_29'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_29 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_30'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_30 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁfit__mutmut['xǁIQRDetectorǁfit__mutmut_31'] = IQRDetector.xǁIQRDetectorǁfit__mutmut_31 # type: ignore # mutmut generated

mutants_xǁIQRDetectorǁ_exceedance__mutmut['_mutmut_orig'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_orig # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_1'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_1 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_2'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_2 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_3'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_3 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_4'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_4 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_5'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_5 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_6'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_6 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_7'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_7 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_8'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_8 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_9'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_9 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_10'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_10 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_11'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_11 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_12'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_12 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_13'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_13 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_14'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_14 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_15'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_15 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_16'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_16 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_17'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_17 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_18'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_18 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_19'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_19 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_20'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_20 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_21'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_21 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_22'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_22 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁ_exceedance__mutmut['xǁIQRDetectorǁ_exceedance__mutmut_23'] = IQRDetector.xǁIQRDetectorǁ_exceedance__mutmut_23 # type: ignore # mutmut generated

mutants_xǁIQRDetectorǁpredict__mutmut['_mutmut_orig'] = IQRDetector.xǁIQRDetectorǁpredict__mutmut_orig # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁpredict__mutmut['xǁIQRDetectorǁpredict__mutmut_1'] = IQRDetector.xǁIQRDetectorǁpredict__mutmut_1 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁpredict__mutmut['xǁIQRDetectorǁpredict__mutmut_2'] = IQRDetector.xǁIQRDetectorǁpredict__mutmut_2 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁpredict__mutmut['xǁIQRDetectorǁpredict__mutmut_3'] = IQRDetector.xǁIQRDetectorǁpredict__mutmut_3 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁpredict__mutmut['xǁIQRDetectorǁpredict__mutmut_4'] = IQRDetector.xǁIQRDetectorǁpredict__mutmut_4 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁpredict__mutmut['xǁIQRDetectorǁpredict__mutmut_5'] = IQRDetector.xǁIQRDetectorǁpredict__mutmut_5 # type: ignore # mutmut generated

mutants_xǁIQRDetectorǁscore__mutmut['_mutmut_orig'] = IQRDetector.xǁIQRDetectorǁscore__mutmut_orig # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁscore__mutmut['xǁIQRDetectorǁscore__mutmut_1'] = IQRDetector.xǁIQRDetectorǁscore__mutmut_1 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁscore__mutmut['xǁIQRDetectorǁscore__mutmut_2'] = IQRDetector.xǁIQRDetectorǁscore__mutmut_2 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁscore__mutmut['xǁIQRDetectorǁscore__mutmut_3'] = IQRDetector.xǁIQRDetectorǁscore__mutmut_3 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁscore__mutmut['xǁIQRDetectorǁscore__mutmut_4'] = IQRDetector.xǁIQRDetectorǁscore__mutmut_4 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁscore__mutmut['xǁIQRDetectorǁscore__mutmut_5'] = IQRDetector.xǁIQRDetectorǁscore__mutmut_5 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁscore__mutmut['xǁIQRDetectorǁscore__mutmut_6'] = IQRDetector.xǁIQRDetectorǁscore__mutmut_6 # type: ignore # mutmut generated
mutants_xǁIQRDetectorǁscore__mutmut['xǁIQRDetectorǁscore__mutmut_7'] = IQRDetector.xǁIQRDetectorǁscore__mutmut_7 # type: ignore # mutmut generated
