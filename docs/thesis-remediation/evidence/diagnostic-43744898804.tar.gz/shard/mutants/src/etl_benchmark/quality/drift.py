"""A time-aware detector for distributional drift.

The other detectors ignore the order of the rows. This one uses a
timestamp column. In :meth:`fit` it learns a per-feature baseline from the
oldest ``reference_frac`` of the rows. In :meth:`score` it measures how
far the *recent* window's mean has moved from that baseline, on the
features that actually moved (the window drift ``w``), and, for each
recent row, how strongly the row leans in the same direction. A row
scores high only when the window has drifted *and* the row contributes to
that drift; a row that a single feature makes a gross outlier is
excluded, so this detector stays out of the univariate detectors' lane.

Injected drift is subtle on purpose: the shifted values stay inside the
global range, and after dilution by the many clean recent rows the window
shift is only about a tenth of a standard deviation. At that magnitude
this detector, like every other, recovers almost none of it, which is the
point: drift is a windowed-monitoring problem, not a per-row one. The
severity sweep shows its recall climbing once the injected shift is a few
times larger.

On a dataset without the timestamp column the detector fits to a silent
no-op, so it can sit in a shared detector list without special-casing.
"""

from __future__ import annotations

from typing import Self

import numpy as np
import pandas as pd

from etl_benchmark.quality.base import Detector


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_xǁTemporalDriftDetectorǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁTemporalDriftDetectorǁfit__mutmut: MutantDict = {}  # type: ignore
mutants_xǁTemporalDriftDetectorǁ_guard__mutmut: MutantDict = {}  # type: ignore
mutants_xǁTemporalDriftDetectorǁ_z__mutmut: MutantDict = {}  # type: ignore
mutants_xǁTemporalDriftDetectorǁ_is_recent__mutmut: MutantDict = {}  # type: ignore
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut: MutantDict = {}  # type: ignore
mutants_xǁTemporalDriftDetectorǁpredict__mutmut: MutantDict = {}  # type: ignore
mutants_xǁTemporalDriftDetectorǁscore__mutmut: MutantDict = {}  # type: ignore


class TemporalDriftDetector(Detector):
    name = "drift"

    @_mutmut_mutated(mutants_xǁTemporalDriftDetectorǁ__init____mutmut)
    def __init__(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_orig(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_1(
        self,
        time_column: str = "XXsignup_dateXX",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_2(
        self,
        time_column: str = "SIGNUP_DATE",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_3(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 1.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_4(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 1.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_5(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 6.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_6(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = None
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_7(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = None
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_8(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = None
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_9(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = None
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_10(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = None
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_11(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = None
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_12(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = True
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_13(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = None
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_14(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = True
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_15(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = ""
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_16(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = ""
        self._stds: pd.Series | None = None

    def xǁTemporalDriftDetectorǁ__init____mutmut_17(
        self,
        time_column: str = "signup_date",
        columns: list[str] | None = None,
        reference_frac: float = 0.6,
        threshold: float = 0.35,
        outlier_z: float = 5.0,
    ) -> None:
        self.time_column = time_column
        self._user_columns = columns
        self.reference_frac = reference_frac
        self.threshold = threshold
        self.outlier_z = outlier_z
        self._fitted = False
        self._active = False
        self._cutoff: object | None = None
        self._means: pd.Series | None = None
        self._stds: pd.Series | None = ""

    @_mutmut_mutated(mutants_xǁTemporalDriftDetectorǁfit__mutmut)
    def fit(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_orig(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_1(self, df: pd.DataFrame) -> Self:
        self._fitted = None
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_2(self, df: pd.DataFrame) -> Self:
        self._fitted = False
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_3(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_4(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = None
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_5(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = True
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_6(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = None
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_7(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = False
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_8(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = None
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_9(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = None
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_10(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(None, len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_11(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), None)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_12(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_13(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), )
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_14(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(None, 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_15(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), None), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_16(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_17(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), ), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_18(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(None), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_19(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) / self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_20(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 2), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_21(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) + 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_22(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 2)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_23(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = None
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_24(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = None

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_25(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = None
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_26(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns and reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_27(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=None).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_28(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = None
        self._stds = reference[cols].std().replace(0, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_29(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = None
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_30(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(None, np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_31(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, None)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_32(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(np.nan)
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_33(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(0, )
        return self

    def xǁTemporalDriftDetectorǁfit__mutmut_34(self, df: pd.DataFrame) -> Self:
        self._fitted = True
        if self.time_column not in df.columns:
            self._active = False
            return self

        self._active = True
        order = df[self.time_column].sort_values()
        cut = min(max(int(len(order) * self.reference_frac), 1), len(order) - 1)
        self._cutoff = order.iloc[cut]
        reference = df.loc[order.index[:cut]]

        cols = self._user_columns or reference.select_dtypes(include=np.number).columns.tolist()
        self._means = reference[cols].mean()
        self._stds = reference[cols].std().replace(1, np.nan)
        return self

    @_mutmut_mutated(mutants_xǁTemporalDriftDetectorǁ_guard__mutmut)
    def _guard(self) -> None:
        if not self._fitted:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

    def xǁTemporalDriftDetectorǁ_guard__mutmut_orig(self) -> None:
        if not self._fitted:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

    def xǁTemporalDriftDetectorǁ_guard__mutmut_1(self) -> None:
        if self._fitted:
            raise RuntimeError(f"{self.name} detector not fitted. Call fit() first.")

    def xǁTemporalDriftDetectorǁ_guard__mutmut_2(self) -> None:
        if not self._fitted:
            raise RuntimeError(None)

    @_mutmut_mutated(mutants_xǁTemporalDriftDetectorǁ_z__mutmut)
    def _z(self, df: pd.DataFrame) -> pd.DataFrame:
        cols = self._means.index
        return (df[cols] - self._means) / self._stds

    def xǁTemporalDriftDetectorǁ_z__mutmut_orig(self, df: pd.DataFrame) -> pd.DataFrame:
        cols = self._means.index
        return (df[cols] - self._means) / self._stds

    def xǁTemporalDriftDetectorǁ_z__mutmut_1(self, df: pd.DataFrame) -> pd.DataFrame:
        cols = None
        return (df[cols] - self._means) / self._stds

    def xǁTemporalDriftDetectorǁ_z__mutmut_2(self, df: pd.DataFrame) -> pd.DataFrame:
        cols = self._means.index
        return (df[cols] - self._means) * self._stds

    def xǁTemporalDriftDetectorǁ_z__mutmut_3(self, df: pd.DataFrame) -> pd.DataFrame:
        cols = self._means.index
        return (df[cols] + self._means) / self._stds

    @_mutmut_mutated(mutants_xǁTemporalDriftDetectorǁ_is_recent__mutmut)
    def _is_recent(self, df: pd.DataFrame) -> pd.Series:
        return df[self.time_column] >= self._cutoff

    def xǁTemporalDriftDetectorǁ_is_recent__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        return df[self.time_column] >= self._cutoff

    def xǁTemporalDriftDetectorǁ_is_recent__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        return df[self.time_column] > self._cutoff

    @_mutmut_mutated(mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut)
    def _row_score(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        z = None
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(None)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_3(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = None

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_4(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(None)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_5(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = None
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_6(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) <= 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_7(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 21:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_8(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(None, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_9(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=None)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_10(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_11(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, )

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_12(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(1.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_13(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = None  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_14(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = None  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_15(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() >= 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_16(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 1.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_17(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_18(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(None, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_19(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=None)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_20(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_21(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, )
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_22(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(1.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_23(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = None
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_24(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(None)
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_25(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = None

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_26(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(None)

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_27(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = None
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_28(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=None)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_29(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(None, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_30(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, None).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_31(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_32(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, ).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_33(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] / direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_34(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(1.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_35(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 5.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_36(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=2)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_37(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = None  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_38(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=None) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_39(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=2) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_40(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) >= self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_41(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = None
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_42(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w / lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_43(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = None
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_44(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 1.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_45(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(None)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_46(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row / np.where(recent, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_47(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(None, 1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_48(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, None, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_49(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, None)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_50(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(1.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_51(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_52(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, )).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_53(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 2.0, 0.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_54(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 1.2)).fillna(0.0)

    def xǁTemporalDriftDetectorǁ_row_score__mutmut_55(self, df: pd.DataFrame) -> pd.Series:
        z = self._z(df)
        recent = self._is_recent(df)

        window = z.loc[recent]
        if len(window) < 20:
            return pd.Series(0.0, index=df.index)

        shift = window.mean()  # per-feature mean shift of the recent window, in ref-std units
        moved = shift.abs() > 0.03  # features that actually drifted
        if not moved.any():
            return pd.Series(0.0, index=df.index)
        w = float(shift[moved].abs().max())
        direction = np.sign(shift[moved])

        # how strongly each row leans in the drift direction, on the drifted features only
        lean = (z.loc[:, moved.index[moved]] * direction).clip(0.0, 4.0).mean(axis=1)
        gross = z.abs().max(axis=1) > self.outlier_z  # leave single-feature outliers to others
        row = w * lean
        row[gross] = 0.0
        # keep a faint signal on non-recent rows so the ranking is still ordered
        return (row * np.where(recent, 1.0, 0.2)).fillna(1.0)

    @_mutmut_mutated(mutants_xǁTemporalDriftDetectorǁpredict__mutmut)
    def predict(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(False, index=df.index)
        return (self._row_score(df) > self.threshold) & self._is_recent(df)

    def xǁTemporalDriftDetectorǁpredict__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(False, index=df.index)
        return (self._row_score(df) > self.threshold) & self._is_recent(df)

    def xǁTemporalDriftDetectorǁpredict__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if self._active:
            return pd.Series(False, index=df.index)
        return (self._row_score(df) > self.threshold) & self._is_recent(df)

    def xǁTemporalDriftDetectorǁpredict__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(None, index=df.index)
        return (self._row_score(df) > self.threshold) & self._is_recent(df)

    def xǁTemporalDriftDetectorǁpredict__mutmut_3(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(False, index=None)
        return (self._row_score(df) > self.threshold) & self._is_recent(df)

    def xǁTemporalDriftDetectorǁpredict__mutmut_4(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(index=df.index)
        return (self._row_score(df) > self.threshold) & self._is_recent(df)

    def xǁTemporalDriftDetectorǁpredict__mutmut_5(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(False, )
        return (self._row_score(df) > self.threshold) & self._is_recent(df)

    def xǁTemporalDriftDetectorǁpredict__mutmut_6(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(True, index=df.index)
        return (self._row_score(df) > self.threshold) & self._is_recent(df)

    def xǁTemporalDriftDetectorǁpredict__mutmut_7(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(False, index=df.index)
        return (self._row_score(df) > self.threshold) | self._is_recent(df)

    def xǁTemporalDriftDetectorǁpredict__mutmut_8(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(False, index=df.index)
        return (self._row_score(None) > self.threshold) & self._is_recent(df)

    def xǁTemporalDriftDetectorǁpredict__mutmut_9(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(False, index=df.index)
        return (self._row_score(df) >= self.threshold) & self._is_recent(df)

    def xǁTemporalDriftDetectorǁpredict__mutmut_10(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(False, index=df.index)
        return (self._row_score(df) > self.threshold) & self._is_recent(None)

    @_mutmut_mutated(mutants_xǁTemporalDriftDetectorǁscore__mutmut)
    def score(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(0.0, index=df.index)
        return self._row_score(df)

    def xǁTemporalDriftDetectorǁscore__mutmut_orig(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(0.0, index=df.index)
        return self._row_score(df)

    def xǁTemporalDriftDetectorǁscore__mutmut_1(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if self._active:
            return pd.Series(0.0, index=df.index)
        return self._row_score(df)

    def xǁTemporalDriftDetectorǁscore__mutmut_2(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(None, index=df.index)
        return self._row_score(df)

    def xǁTemporalDriftDetectorǁscore__mutmut_3(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(0.0, index=None)
        return self._row_score(df)

    def xǁTemporalDriftDetectorǁscore__mutmut_4(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(index=df.index)
        return self._row_score(df)

    def xǁTemporalDriftDetectorǁscore__mutmut_5(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(0.0, )
        return self._row_score(df)

    def xǁTemporalDriftDetectorǁscore__mutmut_6(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(1.0, index=df.index)
        return self._row_score(df)

    def xǁTemporalDriftDetectorǁscore__mutmut_7(self, df: pd.DataFrame) -> pd.Series:
        self._guard()
        if not self._active:
            return pd.Series(0.0, index=df.index)
        return self._row_score(None)

mutants_xǁTemporalDriftDetectorǁ__init____mutmut['_mutmut_orig'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_1'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_2'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_3'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_4'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_5'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_6'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_6 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_7'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_7 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_8'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_8 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_9'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_9 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_10'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_10 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_11'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_11 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_12'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_12 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_13'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_13 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_14'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_14 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_15'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_15 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_16'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_16 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ__init____mutmut['xǁTemporalDriftDetectorǁ__init____mutmut_17'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ__init____mutmut_17 # type: ignore # mutmut generated

mutants_xǁTemporalDriftDetectorǁfit__mutmut['_mutmut_orig'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_1'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_2'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_2 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_3'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_3 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_4'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_4 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_5'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_5 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_6'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_6 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_7'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_7 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_8'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_8 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_9'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_9 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_10'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_10 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_11'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_11 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_12'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_12 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_13'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_13 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_14'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_14 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_15'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_15 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_16'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_16 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_17'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_17 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_18'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_18 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_19'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_19 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_20'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_20 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_21'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_21 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_22'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_22 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_23'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_23 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_24'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_24 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_25'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_25 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_26'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_26 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_27'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_27 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_28'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_28 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_29'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_29 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_30'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_30 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_31'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_31 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_32'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_32 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_33'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_33 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁfit__mutmut['xǁTemporalDriftDetectorǁfit__mutmut_34'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁfit__mutmut_34 # type: ignore # mutmut generated

mutants_xǁTemporalDriftDetectorǁ_guard__mutmut['_mutmut_orig'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_guard__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_guard__mutmut['xǁTemporalDriftDetectorǁ_guard__mutmut_1'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_guard__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_guard__mutmut['xǁTemporalDriftDetectorǁ_guard__mutmut_2'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_guard__mutmut_2 # type: ignore # mutmut generated

mutants_xǁTemporalDriftDetectorǁ_z__mutmut['_mutmut_orig'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_z__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_z__mutmut['xǁTemporalDriftDetectorǁ_z__mutmut_1'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_z__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_z__mutmut['xǁTemporalDriftDetectorǁ_z__mutmut_2'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_z__mutmut_2 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_z__mutmut['xǁTemporalDriftDetectorǁ_z__mutmut_3'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_z__mutmut_3 # type: ignore # mutmut generated

mutants_xǁTemporalDriftDetectorǁ_is_recent__mutmut['_mutmut_orig'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_is_recent__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_is_recent__mutmut['xǁTemporalDriftDetectorǁ_is_recent__mutmut_1'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_is_recent__mutmut_1 # type: ignore # mutmut generated

mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['_mutmut_orig'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_1'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_2'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_2 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_3'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_3 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_4'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_4 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_5'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_5 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_6'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_6 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_7'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_7 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_8'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_8 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_9'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_9 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_10'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_10 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_11'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_11 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_12'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_12 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_13'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_13 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_14'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_14 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_15'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_15 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_16'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_16 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_17'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_17 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_18'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_18 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_19'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_19 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_20'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_20 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_21'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_21 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_22'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_22 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_23'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_23 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_24'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_24 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_25'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_25 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_26'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_26 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_27'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_27 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_28'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_28 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_29'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_29 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_30'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_30 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_31'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_31 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_32'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_32 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_33'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_33 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_34'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_34 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_35'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_35 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_36'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_36 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_37'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_37 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_38'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_38 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_39'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_39 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_40'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_40 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_41'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_41 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_42'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_42 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_43'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_43 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_44'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_44 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_45'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_45 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_46'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_46 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_47'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_47 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_48'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_48 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_49'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_49 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_50'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_50 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_51'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_51 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_52'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_52 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_53'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_53 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_54'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_54 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁ_row_score__mutmut['xǁTemporalDriftDetectorǁ_row_score__mutmut_55'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁ_row_score__mutmut_55 # type: ignore # mutmut generated

mutants_xǁTemporalDriftDetectorǁpredict__mutmut['_mutmut_orig'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁpredict__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁpredict__mutmut['xǁTemporalDriftDetectorǁpredict__mutmut_1'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁpredict__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁpredict__mutmut['xǁTemporalDriftDetectorǁpredict__mutmut_2'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁpredict__mutmut_2 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁpredict__mutmut['xǁTemporalDriftDetectorǁpredict__mutmut_3'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁpredict__mutmut_3 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁpredict__mutmut['xǁTemporalDriftDetectorǁpredict__mutmut_4'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁpredict__mutmut_4 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁpredict__mutmut['xǁTemporalDriftDetectorǁpredict__mutmut_5'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁpredict__mutmut_5 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁpredict__mutmut['xǁTemporalDriftDetectorǁpredict__mutmut_6'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁpredict__mutmut_6 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁpredict__mutmut['xǁTemporalDriftDetectorǁpredict__mutmut_7'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁpredict__mutmut_7 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁpredict__mutmut['xǁTemporalDriftDetectorǁpredict__mutmut_8'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁpredict__mutmut_8 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁpredict__mutmut['xǁTemporalDriftDetectorǁpredict__mutmut_9'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁpredict__mutmut_9 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁpredict__mutmut['xǁTemporalDriftDetectorǁpredict__mutmut_10'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁpredict__mutmut_10 # type: ignore # mutmut generated

mutants_xǁTemporalDriftDetectorǁscore__mutmut['_mutmut_orig'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁscore__mutmut_orig # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁscore__mutmut['xǁTemporalDriftDetectorǁscore__mutmut_1'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁscore__mutmut_1 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁscore__mutmut['xǁTemporalDriftDetectorǁscore__mutmut_2'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁscore__mutmut_2 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁscore__mutmut['xǁTemporalDriftDetectorǁscore__mutmut_3'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁscore__mutmut_3 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁscore__mutmut['xǁTemporalDriftDetectorǁscore__mutmut_4'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁscore__mutmut_4 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁscore__mutmut['xǁTemporalDriftDetectorǁscore__mutmut_5'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁscore__mutmut_5 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁscore__mutmut['xǁTemporalDriftDetectorǁscore__mutmut_6'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁscore__mutmut_6 # type: ignore # mutmut generated
mutants_xǁTemporalDriftDetectorǁscore__mutmut['xǁTemporalDriftDetectorǁscore__mutmut_7'] = TemporalDriftDetector.xǁTemporalDriftDetectorǁscore__mutmut_7 # type: ignore # mutmut generated
