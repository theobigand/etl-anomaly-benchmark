"""Chronological window monitoring, separate from row-level detectors."""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x__times__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__times__mutmut)
def _times(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_orig(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_1(frame: pd.DataFrame, column: str) -> pd.Series:
    if column in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_2(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(None)
    try:
        times = pd.to_datetime(frame[column], utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_3(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = None
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_4(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(None, utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_5(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=None, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_6(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format=None)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_7(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_8(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_9(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, )
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_10(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=False, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_11(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format="XXmixedXX")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_12(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format="MIXED")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_13(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError(None) from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_14(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("XXinvalid timestampXX") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_15(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("INVALID TIMESTAMP") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")
    return times


def x__times__mutmut_16(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError(None)
    return times


def x__times__mutmut_17(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("XXmissing timestampXX")
    return times


def x__times__mutmut_18(frame: pd.DataFrame, column: str) -> pd.Series:
    if column not in frame:
        raise ValueError(f"missing timestamp column {column!r}")
    try:
        times = pd.to_datetime(frame[column], utc=True, format="mixed")
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("MISSING TIMESTAMP")
    return times

mutants_x__times__mutmut['_mutmut_orig'] = x__times__mutmut_orig # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_1'] = x__times__mutmut_1 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_2'] = x__times__mutmut_2 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_3'] = x__times__mutmut_3 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_4'] = x__times__mutmut_4 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_5'] = x__times__mutmut_5 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_6'] = x__times__mutmut_6 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_7'] = x__times__mutmut_7 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_8'] = x__times__mutmut_8 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_9'] = x__times__mutmut_9 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_10'] = x__times__mutmut_10 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_11'] = x__times__mutmut_11 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_12'] = x__times__mutmut_12 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_13'] = x__times__mutmut_13 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_14'] = x__times__mutmut_14 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_15'] = x__times__mutmut_15 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_16'] = x__times__mutmut_16 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_17'] = x__times__mutmut_17 # type: ignore # mutmut generated
mutants_x__times__mutmut['x__times__mutmut_18'] = x__times__mutmut_18 # type: ignore # mutmut generated
mutants_x__numeric__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__numeric__mutmut)
def _numeric(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_orig(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_1(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns and any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_2(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_3(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(None):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_4(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_5(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError(None)
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_6(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("XXmissing feature columnXX")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_7(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("MISSING FEATURE COLUMN")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_8(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = None
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_9(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(None)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_10(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_11(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(None):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_12(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(None) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_13(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError(None)
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_14(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("XXfeature columns must be numericXX")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_15(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("FEATURE COLUMNS MUST BE NUMERIC")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_16(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_17(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(None).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_18(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=None)).all():
        raise ValueError("feature columns must be finite")
    return values


def x__numeric__mutmut_19(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError(None)
    return values


def x__numeric__mutmut_20(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("XXfeature columns must be finiteXX")
    return values


def x__numeric__mutmut_21(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    if not columns or any(column not in frame for column in columns):
        raise ValueError("missing feature column")
    values = frame[list(columns)]
    if not all(pd.api.types.is_numeric_dtype(dtype) for dtype in values.dtypes):
        raise ValueError("feature columns must be numeric")
    if not np.isfinite(values.to_numpy(dtype=float)).all():
        raise ValueError("FEATURE COLUMNS MUST BE FINITE")
    return values

mutants_x__numeric__mutmut['_mutmut_orig'] = x__numeric__mutmut_orig # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_1'] = x__numeric__mutmut_1 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_2'] = x__numeric__mutmut_2 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_3'] = x__numeric__mutmut_3 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_4'] = x__numeric__mutmut_4 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_5'] = x__numeric__mutmut_5 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_6'] = x__numeric__mutmut_6 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_7'] = x__numeric__mutmut_7 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_8'] = x__numeric__mutmut_8 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_9'] = x__numeric__mutmut_9 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_10'] = x__numeric__mutmut_10 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_11'] = x__numeric__mutmut_11 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_12'] = x__numeric__mutmut_12 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_13'] = x__numeric__mutmut_13 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_14'] = x__numeric__mutmut_14 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_15'] = x__numeric__mutmut_15 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_16'] = x__numeric__mutmut_16 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_17'] = x__numeric__mutmut_17 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_18'] = x__numeric__mutmut_18 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_19'] = x__numeric__mutmut_19 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_20'] = x__numeric__mutmut_20 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_21'] = x__numeric__mutmut_21 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁWindowDriftMonitorǁfit__mutmut: MutantDict = {}  # type: ignore
mutants_xǁWindowDriftMonitorǁevaluate__mutmut: MutantDict = {}  # type: ignore


class WindowDriftMonitor:
    """Score complete future windows against a fixed training baseline.

    This is a distributional alert, not a per-row anomaly detector. Equal
    timestamps stay together, so each window may contain more than the
    requested minimum number of rows.
    """

    @_mutmut_mutated(mutants_xǁWindowDriftMonitorǁ__init____mutmut)
    def __init__(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_orig(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_1(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 21,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_2(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 3.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_3(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size <= 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_4(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 3:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_5(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError(None)
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_6(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("XXwindow_size must be at least twoXX")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_7(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("WINDOW_SIZE MUST BE AT LEAST TWO")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_8(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) and threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_9(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_10(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(None) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_11(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold < 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_12(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 1:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_13(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError(None)
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_14(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("XXthreshold must be positive and finiteXX")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_15(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("THRESHOLD MUST BE POSITIVE AND FINITE")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_16(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = None
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_17(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = None
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_18(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(None)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_19(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = None
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_20(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = None
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_21(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = ""
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_22(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = ""
        self._scale: pd.Series | None = None

    def xǁWindowDriftMonitorǁ__init____mutmut_23(
        self,
        time_column: str,
        columns: Sequence[str],
        *,
        window_size: int = 20,
        threshold: float = 2.0,
    ) -> None:
        if window_size < 2:
            raise ValueError("window_size must be at least two")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ValueError("threshold must be positive and finite")
        self.time_column = time_column
        self.columns = tuple(columns)
        self.window_size = window_size
        self.threshold = threshold
        self.reference_end: pd.Timestamp | None = None
        self._mean: pd.Series | None = None
        self._scale: pd.Series | None = ""

    @_mutmut_mutated(mutants_xǁWindowDriftMonitorǁfit__mutmut)
    def fit(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_orig(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_1(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) <= 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_2(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 3:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_3(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError(None)
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_4(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("XXreference needs at least two rowsXX")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_5(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("REFERENCE NEEDS AT LEAST TWO ROWS")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_6(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = None
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_7(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(None, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_8(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, None)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_9(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_10(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, )
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_11(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = None
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_12(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(None, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_13(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, None)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_14(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_15(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, )
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_16(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = None
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_17(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = None
        self._scale = values.std(ddof=0).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_18(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = None
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_19(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(None, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_20(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, None)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_21(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_22(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, )
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_23(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=None).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_24(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=1).replace(0.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_25(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(1.0, 1.0)
        return self

    def xǁWindowDriftMonitorǁfit__mutmut_26(self, reference: pd.DataFrame) -> WindowDriftMonitor:
        if len(reference) < 2:
            raise ValueError("reference needs at least two rows")
        times = _times(reference, self.time_column)
        values = _numeric(reference, self.columns)
        self.reference_end = times.max()
        self._mean = values.mean()
        self._scale = values.std(ddof=0).replace(0.0, 2.0)
        return self

    @_mutmut_mutated(mutants_xǁWindowDriftMonitorǁevaluate__mutmut)
    def evaluate(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_orig(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_1(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None and self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_2(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None and self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_3(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is not None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_4(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is not None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_5(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is not None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_6(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError(None)
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_7(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("XXmonitor not fittedXX")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_8(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("MONITOR NOT FITTED")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_9(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = None
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_10(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(None, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_11(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, None)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_12(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_13(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, )
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_14(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = None
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_15(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(None, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_16(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, None)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_17(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_18(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, )
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_19(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_20(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError(None)
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_21(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("XXfuture period is emptyXX")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_22(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("FUTURE PERIOD IS EMPTY")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_23(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() < self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_24(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError(None)

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_25(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("XXfuture period overlaps the referenceXX")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_26(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("FUTURE PERIOD OVERLAPS THE REFERENCE")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_27(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = None
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_28(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = None
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_29(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["XX_event_timeXX"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_30(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_EVENT_TIME"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_31(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = None
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_32(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(None)
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_33(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["XX_event_timeXX", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_34(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_EVENT_TIME", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_35(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = None
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_36(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = None
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_37(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = None
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_38(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 1
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_39(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby(None):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_40(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("XX_event_timeXX"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_41(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_EVENT_TIME"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_42(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(None)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_43(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count = len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_44(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count -= len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_45(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count <= self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_46(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                break
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_47(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = None
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_48(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(None)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_49(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = None
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_50(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) * self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_51(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() + self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_52(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(None)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_53(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = None
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_54(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(None)
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_55(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                None
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_56(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "XXwindow_startXX": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_57(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "WINDOW_START": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_58(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["XX_event_timeXX"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_59(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_EVENT_TIME"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_60(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "XXwindow_endXX": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_61(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "WINDOW_END": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_62(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["XX_event_timeXX"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_63(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_EVENT_TIME"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_64(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "XXn_rowsXX": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_65(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "N_ROWS": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_66(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "XXscoreXX": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_67(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "SCORE": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_68(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "XXalertXX": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_69(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "ALERT": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_70(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score >= self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_71(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = None
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_72(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = None
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_73(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 1
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_74(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            None, columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_75(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=None
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_76(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            columns=["window_start", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_77(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, )

    def xǁWindowDriftMonitorǁevaluate__mutmut_78(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["XXwindow_startXX", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_79(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["WINDOW_START", "window_end", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_80(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "XXwindow_endXX", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_81(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "WINDOW_END", "n_rows", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_82(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "XXn_rowsXX", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_83(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "N_ROWS", "score", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_84(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "XXscoreXX", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_85(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "SCORE", "alert"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_86(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "XXalertXX"]
        )

    def xǁWindowDriftMonitorǁevaluate__mutmut_87(self, future: pd.DataFrame) -> pd.DataFrame:
        if self.reference_end is None or self._mean is None or self._scale is None:
            raise RuntimeError("monitor not fitted")
        times = _times(future, self.time_column)
        values = _numeric(future, self.columns)
        if not len(future):
            raise ValueError("future period is empty")
        if times.min() <= self.reference_end:
            raise ValueError("future period overlaps the reference")

        ordered = values.copy()
        ordered["_event_time"] = times.to_numpy()
        ordered = ordered.sort_values(["_event_time", *self.columns])
        rows = []
        groups = []
        count = 0
        for _, group in ordered.groupby("_event_time"):
            groups.append(group)
            count += len(group)
            if count < self.window_size:
                continue
            window = pd.concat(groups)
            shift = (window[list(self.columns)].mean() - self._mean) / self._scale
            score = float(shift.abs().max())
            rows.append(
                {
                    "window_start": window["_event_time"].min(),
                    "window_end": window["_event_time"].max(),
                    "n_rows": count,
                    "score": score,
                    "alert": score > self.threshold,
                }
            )
            groups = []
            count = 0
        return pd.DataFrame(
            rows, columns=["window_start", "window_end", "n_rows", "score", "ALERT"]
        )

mutants_xǁWindowDriftMonitorǁ__init____mutmut['_mutmut_orig'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_1'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_2'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_3'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_4'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_5'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_6'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_6 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_7'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_7 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_8'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_8 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_9'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_9 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_10'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_10 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_11'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_11 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_12'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_12 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_13'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_13 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_14'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_14 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_15'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_15 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_16'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_16 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_17'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_17 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_18'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_18 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_19'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_19 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_20'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_20 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_21'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_21 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_22'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_22 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁ__init____mutmut['xǁWindowDriftMonitorǁ__init____mutmut_23'] = WindowDriftMonitor.xǁWindowDriftMonitorǁ__init____mutmut_23 # type: ignore # mutmut generated

mutants_xǁWindowDriftMonitorǁfit__mutmut['_mutmut_orig'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_orig # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_1'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_1 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_2'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_2 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_3'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_3 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_4'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_4 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_5'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_5 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_6'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_6 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_7'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_7 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_8'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_8 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_9'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_9 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_10'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_10 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_11'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_11 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_12'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_12 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_13'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_13 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_14'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_14 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_15'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_15 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_16'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_16 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_17'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_17 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_18'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_18 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_19'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_19 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_20'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_20 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_21'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_21 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_22'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_22 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_23'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_23 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_24'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_24 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_25'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_25 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁfit__mutmut['xǁWindowDriftMonitorǁfit__mutmut_26'] = WindowDriftMonitor.xǁWindowDriftMonitorǁfit__mutmut_26 # type: ignore # mutmut generated

mutants_xǁWindowDriftMonitorǁevaluate__mutmut['_mutmut_orig'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_orig # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_1'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_1 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_2'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_2 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_3'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_3 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_4'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_4 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_5'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_5 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_6'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_6 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_7'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_7 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_8'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_8 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_9'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_9 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_10'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_10 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_11'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_11 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_12'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_12 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_13'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_13 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_14'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_14 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_15'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_15 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_16'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_16 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_17'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_17 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_18'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_18 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_19'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_19 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_20'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_20 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_21'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_21 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_22'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_22 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_23'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_23 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_24'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_24 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_25'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_25 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_26'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_26 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_27'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_27 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_28'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_28 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_29'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_29 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_30'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_30 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_31'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_31 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_32'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_32 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_33'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_33 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_34'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_34 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_35'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_35 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_36'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_36 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_37'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_37 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_38'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_38 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_39'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_39 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_40'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_40 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_41'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_41 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_42'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_42 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_43'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_43 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_44'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_44 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_45'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_45 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_46'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_46 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_47'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_47 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_48'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_48 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_49'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_49 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_50'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_50 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_51'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_51 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_52'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_52 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_53'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_53 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_54'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_54 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_55'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_55 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_56'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_56 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_57'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_57 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_58'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_58 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_59'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_59 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_60'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_60 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_61'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_61 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_62'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_62 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_63'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_63 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_64'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_64 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_65'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_65 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_66'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_66 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_67'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_67 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_68'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_68 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_69'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_69 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_70'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_70 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_71'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_71 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_72'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_72 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_73'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_73 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_74'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_74 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_75'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_75 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_76'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_76 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_77'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_77 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_78'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_78 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_79'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_79 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_80'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_80 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_81'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_81 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_82'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_82 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_83'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_83 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_84'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_84 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_85'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_85 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_86'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_86 # type: ignore # mutmut generated
mutants_xǁWindowDriftMonitorǁevaluate__mutmut['xǁWindowDriftMonitorǁevaluate__mutmut_87'] = WindowDriftMonitor.xǁWindowDriftMonitorǁevaluate__mutmut_87 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_event_metrics__mutmut)
def event_metrics(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_orig(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_1(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty and not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_2(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_3(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(None):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_4(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"XXwindow_endXX", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_5(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"WINDOW_END", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_6(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "XXalertXX"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_7(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "ALERT"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_8(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError(None)
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_9(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("XXwindow results are requiredXX")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_10(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("WINDOW RESULTS ARE REQUIRED")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_11(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_12(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(None):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_13(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["XXalertXX"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_14(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["ALERT"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_15(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError(None)
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_16(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("XXalert must be booleanXX")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_17(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("ALERT MUST BE BOOLEAN")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_18(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = None
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_19(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(None)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_20(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = None
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_21(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if (cutoff.tzinfo is None) and False else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_22(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if (cutoff.tzinfo is None) or True else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_23(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize(None) if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_24(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("XXUTCXX") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_25(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("utc") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_26(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is not None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_27(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert(None)
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_28(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("XXUTCXX")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_29(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("utc")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_30(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = None
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_31(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(None, utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_32(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=None)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_33(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_34(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], )
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_35(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["XXwindow_endXX"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_36(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["WINDOW_END"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_37(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=False)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_38(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = None
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_39(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends <= cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_40(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = None
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_41(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) | windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_42(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[before & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_43(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["XXalertXX"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_44(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["ALERT"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_45(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = None  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_46(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "XXfalse_alarm_rateXX": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_47(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "FALSE_ALARM_RATE": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_48(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(None),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_49(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "XXalertXX"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_50(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "ALERT"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_51(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "XXdetectedXX": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_52(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "DETECTED": bool(not pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_53(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(None),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_54(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(pd.isna(first)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_55(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(None)),
        "detection_delay": first - cutoff,
    }


def x_event_metrics__mutmut_56(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "XXdetection_delayXX": first - cutoff,
    }


def x_event_metrics__mutmut_57(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "DETECTION_DELAY": first - cutoff,
    }


def x_event_metrics__mutmut_58(windows: pd.DataFrame, change_time: pd.Timestamp) -> dict:
    """Report window-level detection delay and pre-change false alarms."""
    if windows.empty or not {"window_end", "alert"}.issubset(windows):
        raise ValueError("window results are required")
    if not pd.api.types.is_bool_dtype(windows["alert"]):
        raise ValueError("alert must be boolean")
    cutoff = pd.Timestamp(change_time)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    ends = pd.to_datetime(windows["window_end"], utc=True)
    before = ends < cutoff
    after_alert = ends[(~before) & windows["alert"]]
    first = after_alert.min()  # NaT when no window alerted after the change
    return {
        "false_alarm_rate": float(windows.loc[before, "alert"].mean()),  # NaN without windows
        "detected": bool(not pd.isna(first)),
        "detection_delay": first + cutoff,
    }

mutants_x_event_metrics__mutmut['_mutmut_orig'] = x_event_metrics__mutmut_orig # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_1'] = x_event_metrics__mutmut_1 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_2'] = x_event_metrics__mutmut_2 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_3'] = x_event_metrics__mutmut_3 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_4'] = x_event_metrics__mutmut_4 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_5'] = x_event_metrics__mutmut_5 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_6'] = x_event_metrics__mutmut_6 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_7'] = x_event_metrics__mutmut_7 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_8'] = x_event_metrics__mutmut_8 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_9'] = x_event_metrics__mutmut_9 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_10'] = x_event_metrics__mutmut_10 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_11'] = x_event_metrics__mutmut_11 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_12'] = x_event_metrics__mutmut_12 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_13'] = x_event_metrics__mutmut_13 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_14'] = x_event_metrics__mutmut_14 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_15'] = x_event_metrics__mutmut_15 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_16'] = x_event_metrics__mutmut_16 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_17'] = x_event_metrics__mutmut_17 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_18'] = x_event_metrics__mutmut_18 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_19'] = x_event_metrics__mutmut_19 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_20'] = x_event_metrics__mutmut_20 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_21'] = x_event_metrics__mutmut_21 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_22'] = x_event_metrics__mutmut_22 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_23'] = x_event_metrics__mutmut_23 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_24'] = x_event_metrics__mutmut_24 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_25'] = x_event_metrics__mutmut_25 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_26'] = x_event_metrics__mutmut_26 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_27'] = x_event_metrics__mutmut_27 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_28'] = x_event_metrics__mutmut_28 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_29'] = x_event_metrics__mutmut_29 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_30'] = x_event_metrics__mutmut_30 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_31'] = x_event_metrics__mutmut_31 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_32'] = x_event_metrics__mutmut_32 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_33'] = x_event_metrics__mutmut_33 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_34'] = x_event_metrics__mutmut_34 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_35'] = x_event_metrics__mutmut_35 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_36'] = x_event_metrics__mutmut_36 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_37'] = x_event_metrics__mutmut_37 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_38'] = x_event_metrics__mutmut_38 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_39'] = x_event_metrics__mutmut_39 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_40'] = x_event_metrics__mutmut_40 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_41'] = x_event_metrics__mutmut_41 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_42'] = x_event_metrics__mutmut_42 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_43'] = x_event_metrics__mutmut_43 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_44'] = x_event_metrics__mutmut_44 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_45'] = x_event_metrics__mutmut_45 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_46'] = x_event_metrics__mutmut_46 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_47'] = x_event_metrics__mutmut_47 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_48'] = x_event_metrics__mutmut_48 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_49'] = x_event_metrics__mutmut_49 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_50'] = x_event_metrics__mutmut_50 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_51'] = x_event_metrics__mutmut_51 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_52'] = x_event_metrics__mutmut_52 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_53'] = x_event_metrics__mutmut_53 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_54'] = x_event_metrics__mutmut_54 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_55'] = x_event_metrics__mutmut_55 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_56'] = x_event_metrics__mutmut_56 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_57'] = x_event_metrics__mutmut_57 # type: ignore # mutmut generated
mutants_x_event_metrics__mutmut['x_event_metrics__mutmut_58'] = x_event_metrics__mutmut_58 # type: ignore # mutmut generated
