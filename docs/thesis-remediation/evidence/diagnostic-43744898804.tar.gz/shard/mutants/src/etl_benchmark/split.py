"""Stratified train / validation / test split.

The detectors are unsupervised: the label is never used to fit them. The
split still matters for an honest evaluation, so that a detector is fitted
on one part of the stream and scored on rows it has not seen. ``train`` is
used for fitting (and for reading off the anomaly prevalence that sets the
ML contamination), ``test`` carries the reported metrics, and ``val`` is
held back for hyper-parameter work.
"""

from __future__ import annotations

from math import isfinite

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from etl_benchmark import config


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x__check_ratios__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__check_ratios__mutmut)
def _check_ratios(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_orig(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_1(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r <= 0 for r in ratios) and abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_2(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3 and any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_3(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) == 3
        or any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_4(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 4
        or any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_5(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(None)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_6(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) and r <= 0 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_7(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_8(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(None) or r <= 0 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_9(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r < 0 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_10(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r <= 1 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_11(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(None) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_12(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(ratios) + 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_13(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(None) - 1.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_14(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(ratios) - 2.0) > 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_15(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(ratios) - 1.0) >= 1e-6
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_16(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1.000001
    ):
        raise ValueError(f"ratios must be three positive fractions summing to 1, got {ratios}")


def x__check_ratios__mutmut_17(ratios: tuple[float, float, float]) -> None:
    if (
        len(ratios) != 3
        or any(not isfinite(r) or r <= 0 for r in ratios)
        or abs(sum(ratios) - 1.0) > 1e-6
    ):
        raise ValueError(None)

mutants_x__check_ratios__mutmut['_mutmut_orig'] = x__check_ratios__mutmut_orig # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_1'] = x__check_ratios__mutmut_1 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_2'] = x__check_ratios__mutmut_2 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_3'] = x__check_ratios__mutmut_3 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_4'] = x__check_ratios__mutmut_4 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_5'] = x__check_ratios__mutmut_5 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_6'] = x__check_ratios__mutmut_6 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_7'] = x__check_ratios__mutmut_7 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_8'] = x__check_ratios__mutmut_8 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_9'] = x__check_ratios__mutmut_9 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_10'] = x__check_ratios__mutmut_10 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_11'] = x__check_ratios__mutmut_11 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_12'] = x__check_ratios__mutmut_12 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_13'] = x__check_ratios__mutmut_13 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_14'] = x__check_ratios__mutmut_14 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_15'] = x__check_ratios__mutmut_15 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_16'] = x__check_ratios__mutmut_16 # type: ignore # mutmut generated
mutants_x__check_ratios__mutmut['x__check_ratios__mutmut_17'] = x__check_ratios__mutmut_17 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_stratified_split__mutmut)
def stratified_split(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_orig(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_1(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(None)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_2(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_3(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError(None)
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_4(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("XXinput index must be unique so rows can be alignedXX")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_5(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("INPUT INDEX MUST BE UNIQUE SO ROWS CAN BE ALIGNED")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_6(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = None
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_7(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique and set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_8(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_9(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(None) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_10(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) == set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_11(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(None):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_12(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError(None)
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_13(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("XXstratification Series index must match the input indexXX")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_14(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_15(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("STRATIFICATION SERIES INDEX MUST MATCH THE INPUT INDEX")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_16(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = None
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_17(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(None)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_18(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = None

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_19(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = None
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_20(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        None,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_21(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=None,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_22(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=None,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_23(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=None,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_24(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_25(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_26(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_27(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_28(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = None
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_29(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = None
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_30(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        None,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_31(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=None,
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_32(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=None,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_33(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=None,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_34(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_35(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_36(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_37(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_38(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac * (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_39(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac - test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_40(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=None),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_41(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=False),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_42(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=None),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_43(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=False),
        test_df.reset_index(drop=True),
    )


def x_stratified_split__mutmut_44(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=None),
    )


def x_stratified_split__mutmut_45(
    df: pd.DataFrame,
    stratify_on: str | pd.Series,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
    seed: int = config.RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split ``df`` into train / val / test, keeping the class balance.

    ``stratify_on`` is a column name or an index-aligned Series. ``ratios``
    must be three positive fractions that sum to one. Each returned frame
    has a fresh 0..n-1 index.
    """
    _check_ratios(ratios)

    if not df.index.is_unique:
        raise ValueError("input index must be unique so rows can be aligned")
    if isinstance(stratify_on, str):
        strat = df[stratify_on]
    else:
        if not stratify_on.index.is_unique or set(stratify_on.index) != set(df.index):
            raise ValueError("stratification Series index must match the input index")
        strat = stratify_on.reindex(df.index)
    train_frac, val_frac, test_frac = ratios

    train_df, rest_df = train_test_split(
        df,
        train_size=train_frac,
        random_state=seed,
        stratify=strat,
    )
    rest_strat = strat.loc[rest_df.index]
    val_df, test_df = train_test_split(
        rest_df,
        test_size=test_frac / (val_frac + test_frac),
        random_state=seed,
        stratify=rest_strat,
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=False),
    )

mutants_x_stratified_split__mutmut['_mutmut_orig'] = x_stratified_split__mutmut_orig # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_1'] = x_stratified_split__mutmut_1 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_2'] = x_stratified_split__mutmut_2 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_3'] = x_stratified_split__mutmut_3 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_4'] = x_stratified_split__mutmut_4 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_5'] = x_stratified_split__mutmut_5 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_6'] = x_stratified_split__mutmut_6 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_7'] = x_stratified_split__mutmut_7 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_8'] = x_stratified_split__mutmut_8 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_9'] = x_stratified_split__mutmut_9 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_10'] = x_stratified_split__mutmut_10 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_11'] = x_stratified_split__mutmut_11 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_12'] = x_stratified_split__mutmut_12 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_13'] = x_stratified_split__mutmut_13 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_14'] = x_stratified_split__mutmut_14 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_15'] = x_stratified_split__mutmut_15 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_16'] = x_stratified_split__mutmut_16 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_17'] = x_stratified_split__mutmut_17 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_18'] = x_stratified_split__mutmut_18 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_19'] = x_stratified_split__mutmut_19 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_20'] = x_stratified_split__mutmut_20 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_21'] = x_stratified_split__mutmut_21 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_22'] = x_stratified_split__mutmut_22 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_23'] = x_stratified_split__mutmut_23 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_24'] = x_stratified_split__mutmut_24 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_25'] = x_stratified_split__mutmut_25 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_26'] = x_stratified_split__mutmut_26 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_27'] = x_stratified_split__mutmut_27 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_28'] = x_stratified_split__mutmut_28 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_29'] = x_stratified_split__mutmut_29 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_30'] = x_stratified_split__mutmut_30 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_31'] = x_stratified_split__mutmut_31 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_32'] = x_stratified_split__mutmut_32 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_33'] = x_stratified_split__mutmut_33 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_34'] = x_stratified_split__mutmut_34 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_35'] = x_stratified_split__mutmut_35 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_36'] = x_stratified_split__mutmut_36 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_37'] = x_stratified_split__mutmut_37 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_38'] = x_stratified_split__mutmut_38 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_39'] = x_stratified_split__mutmut_39 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_40'] = x_stratified_split__mutmut_40 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_41'] = x_stratified_split__mutmut_41 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_42'] = x_stratified_split__mutmut_42 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_43'] = x_stratified_split__mutmut_43 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_44'] = x_stratified_split__mutmut_44 # type: ignore # mutmut generated
mutants_x_stratified_split__mutmut['x_stratified_split__mutmut_45'] = x_stratified_split__mutmut_45 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_chronological_split__mutmut)
def chronological_split(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_orig(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_1(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(None)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_2(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_3(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(None)
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_4(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = None
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_5(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(None, utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_6(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=None)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_7(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_8(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], )
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_9(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=False)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_10(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError(None) from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_11(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("XXinvalid timestampXX") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_12(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("INVALID TIMESTAMP") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_13(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError(None)

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_14(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("XXmissing timestampXX")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_15(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("MISSING TIMESTAMP")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_16(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = None
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_17(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(None, kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_18(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind=None)
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_19(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_20(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), )
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_21(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="XXstableXX")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_22(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="STABLE")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_23(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = None
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_24(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = None
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_25(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) - 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_26(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(None) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_27(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[2:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_28(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] == sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_29(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:+1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_30(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-2]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_31(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 2
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_32(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) <= 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_33(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 3:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_34(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError(None)

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_35(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("XXthree distinct timestamp groups are requiredXX")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_36(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("THREE DISTINCT TIMESTAMP GROUPS ARE REQUIRED")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_37(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = None
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_38(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) / ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_39(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[1]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_40(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = None
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_41(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(None)
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_42(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:+1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_43(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-2][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_44(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(None).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_45(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] + target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_46(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:+1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_47(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-2] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_48(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = None
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_49(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries >= first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_50(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = None
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_51(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) / (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_52(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] - ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_53(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[1] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_54(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[2])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_55(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = None
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_56(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(None)
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_57(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(None).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_58(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later + target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_59(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = None
    return tuple(
        part.reset_index(drop=True)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_60(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        None
    )


def x_chronological_split__mutmut_61(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=None)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )


def x_chronological_split__mutmut_62(
    df: pd.DataFrame,
    time_column: str,
    ratios: tuple[float, float, float] = config.SPLIT_RATIOS,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by event time, keeping equal timestamps in the same partition."""
    _check_ratios(ratios)
    if time_column not in df:
        raise ValueError(f"missing timestamp column {time_column!r}")
    try:
        times = pd.to_datetime(df[time_column], utc=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid timestamp") from exc
    if times.isna().any():
        raise ValueError("missing timestamp")

    positions = np.argsort(times.to_numpy(), kind="stable")
    sorted_times = times.iloc[positions].to_numpy()
    boundaries = np.flatnonzero(sorted_times[1:] != sorted_times[:-1]) + 1
    if len(boundaries) < 2:
        raise ValueError("three distinct timestamp groups are required")

    target_train = len(df) * ratios[0]
    first = int(boundaries[:-1][np.abs(boundaries[:-1] - target_train).argmin()])
    later = boundaries[boundaries > first]
    target_val = len(df) * (ratios[0] + ratios[1])
    second = int(later[np.abs(later - target_val).argmin()])
    ordered = df.iloc[positions]
    return tuple(
        part.reset_index(drop=False)
        for part in (ordered.iloc[:first], ordered.iloc[first:second], ordered.iloc[second:])
    )

mutants_x_chronological_split__mutmut['_mutmut_orig'] = x_chronological_split__mutmut_orig # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_1'] = x_chronological_split__mutmut_1 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_2'] = x_chronological_split__mutmut_2 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_3'] = x_chronological_split__mutmut_3 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_4'] = x_chronological_split__mutmut_4 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_5'] = x_chronological_split__mutmut_5 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_6'] = x_chronological_split__mutmut_6 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_7'] = x_chronological_split__mutmut_7 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_8'] = x_chronological_split__mutmut_8 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_9'] = x_chronological_split__mutmut_9 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_10'] = x_chronological_split__mutmut_10 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_11'] = x_chronological_split__mutmut_11 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_12'] = x_chronological_split__mutmut_12 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_13'] = x_chronological_split__mutmut_13 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_14'] = x_chronological_split__mutmut_14 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_15'] = x_chronological_split__mutmut_15 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_16'] = x_chronological_split__mutmut_16 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_17'] = x_chronological_split__mutmut_17 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_18'] = x_chronological_split__mutmut_18 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_19'] = x_chronological_split__mutmut_19 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_20'] = x_chronological_split__mutmut_20 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_21'] = x_chronological_split__mutmut_21 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_22'] = x_chronological_split__mutmut_22 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_23'] = x_chronological_split__mutmut_23 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_24'] = x_chronological_split__mutmut_24 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_25'] = x_chronological_split__mutmut_25 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_26'] = x_chronological_split__mutmut_26 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_27'] = x_chronological_split__mutmut_27 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_28'] = x_chronological_split__mutmut_28 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_29'] = x_chronological_split__mutmut_29 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_30'] = x_chronological_split__mutmut_30 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_31'] = x_chronological_split__mutmut_31 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_32'] = x_chronological_split__mutmut_32 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_33'] = x_chronological_split__mutmut_33 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_34'] = x_chronological_split__mutmut_34 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_35'] = x_chronological_split__mutmut_35 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_36'] = x_chronological_split__mutmut_36 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_37'] = x_chronological_split__mutmut_37 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_38'] = x_chronological_split__mutmut_38 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_39'] = x_chronological_split__mutmut_39 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_40'] = x_chronological_split__mutmut_40 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_41'] = x_chronological_split__mutmut_41 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_42'] = x_chronological_split__mutmut_42 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_43'] = x_chronological_split__mutmut_43 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_44'] = x_chronological_split__mutmut_44 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_45'] = x_chronological_split__mutmut_45 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_46'] = x_chronological_split__mutmut_46 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_47'] = x_chronological_split__mutmut_47 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_48'] = x_chronological_split__mutmut_48 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_49'] = x_chronological_split__mutmut_49 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_50'] = x_chronological_split__mutmut_50 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_51'] = x_chronological_split__mutmut_51 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_52'] = x_chronological_split__mutmut_52 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_53'] = x_chronological_split__mutmut_53 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_54'] = x_chronological_split__mutmut_54 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_55'] = x_chronological_split__mutmut_55 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_56'] = x_chronological_split__mutmut_56 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_57'] = x_chronological_split__mutmut_57 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_58'] = x_chronological_split__mutmut_58 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_59'] = x_chronological_split__mutmut_59 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_60'] = x_chronological_split__mutmut_60 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_61'] = x_chronological_split__mutmut_61 # type: ignore # mutmut generated
mutants_x_chronological_split__mutmut['x_chronological_split__mutmut_62'] = x_chronological_split__mutmut_62 # type: ignore # mutmut generated
