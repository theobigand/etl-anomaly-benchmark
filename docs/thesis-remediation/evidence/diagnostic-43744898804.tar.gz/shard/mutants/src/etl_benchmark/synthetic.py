"""Controlled synthetic dataset with six labelled anomaly types.

The real datasets in this benchmark (Credit Card Fraud, later UCI Water
Quality) carry a single binary label and mix every kind of defect
together. To measure *which detector catches which kind of problem* we
need a dataset where the anomaly category of every bad row is known. This
module builds one.

A base population of plausible customer records is generated with Faker
and NumPy (income correlated with balance and transaction size, tenure
spread over three years). Six anomaly types are then injected at a
controlled rate each, every injected row tagged in ``anomaly_type``:

    - ``missing_value``       — one or two feature cells nulled out;
    - ``duplicate``           — an exact copy of a clean row (appended);
    - ``univariate_outlier``  — one numeric field pushed far out of range;
    - ``multivariate_outlier``— each field in range, the combination not
      (e.g. an 18-year-old with a top-percentile balance and income);
    - ``temporal_drift``      — recent-signup rows whose income and
      balance distribution has shifted upward by ~50%;
    - ``invalid_format``      — malformed email, out-of-domain country
      code, impossible age.

:func:`make_synthetic` returns a single DataFrame; ``anomaly`` is the
binary ground truth and ``anomaly_type`` the fine-grained one.
:data:`FEATURE_COLUMNS` lists the columns a detector may look at (the
ground-truth columns and the id are excluded).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from faker import Faker

from etl_benchmark import config

ANOMALY_TYPES: list[str] = [
    "missing_value",
    "duplicate",
    "univariate_outlier",
    "multivariate_outlier",
    "temporal_drift",
    "invalid_format",
]

FEATURE_COLUMNS: list[str] = [
    "age",
    "annual_income",
    "account_balance",
    "n_transactions_30d",
    "avg_transaction_amount",
    "tenure_days",
    "signup_date",
    "email",
    "country",
]

NUMERIC_FEATURES: list[str] = [
    "age",
    "annual_income",
    "account_balance",
    "n_transactions_30d",
    "avg_transaction_amount",
    "tenure_days",
]

_COUNTRIES = ["FR", "DE", "ES", "IT", "BE", "NL", "PT"]
_REFERENCE_DATE = pd.Timestamp("2026-06-30")


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x__clean_population__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__clean_population__mutmut)
def _clean_population(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_orig(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_1(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = None
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_2(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(None, 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_3(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), None, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_4(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, None).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_5(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_6(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_7(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, ).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_8(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(None, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_9(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, None, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_10(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, None), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_11(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_12(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_13(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, ), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_14(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(43, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_15(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 14, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_16(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 19, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_17(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 89).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_18(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = None
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_19(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) - (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_20(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(None) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_21(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(None, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_22(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, None, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_23(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, None)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_24(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_25(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_26(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, )) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_27(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(11.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_28(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 1.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_29(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) / 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_30(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age + 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_31(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 43) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_32(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 351
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_33(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = None
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_34(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(None, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_35(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, None, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_36(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_37(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_38(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, )
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_39(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6001, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_40(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = None
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_41(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) - rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_42(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income / rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_43(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(None, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_44(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, None, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_45(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, None) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_46(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_47(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_48(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, ) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_49(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(1.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_50(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 1.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_51(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(None, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_52(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, None, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_53(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, None)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_54(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_55(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_56(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, )
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_57(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(1, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_58(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 801, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_59(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = None
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_60(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(None, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_61(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, None, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_62(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_63(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_64(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, )
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_65(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 1, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_66(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = None
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_67(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(None)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_68(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(None).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_69(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(None, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_70(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, None, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_71(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, None)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_72(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_73(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_74(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, )).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_75(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income * 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_76(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4001, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_77(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 3, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_78(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 91)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_79(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = None
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_80(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 / rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_81(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income * 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_82(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1201 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_83(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(None, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_84(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, None, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_85(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, None)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_86(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_87(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_88(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, )
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_89(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(1.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_90(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 2.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_91(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = None
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_92(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(None)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_93(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(None, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_94(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, None, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_95(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, None).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_96(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_97(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_98(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, ).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_99(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(31, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_100(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 / 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_101(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 4 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_102(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 366, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_103(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = None
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_104(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(None, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_105(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, None, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_106(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, None)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_107(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_108(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_109(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, )
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_110(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(91, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_111(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 / 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_112(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 4 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_113(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 366, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_114(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = None
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_115(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime(None) for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_116(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE + pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_117(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=None)).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_118(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(None))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_119(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("XX%Y-%m-%dXX") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_120(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_121(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%M-%D") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_122(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = None
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_123(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(None)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_124(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = None

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_125(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(None, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_126(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=None)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_127(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_128(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, )

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_129(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        None
    )


def x__clean_population__mutmut_130(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "XXageXX": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_131(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "AGE": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_132(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "XXannual_incomeXX": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_133(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "ANNUAL_INCOME": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_134(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(None),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_135(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(3),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_136(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "XXaccount_balanceXX": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_137(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "ACCOUNT_BALANCE": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_138(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(None),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_139(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(3),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_140(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "XXn_transactions_30dXX": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_141(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "N_TRANSACTIONS_30D": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_142(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "XXavg_transaction_amountXX": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_143(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "AVG_TRANSACTION_AMOUNT": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_144(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(None),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_145(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(3),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_146(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "XXtenure_daysXX": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_147(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "TENURE_DAYS": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_148(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "XXsignup_dateXX": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_149(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "SIGNUP_DATE": signup_date,
            "email": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_150(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "XXemailXX": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_151(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "EMAIL": email,
            "country": country,
        }
    )


def x__clean_population__mutmut_152(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "XXcountryXX": country,
        }
    )


def x__clean_population__mutmut_153(n: int, rng: np.random.Generator, fake: Faker) -> pd.DataFrame:
    age = np.clip(rng.normal(42, 13, n), 18, 88).round()
    annual_income = np.exp(rng.normal(10.6, 0.45, n)) + (age - 42) * 350
    annual_income = np.clip(annual_income, 6_000, None)
    account_balance = annual_income * rng.uniform(0.03, 0.55, n) + rng.normal(0, 800, n)
    account_balance = np.clip(account_balance, 0, None)
    n_transactions_30d = rng.poisson(np.clip(annual_income / 4_000, 2, 90)).astype(float)
    avg_transaction_amount = annual_income / 1_200 * rng.uniform(0.5, 1.6, n)
    tenure_days = rng.integers(30, 3 * 365, n).astype(float)
    offsets = rng.integers(90, 3 * 365, n)
    signup_date = [
        (_REFERENCE_DATE - pd.Timedelta(days=int(d))).strftime("%Y-%m-%d") for d in offsets
    ]
    email = [fake.email() for _ in range(n)]
    country = rng.choice(_COUNTRIES, size=n)

    return pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(2),
            "account_balance": account_balance.round(2),
            "n_transactions_30d": n_transactions_30d,
            "avg_transaction_amount": avg_transaction_amount.round(2),
            "tenure_days": tenure_days,
            "signup_date": signup_date,
            "email": email,
            "COUNTRY": country,
        }
    )

mutants_x__clean_population__mutmut['_mutmut_orig'] = x__clean_population__mutmut_orig # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_1'] = x__clean_population__mutmut_1 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_2'] = x__clean_population__mutmut_2 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_3'] = x__clean_population__mutmut_3 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_4'] = x__clean_population__mutmut_4 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_5'] = x__clean_population__mutmut_5 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_6'] = x__clean_population__mutmut_6 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_7'] = x__clean_population__mutmut_7 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_8'] = x__clean_population__mutmut_8 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_9'] = x__clean_population__mutmut_9 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_10'] = x__clean_population__mutmut_10 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_11'] = x__clean_population__mutmut_11 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_12'] = x__clean_population__mutmut_12 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_13'] = x__clean_population__mutmut_13 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_14'] = x__clean_population__mutmut_14 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_15'] = x__clean_population__mutmut_15 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_16'] = x__clean_population__mutmut_16 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_17'] = x__clean_population__mutmut_17 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_18'] = x__clean_population__mutmut_18 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_19'] = x__clean_population__mutmut_19 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_20'] = x__clean_population__mutmut_20 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_21'] = x__clean_population__mutmut_21 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_22'] = x__clean_population__mutmut_22 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_23'] = x__clean_population__mutmut_23 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_24'] = x__clean_population__mutmut_24 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_25'] = x__clean_population__mutmut_25 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_26'] = x__clean_population__mutmut_26 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_27'] = x__clean_population__mutmut_27 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_28'] = x__clean_population__mutmut_28 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_29'] = x__clean_population__mutmut_29 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_30'] = x__clean_population__mutmut_30 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_31'] = x__clean_population__mutmut_31 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_32'] = x__clean_population__mutmut_32 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_33'] = x__clean_population__mutmut_33 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_34'] = x__clean_population__mutmut_34 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_35'] = x__clean_population__mutmut_35 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_36'] = x__clean_population__mutmut_36 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_37'] = x__clean_population__mutmut_37 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_38'] = x__clean_population__mutmut_38 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_39'] = x__clean_population__mutmut_39 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_40'] = x__clean_population__mutmut_40 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_41'] = x__clean_population__mutmut_41 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_42'] = x__clean_population__mutmut_42 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_43'] = x__clean_population__mutmut_43 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_44'] = x__clean_population__mutmut_44 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_45'] = x__clean_population__mutmut_45 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_46'] = x__clean_population__mutmut_46 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_47'] = x__clean_population__mutmut_47 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_48'] = x__clean_population__mutmut_48 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_49'] = x__clean_population__mutmut_49 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_50'] = x__clean_population__mutmut_50 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_51'] = x__clean_population__mutmut_51 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_52'] = x__clean_population__mutmut_52 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_53'] = x__clean_population__mutmut_53 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_54'] = x__clean_population__mutmut_54 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_55'] = x__clean_population__mutmut_55 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_56'] = x__clean_population__mutmut_56 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_57'] = x__clean_population__mutmut_57 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_58'] = x__clean_population__mutmut_58 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_59'] = x__clean_population__mutmut_59 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_60'] = x__clean_population__mutmut_60 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_61'] = x__clean_population__mutmut_61 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_62'] = x__clean_population__mutmut_62 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_63'] = x__clean_population__mutmut_63 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_64'] = x__clean_population__mutmut_64 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_65'] = x__clean_population__mutmut_65 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_66'] = x__clean_population__mutmut_66 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_67'] = x__clean_population__mutmut_67 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_68'] = x__clean_population__mutmut_68 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_69'] = x__clean_population__mutmut_69 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_70'] = x__clean_population__mutmut_70 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_71'] = x__clean_population__mutmut_71 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_72'] = x__clean_population__mutmut_72 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_73'] = x__clean_population__mutmut_73 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_74'] = x__clean_population__mutmut_74 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_75'] = x__clean_population__mutmut_75 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_76'] = x__clean_population__mutmut_76 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_77'] = x__clean_population__mutmut_77 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_78'] = x__clean_population__mutmut_78 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_79'] = x__clean_population__mutmut_79 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_80'] = x__clean_population__mutmut_80 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_81'] = x__clean_population__mutmut_81 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_82'] = x__clean_population__mutmut_82 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_83'] = x__clean_population__mutmut_83 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_84'] = x__clean_population__mutmut_84 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_85'] = x__clean_population__mutmut_85 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_86'] = x__clean_population__mutmut_86 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_87'] = x__clean_population__mutmut_87 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_88'] = x__clean_population__mutmut_88 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_89'] = x__clean_population__mutmut_89 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_90'] = x__clean_population__mutmut_90 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_91'] = x__clean_population__mutmut_91 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_92'] = x__clean_population__mutmut_92 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_93'] = x__clean_population__mutmut_93 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_94'] = x__clean_population__mutmut_94 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_95'] = x__clean_population__mutmut_95 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_96'] = x__clean_population__mutmut_96 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_97'] = x__clean_population__mutmut_97 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_98'] = x__clean_population__mutmut_98 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_99'] = x__clean_population__mutmut_99 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_100'] = x__clean_population__mutmut_100 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_101'] = x__clean_population__mutmut_101 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_102'] = x__clean_population__mutmut_102 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_103'] = x__clean_population__mutmut_103 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_104'] = x__clean_population__mutmut_104 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_105'] = x__clean_population__mutmut_105 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_106'] = x__clean_population__mutmut_106 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_107'] = x__clean_population__mutmut_107 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_108'] = x__clean_population__mutmut_108 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_109'] = x__clean_population__mutmut_109 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_110'] = x__clean_population__mutmut_110 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_111'] = x__clean_population__mutmut_111 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_112'] = x__clean_population__mutmut_112 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_113'] = x__clean_population__mutmut_113 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_114'] = x__clean_population__mutmut_114 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_115'] = x__clean_population__mutmut_115 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_116'] = x__clean_population__mutmut_116 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_117'] = x__clean_population__mutmut_117 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_118'] = x__clean_population__mutmut_118 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_119'] = x__clean_population__mutmut_119 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_120'] = x__clean_population__mutmut_120 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_121'] = x__clean_population__mutmut_121 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_122'] = x__clean_population__mutmut_122 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_123'] = x__clean_population__mutmut_123 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_124'] = x__clean_population__mutmut_124 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_125'] = x__clean_population__mutmut_125 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_126'] = x__clean_population__mutmut_126 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_127'] = x__clean_population__mutmut_127 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_128'] = x__clean_population__mutmut_128 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_129'] = x__clean_population__mutmut_129 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_130'] = x__clean_population__mutmut_130 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_131'] = x__clean_population__mutmut_131 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_132'] = x__clean_population__mutmut_132 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_133'] = x__clean_population__mutmut_133 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_134'] = x__clean_population__mutmut_134 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_135'] = x__clean_population__mutmut_135 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_136'] = x__clean_population__mutmut_136 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_137'] = x__clean_population__mutmut_137 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_138'] = x__clean_population__mutmut_138 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_139'] = x__clean_population__mutmut_139 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_140'] = x__clean_population__mutmut_140 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_141'] = x__clean_population__mutmut_141 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_142'] = x__clean_population__mutmut_142 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_143'] = x__clean_population__mutmut_143 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_144'] = x__clean_population__mutmut_144 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_145'] = x__clean_population__mutmut_145 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_146'] = x__clean_population__mutmut_146 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_147'] = x__clean_population__mutmut_147 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_148'] = x__clean_population__mutmut_148 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_149'] = x__clean_population__mutmut_149 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_150'] = x__clean_population__mutmut_150 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_151'] = x__clean_population__mutmut_151 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_152'] = x__clean_population__mutmut_152 # type: ignore # mutmut generated
mutants_x__clean_population__mutmut['x__clean_population__mutmut_153'] = x__clean_population__mutmut_153 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__inject_missing_value__mutmut)
def _inject_missing_value(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_orig(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_1(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = None
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_2(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "XXannual_incomeXX",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_3(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "ANNUAL_INCOME",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_4(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "XXaccount_balanceXX",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_5(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "ACCOUNT_BALANCE",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_6(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "XXavg_transaction_amountXX",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_7(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "AVG_TRANSACTION_AMOUNT",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_8(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "XXtenure_daysXX",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_9(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "TENURE_DAYS",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_10(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "XXn_transactions_30dXX",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_11(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "N_TRANSACTIONS_30D",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_12(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "XXemailXX",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_13(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "EMAIL",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_14(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "XXcountryXX",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_15(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "COUNTRY",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_16(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(None):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_17(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = None
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_18(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(None, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_19(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=None, replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_20(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=None)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_21(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_22(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_23(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), )
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_24(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(None), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_25(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(None, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_26(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, None)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_27(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_28(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, )), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_29(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(2, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_30(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 4)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_31(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=True)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = np.nan
    return block


def x__inject_missing_value__mutmut_32(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(col)] = None
    return block


def x__inject_missing_value__mutmut_33(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    nullable = [
        "annual_income",
        "account_balance",
        "avg_transaction_amount",
        "tenure_days",
        "n_transactions_30d",
        "email",
        "country",
    ]
    for pos in range(len(block)):
        cols = rng.choice(nullable, size=int(rng.integers(1, 3)), replace=False)
        for col in cols:
            block.iloc[pos, block.columns.get_loc(None)] = np.nan
    return block

mutants_x__inject_missing_value__mutmut['_mutmut_orig'] = x__inject_missing_value__mutmut_orig # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_1'] = x__inject_missing_value__mutmut_1 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_2'] = x__inject_missing_value__mutmut_2 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_3'] = x__inject_missing_value__mutmut_3 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_4'] = x__inject_missing_value__mutmut_4 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_5'] = x__inject_missing_value__mutmut_5 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_6'] = x__inject_missing_value__mutmut_6 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_7'] = x__inject_missing_value__mutmut_7 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_8'] = x__inject_missing_value__mutmut_8 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_9'] = x__inject_missing_value__mutmut_9 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_10'] = x__inject_missing_value__mutmut_10 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_11'] = x__inject_missing_value__mutmut_11 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_12'] = x__inject_missing_value__mutmut_12 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_13'] = x__inject_missing_value__mutmut_13 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_14'] = x__inject_missing_value__mutmut_14 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_15'] = x__inject_missing_value__mutmut_15 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_16'] = x__inject_missing_value__mutmut_16 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_17'] = x__inject_missing_value__mutmut_17 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_18'] = x__inject_missing_value__mutmut_18 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_19'] = x__inject_missing_value__mutmut_19 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_20'] = x__inject_missing_value__mutmut_20 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_21'] = x__inject_missing_value__mutmut_21 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_22'] = x__inject_missing_value__mutmut_22 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_23'] = x__inject_missing_value__mutmut_23 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_24'] = x__inject_missing_value__mutmut_24 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_25'] = x__inject_missing_value__mutmut_25 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_26'] = x__inject_missing_value__mutmut_26 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_27'] = x__inject_missing_value__mutmut_27 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_28'] = x__inject_missing_value__mutmut_28 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_29'] = x__inject_missing_value__mutmut_29 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_30'] = x__inject_missing_value__mutmut_30 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_31'] = x__inject_missing_value__mutmut_31 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_32'] = x__inject_missing_value__mutmut_32 # type: ignore # mutmut generated
mutants_x__inject_missing_value__mutmut['x__inject_missing_value__mutmut_33'] = x__inject_missing_value__mutmut_33 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__inject_univariate_outlier__mutmut)
def _inject_univariate_outlier(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_orig(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_1(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(None):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_2(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = None
        factor = rng.uniform(15, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_3(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(None)
        factor = rng.uniform(15, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_4(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = None
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_5(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, 45) / severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_6(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(None, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_7(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, None) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_8(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_9(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, ) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_10(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(16, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_11(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, 46) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_12(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = None
    return block


def x__inject_univariate_outlier__mutmut_13(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, 45) * severity
        block.iloc[pos, block.columns.get_loc(None)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_14(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) * factor - factor
        )
    return block


def x__inject_univariate_outlier__mutmut_15(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(col)]) / factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_16(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(None) * factor + factor
        )
    return block


def x__inject_univariate_outlier__mutmut_17(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        col = rng.choice(NUMERIC_FEATURES)
        factor = rng.uniform(15, 45) * severity
        block.iloc[pos, block.columns.get_loc(col)] = (
            float(block.iloc[pos, block.columns.get_loc(None)]) * factor + factor
        )
    return block

mutants_x__inject_univariate_outlier__mutmut['_mutmut_orig'] = x__inject_univariate_outlier__mutmut_orig # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_1'] = x__inject_univariate_outlier__mutmut_1 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_2'] = x__inject_univariate_outlier__mutmut_2 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_3'] = x__inject_univariate_outlier__mutmut_3 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_4'] = x__inject_univariate_outlier__mutmut_4 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_5'] = x__inject_univariate_outlier__mutmut_5 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_6'] = x__inject_univariate_outlier__mutmut_6 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_7'] = x__inject_univariate_outlier__mutmut_7 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_8'] = x__inject_univariate_outlier__mutmut_8 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_9'] = x__inject_univariate_outlier__mutmut_9 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_10'] = x__inject_univariate_outlier__mutmut_10 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_11'] = x__inject_univariate_outlier__mutmut_11 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_12'] = x__inject_univariate_outlier__mutmut_12 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_13'] = x__inject_univariate_outlier__mutmut_13 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_14'] = x__inject_univariate_outlier__mutmut_14 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_15'] = x__inject_univariate_outlier__mutmut_15 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_16'] = x__inject_univariate_outlier__mutmut_16 # type: ignore # mutmut generated
mutants_x__inject_univariate_outlier__mutmut['x__inject_univariate_outlier__mutmut_17'] = x__inject_univariate_outlier__mutmut_17 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__inject_multivariate_outlier__mutmut)
def _inject_multivariate_outlier(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_orig(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_1(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = None
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_2(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(None, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_3(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, None)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_4(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_5(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, )
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_6(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 + 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_7(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(2.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_8(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 * severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_9(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 1.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_10(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 1.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_11(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = None
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_12(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(None, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_13(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, None)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_14(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_15(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, )
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_16(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 * severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_17(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(1.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_18(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 1.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_19(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = None
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_20(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(None)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_21(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["XXannual_incomeXX"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_22(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["ANNUAL_INCOME"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_23(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = None
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_24(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(None)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_25(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["XXaccount_balanceXX"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_26(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["ACCOUNT_BALANCE"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_27(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = None
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_28(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(None)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_29(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["XXn_transactions_30dXX"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_30(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["N_TRANSACTIONS_30D"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_31(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = None
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_32(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(None)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_33(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["XXavg_transaction_amountXX"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_34(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["AVG_TRANSACTION_AMOUNT"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_35(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(None):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_36(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos / 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_37(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 3 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_38(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 != 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_39(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 1:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_40(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = None
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_41(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc(None)] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_42(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("XXageXX")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_43(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("AGE")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_44(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(None)
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_45(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(None, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_46(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, None))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_47(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_48(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, ))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_49(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(19, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_50(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 24))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_51(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = None
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_52(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc(None)] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_53(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("XXannual_incomeXX")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_54(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("ANNUAL_INCOME")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_55(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(None)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_56(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = None
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_57(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc(None)] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_58(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("XXaccount_balanceXX")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_59(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("ACCOUNT_BALANCE")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_60(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(None)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_61(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = None
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_62(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc(None)] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_63(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("XXn_transactions_30dXX")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_64(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("N_TRANSACTIONS_30D")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_65(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(None)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_66(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = None
    return block


def x__inject_multivariate_outlier__mutmut_67(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc(None)] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_68(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("XXavg_transaction_amountXX")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_69(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("AVG_TRANSACTION_AMOUNT")] = float(lo_amount)
    return block


def x__inject_multivariate_outlier__mutmut_70(
    block: pd.DataFrame, rng: np.random.Generator, clean: pd.DataFrame, severity: float
) -> pd.DataFrame:
    # more severe -> a more extreme percentile of the clean marginals
    hi_q = min(1.0 - 0.03 / severity, 0.999)
    lo_q = max(0.03 / severity, 0.001)
    hi_income = clean["annual_income"].quantile(hi_q)
    hi_balance = clean["account_balance"].quantile(hi_q)
    hi_txn = clean["n_transactions_30d"].quantile(hi_q)
    lo_amount = clean["avg_transaction_amount"].quantile(lo_q)
    for pos in range(len(block)):
        if pos % 2 == 0:
            # young but top-percentile wealth: each value seen in clean data
            block.iloc[pos, block.columns.get_loc("age")] = float(rng.integers(18, 23))
            block.iloc[pos, block.columns.get_loc("annual_income")] = float(hi_income)
            block.iloc[pos, block.columns.get_loc("account_balance")] = float(hi_balance)
        else:
            # very active account with near-zero average ticket
            block.iloc[pos, block.columns.get_loc("n_transactions_30d")] = float(hi_txn)
            block.iloc[pos, block.columns.get_loc("avg_transaction_amount")] = float(None)
    return block

mutants_x__inject_multivariate_outlier__mutmut['_mutmut_orig'] = x__inject_multivariate_outlier__mutmut_orig # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_1'] = x__inject_multivariate_outlier__mutmut_1 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_2'] = x__inject_multivariate_outlier__mutmut_2 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_3'] = x__inject_multivariate_outlier__mutmut_3 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_4'] = x__inject_multivariate_outlier__mutmut_4 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_5'] = x__inject_multivariate_outlier__mutmut_5 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_6'] = x__inject_multivariate_outlier__mutmut_6 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_7'] = x__inject_multivariate_outlier__mutmut_7 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_8'] = x__inject_multivariate_outlier__mutmut_8 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_9'] = x__inject_multivariate_outlier__mutmut_9 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_10'] = x__inject_multivariate_outlier__mutmut_10 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_11'] = x__inject_multivariate_outlier__mutmut_11 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_12'] = x__inject_multivariate_outlier__mutmut_12 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_13'] = x__inject_multivariate_outlier__mutmut_13 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_14'] = x__inject_multivariate_outlier__mutmut_14 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_15'] = x__inject_multivariate_outlier__mutmut_15 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_16'] = x__inject_multivariate_outlier__mutmut_16 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_17'] = x__inject_multivariate_outlier__mutmut_17 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_18'] = x__inject_multivariate_outlier__mutmut_18 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_19'] = x__inject_multivariate_outlier__mutmut_19 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_20'] = x__inject_multivariate_outlier__mutmut_20 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_21'] = x__inject_multivariate_outlier__mutmut_21 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_22'] = x__inject_multivariate_outlier__mutmut_22 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_23'] = x__inject_multivariate_outlier__mutmut_23 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_24'] = x__inject_multivariate_outlier__mutmut_24 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_25'] = x__inject_multivariate_outlier__mutmut_25 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_26'] = x__inject_multivariate_outlier__mutmut_26 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_27'] = x__inject_multivariate_outlier__mutmut_27 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_28'] = x__inject_multivariate_outlier__mutmut_28 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_29'] = x__inject_multivariate_outlier__mutmut_29 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_30'] = x__inject_multivariate_outlier__mutmut_30 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_31'] = x__inject_multivariate_outlier__mutmut_31 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_32'] = x__inject_multivariate_outlier__mutmut_32 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_33'] = x__inject_multivariate_outlier__mutmut_33 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_34'] = x__inject_multivariate_outlier__mutmut_34 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_35'] = x__inject_multivariate_outlier__mutmut_35 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_36'] = x__inject_multivariate_outlier__mutmut_36 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_37'] = x__inject_multivariate_outlier__mutmut_37 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_38'] = x__inject_multivariate_outlier__mutmut_38 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_39'] = x__inject_multivariate_outlier__mutmut_39 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_40'] = x__inject_multivariate_outlier__mutmut_40 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_41'] = x__inject_multivariate_outlier__mutmut_41 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_42'] = x__inject_multivariate_outlier__mutmut_42 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_43'] = x__inject_multivariate_outlier__mutmut_43 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_44'] = x__inject_multivariate_outlier__mutmut_44 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_45'] = x__inject_multivariate_outlier__mutmut_45 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_46'] = x__inject_multivariate_outlier__mutmut_46 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_47'] = x__inject_multivariate_outlier__mutmut_47 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_48'] = x__inject_multivariate_outlier__mutmut_48 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_49'] = x__inject_multivariate_outlier__mutmut_49 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_50'] = x__inject_multivariate_outlier__mutmut_50 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_51'] = x__inject_multivariate_outlier__mutmut_51 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_52'] = x__inject_multivariate_outlier__mutmut_52 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_53'] = x__inject_multivariate_outlier__mutmut_53 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_54'] = x__inject_multivariate_outlier__mutmut_54 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_55'] = x__inject_multivariate_outlier__mutmut_55 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_56'] = x__inject_multivariate_outlier__mutmut_56 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_57'] = x__inject_multivariate_outlier__mutmut_57 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_58'] = x__inject_multivariate_outlier__mutmut_58 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_59'] = x__inject_multivariate_outlier__mutmut_59 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_60'] = x__inject_multivariate_outlier__mutmut_60 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_61'] = x__inject_multivariate_outlier__mutmut_61 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_62'] = x__inject_multivariate_outlier__mutmut_62 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_63'] = x__inject_multivariate_outlier__mutmut_63 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_64'] = x__inject_multivariate_outlier__mutmut_64 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_65'] = x__inject_multivariate_outlier__mutmut_65 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_66'] = x__inject_multivariate_outlier__mutmut_66 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_67'] = x__inject_multivariate_outlier__mutmut_67 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_68'] = x__inject_multivariate_outlier__mutmut_68 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_69'] = x__inject_multivariate_outlier__mutmut_69 # type: ignore # mutmut generated
mutants_x__inject_multivariate_outlier__mutmut['x__inject_multivariate_outlier__mutmut_70'] = x__inject_multivariate_outlier__mutmut_70 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__inject_temporal_drift__mutmut)
def _inject_temporal_drift(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_orig(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_1(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(None):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_2(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = None
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_3(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE + pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_4(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=None)
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_5(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(None))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_6(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(None, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_7(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, None)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_8(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_9(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, )))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_10(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(2, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_11(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 81)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_12(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = None
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_13(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc(None)] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_14(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("XXsignup_dateXX")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_15(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("SIGNUP_DATE")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_16(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime(None)
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_17(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("XX%Y-%m-%dXX")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_18(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_19(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%M-%D")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_20(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("XXannual_incomeXX", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_21(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("ANNUAL_INCOME", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_22(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 2.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_23(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("XXaccount_balanceXX", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_24(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("ACCOUNT_BALANCE", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_25(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 2.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_26(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("XXavg_transaction_amountXX", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_27(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("AVG_TRANSACTION_AMOUNT", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_28(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 2.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_29(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = None
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_30(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 - (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_31(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 2.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_32(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) / severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_33(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base + 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_34(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 2.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_35(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = None
    return block


def x__inject_temporal_drift__mutmut_36(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(None)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_37(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(col)]) / mult
            )
    return block


def x__inject_temporal_drift__mutmut_38(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(None) * mult
            )
    return block


def x__inject_temporal_drift__mutmut_39(
    block: pd.DataFrame, rng: np.random.Generator, severity: float
) -> pd.DataFrame:
    for pos in range(len(block)):
        recent = _REFERENCE_DATE - pd.Timedelta(days=int(rng.integers(1, 80)))
        block.iloc[pos, block.columns.get_loc("signup_date")] = recent.strftime("%Y-%m-%d")
        for col, base in (
            ("annual_income", 1.55),
            ("account_balance", 1.6),
            ("avg_transaction_amount", 1.5),
        ):
            mult = 1.0 + (base - 1.0) * severity
            block.iloc[pos, block.columns.get_loc(col)] = (
                float(block.iloc[pos, block.columns.get_loc(None)]) * mult
            )
    return block

mutants_x__inject_temporal_drift__mutmut['_mutmut_orig'] = x__inject_temporal_drift__mutmut_orig # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_1'] = x__inject_temporal_drift__mutmut_1 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_2'] = x__inject_temporal_drift__mutmut_2 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_3'] = x__inject_temporal_drift__mutmut_3 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_4'] = x__inject_temporal_drift__mutmut_4 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_5'] = x__inject_temporal_drift__mutmut_5 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_6'] = x__inject_temporal_drift__mutmut_6 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_7'] = x__inject_temporal_drift__mutmut_7 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_8'] = x__inject_temporal_drift__mutmut_8 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_9'] = x__inject_temporal_drift__mutmut_9 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_10'] = x__inject_temporal_drift__mutmut_10 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_11'] = x__inject_temporal_drift__mutmut_11 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_12'] = x__inject_temporal_drift__mutmut_12 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_13'] = x__inject_temporal_drift__mutmut_13 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_14'] = x__inject_temporal_drift__mutmut_14 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_15'] = x__inject_temporal_drift__mutmut_15 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_16'] = x__inject_temporal_drift__mutmut_16 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_17'] = x__inject_temporal_drift__mutmut_17 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_18'] = x__inject_temporal_drift__mutmut_18 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_19'] = x__inject_temporal_drift__mutmut_19 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_20'] = x__inject_temporal_drift__mutmut_20 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_21'] = x__inject_temporal_drift__mutmut_21 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_22'] = x__inject_temporal_drift__mutmut_22 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_23'] = x__inject_temporal_drift__mutmut_23 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_24'] = x__inject_temporal_drift__mutmut_24 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_25'] = x__inject_temporal_drift__mutmut_25 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_26'] = x__inject_temporal_drift__mutmut_26 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_27'] = x__inject_temporal_drift__mutmut_27 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_28'] = x__inject_temporal_drift__mutmut_28 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_29'] = x__inject_temporal_drift__mutmut_29 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_30'] = x__inject_temporal_drift__mutmut_30 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_31'] = x__inject_temporal_drift__mutmut_31 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_32'] = x__inject_temporal_drift__mutmut_32 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_33'] = x__inject_temporal_drift__mutmut_33 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_34'] = x__inject_temporal_drift__mutmut_34 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_35'] = x__inject_temporal_drift__mutmut_35 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_36'] = x__inject_temporal_drift__mutmut_36 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_37'] = x__inject_temporal_drift__mutmut_37 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_38'] = x__inject_temporal_drift__mutmut_38 # type: ignore # mutmut generated
mutants_x__inject_temporal_drift__mutmut['x__inject_temporal_drift__mutmut_39'] = x__inject_temporal_drift__mutmut_39 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__inject_invalid_format__mutmut)
def _inject_invalid_format(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_orig(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_1(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = None
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_2(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["XXnot-an-emailXX", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_3(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["NOT-AN-EMAIL", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_4(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "XXmissing.at.sign.comXX", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_5(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "MISSING.AT.SIGN.COM", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_6(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "XXjohn doe@exampleXX", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_7(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "JOHN DOE@EXAMPLE", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_8(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "XX@nodomain.comXX", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_9(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@NODOMAIN.COM", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_10(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "XXn/aXX"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_11(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "N/A"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_12(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = None
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_13(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [+5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_14(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-6.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_15(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, +1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_16(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -2.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_17(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 1.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_18(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 241.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_19(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 1000.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_20(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = None
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_21(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["XXZZXX", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_22(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["zz", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_23(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XXXXXX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_24(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "xx", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_25(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "XX??XX", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_26(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "XX1XX"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_27(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(None):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_28(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = None
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_29(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc(None)] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_30(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("XXemailXX")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_31(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("EMAIL")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_32(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(None)
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_33(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(None))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_34(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = None
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_35(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc(None)] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_36(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("XXageXX")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_37(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("AGE")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_38(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(None)
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_39(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(None))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_40(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = None
    return block


def x__inject_invalid_format__mutmut_41(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc(None)] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_42(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("XXcountryXX")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_43(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("COUNTRY")] = str(rng.choice(bad_countries))
    return block


def x__inject_invalid_format__mutmut_44(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(None)
    return block


def x__inject_invalid_format__mutmut_45(block: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    bad_emails = ["not-an-email", "missing.at.sign.com", "john doe@example", "@nodomain.com", "n/a"]
    bad_ages = [-5.0, -1.0, 0.0, 240.0, 999.0]
    bad_countries = ["ZZ", "XX", "??", "1"]
    for pos in range(len(block)):
        block.iloc[pos, block.columns.get_loc("email")] = str(rng.choice(bad_emails))
        block.iloc[pos, block.columns.get_loc("age")] = float(rng.choice(bad_ages))
        block.iloc[pos, block.columns.get_loc("country")] = str(rng.choice(None))
    return block

mutants_x__inject_invalid_format__mutmut['_mutmut_orig'] = x__inject_invalid_format__mutmut_orig # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_1'] = x__inject_invalid_format__mutmut_1 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_2'] = x__inject_invalid_format__mutmut_2 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_3'] = x__inject_invalid_format__mutmut_3 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_4'] = x__inject_invalid_format__mutmut_4 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_5'] = x__inject_invalid_format__mutmut_5 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_6'] = x__inject_invalid_format__mutmut_6 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_7'] = x__inject_invalid_format__mutmut_7 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_8'] = x__inject_invalid_format__mutmut_8 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_9'] = x__inject_invalid_format__mutmut_9 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_10'] = x__inject_invalid_format__mutmut_10 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_11'] = x__inject_invalid_format__mutmut_11 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_12'] = x__inject_invalid_format__mutmut_12 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_13'] = x__inject_invalid_format__mutmut_13 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_14'] = x__inject_invalid_format__mutmut_14 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_15'] = x__inject_invalid_format__mutmut_15 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_16'] = x__inject_invalid_format__mutmut_16 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_17'] = x__inject_invalid_format__mutmut_17 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_18'] = x__inject_invalid_format__mutmut_18 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_19'] = x__inject_invalid_format__mutmut_19 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_20'] = x__inject_invalid_format__mutmut_20 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_21'] = x__inject_invalid_format__mutmut_21 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_22'] = x__inject_invalid_format__mutmut_22 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_23'] = x__inject_invalid_format__mutmut_23 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_24'] = x__inject_invalid_format__mutmut_24 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_25'] = x__inject_invalid_format__mutmut_25 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_26'] = x__inject_invalid_format__mutmut_26 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_27'] = x__inject_invalid_format__mutmut_27 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_28'] = x__inject_invalid_format__mutmut_28 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_29'] = x__inject_invalid_format__mutmut_29 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_30'] = x__inject_invalid_format__mutmut_30 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_31'] = x__inject_invalid_format__mutmut_31 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_32'] = x__inject_invalid_format__mutmut_32 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_33'] = x__inject_invalid_format__mutmut_33 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_34'] = x__inject_invalid_format__mutmut_34 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_35'] = x__inject_invalid_format__mutmut_35 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_36'] = x__inject_invalid_format__mutmut_36 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_37'] = x__inject_invalid_format__mutmut_37 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_38'] = x__inject_invalid_format__mutmut_38 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_39'] = x__inject_invalid_format__mutmut_39 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_40'] = x__inject_invalid_format__mutmut_40 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_41'] = x__inject_invalid_format__mutmut_41 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_42'] = x__inject_invalid_format__mutmut_42 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_43'] = x__inject_invalid_format__mutmut_43 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_44'] = x__inject_invalid_format__mutmut_44 # type: ignore # mutmut generated
mutants_x__inject_invalid_format__mutmut['x__inject_invalid_format__mutmut_45'] = x__inject_invalid_format__mutmut_45 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_make_synthetic__mutmut)
def make_synthetic(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_orig(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_1(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 2.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_2(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) and n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_3(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_4(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows <= 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_5(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 91:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_6(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError(None)
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_7(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("XXn_rows must be an integer of at least 90XX")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_8(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("N_ROWS MUST BE AN INTEGER OF AT LEAST 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_9(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) and not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_10(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_11(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(None) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_12(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_13(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 1 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_14(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 < anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_15(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate < 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_16(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 * 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_17(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 2 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_18(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 7:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_19(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError(None)
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_20(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("XXanomaly_rate must be finite and between 0 and 1/6XX")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_21(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("ANOMALY_RATE MUST BE FINITE AND BETWEEN 0 AND 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_22(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) and severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_23(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_24(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(None) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_25(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity < 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_26(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 1:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_27(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError(None)
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_28(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("XXseverity must be finite and positiveXX")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_29(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("SEVERITY MUST BE FINITE AND POSITIVE")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_30(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = None
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_31(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if (anomaly_rate == 0) and False else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_32(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if (anomaly_rate == 0) or True else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_33(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 1 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_34(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate != 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_35(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 1 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_36(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(None, 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_37(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), None)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_38(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_39(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), )
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_40(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(None), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_41(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(None)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_42(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate / n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_43(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 16)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_44(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 / k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_45(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 7 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_46(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k >= n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_47(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError(None)

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_48(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("XXn_rows cannot hold six anomaly groups of the requested sizeXX")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_49(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("N_ROWS CANNOT HOLD SIX ANOMALY GROUPS OF THE REQUESTED SIZE")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_50(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = None
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_51(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(None)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_52(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(None)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_53(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = None

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_54(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker(None)

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_55(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("XXen_USXX")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_56(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_us")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_57(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("EN_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_58(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = None

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_59(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows + 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_60(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 / k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_61(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 6 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_62(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = None
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_63(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(None, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_64(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, None, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_65(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, None)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_66(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_67(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_68(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, )
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_69(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = None
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_70(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["XXcustomer_idXX"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_71(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["CUSTOMER_ID"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_72(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(None, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_73(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, None)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_74(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_75(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, )
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_76(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(2, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_77(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows - 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_78(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 2)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_79(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = None

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_80(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["XXanomaly_typeXX"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_81(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["ANOMALY_TYPE"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_82(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "XXcleanXX"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_83(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "CLEAN"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_84(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = None
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_85(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = None
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_86(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = None

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_87(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "XXmissing_valueXX": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_88(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "MISSING_VALUE": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_89(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: None,
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_90(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(None, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_91(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, None),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_92(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_93(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, ),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_94(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "XXunivariate_outlierXX": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_95(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "UNIVARIATE_OUTLIER": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_96(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: None,
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_97(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(None, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_98(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, None, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_99(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, None),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_100(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_101(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_102(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, ),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_103(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "XXmultivariate_outlierXX": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_104(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "MULTIVARIATE_OUTLIER": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_105(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: None,
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_106(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(None, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_107(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, None, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_108(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, None, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_109(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, None),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_110(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_111(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_112(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_113(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, ),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_114(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "XXtemporal_driftXX": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_115(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "TEMPORAL_DRIFT": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_116(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: None,
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_117(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(None, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_118(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, None, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_119(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, None),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_120(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_121(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_122(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, ),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_123(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "XXinvalid_formatXX": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_124(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "INVALID_FORMAT": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_125(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: None,
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_126(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(None, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_127(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, None),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_128(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_129(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, ),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_130(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = None
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_131(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = None
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_132(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor - k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_133(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor = k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_134(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor -= k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_135(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = None
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_136(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(None)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_137(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = None
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_138(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["XXanomaly_typeXX"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_139(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["ANOMALY_TYPE"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_140(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(None)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_141(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = None
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_142(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=None, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_143(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=None).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_144(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_145(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, ).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_146(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns=None).sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_147(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="XXanomaly_typeXX").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_148(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="ANOMALY_TYPE").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_149(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = None
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_150(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["XXanomaly_typeXX"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_151(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["ANOMALY_TYPE"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_152(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "XXduplicateXX"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_153(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "DUPLICATE"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_154(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(None)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_155(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = None
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_156(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(None)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_157(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = None

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_158(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["XXanomalyXX"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_159(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["ANOMALY"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_160(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["XXanomaly_typeXX"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_161(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["ANOMALY_TYPE"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_162(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] == "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_163(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "XXcleanXX"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_164(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "CLEAN"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_165(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = None
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_166(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=None, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_167(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=None, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_168(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=None)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_169(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_170(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_171(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, )
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_172(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=2.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_173(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=False)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_174(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["XXcustomer_idXX", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_175(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["CUSTOMER_ID", *FEATURE_COLUMNS, "anomaly", "anomaly_type"]]


def x_make_synthetic__mutmut_176(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "XXanomalyXX", "anomaly_type"]]


def x_make_synthetic__mutmut_177(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "ANOMALY", "anomaly_type"]]


def x_make_synthetic__mutmut_178(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "XXanomaly_typeXX"]]


def x_make_synthetic__mutmut_179(
    n_rows: int = config.SYNTHETIC_ROWS,
    anomaly_rate: float = config.SYNTHETIC_ANOMALY_RATE,
    seed: int = config.RANDOM_SEED,
    severity: float = 1.0,
) -> pd.DataFrame:
    """Build the labelled synthetic dataset.

    ``anomaly_rate`` is applied per anomaly type. The five in-place types
    replace clean rows (the total stays ``n_rows``); ``duplicate`` rows
    are appended, so the frame has about ``n_rows * (1 + anomaly_rate)``
    rows in the end.

    ``severity`` scales the magnitude of the injections that have a
    magnitude (univariate factor, multivariate percentile extremity,
    temporal-drift multiplier). ``severity=1.0`` is the reference dataset;
    ``missing_value``, ``duplicate`` and ``invalid_format`` do not depend
    on it.
    """
    if not isinstance(n_rows, int) or n_rows < 90:
        raise ValueError("n_rows must be an integer of at least 90")
    if not np.isfinite(anomaly_rate) or not 0 <= anomaly_rate <= 1 / 6:
        raise ValueError("anomaly_rate must be finite and between 0 and 1/6")
    if not np.isfinite(severity) or severity <= 0:
        raise ValueError("severity must be finite and positive")
    k = 0 if anomaly_rate == 0 else max(int(round(anomaly_rate * n_rows)), 15)
    if 6 * k > n_rows:
        raise ValueError("n_rows cannot hold six anomaly groups of the requested size")

    rng = np.random.default_rng(seed)
    Faker.seed(seed)
    fake = Faker("en_US")

    n_clean = n_rows - 5 * k

    pop = _clean_population(n_rows, rng, fake)
    pop["customer_id"] = np.arange(1, n_rows + 1)
    pop["anomaly_type"] = "clean"

    clean = pop.iloc[:n_clean].copy()
    cursor = n_clean
    injectors = {
        "missing_value": lambda b: _inject_missing_value(b, rng),
        "univariate_outlier": lambda b: _inject_univariate_outlier(b, rng, severity),
        "multivariate_outlier": lambda b: _inject_multivariate_outlier(b, rng, clean, severity),
        "temporal_drift": lambda b: _inject_temporal_drift(b, rng, severity),
        "invalid_format": lambda b: _inject_invalid_format(b, rng),
    }

    parts = [clean]
    for name, fn in injectors.items():
        block = pop.iloc[cursor : cursor + k].copy()
        cursor += k
        block = fn(block)
        block["anomaly_type"] = name
        parts.append(block)

    dups = clean.drop(columns="anomaly_type").sample(n=k, random_state=seed).copy()
    dups["anomaly_type"] = "duplicate"
    parts.append(dups)

    df = pd.concat(parts)
    df["anomaly"] = df["anomaly_type"] != "clean"

    df = df.sample(frac=1.0, random_state=seed, ignore_index=True)
    return df[["customer_id", *FEATURE_COLUMNS, "anomaly", "ANOMALY_TYPE"]]

mutants_x_make_synthetic__mutmut['_mutmut_orig'] = x_make_synthetic__mutmut_orig # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_1'] = x_make_synthetic__mutmut_1 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_2'] = x_make_synthetic__mutmut_2 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_3'] = x_make_synthetic__mutmut_3 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_4'] = x_make_synthetic__mutmut_4 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_5'] = x_make_synthetic__mutmut_5 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_6'] = x_make_synthetic__mutmut_6 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_7'] = x_make_synthetic__mutmut_7 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_8'] = x_make_synthetic__mutmut_8 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_9'] = x_make_synthetic__mutmut_9 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_10'] = x_make_synthetic__mutmut_10 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_11'] = x_make_synthetic__mutmut_11 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_12'] = x_make_synthetic__mutmut_12 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_13'] = x_make_synthetic__mutmut_13 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_14'] = x_make_synthetic__mutmut_14 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_15'] = x_make_synthetic__mutmut_15 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_16'] = x_make_synthetic__mutmut_16 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_17'] = x_make_synthetic__mutmut_17 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_18'] = x_make_synthetic__mutmut_18 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_19'] = x_make_synthetic__mutmut_19 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_20'] = x_make_synthetic__mutmut_20 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_21'] = x_make_synthetic__mutmut_21 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_22'] = x_make_synthetic__mutmut_22 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_23'] = x_make_synthetic__mutmut_23 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_24'] = x_make_synthetic__mutmut_24 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_25'] = x_make_synthetic__mutmut_25 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_26'] = x_make_synthetic__mutmut_26 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_27'] = x_make_synthetic__mutmut_27 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_28'] = x_make_synthetic__mutmut_28 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_29'] = x_make_synthetic__mutmut_29 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_30'] = x_make_synthetic__mutmut_30 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_31'] = x_make_synthetic__mutmut_31 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_32'] = x_make_synthetic__mutmut_32 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_33'] = x_make_synthetic__mutmut_33 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_34'] = x_make_synthetic__mutmut_34 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_35'] = x_make_synthetic__mutmut_35 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_36'] = x_make_synthetic__mutmut_36 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_37'] = x_make_synthetic__mutmut_37 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_38'] = x_make_synthetic__mutmut_38 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_39'] = x_make_synthetic__mutmut_39 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_40'] = x_make_synthetic__mutmut_40 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_41'] = x_make_synthetic__mutmut_41 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_42'] = x_make_synthetic__mutmut_42 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_43'] = x_make_synthetic__mutmut_43 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_44'] = x_make_synthetic__mutmut_44 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_45'] = x_make_synthetic__mutmut_45 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_46'] = x_make_synthetic__mutmut_46 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_47'] = x_make_synthetic__mutmut_47 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_48'] = x_make_synthetic__mutmut_48 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_49'] = x_make_synthetic__mutmut_49 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_50'] = x_make_synthetic__mutmut_50 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_51'] = x_make_synthetic__mutmut_51 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_52'] = x_make_synthetic__mutmut_52 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_53'] = x_make_synthetic__mutmut_53 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_54'] = x_make_synthetic__mutmut_54 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_55'] = x_make_synthetic__mutmut_55 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_56'] = x_make_synthetic__mutmut_56 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_57'] = x_make_synthetic__mutmut_57 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_58'] = x_make_synthetic__mutmut_58 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_59'] = x_make_synthetic__mutmut_59 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_60'] = x_make_synthetic__mutmut_60 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_61'] = x_make_synthetic__mutmut_61 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_62'] = x_make_synthetic__mutmut_62 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_63'] = x_make_synthetic__mutmut_63 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_64'] = x_make_synthetic__mutmut_64 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_65'] = x_make_synthetic__mutmut_65 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_66'] = x_make_synthetic__mutmut_66 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_67'] = x_make_synthetic__mutmut_67 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_68'] = x_make_synthetic__mutmut_68 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_69'] = x_make_synthetic__mutmut_69 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_70'] = x_make_synthetic__mutmut_70 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_71'] = x_make_synthetic__mutmut_71 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_72'] = x_make_synthetic__mutmut_72 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_73'] = x_make_synthetic__mutmut_73 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_74'] = x_make_synthetic__mutmut_74 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_75'] = x_make_synthetic__mutmut_75 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_76'] = x_make_synthetic__mutmut_76 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_77'] = x_make_synthetic__mutmut_77 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_78'] = x_make_synthetic__mutmut_78 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_79'] = x_make_synthetic__mutmut_79 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_80'] = x_make_synthetic__mutmut_80 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_81'] = x_make_synthetic__mutmut_81 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_82'] = x_make_synthetic__mutmut_82 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_83'] = x_make_synthetic__mutmut_83 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_84'] = x_make_synthetic__mutmut_84 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_85'] = x_make_synthetic__mutmut_85 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_86'] = x_make_synthetic__mutmut_86 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_87'] = x_make_synthetic__mutmut_87 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_88'] = x_make_synthetic__mutmut_88 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_89'] = x_make_synthetic__mutmut_89 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_90'] = x_make_synthetic__mutmut_90 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_91'] = x_make_synthetic__mutmut_91 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_92'] = x_make_synthetic__mutmut_92 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_93'] = x_make_synthetic__mutmut_93 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_94'] = x_make_synthetic__mutmut_94 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_95'] = x_make_synthetic__mutmut_95 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_96'] = x_make_synthetic__mutmut_96 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_97'] = x_make_synthetic__mutmut_97 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_98'] = x_make_synthetic__mutmut_98 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_99'] = x_make_synthetic__mutmut_99 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_100'] = x_make_synthetic__mutmut_100 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_101'] = x_make_synthetic__mutmut_101 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_102'] = x_make_synthetic__mutmut_102 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_103'] = x_make_synthetic__mutmut_103 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_104'] = x_make_synthetic__mutmut_104 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_105'] = x_make_synthetic__mutmut_105 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_106'] = x_make_synthetic__mutmut_106 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_107'] = x_make_synthetic__mutmut_107 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_108'] = x_make_synthetic__mutmut_108 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_109'] = x_make_synthetic__mutmut_109 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_110'] = x_make_synthetic__mutmut_110 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_111'] = x_make_synthetic__mutmut_111 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_112'] = x_make_synthetic__mutmut_112 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_113'] = x_make_synthetic__mutmut_113 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_114'] = x_make_synthetic__mutmut_114 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_115'] = x_make_synthetic__mutmut_115 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_116'] = x_make_synthetic__mutmut_116 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_117'] = x_make_synthetic__mutmut_117 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_118'] = x_make_synthetic__mutmut_118 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_119'] = x_make_synthetic__mutmut_119 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_120'] = x_make_synthetic__mutmut_120 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_121'] = x_make_synthetic__mutmut_121 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_122'] = x_make_synthetic__mutmut_122 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_123'] = x_make_synthetic__mutmut_123 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_124'] = x_make_synthetic__mutmut_124 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_125'] = x_make_synthetic__mutmut_125 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_126'] = x_make_synthetic__mutmut_126 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_127'] = x_make_synthetic__mutmut_127 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_128'] = x_make_synthetic__mutmut_128 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_129'] = x_make_synthetic__mutmut_129 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_130'] = x_make_synthetic__mutmut_130 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_131'] = x_make_synthetic__mutmut_131 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_132'] = x_make_synthetic__mutmut_132 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_133'] = x_make_synthetic__mutmut_133 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_134'] = x_make_synthetic__mutmut_134 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_135'] = x_make_synthetic__mutmut_135 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_136'] = x_make_synthetic__mutmut_136 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_137'] = x_make_synthetic__mutmut_137 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_138'] = x_make_synthetic__mutmut_138 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_139'] = x_make_synthetic__mutmut_139 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_140'] = x_make_synthetic__mutmut_140 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_141'] = x_make_synthetic__mutmut_141 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_142'] = x_make_synthetic__mutmut_142 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_143'] = x_make_synthetic__mutmut_143 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_144'] = x_make_synthetic__mutmut_144 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_145'] = x_make_synthetic__mutmut_145 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_146'] = x_make_synthetic__mutmut_146 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_147'] = x_make_synthetic__mutmut_147 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_148'] = x_make_synthetic__mutmut_148 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_149'] = x_make_synthetic__mutmut_149 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_150'] = x_make_synthetic__mutmut_150 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_151'] = x_make_synthetic__mutmut_151 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_152'] = x_make_synthetic__mutmut_152 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_153'] = x_make_synthetic__mutmut_153 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_154'] = x_make_synthetic__mutmut_154 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_155'] = x_make_synthetic__mutmut_155 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_156'] = x_make_synthetic__mutmut_156 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_157'] = x_make_synthetic__mutmut_157 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_158'] = x_make_synthetic__mutmut_158 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_159'] = x_make_synthetic__mutmut_159 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_160'] = x_make_synthetic__mutmut_160 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_161'] = x_make_synthetic__mutmut_161 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_162'] = x_make_synthetic__mutmut_162 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_163'] = x_make_synthetic__mutmut_163 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_164'] = x_make_synthetic__mutmut_164 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_165'] = x_make_synthetic__mutmut_165 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_166'] = x_make_synthetic__mutmut_166 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_167'] = x_make_synthetic__mutmut_167 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_168'] = x_make_synthetic__mutmut_168 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_169'] = x_make_synthetic__mutmut_169 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_170'] = x_make_synthetic__mutmut_170 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_171'] = x_make_synthetic__mutmut_171 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_172'] = x_make_synthetic__mutmut_172 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_173'] = x_make_synthetic__mutmut_173 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_174'] = x_make_synthetic__mutmut_174 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_175'] = x_make_synthetic__mutmut_175 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_176'] = x_make_synthetic__mutmut_176 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_177'] = x_make_synthetic__mutmut_177 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_178'] = x_make_synthetic__mutmut_178 # type: ignore # mutmut generated
mutants_x_make_synthetic__mutmut['x_make_synthetic__mutmut_179'] = x_make_synthetic__mutmut_179 # type: ignore # mutmut generated
