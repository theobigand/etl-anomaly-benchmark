"""Registry of the real datasets the benchmark runs on.

Each :class:`DatasetSpec` says where the CSV is, which column is the label
and which value of it counts as the anomaly, and which detectors to run
(LOF and One-Class SVM only where the row count makes them tractable in
the pipeline).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from etl_benchmark import config
from etl_benchmark.pipeline import extract, transform
from etl_benchmark.registry import DETECTOR_NAMES, RULE_NAMES

ANOMALY_COLUMN = "is_anomaly"


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_xǁDatasetSpecǁload__mutmut: MutantDict = {}  # type: ignore
mutants_xǁDatasetSpecǁfeatures__mutmut: MutantDict = {}  # type: ignore


@dataclass(frozen=True)
class DatasetSpec:
    name: str
    csv: Path
    label_column: str
    positive_value: int
    detector_names: list[str] = field(default_factory=lambda: list(DETECTOR_NAMES))
    note: str = ""

    @_mutmut_mutated(mutants_xǁDatasetSpecǁload__mutmut)
    def load(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_orig(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_1(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = None
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_2(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(None)
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_3(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(None))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_4(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_5(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(None)
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_6(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(None)
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_7(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_8(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin(None).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_9(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([1, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_10(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 2]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_11(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(None)
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(int)
        return df

    def xǁDatasetSpecǁload__mutmut_12(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = None
        return df

    def xǁDatasetSpecǁload__mutmut_13(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] == self.positive_value).astype(None)
        return df

    def xǁDatasetSpecǁload__mutmut_14(self) -> pd.DataFrame:
        """Extract, transform, and add a normalised ``is_anomaly`` column."""
        df = transform(extract(self.csv))
        if self.label_column not in df.columns:
            raise ValueError(f"{self.name}: missing label column {self.label_column!r}")
        if df[self.label_column].isna().any():
            raise ValueError(f"{self.name}: label column contains missing values")
        if not df[self.label_column].isin([0, 1]).all():
            raise ValueError(f"{self.name}: label column must contain only 0 and 1")
        df[ANOMALY_COLUMN] = (df[self.label_column] != self.positive_value).astype(int)
        return df

    @_mutmut_mutated(mutants_xǁDatasetSpecǁfeatures__mutmut)
    def features(self, df: pd.DataFrame) -> pd.DataFrame:
        excluded = {self.label_column, ANOMALY_COLUMN, "anomaly", "anomaly_type", "customer_id"}
        return df.drop(columns=[column for column in df if column in excluded])

    def xǁDatasetSpecǁfeatures__mutmut_orig(self, df: pd.DataFrame) -> pd.DataFrame:
        excluded = {self.label_column, ANOMALY_COLUMN, "anomaly", "anomaly_type", "customer_id"}
        return df.drop(columns=[column for column in df if column in excluded])

    def xǁDatasetSpecǁfeatures__mutmut_1(self, df: pd.DataFrame) -> pd.DataFrame:
        excluded = None
        return df.drop(columns=[column for column in df if column in excluded])

    def xǁDatasetSpecǁfeatures__mutmut_2(self, df: pd.DataFrame) -> pd.DataFrame:
        excluded = {self.label_column, ANOMALY_COLUMN, "XXanomalyXX", "anomaly_type", "customer_id"}
        return df.drop(columns=[column for column in df if column in excluded])

    def xǁDatasetSpecǁfeatures__mutmut_3(self, df: pd.DataFrame) -> pd.DataFrame:
        excluded = {self.label_column, ANOMALY_COLUMN, "ANOMALY", "anomaly_type", "customer_id"}
        return df.drop(columns=[column for column in df if column in excluded])

    def xǁDatasetSpecǁfeatures__mutmut_4(self, df: pd.DataFrame) -> pd.DataFrame:
        excluded = {self.label_column, ANOMALY_COLUMN, "anomaly", "XXanomaly_typeXX", "customer_id"}
        return df.drop(columns=[column for column in df if column in excluded])

    def xǁDatasetSpecǁfeatures__mutmut_5(self, df: pd.DataFrame) -> pd.DataFrame:
        excluded = {self.label_column, ANOMALY_COLUMN, "anomaly", "ANOMALY_TYPE", "customer_id"}
        return df.drop(columns=[column for column in df if column in excluded])

    def xǁDatasetSpecǁfeatures__mutmut_6(self, df: pd.DataFrame) -> pd.DataFrame:
        excluded = {self.label_column, ANOMALY_COLUMN, "anomaly", "anomaly_type", "XXcustomer_idXX"}
        return df.drop(columns=[column for column in df if column in excluded])

    def xǁDatasetSpecǁfeatures__mutmut_7(self, df: pd.DataFrame) -> pd.DataFrame:
        excluded = {self.label_column, ANOMALY_COLUMN, "anomaly", "anomaly_type", "CUSTOMER_ID"}
        return df.drop(columns=[column for column in df if column in excluded])

    def xǁDatasetSpecǁfeatures__mutmut_8(self, df: pd.DataFrame) -> pd.DataFrame:
        excluded = {self.label_column, ANOMALY_COLUMN, "anomaly", "anomaly_type", "customer_id"}
        return df.drop(columns=None)

    def xǁDatasetSpecǁfeatures__mutmut_9(self, df: pd.DataFrame) -> pd.DataFrame:
        excluded = {self.label_column, ANOMALY_COLUMN, "anomaly", "anomaly_type", "customer_id"}
        return df.drop(columns=[column for column in df if column not in excluded])

mutants_xǁDatasetSpecǁload__mutmut['_mutmut_orig'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_orig # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_1'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_1 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_2'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_2 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_3'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_3 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_4'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_4 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_5'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_5 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_6'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_6 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_7'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_7 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_8'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_8 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_9'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_9 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_10'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_10 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_11'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_11 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_12'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_12 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_13'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_13 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁload__mutmut['xǁDatasetSpecǁload__mutmut_14'] = DatasetSpec.xǁDatasetSpecǁload__mutmut_14 # type: ignore # mutmut generated

mutants_xǁDatasetSpecǁfeatures__mutmut['_mutmut_orig'] = DatasetSpec.xǁDatasetSpecǁfeatures__mutmut_orig # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁfeatures__mutmut['xǁDatasetSpecǁfeatures__mutmut_1'] = DatasetSpec.xǁDatasetSpecǁfeatures__mutmut_1 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁfeatures__mutmut['xǁDatasetSpecǁfeatures__mutmut_2'] = DatasetSpec.xǁDatasetSpecǁfeatures__mutmut_2 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁfeatures__mutmut['xǁDatasetSpecǁfeatures__mutmut_3'] = DatasetSpec.xǁDatasetSpecǁfeatures__mutmut_3 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁfeatures__mutmut['xǁDatasetSpecǁfeatures__mutmut_4'] = DatasetSpec.xǁDatasetSpecǁfeatures__mutmut_4 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁfeatures__mutmut['xǁDatasetSpecǁfeatures__mutmut_5'] = DatasetSpec.xǁDatasetSpecǁfeatures__mutmut_5 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁfeatures__mutmut['xǁDatasetSpecǁfeatures__mutmut_6'] = DatasetSpec.xǁDatasetSpecǁfeatures__mutmut_6 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁfeatures__mutmut['xǁDatasetSpecǁfeatures__mutmut_7'] = DatasetSpec.xǁDatasetSpecǁfeatures__mutmut_7 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁfeatures__mutmut['xǁDatasetSpecǁfeatures__mutmut_8'] = DatasetSpec.xǁDatasetSpecǁfeatures__mutmut_8 # type: ignore # mutmut generated
mutants_xǁDatasetSpecǁfeatures__mutmut['xǁDatasetSpecǁfeatures__mutmut_9'] = DatasetSpec.xǁDatasetSpecǁfeatures__mutmut_9 # type: ignore # mutmut generated


DATASETS: dict[str, DatasetSpec] = {
    "credit_card": DatasetSpec(
        name="credit_card",
        csv=config.CREDIT_CARD_CSV,
        label_column="Class",
        positive_value=1,
        detector_names=[*RULE_NAMES, "isolation_forest", "ecod", "copod", "hbos", "pca"],
        note="284k rows, 0.17% fraud. LOF, OC-SVM and KNN omitted: they do not scale to this size.",
    ),
    "water_quality": DatasetSpec(
        name="water_quality",
        csv=config.WATER_QUALITY_CSV,
        label_column="Potability",
        positive_value=0,
        detector_names=list(DETECTOR_NAMES),
        note="3.3k rows, 61% not-potable. The target class is common, not rare: "
        "this tests the detectors outside their intended regime, on real missing data.",
    ),
    "cardio": DatasetSpec(
        name="cardio",
        csv=config.CARDIO_CSV,
        label_column="label",
        positive_value=1,
        detector_names=list(DETECTOR_NAMES),
        note="1.8k rows, 21 features, 9.6% anomalies. A genuinely imbalanced "
        "cardiotocography dataset: the regime the detectors are built for.",
    ),
}
