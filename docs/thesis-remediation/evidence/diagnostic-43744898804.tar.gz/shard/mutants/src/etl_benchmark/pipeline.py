"""ETL pipeline: composable stages shared by the demo and the benchmark.

The stages are:
    - ``extract``   — load raw data into a DataFrame;
    - ``transform`` — light cleaning (drop exact duplicates);
    - ``detect``    — the quality stage: fit/predict/score a detector,
      timed, with the ground-truth label excluded from the features.

:func:`run_pipeline` chains all three (and optionally dumps the sorted
clean/anomaly CSVs) for the single-detector demo run with
``python -m etl_benchmark``. The benchmark reuses ``extract``/``transform``
once and calls :func:`detect` per detector, so every method is scored on
the exact same pipeline path and its in-pipeline latency is measured.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from etl_benchmark import config
from etl_benchmark.extract import read_csv
from etl_benchmark.load import write_csv
from etl_benchmark.quality import Detector, ZScoreDetector
from etl_benchmark.transform import clean

log = logging.getLogger(__name__)

# Stage aliases so callers speak the pipeline vocabulary.
extract = read_csv
transform = clean


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict


@dataclass
class DetectionResult:
    """Output of the quality stage for one detector."""

    flags: pd.Series  # boolean per row: True where anomalous
    scores: pd.Series  # continuous anomaly score per row
    fit_s: float
    predict_s: float
    score_s: float

    @property
    def detect_s(self) -> float:
        """In-pipeline detector latency (fit + predict + score)."""
        return self.fit_s + self.predict_s + self.score_s
mutants_x__features__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__features__mutmut)
def _features(df: pd.DataFrame, label_column: str | None) -> pd.DataFrame:
    return df.drop(columns=[label_column]) if label_column in df.columns else df


def x__features__mutmut_orig(df: pd.DataFrame, label_column: str | None) -> pd.DataFrame:
    return df.drop(columns=[label_column]) if label_column in df.columns else df


def x__features__mutmut_1(df: pd.DataFrame, label_column: str | None) -> pd.DataFrame:
    return df.drop(columns=[label_column]) if (label_column in df.columns) and False else df


def x__features__mutmut_2(df: pd.DataFrame, label_column: str | None) -> pd.DataFrame:
    return df.drop(columns=[label_column]) if (label_column in df.columns) or True else df


def x__features__mutmut_3(df: pd.DataFrame, label_column: str | None) -> pd.DataFrame:
    return df.drop(columns=None) if label_column in df.columns else df


def x__features__mutmut_4(df: pd.DataFrame, label_column: str | None) -> pd.DataFrame:
    return df.drop(columns=[label_column]) if label_column not in df.columns else df

mutants_x__features__mutmut['_mutmut_orig'] = x__features__mutmut_orig # type: ignore # mutmut generated
mutants_x__features__mutmut['x__features__mutmut_1'] = x__features__mutmut_1 # type: ignore # mutmut generated
mutants_x__features__mutmut['x__features__mutmut_2'] = x__features__mutmut_2 # type: ignore # mutmut generated
mutants_x__features__mutmut['x__features__mutmut_3'] = x__features__mutmut_3 # type: ignore # mutmut generated
mutants_x__features__mutmut['x__features__mutmut_4'] = x__features__mutmut_4 # type: ignore # mutmut generated
mutants_x_detect__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_detect__mutmut)
def detect(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_orig(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_1(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = None
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_2(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(None, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_3(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, None)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_4(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_5(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, )
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_6(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = None
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_7(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if (fit_df is None) and False else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_8(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if (fit_df is None) or True else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_9(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is not None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_10(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(None, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_11(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, None)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_12(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_13(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, )
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_14(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(None) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_15(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) == list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_16(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(None):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_17(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError(None)

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_18(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("XXfit and evaluation feature schema must match in orderXX")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_19(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("FIT AND EVALUATION FEATURE SCHEMA MUST MATCH IN ORDER")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_20(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = None
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_21(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(None)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_22(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = None
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_23(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = None
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_24(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(None)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_25(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = None
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_26(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = None
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_27(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(None)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_28(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = None

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_29(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) and not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_30(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_31(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_32(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(None):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_33(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError(None)
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_34(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("XXdetector flags must be a Series with the input indexXX")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_35(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_36(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("DETECTOR FLAGS MUST BE A SERIES WITH THE INPUT INDEX")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_37(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) and not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_38(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_39(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_40(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(None):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_41(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError(None)
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_42(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("XXdetector scores must be a Series with the input indexXX")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_43(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_44(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("DETECTOR SCORES MUST BE A SERIES WITH THE INPUT INDEX")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_45(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_46(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(None):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_47(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError(None)
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_48(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("XXdetector flags must be booleanXX")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_49(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("DETECTOR FLAGS MUST BE BOOLEAN")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_50(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_51(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(None).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_52(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=None)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_53(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError(None)

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_54(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("XXdetector scores must be finiteXX")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_55(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("DETECTOR SCORES MUST BE FINITE")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_56(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(None, scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_57(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, None, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_58(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, None, t2 - t1, t3 - t2)


def x_detect__mutmut_59(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, None, t3 - t2)


def x_detect__mutmut_60(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, None)


def x_detect__mutmut_61(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(scores, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_62(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, t1 - t0, t2 - t1, t3 - t2)


def x_detect__mutmut_63(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t2 - t1, t3 - t2)


def x_detect__mutmut_64(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t3 - t2)


def x_detect__mutmut_65(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, )


def x_detect__mutmut_66(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 + t0, t2 - t1, t3 - t2)


def x_detect__mutmut_67(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 + t1, t3 - t2)


def x_detect__mutmut_68(
    df: pd.DataFrame,
    detector: Detector,
    label_column: str | None = None,
    fit_df: pd.DataFrame | None = None,
) -> DetectionResult:
    """Run the quality stage: fit, predict and score ``detector`` on ``df``.

    ``label_column`` (the ground-truth label) is dropped from the features
    so it never leaks into detection. When ``fit_df`` is given the detector
    is fitted on it instead of on ``df`` (used to fit an expensive model on
    a sample while still scoring the whole stream); flags and scores are
    always produced for every row of ``df``.
    """
    features = _features(df, label_column)
    fit_features = features if fit_df is None else _features(fit_df, label_column)
    if list(features.columns) != list(fit_features.columns):
        raise ValueError("fit and evaluation feature schema must match in order")

    t0 = time.perf_counter()
    detector.fit(fit_features)
    t1 = time.perf_counter()
    flags = detector.predict(features)
    t2 = time.perf_counter()
    scores = detector.score(features)
    t3 = time.perf_counter()

    if not isinstance(flags, pd.Series) or not flags.index.equals(df.index):
        raise ValueError("detector flags must be a Series with the input index")
    if not isinstance(scores, pd.Series) or not scores.index.equals(df.index):
        raise ValueError("detector scores must be a Series with the input index")
    if not pd.api.types.is_bool_dtype(flags):
        raise ValueError("detector flags must be boolean")
    if not np.isfinite(scores.to_numpy(dtype=float)).all():
        raise ValueError("detector scores must be finite")

    return DetectionResult(flags, scores, t1 - t0, t2 - t1, t3 + t2)

mutants_x_detect__mutmut['_mutmut_orig'] = x_detect__mutmut_orig # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_1'] = x_detect__mutmut_1 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_2'] = x_detect__mutmut_2 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_3'] = x_detect__mutmut_3 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_4'] = x_detect__mutmut_4 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_5'] = x_detect__mutmut_5 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_6'] = x_detect__mutmut_6 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_7'] = x_detect__mutmut_7 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_8'] = x_detect__mutmut_8 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_9'] = x_detect__mutmut_9 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_10'] = x_detect__mutmut_10 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_11'] = x_detect__mutmut_11 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_12'] = x_detect__mutmut_12 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_13'] = x_detect__mutmut_13 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_14'] = x_detect__mutmut_14 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_15'] = x_detect__mutmut_15 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_16'] = x_detect__mutmut_16 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_17'] = x_detect__mutmut_17 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_18'] = x_detect__mutmut_18 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_19'] = x_detect__mutmut_19 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_20'] = x_detect__mutmut_20 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_21'] = x_detect__mutmut_21 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_22'] = x_detect__mutmut_22 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_23'] = x_detect__mutmut_23 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_24'] = x_detect__mutmut_24 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_25'] = x_detect__mutmut_25 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_26'] = x_detect__mutmut_26 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_27'] = x_detect__mutmut_27 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_28'] = x_detect__mutmut_28 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_29'] = x_detect__mutmut_29 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_30'] = x_detect__mutmut_30 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_31'] = x_detect__mutmut_31 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_32'] = x_detect__mutmut_32 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_33'] = x_detect__mutmut_33 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_34'] = x_detect__mutmut_34 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_35'] = x_detect__mutmut_35 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_36'] = x_detect__mutmut_36 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_37'] = x_detect__mutmut_37 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_38'] = x_detect__mutmut_38 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_39'] = x_detect__mutmut_39 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_40'] = x_detect__mutmut_40 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_41'] = x_detect__mutmut_41 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_42'] = x_detect__mutmut_42 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_43'] = x_detect__mutmut_43 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_44'] = x_detect__mutmut_44 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_45'] = x_detect__mutmut_45 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_46'] = x_detect__mutmut_46 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_47'] = x_detect__mutmut_47 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_48'] = x_detect__mutmut_48 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_49'] = x_detect__mutmut_49 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_50'] = x_detect__mutmut_50 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_51'] = x_detect__mutmut_51 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_52'] = x_detect__mutmut_52 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_53'] = x_detect__mutmut_53 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_54'] = x_detect__mutmut_54 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_55'] = x_detect__mutmut_55 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_56'] = x_detect__mutmut_56 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_57'] = x_detect__mutmut_57 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_58'] = x_detect__mutmut_58 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_59'] = x_detect__mutmut_59 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_60'] = x_detect__mutmut_60 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_61'] = x_detect__mutmut_61 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_62'] = x_detect__mutmut_62 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_63'] = x_detect__mutmut_63 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_64'] = x_detect__mutmut_64 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_65'] = x_detect__mutmut_65 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_66'] = x_detect__mutmut_66 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_67'] = x_detect__mutmut_67 # type: ignore # mutmut generated
mutants_x_detect__mutmut['x_detect__mutmut_68'] = x_detect__mutmut_68 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run_pipeline__mutmut)
def run_pipeline(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_orig(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_1(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "XXClassXX",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_2(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_3(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "CLASS",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_4(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = None

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_5(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector and ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_6(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=None)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_7(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info(None, input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_8(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", None)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_9(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info(input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_10(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", )
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_11(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("XXextract: loading %sXX", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_12(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("EXTRACT: LOADING %S", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_13(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = None
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_14(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(None)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_15(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info(None, len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_16(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", None, df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_17(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), None)

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_18(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info(len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_19(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_20(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), )

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_21(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("XXextract: %d rows x %d colsXX", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_22(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("EXTRACT: %D ROWS X %D COLS", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_23(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[2])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_24(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = None
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_25(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(None)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_26(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info(None, len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_27(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", None)

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_28(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info(len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_29(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", )

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_30(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("XXtransform: %d rows after cleaningXX", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_31(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("TRANSFORM: %D ROWS AFTER CLEANING", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_32(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info(None, detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_33(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", None)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_34(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info(detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_35(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", )
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_36(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("XXquality: fitting detector %sXX", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_37(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("QUALITY: FITTING DETECTOR %S", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_38(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = None
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_39(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(None, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_40(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, None, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_41(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=None)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_42(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_43(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_44(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, )
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_45(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = None
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_46(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(None)
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_47(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        None,
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_48(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        None,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_49(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        None,
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_50(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        None,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_51(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_52(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_53(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_54(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_55(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "XXquality: %d anomalies flagged (%.2f%%) in %.2fsXX",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_56(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "QUALITY: %D ANOMALIES FLAGGED (%.2F%%) IN %.2FS",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_57(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n * len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_58(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 / n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_59(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        101 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_60(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_61(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = None
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_62(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(None)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_63(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = None
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_64(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(None, dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_65(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], None)
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_66(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_67(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], )
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_68(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_69(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir * "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_70(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "XXpipeline_clean.csvXX")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_71(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "PIPELINE_CLEAN.CSV")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_72(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = None
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_73(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(None, dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_74(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], None)
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_75(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_76(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], )
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_77(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir * "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_78(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "XXpipeline_anomalies.csvXX")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_79(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "PIPELINE_ANOMALIES.CSV")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_80(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info(None, clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_81(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", None)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_82(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info(clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_83(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", )
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_84(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("XXload: clean -> %sXX", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_85(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("LOAD: CLEAN -> %S", clean_path)
        log.info("load: anomalies -> %s", anom_path)

    return df, result


def x_run_pipeline__mutmut_86(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info(None, anom_path)

    return df, result


def x_run_pipeline__mutmut_87(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", None)

    return df, result


def x_run_pipeline__mutmut_88(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info(anom_path)

    return df, result


def x_run_pipeline__mutmut_89(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("load: anomalies -> %s", )

    return df, result


def x_run_pipeline__mutmut_90(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("XXload: anomalies -> %sXX", anom_path)

    return df, result


def x_run_pipeline__mutmut_91(
    input_path: Path = config.CREDIT_CARD_CSV,
    detector: Detector | None = None,
    label_column: str | None = "Class",
    dump_dir: Path | None = None,
) -> tuple[pd.DataFrame, DetectionResult]:
    """Chain extract -> transform -> detect for a single detector.

    When ``dump_dir`` is given, the sorted rows are written to
    ``pipeline_clean.csv`` and ``pipeline_anomalies.csv`` (the load stage);
    otherwise nothing is persisted.
    """
    detector = detector or ZScoreDetector(threshold=config.ZSCORE_THRESHOLD)

    log.info("extract: loading %s", input_path)
    df = extract(input_path)
    log.info("extract: %d rows x %d cols", len(df), df.shape[1])

    df = transform(df)
    log.info("transform: %d rows after cleaning", len(df))

    log.info("quality: fitting detector %s", detector.name)
    result = detect(df, detector, label_column=label_column)
    n = int(result.flags.sum())
    log.info(
        "quality: %d anomalies flagged (%.2f%%) in %.2fs",
        n,
        100 * n / len(df),
        result.detect_s,
    )

    if dump_dir is not None:
        dump_dir = Path(dump_dir)
        clean_path = write_csv(df[~result.flags], dump_dir / "pipeline_clean.csv")
        anom_path = write_csv(df[result.flags], dump_dir / "pipeline_anomalies.csv")
        log.info("load: clean -> %s", clean_path)
        log.info("LOAD: ANOMALIES -> %S", anom_path)

    return df, result

mutants_x_run_pipeline__mutmut['_mutmut_orig'] = x_run_pipeline__mutmut_orig # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_1'] = x_run_pipeline__mutmut_1 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_2'] = x_run_pipeline__mutmut_2 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_3'] = x_run_pipeline__mutmut_3 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_4'] = x_run_pipeline__mutmut_4 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_5'] = x_run_pipeline__mutmut_5 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_6'] = x_run_pipeline__mutmut_6 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_7'] = x_run_pipeline__mutmut_7 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_8'] = x_run_pipeline__mutmut_8 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_9'] = x_run_pipeline__mutmut_9 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_10'] = x_run_pipeline__mutmut_10 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_11'] = x_run_pipeline__mutmut_11 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_12'] = x_run_pipeline__mutmut_12 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_13'] = x_run_pipeline__mutmut_13 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_14'] = x_run_pipeline__mutmut_14 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_15'] = x_run_pipeline__mutmut_15 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_16'] = x_run_pipeline__mutmut_16 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_17'] = x_run_pipeline__mutmut_17 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_18'] = x_run_pipeline__mutmut_18 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_19'] = x_run_pipeline__mutmut_19 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_20'] = x_run_pipeline__mutmut_20 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_21'] = x_run_pipeline__mutmut_21 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_22'] = x_run_pipeline__mutmut_22 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_23'] = x_run_pipeline__mutmut_23 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_24'] = x_run_pipeline__mutmut_24 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_25'] = x_run_pipeline__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_26'] = x_run_pipeline__mutmut_26 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_27'] = x_run_pipeline__mutmut_27 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_28'] = x_run_pipeline__mutmut_28 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_29'] = x_run_pipeline__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_30'] = x_run_pipeline__mutmut_30 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_31'] = x_run_pipeline__mutmut_31 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_32'] = x_run_pipeline__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_33'] = x_run_pipeline__mutmut_33 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_34'] = x_run_pipeline__mutmut_34 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_35'] = x_run_pipeline__mutmut_35 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_36'] = x_run_pipeline__mutmut_36 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_37'] = x_run_pipeline__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_38'] = x_run_pipeline__mutmut_38 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_39'] = x_run_pipeline__mutmut_39 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_40'] = x_run_pipeline__mutmut_40 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_41'] = x_run_pipeline__mutmut_41 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_42'] = x_run_pipeline__mutmut_42 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_43'] = x_run_pipeline__mutmut_43 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_44'] = x_run_pipeline__mutmut_44 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_45'] = x_run_pipeline__mutmut_45 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_46'] = x_run_pipeline__mutmut_46 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_47'] = x_run_pipeline__mutmut_47 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_48'] = x_run_pipeline__mutmut_48 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_49'] = x_run_pipeline__mutmut_49 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_50'] = x_run_pipeline__mutmut_50 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_51'] = x_run_pipeline__mutmut_51 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_52'] = x_run_pipeline__mutmut_52 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_53'] = x_run_pipeline__mutmut_53 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_54'] = x_run_pipeline__mutmut_54 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_55'] = x_run_pipeline__mutmut_55 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_56'] = x_run_pipeline__mutmut_56 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_57'] = x_run_pipeline__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_58'] = x_run_pipeline__mutmut_58 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_59'] = x_run_pipeline__mutmut_59 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_60'] = x_run_pipeline__mutmut_60 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_61'] = x_run_pipeline__mutmut_61 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_62'] = x_run_pipeline__mutmut_62 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_63'] = x_run_pipeline__mutmut_63 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_64'] = x_run_pipeline__mutmut_64 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_65'] = x_run_pipeline__mutmut_65 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_66'] = x_run_pipeline__mutmut_66 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_67'] = x_run_pipeline__mutmut_67 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_68'] = x_run_pipeline__mutmut_68 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_69'] = x_run_pipeline__mutmut_69 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_70'] = x_run_pipeline__mutmut_70 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_71'] = x_run_pipeline__mutmut_71 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_72'] = x_run_pipeline__mutmut_72 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_73'] = x_run_pipeline__mutmut_73 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_74'] = x_run_pipeline__mutmut_74 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_75'] = x_run_pipeline__mutmut_75 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_76'] = x_run_pipeline__mutmut_76 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_77'] = x_run_pipeline__mutmut_77 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_78'] = x_run_pipeline__mutmut_78 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_79'] = x_run_pipeline__mutmut_79 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_80'] = x_run_pipeline__mutmut_80 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_81'] = x_run_pipeline__mutmut_81 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_82'] = x_run_pipeline__mutmut_82 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_83'] = x_run_pipeline__mutmut_83 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_84'] = x_run_pipeline__mutmut_84 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_85'] = x_run_pipeline__mutmut_85 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_86'] = x_run_pipeline__mutmut_86 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_87'] = x_run_pipeline__mutmut_87 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_88'] = x_run_pipeline__mutmut_88 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_89'] = x_run_pipeline__mutmut_89 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_90'] = x_run_pipeline__mutmut_90 # type: ignore # mutmut generated
mutants_x_run_pipeline__mutmut['x_run_pipeline__mutmut_91'] = x_run_pipeline__mutmut_91 # type: ignore # mutmut generated
