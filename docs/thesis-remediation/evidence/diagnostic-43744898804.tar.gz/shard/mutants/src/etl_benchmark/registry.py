"""Central registry of detectors with their default hyperparameters.

Both the pipeline demo (``python -m etl_benchmark --detector <name>``) and
the benchmarks build detectors from here, so adding a new detector (e.g. a
PyOD wrapper) is a single entry that every entry point picks up.

The ML detectors take a ``contamination`` (the expected anomaly share used
for the flag threshold). The benchmarks usually pass the train-set prevalence;
:func:`get_detector` / :func:`all_detectors` fall back to
``config.ML_CONTAMINATION`` when none is given.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from math import isfinite

from etl_benchmark import config
from etl_benchmark.quality import (
    AE1SVMDetector,
    AutoencoderDetector,
    COPODDetector,
    DeepSVDDDetector,
    Detector,
    DIFDetector,
    ECODDetector,
    GreatExpectationsDetector,
    HBOSDetector,
    IQRDetector,
    IsolationForestDetector,
    KNNDetector,
    LOFDetector,
    LUNARDetector,
    OneClassSVMDetector,
    PCADetector,
    TemporalDriftDetector,
    VAEDetector,
    ZScoreDetector,
)

# Each factory takes the ML contamination to use (other detectors ignore it).
_FACTORIES: dict[str, Callable[[float], Detector]] = {
    "zscore": lambda c: ZScoreDetector(threshold=config.ZSCORE_THRESHOLD),
    "iqr": lambda c: IQRDetector(multiplier=config.IQR_MULTIPLIER),
    "great_expectations": lambda c: GreatExpectationsDetector(),
    "isolation_forest": lambda c: IsolationForestDetector(contamination=c),
    "lof": lambda c: LOFDetector(contamination=c),
    "ocsvm": lambda c: OneClassSVMDetector(contamination=c),
    "ecod": lambda c: ECODDetector(contamination=c),
    "copod": lambda c: COPODDetector(contamination=c),
    "hbos": lambda c: HBOSDetector(contamination=c),
    "knn": lambda c: KNNDetector(contamination=c),
    "pca": lambda c: PCADetector(contamination=c),
    "drift": lambda c: TemporalDriftDetector(),
    "autoencoder": lambda c: AutoencoderDetector(contamination=c),
    "vae": lambda c: VAEDetector(contamination=c),
    "deep_svdd": lambda c: DeepSVDDDetector(contamination=c),
    "dif": lambda c: DIFDetector(contamination=c),
    "ae1svm": lambda c: AE1SVMDetector(contamination=c),
    "lunar": lambda c: LUNARDetector(contamination=c),
}

RULE_NAMES: list[str] = ["zscore", "iqr", "great_expectations"]
ML_NAMES: list[str] = ["isolation_forest", "lof", "ocsvm", "ecod", "copod", "hbos", "knn", "pca"]
# The core comparison set. ``drift`` needs a timestamp column, so it is opt-in
# (the synthetic benchmark adds it) rather than part of the default sweep.
DETECTOR_NAMES: list[str] = [*RULE_NAMES, *ML_NAMES]
DRIFT_NAME: str = "drift"
ALL_NAMES: list[str] = [*DETECTOR_NAMES, DRIFT_NAME]
# Neural models are opt-in too (they need PyTorch, except the MLP autoencoder):
# their results enter the thesis tables only after the protocol-parity checks in
# verification/deep_models.md and the protocol of verification/full_registry.md.
DEEP_NAMES: list[str] = ["autoencoder", "vae", "deep_svdd", "dif", "ae1svm", "lunar"]


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_clip_contamination__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_clip_contamination__mutmut)
def clip_contamination(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_orig(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_1(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is not None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_2(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = None
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_3(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 and prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_4(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) and prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_5(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_6(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(None) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_7(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence <= 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_8(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 1 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_9(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence >= 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_10(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 2:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_11(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError(None)
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_12(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("XXprevalence must be finite and between 0 and 1XX")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_13(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("PREVALENCE MUST BE FINITE AND BETWEEN 0 AND 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_14(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = None
    return float(min(max(prevalence, lo), hi))


def x_clip_contamination__mutmut_15(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(None)


def x_clip_contamination__mutmut_16(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(None, hi))


def x_clip_contamination__mutmut_17(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), None))


def x_clip_contamination__mutmut_18(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(hi))


def x_clip_contamination__mutmut_19(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, lo), ))


def x_clip_contamination__mutmut_20(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(None, lo), hi))


def x_clip_contamination__mutmut_21(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, None), hi))


def x_clip_contamination__mutmut_22(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(lo), hi))


def x_clip_contamination__mutmut_23(prevalence: float | None) -> float:
    """Clamp a prevalence into the range PyOD accepts for ``contamination``."""
    if prevalence is None:
        prevalence = config.ML_CONTAMINATION
    if not isfinite(prevalence) or prevalence < 0 or prevalence > 1:
        raise ValueError("prevalence must be finite and between 0 and 1")
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    return float(min(max(prevalence, ), hi))

mutants_x_clip_contamination__mutmut['_mutmut_orig'] = x_clip_contamination__mutmut_orig # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_1'] = x_clip_contamination__mutmut_1 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_2'] = x_clip_contamination__mutmut_2 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_3'] = x_clip_contamination__mutmut_3 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_4'] = x_clip_contamination__mutmut_4 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_5'] = x_clip_contamination__mutmut_5 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_6'] = x_clip_contamination__mutmut_6 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_7'] = x_clip_contamination__mutmut_7 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_8'] = x_clip_contamination__mutmut_8 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_9'] = x_clip_contamination__mutmut_9 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_10'] = x_clip_contamination__mutmut_10 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_11'] = x_clip_contamination__mutmut_11 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_12'] = x_clip_contamination__mutmut_12 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_13'] = x_clip_contamination__mutmut_13 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_14'] = x_clip_contamination__mutmut_14 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_15'] = x_clip_contamination__mutmut_15 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_16'] = x_clip_contamination__mutmut_16 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_17'] = x_clip_contamination__mutmut_17 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_18'] = x_clip_contamination__mutmut_18 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_19'] = x_clip_contamination__mutmut_19 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_20'] = x_clip_contamination__mutmut_20 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_21'] = x_clip_contamination__mutmut_21 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_22'] = x_clip_contamination__mutmut_22 # type: ignore # mutmut generated
mutants_x_clip_contamination__mutmut['x_clip_contamination__mutmut_23'] = x_clip_contamination__mutmut_23 # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_fixed_contamination__mutmut)
def fixed_contamination(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is None or not isfinite(value) or not lo <= value <= hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(value)


def x_fixed_contamination__mutmut_orig(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is None or not isfinite(value) or not lo <= value <= hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(value)


def x_fixed_contamination__mutmut_1(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = None
    if value is None or not isfinite(value) or not lo <= value <= hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(value)


def x_fixed_contamination__mutmut_2(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is None or not isfinite(value) and not lo <= value <= hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(value)


def x_fixed_contamination__mutmut_3(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is None and not isfinite(value) or not lo <= value <= hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(value)


def x_fixed_contamination__mutmut_4(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is not None or not isfinite(value) or not lo <= value <= hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(value)


def x_fixed_contamination__mutmut_5(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is None or isfinite(value) or not lo <= value <= hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(value)


def x_fixed_contamination__mutmut_6(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is None or not isfinite(None) or not lo <= value <= hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(value)


def x_fixed_contamination__mutmut_7(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is None or not isfinite(value) or lo <= value <= hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(value)


def x_fixed_contamination__mutmut_8(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is None or not isfinite(value) or not lo < value <= hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(value)


def x_fixed_contamination__mutmut_9(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is None or not isfinite(value) or not lo <= value < hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(value)


def x_fixed_contamination__mutmut_10(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is None or not isfinite(value) or not lo <= value <= hi:
        raise ValueError(None)
    return float(value)


def x_fixed_contamination__mutmut_11(value: float | None) -> float:
    """Validate a contamination chosen before looking at any labels."""
    lo, hi = config.ML_CONTAMINATION_BOUNDS
    if value is None or not isfinite(value) or not lo <= value <= hi:
        raise ValueError(f"fixed contamination must be between {lo} and {hi}")
    return float(None)

mutants_x_fixed_contamination__mutmut['_mutmut_orig'] = x_fixed_contamination__mutmut_orig # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut['x_fixed_contamination__mutmut_1'] = x_fixed_contamination__mutmut_1 # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut['x_fixed_contamination__mutmut_2'] = x_fixed_contamination__mutmut_2 # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut['x_fixed_contamination__mutmut_3'] = x_fixed_contamination__mutmut_3 # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut['x_fixed_contamination__mutmut_4'] = x_fixed_contamination__mutmut_4 # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut['x_fixed_contamination__mutmut_5'] = x_fixed_contamination__mutmut_5 # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut['x_fixed_contamination__mutmut_6'] = x_fixed_contamination__mutmut_6 # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut['x_fixed_contamination__mutmut_7'] = x_fixed_contamination__mutmut_7 # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut['x_fixed_contamination__mutmut_8'] = x_fixed_contamination__mutmut_8 # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut['x_fixed_contamination__mutmut_9'] = x_fixed_contamination__mutmut_9 # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut['x_fixed_contamination__mutmut_10'] = x_fixed_contamination__mutmut_10 # type: ignore # mutmut generated
mutants_x_fixed_contamination__mutmut['x_fixed_contamination__mutmut_11'] = x_fixed_contamination__mutmut_11 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_calibrate_contamination__mutmut)
def calibrate_contamination(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_orig(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_1(
    train_labels: Iterable[int],
    *,
    policy: str = "XXtrain_prevalenceXX",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_2(
    train_labels: Iterable[int],
    *,
    policy: str = "TRAIN_PREVALENCE",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_3(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy != "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_4(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "XXfixedXX":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_5(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "FIXED":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_6(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(None)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_7(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy == "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_8(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "XXtrain_prevalenceXX":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_9(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "TRAIN_PREVALENCE":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_10(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(None)
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_11(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = None
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_12(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(None)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_13(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels and set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_14(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_15(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) + {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_16(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(None) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_17(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {1, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_18(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 2}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_19(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError(None)
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_20(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("XXtraining labels must be nonempty and binaryXX")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_21(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("TRAINING LABELS MUST BE NONEMPTY AND BINARY")
    return clip_contamination(sum(labels) / len(labels))


def x_calibrate_contamination__mutmut_22(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(None)


def x_calibrate_contamination__mutmut_23(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(labels) * len(labels))


def x_calibrate_contamination__mutmut_24(
    train_labels: Iterable[int],
    *,
    policy: str = "train_prevalence",
    fixed: float | None = None,
) -> float:
    """Choose the detector threshold without consulting validation or test labels."""
    if policy == "fixed":
        return fixed_contamination(fixed)
    if policy != "train_prevalence":
        raise ValueError(f"unknown calibration policy {policy!r}")
    labels = list(train_labels)
    if not labels or set(labels) - {0, 1}:
        raise ValueError("training labels must be nonempty and binary")
    return clip_contamination(sum(None) / len(labels))

mutants_x_calibrate_contamination__mutmut['_mutmut_orig'] = x_calibrate_contamination__mutmut_orig # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_1'] = x_calibrate_contamination__mutmut_1 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_2'] = x_calibrate_contamination__mutmut_2 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_3'] = x_calibrate_contamination__mutmut_3 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_4'] = x_calibrate_contamination__mutmut_4 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_5'] = x_calibrate_contamination__mutmut_5 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_6'] = x_calibrate_contamination__mutmut_6 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_7'] = x_calibrate_contamination__mutmut_7 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_8'] = x_calibrate_contamination__mutmut_8 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_9'] = x_calibrate_contamination__mutmut_9 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_10'] = x_calibrate_contamination__mutmut_10 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_11'] = x_calibrate_contamination__mutmut_11 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_12'] = x_calibrate_contamination__mutmut_12 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_13'] = x_calibrate_contamination__mutmut_13 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_14'] = x_calibrate_contamination__mutmut_14 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_15'] = x_calibrate_contamination__mutmut_15 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_16'] = x_calibrate_contamination__mutmut_16 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_17'] = x_calibrate_contamination__mutmut_17 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_18'] = x_calibrate_contamination__mutmut_18 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_19'] = x_calibrate_contamination__mutmut_19 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_20'] = x_calibrate_contamination__mutmut_20 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_21'] = x_calibrate_contamination__mutmut_21 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_22'] = x_calibrate_contamination__mutmut_22 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_23'] = x_calibrate_contamination__mutmut_23 # type: ignore # mutmut generated
mutants_x_calibrate_contamination__mutmut['x_calibrate_contamination__mutmut_24'] = x_calibrate_contamination__mutmut_24 # type: ignore # mutmut generated
mutants_x_get_detector__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_get_detector__mutmut)
def get_detector(name: str, ml_contamination: float | None = None) -> Detector:
    """Build a fresh detector by name.

    ``ml_contamination`` sets the flag threshold of the ML detectors; it is
    ignored by the rule-based ones.
    """
    try:
        factory = _FACTORIES[name]
    except KeyError:
        raise ValueError(
            f"unknown detector {name!r}; choose from {[*ALL_NAMES, *DEEP_NAMES]}"
        ) from None
    return factory(clip_contamination(ml_contamination))


def x_get_detector__mutmut_orig(name: str, ml_contamination: float | None = None) -> Detector:
    """Build a fresh detector by name.

    ``ml_contamination`` sets the flag threshold of the ML detectors; it is
    ignored by the rule-based ones.
    """
    try:
        factory = _FACTORIES[name]
    except KeyError:
        raise ValueError(
            f"unknown detector {name!r}; choose from {[*ALL_NAMES, *DEEP_NAMES]}"
        ) from None
    return factory(clip_contamination(ml_contamination))


def x_get_detector__mutmut_1(name: str, ml_contamination: float | None = None) -> Detector:
    """Build a fresh detector by name.

    ``ml_contamination`` sets the flag threshold of the ML detectors; it is
    ignored by the rule-based ones.
    """
    try:
        factory = None
    except KeyError:
        raise ValueError(
            f"unknown detector {name!r}; choose from {[*ALL_NAMES, *DEEP_NAMES]}"
        ) from None
    return factory(clip_contamination(ml_contamination))


def x_get_detector__mutmut_2(name: str, ml_contamination: float | None = None) -> Detector:
    """Build a fresh detector by name.

    ``ml_contamination`` sets the flag threshold of the ML detectors; it is
    ignored by the rule-based ones.
    """
    try:
        factory = _FACTORIES[name]
    except KeyError:
        raise ValueError(
            None
        ) from None
    return factory(clip_contamination(ml_contamination))


def x_get_detector__mutmut_3(name: str, ml_contamination: float | None = None) -> Detector:
    """Build a fresh detector by name.

    ``ml_contamination`` sets the flag threshold of the ML detectors; it is
    ignored by the rule-based ones.
    """
    try:
        factory = _FACTORIES[name]
    except KeyError:
        raise ValueError(
            f"unknown detector {name!r}; choose from {[*ALL_NAMES, *DEEP_NAMES]}"
        ) from None
    return factory(None)


def x_get_detector__mutmut_4(name: str, ml_contamination: float | None = None) -> Detector:
    """Build a fresh detector by name.

    ``ml_contamination`` sets the flag threshold of the ML detectors; it is
    ignored by the rule-based ones.
    """
    try:
        factory = _FACTORIES[name]
    except KeyError:
        raise ValueError(
            f"unknown detector {name!r}; choose from {[*ALL_NAMES, *DEEP_NAMES]}"
        ) from None
    return factory(clip_contamination(None))

mutants_x_get_detector__mutmut['_mutmut_orig'] = x_get_detector__mutmut_orig # type: ignore # mutmut generated
mutants_x_get_detector__mutmut['x_get_detector__mutmut_1'] = x_get_detector__mutmut_1 # type: ignore # mutmut generated
mutants_x_get_detector__mutmut['x_get_detector__mutmut_2'] = x_get_detector__mutmut_2 # type: ignore # mutmut generated
mutants_x_get_detector__mutmut['x_get_detector__mutmut_3'] = x_get_detector__mutmut_3 # type: ignore # mutmut generated
mutants_x_get_detector__mutmut['x_get_detector__mutmut_4'] = x_get_detector__mutmut_4 # type: ignore # mutmut generated
mutants_x_all_detectors__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_all_detectors__mutmut)
def all_detectors(
    ml_contamination: float | None = None,
    names: list[str] | None = None,
) -> list[Detector]:
    """Build one fresh instance of every registered detector (or ``names``)."""
    wanted = names or DETECTOR_NAMES
    return [get_detector(name, ml_contamination) for name in wanted]


def x_all_detectors__mutmut_orig(
    ml_contamination: float | None = None,
    names: list[str] | None = None,
) -> list[Detector]:
    """Build one fresh instance of every registered detector (or ``names``)."""
    wanted = names or DETECTOR_NAMES
    return [get_detector(name, ml_contamination) for name in wanted]


def x_all_detectors__mutmut_1(
    ml_contamination: float | None = None,
    names: list[str] | None = None,
) -> list[Detector]:
    """Build one fresh instance of every registered detector (or ``names``)."""
    wanted = None
    return [get_detector(name, ml_contamination) for name in wanted]


def x_all_detectors__mutmut_2(
    ml_contamination: float | None = None,
    names: list[str] | None = None,
) -> list[Detector]:
    """Build one fresh instance of every registered detector (or ``names``)."""
    wanted = names and DETECTOR_NAMES
    return [get_detector(name, ml_contamination) for name in wanted]


def x_all_detectors__mutmut_3(
    ml_contamination: float | None = None,
    names: list[str] | None = None,
) -> list[Detector]:
    """Build one fresh instance of every registered detector (or ``names``)."""
    wanted = names or DETECTOR_NAMES
    return [get_detector(None, ml_contamination) for name in wanted]


def x_all_detectors__mutmut_4(
    ml_contamination: float | None = None,
    names: list[str] | None = None,
) -> list[Detector]:
    """Build one fresh instance of every registered detector (or ``names``)."""
    wanted = names or DETECTOR_NAMES
    return [get_detector(name, None) for name in wanted]


def x_all_detectors__mutmut_5(
    ml_contamination: float | None = None,
    names: list[str] | None = None,
) -> list[Detector]:
    """Build one fresh instance of every registered detector (or ``names``)."""
    wanted = names or DETECTOR_NAMES
    return [get_detector(ml_contamination) for name in wanted]


def x_all_detectors__mutmut_6(
    ml_contamination: float | None = None,
    names: list[str] | None = None,
) -> list[Detector]:
    """Build one fresh instance of every registered detector (or ``names``)."""
    wanted = names or DETECTOR_NAMES
    return [get_detector(name, ) for name in wanted]

mutants_x_all_detectors__mutmut['_mutmut_orig'] = x_all_detectors__mutmut_orig # type: ignore # mutmut generated
mutants_x_all_detectors__mutmut['x_all_detectors__mutmut_1'] = x_all_detectors__mutmut_1 # type: ignore # mutmut generated
mutants_x_all_detectors__mutmut['x_all_detectors__mutmut_2'] = x_all_detectors__mutmut_2 # type: ignore # mutmut generated
mutants_x_all_detectors__mutmut['x_all_detectors__mutmut_3'] = x_all_detectors__mutmut_3 # type: ignore # mutmut generated
mutants_x_all_detectors__mutmut['x_all_detectors__mutmut_4'] = x_all_detectors__mutmut_4 # type: ignore # mutmut generated
mutants_x_all_detectors__mutmut['x_all_detectors__mutmut_5'] = x_all_detectors__mutmut_5 # type: ignore # mutmut generated
mutants_x_all_detectors__mutmut['x_all_detectors__mutmut_6'] = x_all_detectors__mutmut_6 # type: ignore # mutmut generated
