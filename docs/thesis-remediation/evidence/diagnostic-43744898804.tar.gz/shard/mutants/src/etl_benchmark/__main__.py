"""Pipeline demo: run one detector through the full ETL pipeline.

python -m etl_benchmark                       # Z-score (default)
python -m etl_benchmark --detector iqr
python -m etl_benchmark --detector great_expectations
python -m etl_benchmark --detector autoencoder
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

from etl_benchmark import config
from etl_benchmark.logging_setup import setup_logging
from etl_benchmark.pipeline import run_pipeline
from etl_benchmark.registry import ALL_NAMES, DEEP_NAMES, get_detector


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_orig() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_1() -> None:
    parser = None
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_2() -> None:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_3() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        None,
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_4() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=None,
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_5() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default=None,
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_6() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help=None,
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_7() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_8() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_9() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_10() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_11() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "XX--detectorXX",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_12() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--DETECTOR",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_13() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="XXzscoreXX",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_14() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="ZSCORE",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_15() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="XXwhich detector to run (default: zscore)XX",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_16() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="WHICH DETECTOR TO RUN (DEFAULT: ZSCORE)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_17() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument(None, type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_18() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=None, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_19() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=None)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_20() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument(type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_21() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_22() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, )
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_23() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("XX--inputXX", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_24() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--INPUT", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_25() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = None

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_26() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(None)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_27() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger(None).setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_28() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("XXgreat_expectationsXX").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_29() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("GREAT_EXPECTATIONS").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_30() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=None,
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_31() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=None,
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_32() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        dump_dir=None,
    )


def x_main__mutmut_33() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        detector=get_detector(args.detector),
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_34() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        dump_dir=config.RESULTS_DIR,
    )


def x_main__mutmut_35() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(args.detector),
        )


def x_main__mutmut_36() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--detector",
        choices=[*ALL_NAMES, *DEEP_NAMES],
        default="zscore",
        help="which detector to run (default: zscore)",
    )
    parser.add_argument("--input", type=Path, default=config.CREDIT_CARD_CSV)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)

    # Demo run: one detector through the full pipeline, sorted rows dumped.
    run_pipeline(
        input_path=args.input,
        detector=get_detector(None),
        dump_dir=config.RESULTS_DIR,
    )

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated


if __name__ == "__main__":
    main()
