"""Publish a result file whole or not at all.

A writer fills a hidden sibling of the destination; only a finished, non-empty,
flushed file is renamed over the destination. An error or an interrupt removes
the sibling and leaves whatever the destination held before.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict


@contextmanager
def atomic_path(path: str | Path) -> Iterator[Path]:
    """Yield a hidden path next to ``path``; on success it replaces ``path``.

    The sibling keeps the destination's extension so writers that infer the
    format from it (CSV, PNG) behave as they do for the real name.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_name(f".{path.stem}.partial-{os.getpid()}{path.suffix}")
    try:
        yield partial
        if partial.stat().st_size == 0:
            raise ValueError(f"refusing to publish an empty {path.name}")
        with partial.open("rb") as stream:
            os.fsync(stream.fileno())
        os.replace(partial, path)
    except BaseException:
        partial.unlink(missing_ok=True)
        raise
mutants_x_write_text__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_write_text__mutmut)
def write_text(path: str | Path, text: str) -> Path:
    with atomic_path(path) as partial:
        partial.write_text(text)
    return Path(path)


def x_write_text__mutmut_orig(path: str | Path, text: str) -> Path:
    with atomic_path(path) as partial:
        partial.write_text(text)
    return Path(path)


def x_write_text__mutmut_1(path: str | Path, text: str) -> Path:
    with atomic_path(None) as partial:
        partial.write_text(text)
    return Path(path)


def x_write_text__mutmut_2(path: str | Path, text: str) -> Path:
    with atomic_path(path) as partial:
        partial.write_text(None)
    return Path(path)


def x_write_text__mutmut_3(path: str | Path, text: str) -> Path:
    with atomic_path(path) as partial:
        partial.write_text(text)
    return Path(None)

mutants_x_write_text__mutmut['_mutmut_orig'] = x_write_text__mutmut_orig # type: ignore # mutmut generated
mutants_x_write_text__mutmut['x_write_text__mutmut_1'] = x_write_text__mutmut_1 # type: ignore # mutmut generated
mutants_x_write_text__mutmut['x_write_text__mutmut_2'] = x_write_text__mutmut_2 # type: ignore # mutmut generated
mutants_x_write_text__mutmut['x_write_text__mutmut_3'] = x_write_text__mutmut_3 # type: ignore # mutmut generated
mutants_x_write_bytes__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_write_bytes__mutmut)
def write_bytes(path: str | Path, data: bytes) -> Path:
    with atomic_path(path) as partial:
        partial.write_bytes(data)
    return Path(path)


def x_write_bytes__mutmut_orig(path: str | Path, data: bytes) -> Path:
    with atomic_path(path) as partial:
        partial.write_bytes(data)
    return Path(path)


def x_write_bytes__mutmut_1(path: str | Path, data: bytes) -> Path:
    with atomic_path(None) as partial:
        partial.write_bytes(data)
    return Path(path)


def x_write_bytes__mutmut_2(path: str | Path, data: bytes) -> Path:
    with atomic_path(path) as partial:
        partial.write_bytes(None)
    return Path(path)


def x_write_bytes__mutmut_3(path: str | Path, data: bytes) -> Path:
    with atomic_path(path) as partial:
        partial.write_bytes(data)
    return Path(None)

mutants_x_write_bytes__mutmut['_mutmut_orig'] = x_write_bytes__mutmut_orig # type: ignore # mutmut generated
mutants_x_write_bytes__mutmut['x_write_bytes__mutmut_1'] = x_write_bytes__mutmut_1 # type: ignore # mutmut generated
mutants_x_write_bytes__mutmut['x_write_bytes__mutmut_2'] = x_write_bytes__mutmut_2 # type: ignore # mutmut generated
mutants_x_write_bytes__mutmut['x_write_bytes__mutmut_3'] = x_write_bytes__mutmut_3 # type: ignore # mutmut generated
