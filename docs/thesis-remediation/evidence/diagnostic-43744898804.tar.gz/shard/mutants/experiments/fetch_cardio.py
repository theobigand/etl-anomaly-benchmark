"""Download the cardiotocography anomaly dataset and write ``data/cardio.csv``.

The source is the ``cardio`` dataset as packaged for anomaly-detection
benchmarking (an ``.npz`` with an ``X`` feature matrix and a ``y`` label
where 1 marks the anomaly). It is small (1{,}831 rows), already
standardised, and genuinely imbalanced (9.6% anomalies), which is the
regime the detectors are designed for.

    python experiments/fetch_cardio.py
"""

from __future__ import annotations

import io
import logging
import urllib.request

import numpy as np
import pandas as pd

from etl_benchmark import config
from etl_benchmark.atomic import atomic_path
from etl_benchmark.logging_setup import setup_logging

log = logging.getLogger(__name__)

URL = "https://raw.githubusercontent.com/Minqi824/ADBench/main/adbench/datasets/Classical/6_cardio.npz"


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_orig() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_1() -> None:
    setup_logging()
    log.info(None, URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_2() -> None:
    setup_logging()
    log.info("downloading %s", None)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_3() -> None:
    setup_logging()
    log.info(URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_4() -> None:
    setup_logging()
    log.info("downloading %s", )
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_5() -> None:
    setup_logging()
    log.info("XXdownloading %sXX", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_6() -> None:
    setup_logging()
    log.info("DOWNLOADING %S", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_7() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(None, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_8() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=None) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_9() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_10() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, ) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_11() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=31) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_12() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = None

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_13() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = None
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_14() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(None)
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_15() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(None))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_16() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = None
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_17() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["XXXXX"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_18() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["x"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_19() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(None)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_20() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["XXyXX"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_21() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["Y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_22() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = None
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_23() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(None, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_24() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=None)
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_25() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_26() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, )
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_27() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(None)])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_28() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[2])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_29() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = None

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_30() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["XXlabelXX"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_31() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["LABEL"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_32() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=None, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_33() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=None)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_34() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_35() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, )
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_36() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=False, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_37() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=False)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_38() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(None) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_39() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(None, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_40() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=None)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_41() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_42() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, )
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_43() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=True)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_44() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        None,
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_45() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        None,
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_46() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        None,
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_47() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        None,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_48() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        None,
        100 * y.mean(),
    )


def x_main__mutmut_49() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        None,
    )


def x_main__mutmut_50() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_51() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_52() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_53() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_54() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        100 * y.mean(),
    )


def x_main__mutmut_55() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        )


def x_main__mutmut_56() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "XXwrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)XX",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_57() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "WROTE %D ROWS X %D COLS -> %S (%D ANOMALIES, %.1F%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_58() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[2],
        config.CARDIO_CSV,
        int(y.sum()),
        100 * y.mean(),
    )


def x_main__mutmut_59() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(None),
        100 * y.mean(),
    )


def x_main__mutmut_60() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        100 / y.mean(),
    )


def x_main__mutmut_61() -> None:
    setup_logging()
    log.info("downloading %s", URL)
    with urllib.request.urlopen(URL, timeout=30) as resp:  # noqa: S310 - fixed https URL
        payload = resp.read()

    npz = np.load(io.BytesIO(payload))
    x, y = npz["X"], npz["y"].astype(int)
    frame = pd.DataFrame(x, columns=[f"f{i:02d}" for i in range(x.shape[1])])
    frame["label"] = y

    config.CARDIO_CSV.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(config.CARDIO_CSV) as partial:
        frame.to_csv(partial, index=False)
    log.info(
        "wrote %d rows x %d cols -> %s (%d anomalies, %.1f%%)",
        len(frame),
        frame.shape[1],
        config.CARDIO_CSV,
        int(y.sum()),
        101 * y.mean(),
    )

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated


if __name__ == "__main__":
    main()
