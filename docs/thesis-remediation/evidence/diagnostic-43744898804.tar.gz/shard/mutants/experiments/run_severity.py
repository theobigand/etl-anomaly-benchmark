"""Detection rate versus injection severity, on the synthetic dataset.

The synthetic magnitudes are a design choice and a stated threat to
validity. This sweep turns the choice into a curve: for a range of
``--severities`` (1.0 is the reference dataset) it regenerates the data,
runs the same held-out per-type evaluation as
``run_synthetic_benchmark.py``, and plots per-type recall against
severity for every method.

    python experiments/run_severity.py
    python experiments/run_severity.py --severities 0.5 1 2 4 --seeds 42
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from datetime import UTC, datetime
from pathlib import Path

os.environ.setdefault("TQDM_DISABLE", "1")

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
from provenance import write_record  # noqa: E402
from run_synthetic_benchmark import evaluate  # noqa: E402

from etl_benchmark import config  # noqa: E402
from etl_benchmark.atomic import atomic_path  # noqa: E402
from etl_benchmark.logging_setup import setup_logging  # noqa: E402
from etl_benchmark.synthetic import make_synthetic  # noqa: E402

log = logging.getLogger(__name__)

PAPER_FIGURE = config.PROJECT_ROOT / "paper" / "figures" / "severity_curves.png"
# the three types whose injection has a magnitude to scale
MAGNITUDE_TYPES = ["univariate_outlier", "multivariate_outlier", "temporal_drift"]


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_run__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run__mutmut)
def run(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_orig(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_1(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = None
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_2(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = None
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_3(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = None
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_4(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if (rows) and False else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_5(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if (rows) or True else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_6(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"XXn_rowsXX": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_7(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"N_ROWS": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_8(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = None
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_9(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=None, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_10(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=None, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_11(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_12(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_13(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, )
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_14(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(None)
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_15(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(None, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_16(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, None)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_17(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_18(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, )["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_19(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["XXrecallXX"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_20(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["RECALL"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_21(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info(None, sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_22(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", None, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_23(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, None)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_24(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info(sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_25(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_26(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, )
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_27(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("XXseverity %.2f seed %d doneXX", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_28(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("SEVERITY %.2F SEED %D DONE", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_29(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = None
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_30(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=None, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_31(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=None).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_32(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_33(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, ).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_34(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(None).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_35(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=1, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_36(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=True).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_37(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    None
                )
    return pd.DataFrame(records)


def x_run__mutmut_38(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"XXseverityXX": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_39(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"SEVERITY": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_40(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "XXmethodXX": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_41(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "METHOD": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_42(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "XXanomaly_typeXX": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_43(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "ANOMALY_TYPE": atype, "recall": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_44(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "XXrecallXX": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_45(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "RECALL": recall}
                )
    return pd.DataFrame(records)


def x_run__mutmut_46(severities: list[float], seeds: list[int], rows: int | None) -> pd.DataFrame:
    """Return a long frame: severity, method, anomaly_type, recall (seed-mean)."""
    records = []
    for sev in severities:
        per_seed = []
        for s in seeds:
            kw = {"n_rows": rows} if rows else {}
            df = make_synthetic(seed=s, severity=sev, **kw)
            per_seed.append(evaluate(df, s)["recall"])
            log.info("severity %.2f seed %d done", sev, s)
        mean_recall = pd.concat(per_seed).groupby(level=0, sort=False).mean()
        for method, row in mean_recall.iterrows():
            for atype, recall in row.items():
                records.append(
                    {"severity": sev, "method": method, "anomaly_type": atype, "recall": recall}
                )
    return pd.DataFrame(None)

mutants_x_run__mutmut['_mutmut_orig'] = x_run__mutmut_orig # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_1'] = x_run__mutmut_1 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_2'] = x_run__mutmut_2 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_3'] = x_run__mutmut_3 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_4'] = x_run__mutmut_4 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_5'] = x_run__mutmut_5 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_6'] = x_run__mutmut_6 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_7'] = x_run__mutmut_7 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_8'] = x_run__mutmut_8 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_9'] = x_run__mutmut_9 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_10'] = x_run__mutmut_10 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_11'] = x_run__mutmut_11 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_12'] = x_run__mutmut_12 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_13'] = x_run__mutmut_13 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_14'] = x_run__mutmut_14 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_15'] = x_run__mutmut_15 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_16'] = x_run__mutmut_16 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_17'] = x_run__mutmut_17 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_18'] = x_run__mutmut_18 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_19'] = x_run__mutmut_19 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_20'] = x_run__mutmut_20 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_21'] = x_run__mutmut_21 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_22'] = x_run__mutmut_22 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_23'] = x_run__mutmut_23 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_24'] = x_run__mutmut_24 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_25'] = x_run__mutmut_25 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_26'] = x_run__mutmut_26 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_27'] = x_run__mutmut_27 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_28'] = x_run__mutmut_28 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_29'] = x_run__mutmut_29 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_30'] = x_run__mutmut_30 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_31'] = x_run__mutmut_31 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_32'] = x_run__mutmut_32 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_33'] = x_run__mutmut_33 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_34'] = x_run__mutmut_34 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_35'] = x_run__mutmut_35 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_36'] = x_run__mutmut_36 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_37'] = x_run__mutmut_37 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_38'] = x_run__mutmut_38 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_39'] = x_run__mutmut_39 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_40'] = x_run__mutmut_40 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_41'] = x_run__mutmut_41 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_42'] = x_run__mutmut_42 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_43'] = x_run__mutmut_43 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_44'] = x_run__mutmut_44 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_45'] = x_run__mutmut_45 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_46'] = x_run__mutmut_46 # type: ignore # mutmut generated
mutants_x_render__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_render__mutmut)
def render(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_orig(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_1(curves: pd.DataFrame, path: Path) -> Path:
    methods = None
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_2(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["XXmethodXX"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_3(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["METHOD"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_4(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m == "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_5(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "XXtransform_dedupXX"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_6(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "TRANSFORM_DEDUP"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_7(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = None
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_8(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(None, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_9(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, None, figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_10(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=None)
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_11(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_12(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_13(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), )
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_14(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(2, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_15(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 / len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_16(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(5.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_17(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 4.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_18(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = None

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_19(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap(None)

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_20(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("XXtab10XX")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_21(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("TAB10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_22(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(None, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_23(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, None, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_24(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=None):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_25(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_26(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_27(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, ):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_28(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=False):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_29(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = None
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_30(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["XXanomaly_typeXX"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_31(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["ANOMALY_TYPE"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_32(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] != atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_33(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(None):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_34(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = None
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_35(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values(None)
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_36(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["XXmethodXX"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_37(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["METHOD"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_38(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] != method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_39(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("XXseverityXX")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_40(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("SEVERITY")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_41(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                None,
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_42(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                None,
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_43(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker=None,
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_44(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=None,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_45(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=None,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_46(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=None,
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_47(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=None,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_48(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_49(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_50(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_51(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_52(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_53(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_54(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_55(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["XXseverityXX"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_56(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["SEVERITY"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_57(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["XXrecallXX"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_58(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["RECALL"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_59(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="XXoXX",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_60(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="O",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_61(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=4,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_62(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=2.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_63(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(None),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_64(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i / 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_65(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 11),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_66(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(None)
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_67(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace(None, " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_68(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", None))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_69(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace(" "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_70(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", ))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_71(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("XX_XX", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_72(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", "XX XX"))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_73(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel(None)
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_74(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("XXinjection severity (1.0 = reference)XX")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_75(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("INJECTION SEVERITY (1.0 = REFERENCE)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_76(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(None, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_77(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, None)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_78(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_79(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, )
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_80(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(+0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_81(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-1.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_82(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 2.0300000000000002)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_83(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(None, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_84(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color=None, linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_85(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=None, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_86(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle=None)
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_87(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_88(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_89(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_90(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, )
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_91(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(2.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_92(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="XX0.7XX", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_93(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=1.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_94(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="XX--XX")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_95(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel(None)
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_96(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[1].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_97(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("XXrecall on that typeXX")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_98(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("RECALL ON THAT TYPE")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_99(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=None, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_100(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc=None)
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_101(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_102(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, )
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_103(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[+1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_104(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-2].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_105(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=8, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_106(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="XXlower rightXX")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_107(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="LOWER RIGHT")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_108(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle(None)
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_109(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("XXDetection rate by anomaly type versus injection severity (synthetic)XX")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_110(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_111(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("DETECTION RATE BY ANOMALY TYPE VERSUS INJECTION SEVERITY (SYNTHETIC)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_112(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=None, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_113(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=None)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_114(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_115(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, )
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_116(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=False, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_117(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=False)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_118(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(None) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_119(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(None, dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_120(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=None)
    plt.close(fig)
    return path


def x_render__mutmut_121(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(dpi=150)
    plt.close(fig)
    return path


def x_render__mutmut_122(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, )
    plt.close(fig)
    return path


def x_render__mutmut_123(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=151)
    plt.close(fig)
    return path


def x_render__mutmut_124(curves: pd.DataFrame, path: Path) -> Path:
    methods = [m for m in curves["method"].unique() if m != "transform_dedup"]
    fig, axes = plt.subplots(1, len(MAGNITUDE_TYPES), figsize=(4.2 * len(MAGNITUDE_TYPES), 3.6))
    cmap = plt.get_cmap("tab10")

    for ax, atype in zip(axes, MAGNITUDE_TYPES, strict=True):
        sub = curves[curves["anomaly_type"] == atype]
        for i, method in enumerate(methods):
            line = sub[sub["method"] == method].sort_values("severity")
            ax.plot(
                line["severity"],
                line["recall"],
                marker="o",
                markersize=3,
                linewidth=1.4,
                color=cmap(i % 10),
                label=method,
            )
        ax.set_title(atype.replace("_", " "))
        ax.set_xlabel("injection severity (1.0 = reference)")
        ax.set_ylim(-0.03, 1.03)
        ax.axvline(1.0, color="0.7", linewidth=0.8, linestyle="--")
    axes[0].set_ylabel("recall on that type")
    axes[-1].legend(fontsize=7, loc="lower right")
    fig.suptitle("Detection rate by anomaly type versus injection severity (synthetic)")
    fig.tight_layout()

    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(None)
    return path

mutants_x_render__mutmut['_mutmut_orig'] = x_render__mutmut_orig # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_1'] = x_render__mutmut_1 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_2'] = x_render__mutmut_2 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_3'] = x_render__mutmut_3 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_4'] = x_render__mutmut_4 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_5'] = x_render__mutmut_5 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_6'] = x_render__mutmut_6 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_7'] = x_render__mutmut_7 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_8'] = x_render__mutmut_8 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_9'] = x_render__mutmut_9 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_10'] = x_render__mutmut_10 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_11'] = x_render__mutmut_11 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_12'] = x_render__mutmut_12 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_13'] = x_render__mutmut_13 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_14'] = x_render__mutmut_14 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_15'] = x_render__mutmut_15 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_16'] = x_render__mutmut_16 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_17'] = x_render__mutmut_17 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_18'] = x_render__mutmut_18 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_19'] = x_render__mutmut_19 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_20'] = x_render__mutmut_20 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_21'] = x_render__mutmut_21 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_22'] = x_render__mutmut_22 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_23'] = x_render__mutmut_23 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_24'] = x_render__mutmut_24 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_25'] = x_render__mutmut_25 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_26'] = x_render__mutmut_26 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_27'] = x_render__mutmut_27 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_28'] = x_render__mutmut_28 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_29'] = x_render__mutmut_29 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_30'] = x_render__mutmut_30 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_31'] = x_render__mutmut_31 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_32'] = x_render__mutmut_32 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_33'] = x_render__mutmut_33 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_34'] = x_render__mutmut_34 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_35'] = x_render__mutmut_35 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_36'] = x_render__mutmut_36 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_37'] = x_render__mutmut_37 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_38'] = x_render__mutmut_38 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_39'] = x_render__mutmut_39 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_40'] = x_render__mutmut_40 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_41'] = x_render__mutmut_41 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_42'] = x_render__mutmut_42 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_43'] = x_render__mutmut_43 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_44'] = x_render__mutmut_44 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_45'] = x_render__mutmut_45 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_46'] = x_render__mutmut_46 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_47'] = x_render__mutmut_47 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_48'] = x_render__mutmut_48 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_49'] = x_render__mutmut_49 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_50'] = x_render__mutmut_50 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_51'] = x_render__mutmut_51 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_52'] = x_render__mutmut_52 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_53'] = x_render__mutmut_53 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_54'] = x_render__mutmut_54 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_55'] = x_render__mutmut_55 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_56'] = x_render__mutmut_56 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_57'] = x_render__mutmut_57 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_58'] = x_render__mutmut_58 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_59'] = x_render__mutmut_59 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_60'] = x_render__mutmut_60 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_61'] = x_render__mutmut_61 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_62'] = x_render__mutmut_62 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_63'] = x_render__mutmut_63 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_64'] = x_render__mutmut_64 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_65'] = x_render__mutmut_65 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_66'] = x_render__mutmut_66 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_67'] = x_render__mutmut_67 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_68'] = x_render__mutmut_68 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_69'] = x_render__mutmut_69 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_70'] = x_render__mutmut_70 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_71'] = x_render__mutmut_71 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_72'] = x_render__mutmut_72 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_73'] = x_render__mutmut_73 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_74'] = x_render__mutmut_74 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_75'] = x_render__mutmut_75 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_76'] = x_render__mutmut_76 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_77'] = x_render__mutmut_77 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_78'] = x_render__mutmut_78 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_79'] = x_render__mutmut_79 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_80'] = x_render__mutmut_80 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_81'] = x_render__mutmut_81 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_82'] = x_render__mutmut_82 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_83'] = x_render__mutmut_83 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_84'] = x_render__mutmut_84 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_85'] = x_render__mutmut_85 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_86'] = x_render__mutmut_86 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_87'] = x_render__mutmut_87 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_88'] = x_render__mutmut_88 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_89'] = x_render__mutmut_89 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_90'] = x_render__mutmut_90 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_91'] = x_render__mutmut_91 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_92'] = x_render__mutmut_92 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_93'] = x_render__mutmut_93 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_94'] = x_render__mutmut_94 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_95'] = x_render__mutmut_95 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_96'] = x_render__mutmut_96 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_97'] = x_render__mutmut_97 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_98'] = x_render__mutmut_98 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_99'] = x_render__mutmut_99 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_100'] = x_render__mutmut_100 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_101'] = x_render__mutmut_101 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_102'] = x_render__mutmut_102 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_103'] = x_render__mutmut_103 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_104'] = x_render__mutmut_104 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_105'] = x_render__mutmut_105 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_106'] = x_render__mutmut_106 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_107'] = x_render__mutmut_107 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_108'] = x_render__mutmut_108 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_109'] = x_render__mutmut_109 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_110'] = x_render__mutmut_110 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_111'] = x_render__mutmut_111 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_112'] = x_render__mutmut_112 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_113'] = x_render__mutmut_113 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_114'] = x_render__mutmut_114 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_115'] = x_render__mutmut_115 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_116'] = x_render__mutmut_116 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_117'] = x_render__mutmut_117 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_118'] = x_render__mutmut_118 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_119'] = x_render__mutmut_119 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_120'] = x_render__mutmut_120 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_121'] = x_render__mutmut_121 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_122'] = x_render__mutmut_122 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_123'] = x_render__mutmut_123 # type: ignore # mutmut generated
mutants_x_render__mutmut['x_render__mutmut_124'] = x_render__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_orig() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_1() -> None:
    parser = None
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_2() -> None:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_3() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_4() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=None, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_5() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs=None, default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_6() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=None)
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_7() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_8() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_9() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_10() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", )
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_11() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--severitiesXX", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_12() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--SEVERITIES", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_13() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="XX+XX", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_14() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[1.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_15() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 2.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_16() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 3.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_17() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 4.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_18() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 6.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_19() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument(None, type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_20() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=None, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_21() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs=None, default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_22() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=None)
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_23() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument(type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_24() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_25() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_26() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", )
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_27() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("XX--seedsXX", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_28() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--SEEDS", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_29() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="XX+XX", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_30() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[43, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_31() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 2, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_32() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 3])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_33() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument(None, type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_34() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=None)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_35() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument(type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_36() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", )
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_37() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("XX--rowsXX", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_38() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--ROWS", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_39() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument(None, type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_40() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=None, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_41() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=None)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_42() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument(type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_43() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_44() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, )
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_45() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("XX--figureXX", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_46() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--FIGURE", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_47() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(None, type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_48() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=None, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_49() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=None)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_50() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_51() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_52() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, )
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_53() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("XX--results-dirXX", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_54() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--RESULTS-DIR", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_55() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = None

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_56() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(None)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_57() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger(None).setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_58() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("XXgreat_expectationsXX").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_59() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("GREAT_EXPECTATIONS").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_60() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(None)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_61() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger(None).setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_62() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("XXmatplotlibXX").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_63() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("MATPLOTLIB").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_64() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = None

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_65() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(None, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_66() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, None, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_67() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, None)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_68() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_69() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_70() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, )

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_71() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=None, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_72() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=None)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_73() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_74() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, )
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_75() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=False, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_76() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=False)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_77() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = None
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_78() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime(None)
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_79() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(None).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_80() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("XX%Y%m%d_%H%M%SXX")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_81() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%y%m%d_%h%m%s")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_82() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%M%D_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_83() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = None
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_84() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir * f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_85() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(None) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_86() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(None, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_87() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=None)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_88() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_89() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, )
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_90() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=True)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_91() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = None
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_92() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(None, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_93() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, None)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_94() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_95() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, )
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_96() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        None,
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_97() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment=None,
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_98() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=None,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_99() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset=None,
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_100() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings=None,
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_101() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=None,
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_102() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_103() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_104() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_105() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_106() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_107() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_108() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_109() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir * f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_110() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="XXsynthetic_severityXX",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_111() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="SYNTHETIC_SEVERITY",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_112() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="XXsyntheticXX",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_113() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="SYNTHETIC",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_114() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "XXrowsXX": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_115() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "ROWS": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_116() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows and config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_117() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "XXseveritiesXX": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_118() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "SEVERITIES": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_119() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "XXsplit_ratiosXX": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_120() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "SPLIT_RATIOS": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_121() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(None),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_122() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "XXsplit_strategyXX": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_123() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "SPLIT_STRATEGY": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_124() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "XXcustomer_identity_grouped_stratifiedXX",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_125() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "CUSTOMER_IDENTITY_GROUPED_STRATIFIED",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_126() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "XXcalibrationXX": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_127() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "CALIBRATION": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_128() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "XXtrain_label_prevalenceXX",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_129() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "TRAIN_LABEL_PREVALENCE",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_130() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(None)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_131() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = None
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_132() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=None, columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_133() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns=None, values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_134() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values=None
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_135() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_136() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_137() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_138() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(None)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_139() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["XXanomaly_typeXX"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_140() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["ANOMALY_TYPE"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_141() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["XXanomaly_typeXX", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_142() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["ANOMALY_TYPE", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_143() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "XXmethodXX"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_144() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "METHOD"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_145() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="XXseverityXX", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_146() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="SEVERITY", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_147() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="XXrecallXX"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_148() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="RECALL"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_149() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print(None)
    log.info("figure -> %s", figure)


def x_main__mutmut_150() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" - wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_151() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("XX\nXX" + wide.round(3).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_152() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(None).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_153() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(4).to_string())
    log.info("figure -> %s", figure)


def x_main__mutmut_154() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info(None, figure)


def x_main__mutmut_155() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", None)


def x_main__mutmut_156() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info(figure)


def x_main__mutmut_157() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("figure -> %s", )


def x_main__mutmut_158() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("XXfigure -> %sXX", figure)


def x_main__mutmut_159() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--severities", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 5.0])
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 1, 2])
    parser.add_argument("--rows", type=int)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    curves = run(args.severities, args.seeds, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"severity_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        curves.to_csv(partial, index=False)
    figure = render(curves, args.figure)
    write_record(
        args.results_dir / f"run_severity_{stamp}.json",
        experiment="synthetic_severity",
        seeds=args.seeds,
        dataset="synthetic",
        data_path=None,
        settings={
            "rows": args.rows or config.SYNTHETIC_ROWS,
            "severities": args.severities,
            "split_ratios": list(config.SPLIT_RATIOS),
            "split_strategy": "customer_identity_grouped_stratified",
            "calibration": "train_label_prevalence",
        },
        outputs=[csv_out.name, str(figure)],
    )

    wide = curves[curves["anomaly_type"].isin(MAGNITUDE_TYPES)].pivot_table(
        index=["anomaly_type", "method"], columns="severity", values="recall"
    )
    print("\n" + wide.round(3).to_string())
    log.info("FIGURE -> %S", figure)

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_157'] = x_main__mutmut_157 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_158'] = x_main__mutmut_158 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_159'] = x_main__mutmut_159 # type: ignore # mutmut generated


if __name__ == "__main__":
    main()
