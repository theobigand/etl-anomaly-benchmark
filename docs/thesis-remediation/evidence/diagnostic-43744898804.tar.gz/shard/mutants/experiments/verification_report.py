"""Machine-readable verification evidence from pytest and coverage artifacts."""

from __future__ import annotations

import argparse
import json
import platform
import subprocess
import sys
from datetime import UTC, datetime
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from xml.etree import ElementTree

from etl_benchmark.atomic import atomic_path

_COUNTS = {
    "line": ("covered_lines", "num_statements"),
    "branch": ("covered_branches", "num_branches"),
}


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x__metric__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__metric__mutmut)
def _metric(summary: dict, kind: str) -> dict[str, int]:
    covered, coverable = _COUNTS[kind]
    return {"covered": int(summary[covered]), "coverable": int(summary[coverable])}


def x__metric__mutmut_orig(summary: dict, kind: str) -> dict[str, int]:
    covered, coverable = _COUNTS[kind]
    return {"covered": int(summary[covered]), "coverable": int(summary[coverable])}


def x__metric__mutmut_1(summary: dict, kind: str) -> dict[str, int]:
    covered, coverable = None
    return {"covered": int(summary[covered]), "coverable": int(summary[coverable])}


def x__metric__mutmut_2(summary: dict, kind: str) -> dict[str, int]:
    covered, coverable = _COUNTS[kind]
    return {"XXcoveredXX": int(summary[covered]), "coverable": int(summary[coverable])}


def x__metric__mutmut_3(summary: dict, kind: str) -> dict[str, int]:
    covered, coverable = _COUNTS[kind]
    return {"COVERED": int(summary[covered]), "coverable": int(summary[coverable])}


def x__metric__mutmut_4(summary: dict, kind: str) -> dict[str, int]:
    covered, coverable = _COUNTS[kind]
    return {"covered": int(None), "coverable": int(summary[coverable])}


def x__metric__mutmut_5(summary: dict, kind: str) -> dict[str, int]:
    covered, coverable = _COUNTS[kind]
    return {"covered": int(summary[covered]), "XXcoverableXX": int(summary[coverable])}


def x__metric__mutmut_6(summary: dict, kind: str) -> dict[str, int]:
    covered, coverable = _COUNTS[kind]
    return {"covered": int(summary[covered]), "COVERABLE": int(summary[coverable])}


def x__metric__mutmut_7(summary: dict, kind: str) -> dict[str, int]:
    covered, coverable = _COUNTS[kind]
    return {"covered": int(summary[covered]), "coverable": int(None)}

mutants_x__metric__mutmut['_mutmut_orig'] = x__metric__mutmut_orig # type: ignore # mutmut generated
mutants_x__metric__mutmut['x__metric__mutmut_1'] = x__metric__mutmut_1 # type: ignore # mutmut generated
mutants_x__metric__mutmut['x__metric__mutmut_2'] = x__metric__mutmut_2 # type: ignore # mutmut generated
mutants_x__metric__mutmut['x__metric__mutmut_3'] = x__metric__mutmut_3 # type: ignore # mutmut generated
mutants_x__metric__mutmut['x__metric__mutmut_4'] = x__metric__mutmut_4 # type: ignore # mutmut generated
mutants_x__metric__mutmut['x__metric__mutmut_5'] = x__metric__mutmut_5 # type: ignore # mutmut generated
mutants_x__metric__mutmut['x__metric__mutmut_6'] = x__metric__mutmut_6 # type: ignore # mutmut generated
mutants_x__metric__mutmut['x__metric__mutmut_7'] = x__metric__mutmut_7 # type: ignore # mutmut generated
mutants_x__git__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__git__mutmut)
def _git(*args: str) -> str:
    return subprocess.check_output(["git", *args], text=True).strip()


def x__git__mutmut_orig(*args: str) -> str:
    return subprocess.check_output(["git", *args], text=True).strip()


def x__git__mutmut_1(*args: str) -> str:
    return subprocess.check_output(None, text=True).strip()


def x__git__mutmut_2(*args: str) -> str:
    return subprocess.check_output(["git", *args], text=None).strip()


def x__git__mutmut_3(*args: str) -> str:
    return subprocess.check_output(text=True).strip()


def x__git__mutmut_4(*args: str) -> str:
    return subprocess.check_output(["git", *args], ).strip()


def x__git__mutmut_5(*args: str) -> str:
    return subprocess.check_output(["XXgitXX", *args], text=True).strip()


def x__git__mutmut_6(*args: str) -> str:
    return subprocess.check_output(["GIT", *args], text=True).strip()


def x__git__mutmut_7(*args: str) -> str:
    return subprocess.check_output(["git", *args], text=False).strip()

mutants_x__git__mutmut['_mutmut_orig'] = x__git__mutmut_orig # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_1'] = x__git__mutmut_1 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_2'] = x__git__mutmut_2 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_3'] = x__git__mutmut_3 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_4'] = x__git__mutmut_4 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_5'] = x__git__mutmut_5 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_6'] = x__git__mutmut_6 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_7'] = x__git__mutmut_7 # type: ignore # mutmut generated
mutants_x_build_report__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_build_report__mutmut)
def build_report(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_orig(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_1(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() and not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_2(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_3(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_4(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError(None)
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_5(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("XXmissing coverage or test evidenceXX")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_6(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("MISSING COVERAGE OR TEST EVIDENCE")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_7(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = None
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_8(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(None)
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_9(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = None
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_10(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(None).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_11(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = None
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_12(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if (root.tag == "testsuite") and False else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_13(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if (root.tag == "testsuite") or True else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_14(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag != "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_15(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "XXtestsuiteXX" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_16(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "TESTSUITE" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_17(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(None)
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_18(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall(None))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_19(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("XXtestsuiteXX"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_20(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("TESTSUITE"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_21(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = None
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_22(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(None)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_23(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(None) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_24(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(None, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_25(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, None)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_26(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_27(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, )) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_28(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 1)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_29(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("XXtestsXX", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_30(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("TESTS", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_31(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "XXfailuresXX", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_32(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "FAILURES", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_33(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "XXerrorsXX", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_34(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "ERRORS", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_35(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "XXskippedXX")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_36(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "SKIPPED")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_37(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = None
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_38(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(None, "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_39(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], None)
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_40(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric("line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_41(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], )
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_42(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["XXtotalsXX"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_43(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["TOTALS"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_44(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "XXlineXX")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_45(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "LINE")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_46(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = None
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_47(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(None, "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_48(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], None)
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_49(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric("branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_50(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], )
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_51(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["XXtotalsXX"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_52(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["TOTALS"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_53(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "XXbranchXX")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_54(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "BRANCH")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_55(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError(None) from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_56(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("XXmalformed verification evidenceXX") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_57(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("MALFORMED VERIFICATION EVIDENCE") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_58(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["XXtestsXX"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_59(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["TESTS"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_60(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] < 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_61(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 1:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_62(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError(None)
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_63(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("XXzero tests executedXX")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_64(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("ZERO TESTS EXECUTED")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_65(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 and branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_66(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["XXcoverableXX"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_67(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["COVERABLE"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_68(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] < 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_69(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 1 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_70(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["XXcoverableXX"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_71(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["COVERABLE"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_72(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] < 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_73(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 1:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_74(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError(None)
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_75(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("XXzero instrumented production lines or branchesXX")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_76(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("ZERO INSTRUMENTED PRODUCTION LINES OR BRANCHES")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_77(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = None
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_78(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if (tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))) and False
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_79(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if (tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))) or True
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_80(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "XXPASSXX"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_81(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "pass"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_82(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0 or all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_83(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["XXfailuresXX"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_84(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["FAILURES"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_85(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] != tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_86(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["XXerrorsXX"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_87(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["ERRORS"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_88(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] != tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_89(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["XXskippedXX"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_90(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["SKIPPED"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_91(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] != 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_92(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 1
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_93(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(None)
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_94(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["XXcoveredXX"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_95(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["COVERED"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_96(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] != metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_97(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["XXcoverableXX"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_98(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["COVERABLE"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_99(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "XXFAILXX"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_100(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "fail"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_101(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = None
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_102(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git(None, "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_103(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", None)
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_104(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_105(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", )
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_106(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("XXrev-parseXX", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_107(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("REV-PARSE", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_108(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "XXHEADXX")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_109(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "head")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_110(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = None
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_111(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(None)
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_112(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git(None, "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_113(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", None))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_114(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_115(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", ))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_116(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("XXstatusXX", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_117(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("STATUS", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_118(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "XX--porcelainXX"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_119(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--PORCELAIN"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_120(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_121(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = None
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_122(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("XXpytestXX", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_123(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("PYTEST", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_124(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "XXpytest-covXX", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_125(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "PYTEST-COV", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_126(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "XXnumpyXX", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_127(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "NUMPY", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_128(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "XXpandasXX", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_129(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "PANDAS", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_130(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "XXscikit-learnXX", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_131(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "SCIKIT-LEARN", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_132(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "XXpyodXX"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_133(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "PYOD"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_134(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = None
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_135(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(None)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_136(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = ""
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_137(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "XXschema_versionXX": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_138(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "SCHEMA_VERSION": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_139(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 2,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_140(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "XXstatusXX": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_141(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "STATUS": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_142(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "XXcaptured_atXX": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_143(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "CAPTURED_AT": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_144(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(None).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_145(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "XXsource_revisionXX": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_146(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "SOURCE_REVISION": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_147(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "XXdirtyXX": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_148(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "DIRTY": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_149(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "XXplatformXX": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_150(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "PLATFORM": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_151(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "XXpythonXX": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_152(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "PYTHON": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_153(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[1],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_154(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "XXpackagesXX": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_155(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "PACKAGES": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_156(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "XXtestsXX": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_157(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "TESTS": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_158(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "XXtotalXX": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_159(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "TOTAL": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_160(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["XXtestsXX"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_161(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["TESTS"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_162(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "XXfailuresXX": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_163(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "FAILURES": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_164(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["XXfailuresXX"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_165(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["FAILURES"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_166(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "XXerrorsXX": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_167(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "ERRORS": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_168(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["XXerrorsXX"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_169(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["ERRORS"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_170(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "XXskippedXX": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_171(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "SKIPPED": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_172(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["XXskippedXX"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_173(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["SKIPPED"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_174(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "XXcoverageXX": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_175(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "COVERAGE": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_176(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "XXlineXX": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_177(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "LINE": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_178(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "XXbranchXX": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_179(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "BRANCH": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_180(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "XXper_fileXX": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_181(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "PER_FILE": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_182(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "XXlineXX": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_183(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "LINE": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_184(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(None, "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_185(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], None),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_186(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric("line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_187(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], ),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_188(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["XXsummaryXX"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_189(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["SUMMARY"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_190(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "XXlineXX"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_191(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "LINE"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_192(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "XXbranchXX": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_193(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "BRANCH": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_194(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(None, "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_195(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], None),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_196(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric("branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_197(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], ),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_198(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["XXsummaryXX"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_199(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["SUMMARY"], "branch"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_200(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "XXbranchXX"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_201(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "BRANCH"),
                }
                for name, data in coverage.get("files", {}).items()
            },
        },
    }


def x_build_report__mutmut_202(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get(None, {}).items()
            },
        },
    }


def x_build_report__mutmut_203(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", None).items()
            },
        },
    }


def x_build_report__mutmut_204(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get({}).items()
            },
        },
    }


def x_build_report__mutmut_205(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("files", ).items()
            },
        },
    }


def x_build_report__mutmut_206(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("XXfilesXX", {}).items()
            },
        },
    }


def x_build_report__mutmut_207(coverage_path: Path, junit_path: Path) -> dict:
    """Reject absent, malformed or empty artifacts rather than issuing a pass."""
    if not coverage_path.is_file() or not junit_path.is_file():
        raise ValueError("missing coverage or test evidence")
    try:
        coverage = json.loads(coverage_path.read_text())
        root = ElementTree.parse(junit_path).getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {
            key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        line = _metric(coverage["totals"], "line")
        branch = _metric(coverage["totals"], "branch")
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        raise ValueError("malformed verification evidence") from exc
    if tests["tests"] <= 0:
        raise ValueError("zero tests executed")
    if line["coverable"] <= 0 or branch["coverable"] <= 0:
        raise ValueError("zero instrumented production lines or branches")
    status = (
        "PASS"
        if tests["failures"] == tests["errors"] == tests["skipped"] == 0
        and all(metric["covered"] == metric["coverable"] for metric in (line, branch))
        else "FAIL"
    )
    try:
        revision = _git("rev-parse", "HEAD")
        dirty = bool(_git("status", "--porcelain"))
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = None, None
    packages = {}
    for package in ("pytest", "pytest-cov", "numpy", "pandas", "scikit-learn", "pyod"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {
        "schema_version": 1,
        "status": status,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "dirty": dirty,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "packages": packages,
        "tests": {
            "total": tests["tests"],
            "failures": tests["failures"],
            "errors": tests["errors"],
            "skipped": tests["skipped"],
        },
        "coverage": {
            "line": line,
            "branch": branch,
            "per_file": {
                name: {
                    "line": _metric(data["summary"], "line"),
                    "branch": _metric(data["summary"], "branch"),
                }
                for name, data in coverage.get("FILES", {}).items()
            },
        },
    }

mutants_x_build_report__mutmut['_mutmut_orig'] = x_build_report__mutmut_orig # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_1'] = x_build_report__mutmut_1 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_2'] = x_build_report__mutmut_2 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_3'] = x_build_report__mutmut_3 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_4'] = x_build_report__mutmut_4 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_5'] = x_build_report__mutmut_5 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_6'] = x_build_report__mutmut_6 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_7'] = x_build_report__mutmut_7 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_8'] = x_build_report__mutmut_8 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_9'] = x_build_report__mutmut_9 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_10'] = x_build_report__mutmut_10 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_11'] = x_build_report__mutmut_11 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_12'] = x_build_report__mutmut_12 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_13'] = x_build_report__mutmut_13 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_14'] = x_build_report__mutmut_14 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_15'] = x_build_report__mutmut_15 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_16'] = x_build_report__mutmut_16 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_17'] = x_build_report__mutmut_17 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_18'] = x_build_report__mutmut_18 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_19'] = x_build_report__mutmut_19 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_20'] = x_build_report__mutmut_20 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_21'] = x_build_report__mutmut_21 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_22'] = x_build_report__mutmut_22 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_23'] = x_build_report__mutmut_23 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_24'] = x_build_report__mutmut_24 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_25'] = x_build_report__mutmut_25 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_26'] = x_build_report__mutmut_26 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_27'] = x_build_report__mutmut_27 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_28'] = x_build_report__mutmut_28 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_29'] = x_build_report__mutmut_29 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_30'] = x_build_report__mutmut_30 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_31'] = x_build_report__mutmut_31 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_32'] = x_build_report__mutmut_32 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_33'] = x_build_report__mutmut_33 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_34'] = x_build_report__mutmut_34 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_35'] = x_build_report__mutmut_35 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_36'] = x_build_report__mutmut_36 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_37'] = x_build_report__mutmut_37 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_38'] = x_build_report__mutmut_38 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_39'] = x_build_report__mutmut_39 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_40'] = x_build_report__mutmut_40 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_41'] = x_build_report__mutmut_41 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_42'] = x_build_report__mutmut_42 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_43'] = x_build_report__mutmut_43 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_44'] = x_build_report__mutmut_44 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_45'] = x_build_report__mutmut_45 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_46'] = x_build_report__mutmut_46 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_47'] = x_build_report__mutmut_47 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_48'] = x_build_report__mutmut_48 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_49'] = x_build_report__mutmut_49 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_50'] = x_build_report__mutmut_50 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_51'] = x_build_report__mutmut_51 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_52'] = x_build_report__mutmut_52 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_53'] = x_build_report__mutmut_53 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_54'] = x_build_report__mutmut_54 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_55'] = x_build_report__mutmut_55 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_56'] = x_build_report__mutmut_56 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_57'] = x_build_report__mutmut_57 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_58'] = x_build_report__mutmut_58 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_59'] = x_build_report__mutmut_59 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_60'] = x_build_report__mutmut_60 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_61'] = x_build_report__mutmut_61 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_62'] = x_build_report__mutmut_62 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_63'] = x_build_report__mutmut_63 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_64'] = x_build_report__mutmut_64 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_65'] = x_build_report__mutmut_65 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_66'] = x_build_report__mutmut_66 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_67'] = x_build_report__mutmut_67 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_68'] = x_build_report__mutmut_68 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_69'] = x_build_report__mutmut_69 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_70'] = x_build_report__mutmut_70 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_71'] = x_build_report__mutmut_71 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_72'] = x_build_report__mutmut_72 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_73'] = x_build_report__mutmut_73 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_74'] = x_build_report__mutmut_74 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_75'] = x_build_report__mutmut_75 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_76'] = x_build_report__mutmut_76 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_77'] = x_build_report__mutmut_77 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_78'] = x_build_report__mutmut_78 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_79'] = x_build_report__mutmut_79 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_80'] = x_build_report__mutmut_80 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_81'] = x_build_report__mutmut_81 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_82'] = x_build_report__mutmut_82 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_83'] = x_build_report__mutmut_83 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_84'] = x_build_report__mutmut_84 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_85'] = x_build_report__mutmut_85 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_86'] = x_build_report__mutmut_86 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_87'] = x_build_report__mutmut_87 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_88'] = x_build_report__mutmut_88 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_89'] = x_build_report__mutmut_89 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_90'] = x_build_report__mutmut_90 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_91'] = x_build_report__mutmut_91 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_92'] = x_build_report__mutmut_92 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_93'] = x_build_report__mutmut_93 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_94'] = x_build_report__mutmut_94 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_95'] = x_build_report__mutmut_95 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_96'] = x_build_report__mutmut_96 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_97'] = x_build_report__mutmut_97 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_98'] = x_build_report__mutmut_98 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_99'] = x_build_report__mutmut_99 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_100'] = x_build_report__mutmut_100 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_101'] = x_build_report__mutmut_101 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_102'] = x_build_report__mutmut_102 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_103'] = x_build_report__mutmut_103 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_104'] = x_build_report__mutmut_104 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_105'] = x_build_report__mutmut_105 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_106'] = x_build_report__mutmut_106 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_107'] = x_build_report__mutmut_107 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_108'] = x_build_report__mutmut_108 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_109'] = x_build_report__mutmut_109 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_110'] = x_build_report__mutmut_110 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_111'] = x_build_report__mutmut_111 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_112'] = x_build_report__mutmut_112 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_113'] = x_build_report__mutmut_113 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_114'] = x_build_report__mutmut_114 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_115'] = x_build_report__mutmut_115 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_116'] = x_build_report__mutmut_116 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_117'] = x_build_report__mutmut_117 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_118'] = x_build_report__mutmut_118 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_119'] = x_build_report__mutmut_119 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_120'] = x_build_report__mutmut_120 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_121'] = x_build_report__mutmut_121 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_122'] = x_build_report__mutmut_122 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_123'] = x_build_report__mutmut_123 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_124'] = x_build_report__mutmut_124 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_125'] = x_build_report__mutmut_125 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_126'] = x_build_report__mutmut_126 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_127'] = x_build_report__mutmut_127 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_128'] = x_build_report__mutmut_128 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_129'] = x_build_report__mutmut_129 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_130'] = x_build_report__mutmut_130 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_131'] = x_build_report__mutmut_131 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_132'] = x_build_report__mutmut_132 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_133'] = x_build_report__mutmut_133 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_134'] = x_build_report__mutmut_134 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_135'] = x_build_report__mutmut_135 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_136'] = x_build_report__mutmut_136 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_137'] = x_build_report__mutmut_137 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_138'] = x_build_report__mutmut_138 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_139'] = x_build_report__mutmut_139 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_140'] = x_build_report__mutmut_140 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_141'] = x_build_report__mutmut_141 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_142'] = x_build_report__mutmut_142 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_143'] = x_build_report__mutmut_143 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_144'] = x_build_report__mutmut_144 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_145'] = x_build_report__mutmut_145 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_146'] = x_build_report__mutmut_146 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_147'] = x_build_report__mutmut_147 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_148'] = x_build_report__mutmut_148 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_149'] = x_build_report__mutmut_149 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_150'] = x_build_report__mutmut_150 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_151'] = x_build_report__mutmut_151 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_152'] = x_build_report__mutmut_152 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_153'] = x_build_report__mutmut_153 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_154'] = x_build_report__mutmut_154 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_155'] = x_build_report__mutmut_155 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_156'] = x_build_report__mutmut_156 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_157'] = x_build_report__mutmut_157 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_158'] = x_build_report__mutmut_158 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_159'] = x_build_report__mutmut_159 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_160'] = x_build_report__mutmut_160 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_161'] = x_build_report__mutmut_161 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_162'] = x_build_report__mutmut_162 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_163'] = x_build_report__mutmut_163 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_164'] = x_build_report__mutmut_164 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_165'] = x_build_report__mutmut_165 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_166'] = x_build_report__mutmut_166 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_167'] = x_build_report__mutmut_167 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_168'] = x_build_report__mutmut_168 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_169'] = x_build_report__mutmut_169 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_170'] = x_build_report__mutmut_170 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_171'] = x_build_report__mutmut_171 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_172'] = x_build_report__mutmut_172 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_173'] = x_build_report__mutmut_173 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_174'] = x_build_report__mutmut_174 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_175'] = x_build_report__mutmut_175 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_176'] = x_build_report__mutmut_176 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_177'] = x_build_report__mutmut_177 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_178'] = x_build_report__mutmut_178 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_179'] = x_build_report__mutmut_179 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_180'] = x_build_report__mutmut_180 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_181'] = x_build_report__mutmut_181 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_182'] = x_build_report__mutmut_182 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_183'] = x_build_report__mutmut_183 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_184'] = x_build_report__mutmut_184 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_185'] = x_build_report__mutmut_185 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_186'] = x_build_report__mutmut_186 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_187'] = x_build_report__mutmut_187 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_188'] = x_build_report__mutmut_188 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_189'] = x_build_report__mutmut_189 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_190'] = x_build_report__mutmut_190 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_191'] = x_build_report__mutmut_191 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_192'] = x_build_report__mutmut_192 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_193'] = x_build_report__mutmut_193 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_194'] = x_build_report__mutmut_194 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_195'] = x_build_report__mutmut_195 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_196'] = x_build_report__mutmut_196 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_197'] = x_build_report__mutmut_197 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_198'] = x_build_report__mutmut_198 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_199'] = x_build_report__mutmut_199 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_200'] = x_build_report__mutmut_200 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_201'] = x_build_report__mutmut_201 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_202'] = x_build_report__mutmut_202 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_203'] = x_build_report__mutmut_203 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_204'] = x_build_report__mutmut_204 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_205'] = x_build_report__mutmut_205 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_206'] = x_build_report__mutmut_206 # type: ignore # mutmut generated
mutants_x_build_report__mutmut['x_build_report__mutmut_207'] = x_build_report__mutmut_207 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_orig() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_1() -> int:
    parser = None
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_2() -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_3() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_4() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=None, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_5() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=None)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_6() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_7() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_8() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, )
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_9() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--coverageXX", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_10() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--COVERAGE", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_11() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=False)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_12() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_13() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=None, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_14() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=None)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_15() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_16() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_17() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_18() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("XX--junitXX", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_19() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--JUNIT", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_20() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=False)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_21() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument(None, type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_22() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=None, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_23() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=None)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_24() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument(type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_25() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_26() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, )
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_27() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("XX--outputXX", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_28() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--OUTPUT", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_29() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=False)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_30() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = None
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_31() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = None
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_32() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(None, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_33() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, None)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_34() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_35() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_36() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=None, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_37() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=None)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_38() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_39() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, )
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_40() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=False, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_41() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=False)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_42() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(None) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_43() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(None)
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_44() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) - "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_45() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(None, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_46() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=None, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_47() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=None) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_48() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_49() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_50() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, ) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_51() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=3, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_52() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=False) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_53() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "XX\nXX")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_54() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(None)
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_55() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['XXstatusXX']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_56() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['STATUS']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_57() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['XXtestsXX']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_58() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['TESTS']['total']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_59() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['XXtotalXX']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_60() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['TOTAL']} tests)")
    return 0 if report["status"] == "PASS" else 1


def x_main__mutmut_61() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if (report["status"] == "PASS") and False else 1


def x_main__mutmut_62() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if (report["status"] == "PASS") or True else 1


def x_main__mutmut_63() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 1 if report["status"] == "PASS" else 1


def x_main__mutmut_64() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["XXstatusXX"] == "PASS" else 1


def x_main__mutmut_65() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["STATUS"] == "PASS" else 1


def x_main__mutmut_66() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] != "PASS" else 1


def x_main__mutmut_67() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "XXPASSXX" else 1


def x_main__mutmut_68() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "pass" else 1


def x_main__mutmut_69() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = build_report(args.coverage, args.junit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"verification: {report['status']} ({report['tests']['total']} tests)")
    return 0 if report["status"] == "PASS" else 2

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
