"""Reproducible run metadata for thesis experiment artifacts."""

from __future__ import annotations

import ast
import gzip
import hashlib
import json
import os
import platform
import subprocess
import sys
import tomllib
from datetime import UTC, datetime
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

import pandas as pd

from etl_benchmark.atomic import atomic_path
from etl_benchmark.split import stratified_split

ROOT = Path(__file__).resolve().parents[1]

# Recipe 2 binds only what can change a result. Recipe 1 (``_source_fingerprint``)
# also hashed the verification gates, so editing a gate invalidated every run.
SCIENTIFIC_RECIPE = 2
VERIFICATION_ONLY = frozenset(
    {
        "experiments/verify_real.py",
        "experiments/check_mutation.py",
        "experiments/verification_report.py",
    }
)
# This module only shapes the split archives; its other functions write metadata.
RESULT_FUNCTIONS = ("write_split_ids", "read_split_ids")

# The measurement fingerprint binds how time and memory are measured, apart from
# what is detected. It covers the scaling harness and the timing code of
# ``pipeline.detect``. A new script that measures time or memory must be added
# here (or listed with a reason in ``TIMING_NOT_MEASUREMENT``): a test searches
# the tree for timing primitives and fails on an unregistered file.
MEASUREMENT_RECIPE = 1
MEASUREMENT_FILES = ("verification/scaling.py",)
MEASUREMENT_FUNCTIONS = {"src/etl_benchmark/pipeline.py": ("DetectionResult", "detect")}
TIMING_NOT_MEASUREMENT = {
    "verification/reproduce.py": "compares timing columns as a spread and never decides a status",
}


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_write_split_ids__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_write_split_ids__mutmut)
def write_split_ids(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_orig(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_1(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None or fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_2(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_3(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample < 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_4(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 1:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_5(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError(None)
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_6(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("XXfit_sample must be positiveXX")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_7(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("FIT_SAMPLE MUST BE POSITIVE")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_8(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = None
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_9(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "XX_split_row_idXX"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_10(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_SPLIT_ROW_ID"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_11(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker not in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_12(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(None)
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_13(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = None
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_14(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(None)})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_15(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = None
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_16(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = None
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_17(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(None, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_18(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, None, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_19(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, None, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_20(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, None)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_21(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_22(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_23(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_24(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, )
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_25(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = None
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_26(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(None).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_27(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("XXtrainXX", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_28(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("TRAIN", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_29(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("XXvalidationXX", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_30(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("VALIDATION", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_31(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("XXtestXX", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_32(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("TEST", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_33(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None or fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_34(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_35(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample <= len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_36(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = None
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_37(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["XXfitXX"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_38(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["FIT"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_39(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=None, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_40(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=None).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_41(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_42(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, ).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_43(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = None
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_44(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(None)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_45(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = None
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_46(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"XXschema_versionXX": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_47(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"SCHEMA_VERSION": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_48(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 2, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_49(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "XXrow_countXX": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_50(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "ROW_COUNT": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_51(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "XXseedsXX": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_52(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "SEEDS": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_53(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=None, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_54(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=None)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_55(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_56(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, )
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_57(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=False, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_58(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=False)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_59(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = None
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_60(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(None, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_61(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=None, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_62(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=None).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_63(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_64(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_65(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, ).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_66(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=False, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_67(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=("XX,XX", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_68(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", "XX:XX")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_69(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(None) as partial:
        partial.write_bytes(gzip.compress(document, mtime=0))
    return path


def x_write_split_ids__mutmut_70(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(None)
    return path


def x_write_split_ids__mutmut_71(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(None, mtime=0))
    return path


def x_write_split_ids__mutmut_72(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=None))
    return path


def x_write_split_ids__mutmut_73(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(mtime=0))
    return path


def x_write_split_ids__mutmut_74(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, ))
    return path


def x_write_split_ids__mutmut_75(
    path: Path,
    frame: pd.DataFrame,
    label_column: str,
    seeds: list[int],
    ratios: tuple[float, float, float],
    fit_sample: int | None = None,
) -> Path:
    """Archive row positions after preprocessing for each seeded split."""
    if fit_sample is not None and fit_sample <= 0:
        raise ValueError("fit_sample must be positive")
    marker = "_split_row_id"
    if marker in frame:
        raise ValueError(f"reserved split marker {marker!r} is already present")
    marked = frame.assign(**{marker: range(len(frame))})
    partitions = {}
    for seed in seeds:
        train, validation, test = stratified_split(marked, label_column, ratios, seed)
        membership = {
            name: part[marker].astype(int).tolist()
            for name, part in (("train", train), ("validation", validation), ("test", test))
        }
        if fit_sample is not None and fit_sample < len(train):
            membership["fit"] = train[marker].sample(n=fit_sample, random_state=seed).tolist()
        partitions[str(seed)] = membership
    record = {"schema_version": 1, "row_count": len(frame), "seeds": partitions}
    path.parent.mkdir(parents=True, exist_ok=True)
    document = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    with atomic_path(path) as partial:
        partial.write_bytes(gzip.compress(document, mtime=1))
    return path

mutants_x_write_split_ids__mutmut['_mutmut_orig'] = x_write_split_ids__mutmut_orig # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_1'] = x_write_split_ids__mutmut_1 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_2'] = x_write_split_ids__mutmut_2 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_3'] = x_write_split_ids__mutmut_3 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_4'] = x_write_split_ids__mutmut_4 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_5'] = x_write_split_ids__mutmut_5 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_6'] = x_write_split_ids__mutmut_6 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_7'] = x_write_split_ids__mutmut_7 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_8'] = x_write_split_ids__mutmut_8 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_9'] = x_write_split_ids__mutmut_9 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_10'] = x_write_split_ids__mutmut_10 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_11'] = x_write_split_ids__mutmut_11 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_12'] = x_write_split_ids__mutmut_12 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_13'] = x_write_split_ids__mutmut_13 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_14'] = x_write_split_ids__mutmut_14 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_15'] = x_write_split_ids__mutmut_15 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_16'] = x_write_split_ids__mutmut_16 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_17'] = x_write_split_ids__mutmut_17 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_18'] = x_write_split_ids__mutmut_18 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_19'] = x_write_split_ids__mutmut_19 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_20'] = x_write_split_ids__mutmut_20 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_21'] = x_write_split_ids__mutmut_21 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_22'] = x_write_split_ids__mutmut_22 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_23'] = x_write_split_ids__mutmut_23 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_24'] = x_write_split_ids__mutmut_24 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_25'] = x_write_split_ids__mutmut_25 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_26'] = x_write_split_ids__mutmut_26 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_27'] = x_write_split_ids__mutmut_27 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_28'] = x_write_split_ids__mutmut_28 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_29'] = x_write_split_ids__mutmut_29 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_30'] = x_write_split_ids__mutmut_30 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_31'] = x_write_split_ids__mutmut_31 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_32'] = x_write_split_ids__mutmut_32 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_33'] = x_write_split_ids__mutmut_33 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_34'] = x_write_split_ids__mutmut_34 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_35'] = x_write_split_ids__mutmut_35 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_36'] = x_write_split_ids__mutmut_36 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_37'] = x_write_split_ids__mutmut_37 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_38'] = x_write_split_ids__mutmut_38 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_39'] = x_write_split_ids__mutmut_39 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_40'] = x_write_split_ids__mutmut_40 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_41'] = x_write_split_ids__mutmut_41 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_42'] = x_write_split_ids__mutmut_42 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_43'] = x_write_split_ids__mutmut_43 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_44'] = x_write_split_ids__mutmut_44 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_45'] = x_write_split_ids__mutmut_45 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_46'] = x_write_split_ids__mutmut_46 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_47'] = x_write_split_ids__mutmut_47 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_48'] = x_write_split_ids__mutmut_48 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_49'] = x_write_split_ids__mutmut_49 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_50'] = x_write_split_ids__mutmut_50 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_51'] = x_write_split_ids__mutmut_51 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_52'] = x_write_split_ids__mutmut_52 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_53'] = x_write_split_ids__mutmut_53 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_54'] = x_write_split_ids__mutmut_54 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_55'] = x_write_split_ids__mutmut_55 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_56'] = x_write_split_ids__mutmut_56 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_57'] = x_write_split_ids__mutmut_57 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_58'] = x_write_split_ids__mutmut_58 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_59'] = x_write_split_ids__mutmut_59 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_60'] = x_write_split_ids__mutmut_60 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_61'] = x_write_split_ids__mutmut_61 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_62'] = x_write_split_ids__mutmut_62 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_63'] = x_write_split_ids__mutmut_63 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_64'] = x_write_split_ids__mutmut_64 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_65'] = x_write_split_ids__mutmut_65 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_66'] = x_write_split_ids__mutmut_66 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_67'] = x_write_split_ids__mutmut_67 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_68'] = x_write_split_ids__mutmut_68 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_69'] = x_write_split_ids__mutmut_69 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_70'] = x_write_split_ids__mutmut_70 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_71'] = x_write_split_ids__mutmut_71 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_72'] = x_write_split_ids__mutmut_72 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_73'] = x_write_split_ids__mutmut_73 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_74'] = x_write_split_ids__mutmut_74 # type: ignore # mutmut generated
mutants_x_write_split_ids__mutmut['x_write_split_ids__mutmut_75'] = x_write_split_ids__mutmut_75 # type: ignore # mutmut generated
mutants_x_read_split_ids__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_read_split_ids__mutmut)
def read_split_ids(path: Path) -> dict:
    """Read an archive produced by :func:`write_split_ids`."""
    with gzip.open(path) as stream:
        return json.load(stream)


def x_read_split_ids__mutmut_orig(path: Path) -> dict:
    """Read an archive produced by :func:`write_split_ids`."""
    with gzip.open(path) as stream:
        return json.load(stream)


def x_read_split_ids__mutmut_1(path: Path) -> dict:
    """Read an archive produced by :func:`write_split_ids`."""
    with gzip.open(None) as stream:
        return json.load(stream)


def x_read_split_ids__mutmut_2(path: Path) -> dict:
    """Read an archive produced by :func:`write_split_ids`."""
    with gzip.open(path) as stream:
        return json.load(None)

mutants_x_read_split_ids__mutmut['_mutmut_orig'] = x_read_split_ids__mutmut_orig # type: ignore # mutmut generated
mutants_x_read_split_ids__mutmut['x_read_split_ids__mutmut_1'] = x_read_split_ids__mutmut_1 # type: ignore # mutmut generated
mutants_x_read_split_ids__mutmut['x_read_split_ids__mutmut_2'] = x_read_split_ids__mutmut_2 # type: ignore # mutmut generated
mutants_x__git__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__git__mutmut)
def _git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def x__git__mutmut_orig(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def x__git__mutmut_1(*args: str) -> str:
    return subprocess.check_output(None, cwd=ROOT, text=True).strip()


def x__git__mutmut_2(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=None, text=True).strip()


def x__git__mutmut_3(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=None).strip()


def x__git__mutmut_4(*args: str) -> str:
    return subprocess.check_output(cwd=ROOT, text=True).strip()


def x__git__mutmut_5(*args: str) -> str:
    return subprocess.check_output(["git", *args], text=True).strip()


def x__git__mutmut_6(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, ).strip()


def x__git__mutmut_7(*args: str) -> str:
    return subprocess.check_output(["XXgitXX", *args], cwd=ROOT, text=True).strip()


def x__git__mutmut_8(*args: str) -> str:
    return subprocess.check_output(["GIT", *args], cwd=ROOT, text=True).strip()


def x__git__mutmut_9(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=False).strip()

mutants_x__git__mutmut['_mutmut_orig'] = x__git__mutmut_orig # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_1'] = x__git__mutmut_1 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_2'] = x__git__mutmut_2 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_3'] = x__git__mutmut_3 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_4'] = x__git__mutmut_4 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_5'] = x__git__mutmut_5 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_6'] = x__git__mutmut_6 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_7'] = x__git__mutmut_7 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_8'] = x__git__mutmut_8 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_9'] = x__git__mutmut_9 # type: ignore # mutmut generated
mutants_x__hash_file__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__hash_file__mutmut)
def _hash_file(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, hashlib.sha256).hexdigest()


def x__hash_file__mutmut_orig(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, hashlib.sha256).hexdigest()


def x__hash_file__mutmut_1(path: Path) -> str:
    with path.open(None) as stream:
        return hashlib.file_digest(stream, hashlib.sha256).hexdigest()


def x__hash_file__mutmut_2(path: Path) -> str:
    with path.open("XXrbXX") as stream:
        return hashlib.file_digest(stream, hashlib.sha256).hexdigest()


def x__hash_file__mutmut_3(path: Path) -> str:
    with path.open("RB") as stream:
        return hashlib.file_digest(stream, hashlib.sha256).hexdigest()


def x__hash_file__mutmut_4(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(None, hashlib.sha256).hexdigest()


def x__hash_file__mutmut_5(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, None).hexdigest()


def x__hash_file__mutmut_6(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(hashlib.sha256).hexdigest()


def x__hash_file__mutmut_7(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, ).hexdigest()

mutants_x__hash_file__mutmut['_mutmut_orig'] = x__hash_file__mutmut_orig # type: ignore # mutmut generated
mutants_x__hash_file__mutmut['x__hash_file__mutmut_1'] = x__hash_file__mutmut_1 # type: ignore # mutmut generated
mutants_x__hash_file__mutmut['x__hash_file__mutmut_2'] = x__hash_file__mutmut_2 # type: ignore # mutmut generated
mutants_x__hash_file__mutmut['x__hash_file__mutmut_3'] = x__hash_file__mutmut_3 # type: ignore # mutmut generated
mutants_x__hash_file__mutmut['x__hash_file__mutmut_4'] = x__hash_file__mutmut_4 # type: ignore # mutmut generated
mutants_x__hash_file__mutmut['x__hash_file__mutmut_5'] = x__hash_file__mutmut_5 # type: ignore # mutmut generated
mutants_x__hash_file__mutmut['x__hash_file__mutmut_6'] = x__hash_file__mutmut_6 # type: ignore # mutmut generated
mutants_x__hash_file__mutmut['x__hash_file__mutmut_7'] = x__hash_file__mutmut_7 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__source_fingerprint__mutmut)
def _source_fingerprint() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_orig() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_1() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = None
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_2() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = None
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_3() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob(None),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_4() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("XXsrc/**/*.pyXX"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_5() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("SRC/**/*.PY"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_6() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob(None),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_7() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("XXexperiments/*.pyXX"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_8() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("EXPERIMENTS/*.PY"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_9() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT * "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_10() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "XXenvironment.ymlXX",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_11() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "ENVIRONMENT.YML",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_12() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(None):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_13() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(None)
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_14() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(None).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_15() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(None)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_16() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(None)
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_17() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = None
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_18() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads(None)["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_19() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT * "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_20() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "XXpyproject.tomlXX").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_21() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "PYPROJECT.TOML").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_22() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["XXprojectXX"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_23() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["PROJECT"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_24() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(None)
    return digest.hexdigest()


def x__source_fingerprint__mutmut_25() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(None, sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_26() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=None).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_27() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(sort_keys=True).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_28() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, ).encode())
    return digest.hexdigest()


def x__source_fingerprint__mutmut_29() -> str:
    """Hash the code, the environment file and the project metadata.

    Only the ``[project]`` table of ``pyproject.toml`` counts (name,
    dependencies); settings of test and mutation tools do not change a result.
    """
    digest = hashlib.sha256()
    paths = [
        *ROOT.glob("src/**/*.py"),
        *ROOT.glob("experiments/*.py"),
        ROOT / "environment.yml",
    ]
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
    digest.update(json.dumps(project, sort_keys=False).encode())
    return digest.hexdigest()

mutants_x__source_fingerprint__mutmut['_mutmut_orig'] = x__source_fingerprint__mutmut_orig # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_1'] = x__source_fingerprint__mutmut_1 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_2'] = x__source_fingerprint__mutmut_2 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_3'] = x__source_fingerprint__mutmut_3 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_4'] = x__source_fingerprint__mutmut_4 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_5'] = x__source_fingerprint__mutmut_5 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_6'] = x__source_fingerprint__mutmut_6 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_7'] = x__source_fingerprint__mutmut_7 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_8'] = x__source_fingerprint__mutmut_8 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_9'] = x__source_fingerprint__mutmut_9 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_10'] = x__source_fingerprint__mutmut_10 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_11'] = x__source_fingerprint__mutmut_11 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_12'] = x__source_fingerprint__mutmut_12 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_13'] = x__source_fingerprint__mutmut_13 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_14'] = x__source_fingerprint__mutmut_14 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_15'] = x__source_fingerprint__mutmut_15 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_16'] = x__source_fingerprint__mutmut_16 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_17'] = x__source_fingerprint__mutmut_17 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_18'] = x__source_fingerprint__mutmut_18 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_19'] = x__source_fingerprint__mutmut_19 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_20'] = x__source_fingerprint__mutmut_20 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_21'] = x__source_fingerprint__mutmut_21 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_22'] = x__source_fingerprint__mutmut_22 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_23'] = x__source_fingerprint__mutmut_23 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_24'] = x__source_fingerprint__mutmut_24 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_25'] = x__source_fingerprint__mutmut_25 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_26'] = x__source_fingerprint__mutmut_26 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_27'] = x__source_fingerprint__mutmut_27 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_28'] = x__source_fingerprint__mutmut_28 # type: ignore # mutmut generated
mutants_x__source_fingerprint__mutmut['x__source_fingerprint__mutmut_29'] = x__source_fingerprint__mutmut_29 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_is_scientific_path__mutmut)
def is_scientific_path(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_orig(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_1(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = None
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_2(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split(None)
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_3(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("XX/XX")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_4(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative not in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_5(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return True
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_6(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[1] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_7(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] != "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_8(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "XXsrcXX":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_9(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "SRC":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_10(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(None)
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_11(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith("XX.pyXX")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_12(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".PY")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_13(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[1] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_14(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] != "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_15(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "XXexperimentsXX":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_16(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "EXPERIMENTS":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_17(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 or relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_18(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) != 2 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_19(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 3 and relative.endswith(".py")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_20(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(None)
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_21(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith("XX.pyXX")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_22(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".PY")
    return relative == "environment.yml"


def x_is_scientific_path__mutmut_23(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative != "environment.yml"


def x_is_scientific_path__mutmut_24(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "XXenvironment.ymlXX"


def x_is_scientific_path__mutmut_25(relative: str) -> bool:
    """Whether a repository-relative path is part of the recipe-2 fingerprint."""
    parts = relative.split("/")
    if relative in VERIFICATION_ONLY:
        return False
    if parts[0] == "src":
        return relative.endswith(".py")
    if parts[0] == "experiments":
        return len(parts) == 2 and relative.endswith(".py")
    return relative == "ENVIRONMENT.YML"

mutants_x_is_scientific_path__mutmut['_mutmut_orig'] = x_is_scientific_path__mutmut_orig # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_1'] = x_is_scientific_path__mutmut_1 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_2'] = x_is_scientific_path__mutmut_2 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_3'] = x_is_scientific_path__mutmut_3 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_4'] = x_is_scientific_path__mutmut_4 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_5'] = x_is_scientific_path__mutmut_5 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_6'] = x_is_scientific_path__mutmut_6 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_7'] = x_is_scientific_path__mutmut_7 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_8'] = x_is_scientific_path__mutmut_8 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_9'] = x_is_scientific_path__mutmut_9 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_10'] = x_is_scientific_path__mutmut_10 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_11'] = x_is_scientific_path__mutmut_11 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_12'] = x_is_scientific_path__mutmut_12 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_13'] = x_is_scientific_path__mutmut_13 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_14'] = x_is_scientific_path__mutmut_14 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_15'] = x_is_scientific_path__mutmut_15 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_16'] = x_is_scientific_path__mutmut_16 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_17'] = x_is_scientific_path__mutmut_17 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_18'] = x_is_scientific_path__mutmut_18 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_19'] = x_is_scientific_path__mutmut_19 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_20'] = x_is_scientific_path__mutmut_20 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_21'] = x_is_scientific_path__mutmut_21 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_22'] = x_is_scientific_path__mutmut_22 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_23'] = x_is_scientific_path__mutmut_23 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_24'] = x_is_scientific_path__mutmut_24 # type: ignore # mutmut generated
mutants_x_is_scientific_path__mutmut['x_is_scientific_path__mutmut_25'] = x_is_scientific_path__mutmut_25 # type: ignore # mutmut generated
mutants_x__result_functions__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__result_functions__mutmut)
def _result_functions(source: bytes) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name in RESULT_FUNCTIONS
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__result_functions__mutmut_orig(source: bytes) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name in RESULT_FUNCTIONS
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__result_functions__mutmut_1(source: bytes) -> bytes:
    text = None
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name in RESULT_FUNCTIONS
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__result_functions__mutmut_2(source: bytes) -> bytes:
    text = source.decode()
    nodes = None
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__result_functions__mutmut_3(source: bytes) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(None).body
        if isinstance(node, ast.FunctionDef) and node.name in RESULT_FUNCTIONS
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__result_functions__mutmut_4(source: bytes) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) or node.name in RESULT_FUNCTIONS
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__result_functions__mutmut_5(source: bytes) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name not in RESULT_FUNCTIONS
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__result_functions__mutmut_6(source: bytes) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name in RESULT_FUNCTIONS
    ]
    return "\n".join(None).encode()


def x__result_functions__mutmut_7(source: bytes) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name in RESULT_FUNCTIONS
    ]
    return "XX\nXX".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__result_functions__mutmut_8(source: bytes) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name in RESULT_FUNCTIONS
    ]
    return "\n".join(ast.get_source_segment(None, node) for node in nodes).encode()


def x__result_functions__mutmut_9(source: bytes) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name in RESULT_FUNCTIONS
    ]
    return "\n".join(ast.get_source_segment(text, None) for node in nodes).encode()


def x__result_functions__mutmut_10(source: bytes) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name in RESULT_FUNCTIONS
    ]
    return "\n".join(ast.get_source_segment(node) for node in nodes).encode()


def x__result_functions__mutmut_11(source: bytes) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name in RESULT_FUNCTIONS
    ]
    return "\n".join(ast.get_source_segment(text, ) for node in nodes).encode()

mutants_x__result_functions__mutmut['_mutmut_orig'] = x__result_functions__mutmut_orig # type: ignore # mutmut generated
mutants_x__result_functions__mutmut['x__result_functions__mutmut_1'] = x__result_functions__mutmut_1 # type: ignore # mutmut generated
mutants_x__result_functions__mutmut['x__result_functions__mutmut_2'] = x__result_functions__mutmut_2 # type: ignore # mutmut generated
mutants_x__result_functions__mutmut['x__result_functions__mutmut_3'] = x__result_functions__mutmut_3 # type: ignore # mutmut generated
mutants_x__result_functions__mutmut['x__result_functions__mutmut_4'] = x__result_functions__mutmut_4 # type: ignore # mutmut generated
mutants_x__result_functions__mutmut['x__result_functions__mutmut_5'] = x__result_functions__mutmut_5 # type: ignore # mutmut generated
mutants_x__result_functions__mutmut['x__result_functions__mutmut_6'] = x__result_functions__mutmut_6 # type: ignore # mutmut generated
mutants_x__result_functions__mutmut['x__result_functions__mutmut_7'] = x__result_functions__mutmut_7 # type: ignore # mutmut generated
mutants_x__result_functions__mutmut['x__result_functions__mutmut_8'] = x__result_functions__mutmut_8 # type: ignore # mutmut generated
mutants_x__result_functions__mutmut['x__result_functions__mutmut_9'] = x__result_functions__mutmut_9 # type: ignore # mutmut generated
mutants_x__result_functions__mutmut['x__result_functions__mutmut_10'] = x__result_functions__mutmut_10 # type: ignore # mutmut generated
mutants_x__result_functions__mutmut['x__result_functions__mutmut_11'] = x__result_functions__mutmut_11 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_scientific_fingerprint_of__mutmut)
def scientific_fingerprint_of(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_orig(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_1(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = None
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_2(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(None)
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_3(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(None):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_4(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(None)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_5(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = None
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_6(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative != "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_7(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "XXexperiments/provenance.pyXX":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_8(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "EXPERIMENTS/PROVENANCE.PY":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_9(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = None
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_10(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(None)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_11(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(None)
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_12(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(None)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_13(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = None
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_14(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(None)["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_15(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["XXpyproject.tomlXX"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_16(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["PYPROJECT.TOML"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_17(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["XXprojectXX"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_18(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["PROJECT"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_19(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(None)
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_20(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(None, sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_21(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=None).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_22(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(sort_keys=True).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_23(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, ).encode())
    return digest.hexdigest()


def x_scientific_fingerprint_of__mutmut_24(files: dict[str, bytes]) -> str:
    """Recipe-2 hash of a ``{relative path: content}`` mapping of a source tree.

    Counts the code under ``src/`` and the experiment scripts (not the
    verification gates), the split-archive functions of this module, the
    environment file and the ``[project]`` table of ``pyproject.toml``.
    """
    digest = hashlib.sha256(f"scientific-recipe:{SCIENTIFIC_RECIPE}\n".encode())
    for relative in sorted(path for path in files if is_scientific_path(path)):
        content = files[relative]
        if relative == "experiments/provenance.py":
            content = _result_functions(content)
        digest.update(relative.encode())
        digest.update(content)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=False).encode())
    return digest.hexdigest()

mutants_x_scientific_fingerprint_of__mutmut['_mutmut_orig'] = x_scientific_fingerprint_of__mutmut_orig # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_1'] = x_scientific_fingerprint_of__mutmut_1 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_2'] = x_scientific_fingerprint_of__mutmut_2 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_3'] = x_scientific_fingerprint_of__mutmut_3 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_4'] = x_scientific_fingerprint_of__mutmut_4 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_5'] = x_scientific_fingerprint_of__mutmut_5 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_6'] = x_scientific_fingerprint_of__mutmut_6 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_7'] = x_scientific_fingerprint_of__mutmut_7 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_8'] = x_scientific_fingerprint_of__mutmut_8 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_9'] = x_scientific_fingerprint_of__mutmut_9 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_10'] = x_scientific_fingerprint_of__mutmut_10 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_11'] = x_scientific_fingerprint_of__mutmut_11 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_12'] = x_scientific_fingerprint_of__mutmut_12 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_13'] = x_scientific_fingerprint_of__mutmut_13 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_14'] = x_scientific_fingerprint_of__mutmut_14 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_15'] = x_scientific_fingerprint_of__mutmut_15 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_16'] = x_scientific_fingerprint_of__mutmut_16 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_17'] = x_scientific_fingerprint_of__mutmut_17 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_18'] = x_scientific_fingerprint_of__mutmut_18 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_19'] = x_scientific_fingerprint_of__mutmut_19 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_20'] = x_scientific_fingerprint_of__mutmut_20 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_21'] = x_scientific_fingerprint_of__mutmut_21 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_22'] = x_scientific_fingerprint_of__mutmut_22 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_23'] = x_scientific_fingerprint_of__mutmut_23 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint_of__mutmut['x_scientific_fingerprint_of__mutmut_24'] = x_scientific_fingerprint_of__mutmut_24 # type: ignore # mutmut generated
mutants_x__segments__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__segments__mutmut)
def _segments(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) and node.name in names
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__segments__mutmut_orig(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) and node.name in names
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__segments__mutmut_1(source: bytes, names: tuple[str, ...]) -> bytes:
    text = None
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) and node.name in names
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__segments__mutmut_2(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = None
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__segments__mutmut_3(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(None).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) and node.name in names
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__segments__mutmut_4(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) or node.name in names
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__segments__mutmut_5(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) and node.name not in names
    ]
    return "\n".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__segments__mutmut_6(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) and node.name in names
    ]
    return "\n".join(None).encode()


def x__segments__mutmut_7(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) and node.name in names
    ]
    return "XX\nXX".join(ast.get_source_segment(text, node) for node in nodes).encode()


def x__segments__mutmut_8(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) and node.name in names
    ]
    return "\n".join(ast.get_source_segment(None, node) for node in nodes).encode()


def x__segments__mutmut_9(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) and node.name in names
    ]
    return "\n".join(ast.get_source_segment(text, None) for node in nodes).encode()


def x__segments__mutmut_10(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) and node.name in names
    ]
    return "\n".join(ast.get_source_segment(node) for node in nodes).encode()


def x__segments__mutmut_11(source: bytes, names: tuple[str, ...]) -> bytes:
    text = source.decode()
    nodes = [
        node
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef | ast.ClassDef) and node.name in names
    ]
    return "\n".join(ast.get_source_segment(text, ) for node in nodes).encode()

mutants_x__segments__mutmut['_mutmut_orig'] = x__segments__mutmut_orig # type: ignore # mutmut generated
mutants_x__segments__mutmut['x__segments__mutmut_1'] = x__segments__mutmut_1 # type: ignore # mutmut generated
mutants_x__segments__mutmut['x__segments__mutmut_2'] = x__segments__mutmut_2 # type: ignore # mutmut generated
mutants_x__segments__mutmut['x__segments__mutmut_3'] = x__segments__mutmut_3 # type: ignore # mutmut generated
mutants_x__segments__mutmut['x__segments__mutmut_4'] = x__segments__mutmut_4 # type: ignore # mutmut generated
mutants_x__segments__mutmut['x__segments__mutmut_5'] = x__segments__mutmut_5 # type: ignore # mutmut generated
mutants_x__segments__mutmut['x__segments__mutmut_6'] = x__segments__mutmut_6 # type: ignore # mutmut generated
mutants_x__segments__mutmut['x__segments__mutmut_7'] = x__segments__mutmut_7 # type: ignore # mutmut generated
mutants_x__segments__mutmut['x__segments__mutmut_8'] = x__segments__mutmut_8 # type: ignore # mutmut generated
mutants_x__segments__mutmut['x__segments__mutmut_9'] = x__segments__mutmut_9 # type: ignore # mutmut generated
mutants_x__segments__mutmut['x__segments__mutmut_10'] = x__segments__mutmut_10 # type: ignore # mutmut generated
mutants_x__segments__mutmut['x__segments__mutmut_11'] = x__segments__mutmut_11 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_measurement_fingerprint_of__mutmut)
def measurement_fingerprint_of(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_orig(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_1(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = None
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_2(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(None)
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_3(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted(None):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_4(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_5(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            break
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_6(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = None
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_7(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative not in MEASUREMENT_FUNCTIONS:
            content = _segments(content, MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_8(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = None
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_9(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(None, MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_10(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, None)
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_11(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_12(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, )
        digest.update(relative.encode())
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_13(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, MEASUREMENT_FUNCTIONS[relative])
        digest.update(None)
        digest.update(content)
    return digest.hexdigest()


def x_measurement_fingerprint_of__mutmut_14(files: dict[str, bytes]) -> str:
    """Recipe-1 hash of the measurement method over a ``{path: content}`` mapping."""
    digest = hashlib.sha256(f"measurement-recipe:{MEASUREMENT_RECIPE}\n".encode())
    for relative in sorted({*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}):
        if relative not in files:
            continue
        content = files[relative]
        if relative in MEASUREMENT_FUNCTIONS:
            content = _segments(content, MEASUREMENT_FUNCTIONS[relative])
        digest.update(relative.encode())
        digest.update(None)
    return digest.hexdigest()

mutants_x_measurement_fingerprint_of__mutmut['_mutmut_orig'] = x_measurement_fingerprint_of__mutmut_orig # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_1'] = x_measurement_fingerprint_of__mutmut_1 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_2'] = x_measurement_fingerprint_of__mutmut_2 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_3'] = x_measurement_fingerprint_of__mutmut_3 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_4'] = x_measurement_fingerprint_of__mutmut_4 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_5'] = x_measurement_fingerprint_of__mutmut_5 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_6'] = x_measurement_fingerprint_of__mutmut_6 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_7'] = x_measurement_fingerprint_of__mutmut_7 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_8'] = x_measurement_fingerprint_of__mutmut_8 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_9'] = x_measurement_fingerprint_of__mutmut_9 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_10'] = x_measurement_fingerprint_of__mutmut_10 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_11'] = x_measurement_fingerprint_of__mutmut_11 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_12'] = x_measurement_fingerprint_of__mutmut_12 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_13'] = x_measurement_fingerprint_of__mutmut_13 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint_of__mutmut['x_measurement_fingerprint_of__mutmut_14'] = x_measurement_fingerprint_of__mutmut_14 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_measurement_fingerprint__mutmut)
def measurement_fingerprint() -> str:
    """Recipe-1 measurement hash of the working tree."""
    wanted = {*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}
    files = {name: (ROOT / name).read_bytes() for name in wanted if (ROOT / name).is_file()}
    return measurement_fingerprint_of(files)


def x_measurement_fingerprint__mutmut_orig() -> str:
    """Recipe-1 measurement hash of the working tree."""
    wanted = {*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}
    files = {name: (ROOT / name).read_bytes() for name in wanted if (ROOT / name).is_file()}
    return measurement_fingerprint_of(files)


def x_measurement_fingerprint__mutmut_1() -> str:
    """Recipe-1 measurement hash of the working tree."""
    wanted = None
    files = {name: (ROOT / name).read_bytes() for name in wanted if (ROOT / name).is_file()}
    return measurement_fingerprint_of(files)


def x_measurement_fingerprint__mutmut_2() -> str:
    """Recipe-1 measurement hash of the working tree."""
    wanted = {*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}
    files = None
    return measurement_fingerprint_of(files)


def x_measurement_fingerprint__mutmut_3() -> str:
    """Recipe-1 measurement hash of the working tree."""
    wanted = {*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}
    files = {name: (ROOT * name).read_bytes() for name in wanted if (ROOT / name).is_file()}
    return measurement_fingerprint_of(files)


def x_measurement_fingerprint__mutmut_4() -> str:
    """Recipe-1 measurement hash of the working tree."""
    wanted = {*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}
    files = {name: (ROOT / name).read_bytes() for name in wanted if (ROOT * name).is_file()}
    return measurement_fingerprint_of(files)


def x_measurement_fingerprint__mutmut_5() -> str:
    """Recipe-1 measurement hash of the working tree."""
    wanted = {*MEASUREMENT_FILES, *MEASUREMENT_FUNCTIONS}
    files = {name: (ROOT / name).read_bytes() for name in wanted if (ROOT / name).is_file()}
    return measurement_fingerprint_of(None)

mutants_x_measurement_fingerprint__mutmut['_mutmut_orig'] = x_measurement_fingerprint__mutmut_orig # type: ignore # mutmut generated
mutants_x_measurement_fingerprint__mutmut['x_measurement_fingerprint__mutmut_1'] = x_measurement_fingerprint__mutmut_1 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint__mutmut['x_measurement_fingerprint__mutmut_2'] = x_measurement_fingerprint__mutmut_2 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint__mutmut['x_measurement_fingerprint__mutmut_3'] = x_measurement_fingerprint__mutmut_3 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint__mutmut['x_measurement_fingerprint__mutmut_4'] = x_measurement_fingerprint__mutmut_4 # type: ignore # mutmut generated
mutants_x_measurement_fingerprint__mutmut['x_measurement_fingerprint__mutmut_5'] = x_measurement_fingerprint__mutmut_5 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_scientific_fingerprint__mutmut)
def scientific_fingerprint() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_orig() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_1() -> str:
    """Recipe-2 hash of the working tree."""
    paths = None
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_2() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob(None), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_3() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("XXsrc/**/*.pyXX"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_4() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("SRC/**/*.PY"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_5() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob(None), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_6() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("XXexperiments/*.pyXX"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_7() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("EXPERIMENTS/*.PY"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_8() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT * "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_9() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "XXenvironment.ymlXX"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_10() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "ENVIRONMENT.YML"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_11() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = None
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_12() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(None): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_13() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(None)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_14() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = None
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_15() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["XXpyproject.tomlXX"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_16() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["PYPROJECT.TOML"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_17() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT * "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_18() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "XXpyproject.tomlXX").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_19() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "PYPROJECT.TOML").read_bytes()
    return scientific_fingerprint_of(files)


def x_scientific_fingerprint__mutmut_20() -> str:
    """Recipe-2 hash of the working tree."""
    paths = [*ROOT.glob("src/**/*.py"), *ROOT.glob("experiments/*.py"), ROOT / "environment.yml"]
    files = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    return scientific_fingerprint_of(None)

mutants_x_scientific_fingerprint__mutmut['_mutmut_orig'] = x_scientific_fingerprint__mutmut_orig # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_1'] = x_scientific_fingerprint__mutmut_1 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_2'] = x_scientific_fingerprint__mutmut_2 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_3'] = x_scientific_fingerprint__mutmut_3 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_4'] = x_scientific_fingerprint__mutmut_4 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_5'] = x_scientific_fingerprint__mutmut_5 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_6'] = x_scientific_fingerprint__mutmut_6 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_7'] = x_scientific_fingerprint__mutmut_7 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_8'] = x_scientific_fingerprint__mutmut_8 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_9'] = x_scientific_fingerprint__mutmut_9 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_10'] = x_scientific_fingerprint__mutmut_10 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_11'] = x_scientific_fingerprint__mutmut_11 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_12'] = x_scientific_fingerprint__mutmut_12 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_13'] = x_scientific_fingerprint__mutmut_13 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_14'] = x_scientific_fingerprint__mutmut_14 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_15'] = x_scientific_fingerprint__mutmut_15 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_16'] = x_scientific_fingerprint__mutmut_16 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_17'] = x_scientific_fingerprint__mutmut_17 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_18'] = x_scientific_fingerprint__mutmut_18 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_19'] = x_scientific_fingerprint__mutmut_19 # type: ignore # mutmut generated
mutants_x_scientific_fingerprint__mutmut['x_scientific_fingerprint__mutmut_20'] = x_scientific_fingerprint__mutmut_20 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__environment_lock__mutmut)
def _environment_lock() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_orig() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_1() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = None
    path = ROOT / "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_2() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().upper()}-{platform.machine()}"
    path = ROOT / "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_3() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = None
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_4() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "environment" * f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_5() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" * "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_6() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT * "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_7() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "XXverificationXX" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_8() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "VERIFICATION" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_9() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "XXenvironmentXX" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_10() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "ENVIRONMENT" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_11() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "XXfileXX": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_12() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "FILE": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_13() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "XXsha256XX": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_14() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "SHA256": _hash_file(path) if path.is_file() else None,
    }


def x__environment_lock__mutmut_15() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if (path.is_file()) and False else None,
    }


def x__environment_lock__mutmut_16() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(path) if (path.is_file()) or True else None,
    }


def x__environment_lock__mutmut_17() -> dict[str, str | None]:
    """Hash of the recorded conda lock for this platform, or None when absent."""
    system = f"{platform.system().lower()}-{platform.machine()}"
    path = ROOT / "verification" / "environment" / f"conda-{system}.explicit.txt"
    return {
        "file": f"verification/environment/{path.name}",
        "sha256": _hash_file(None) if path.is_file() else None,
    }

mutants_x__environment_lock__mutmut['_mutmut_orig'] = x__environment_lock__mutmut_orig # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_1'] = x__environment_lock__mutmut_1 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_2'] = x__environment_lock__mutmut_2 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_3'] = x__environment_lock__mutmut_3 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_4'] = x__environment_lock__mutmut_4 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_5'] = x__environment_lock__mutmut_5 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_6'] = x__environment_lock__mutmut_6 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_7'] = x__environment_lock__mutmut_7 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_8'] = x__environment_lock__mutmut_8 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_9'] = x__environment_lock__mutmut_9 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_10'] = x__environment_lock__mutmut_10 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_11'] = x__environment_lock__mutmut_11 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_12'] = x__environment_lock__mutmut_12 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_13'] = x__environment_lock__mutmut_13 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_14'] = x__environment_lock__mutmut_14 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_15'] = x__environment_lock__mutmut_15 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_16'] = x__environment_lock__mutmut_16 # type: ignore # mutmut generated
mutants_x__environment_lock__mutmut['x__environment_lock__mutmut_17'] = x__environment_lock__mutmut_17 # type: ignore # mutmut generated
mutants_x__hash_outputs__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__hash_outputs__mutmut)
def _hash_outputs(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = {}
    for name in outputs:
        target = directory / name  # an absolute name replaces the directory
        if not target.is_file():
            raise FileNotFoundError(f"output {name} was not written")
        if target.stat().st_size == 0:
            raise ValueError(f"output {name} is empty")
        hashes[name] = _hash_file(target)
    return hashes


def x__hash_outputs__mutmut_orig(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = {}
    for name in outputs:
        target = directory / name  # an absolute name replaces the directory
        if not target.is_file():
            raise FileNotFoundError(f"output {name} was not written")
        if target.stat().st_size == 0:
            raise ValueError(f"output {name} is empty")
        hashes[name] = _hash_file(target)
    return hashes


def x__hash_outputs__mutmut_1(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = None
    for name in outputs:
        target = directory / name  # an absolute name replaces the directory
        if not target.is_file():
            raise FileNotFoundError(f"output {name} was not written")
        if target.stat().st_size == 0:
            raise ValueError(f"output {name} is empty")
        hashes[name] = _hash_file(target)
    return hashes


def x__hash_outputs__mutmut_2(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = {}
    for name in outputs:
        target = None  # an absolute name replaces the directory
        if not target.is_file():
            raise FileNotFoundError(f"output {name} was not written")
        if target.stat().st_size == 0:
            raise ValueError(f"output {name} is empty")
        hashes[name] = _hash_file(target)
    return hashes


def x__hash_outputs__mutmut_3(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = {}
    for name in outputs:
        target = directory * name  # an absolute name replaces the directory
        if not target.is_file():
            raise FileNotFoundError(f"output {name} was not written")
        if target.stat().st_size == 0:
            raise ValueError(f"output {name} is empty")
        hashes[name] = _hash_file(target)
    return hashes


def x__hash_outputs__mutmut_4(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = {}
    for name in outputs:
        target = directory / name  # an absolute name replaces the directory
        if target.is_file():
            raise FileNotFoundError(f"output {name} was not written")
        if target.stat().st_size == 0:
            raise ValueError(f"output {name} is empty")
        hashes[name] = _hash_file(target)
    return hashes


def x__hash_outputs__mutmut_5(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = {}
    for name in outputs:
        target = directory / name  # an absolute name replaces the directory
        if not target.is_file():
            raise FileNotFoundError(None)
        if target.stat().st_size == 0:
            raise ValueError(f"output {name} is empty")
        hashes[name] = _hash_file(target)
    return hashes


def x__hash_outputs__mutmut_6(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = {}
    for name in outputs:
        target = directory / name  # an absolute name replaces the directory
        if not target.is_file():
            raise FileNotFoundError(f"output {name} was not written")
        if target.stat().st_size != 0:
            raise ValueError(f"output {name} is empty")
        hashes[name] = _hash_file(target)
    return hashes


def x__hash_outputs__mutmut_7(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = {}
    for name in outputs:
        target = directory / name  # an absolute name replaces the directory
        if not target.is_file():
            raise FileNotFoundError(f"output {name} was not written")
        if target.stat().st_size == 1:
            raise ValueError(f"output {name} is empty")
        hashes[name] = _hash_file(target)
    return hashes


def x__hash_outputs__mutmut_8(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = {}
    for name in outputs:
        target = directory / name  # an absolute name replaces the directory
        if not target.is_file():
            raise FileNotFoundError(f"output {name} was not written")
        if target.stat().st_size == 0:
            raise ValueError(None)
        hashes[name] = _hash_file(target)
    return hashes


def x__hash_outputs__mutmut_9(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = {}
    for name in outputs:
        target = directory / name  # an absolute name replaces the directory
        if not target.is_file():
            raise FileNotFoundError(f"output {name} was not written")
        if target.stat().st_size == 0:
            raise ValueError(f"output {name} is empty")
        hashes[name] = None
    return hashes


def x__hash_outputs__mutmut_10(outputs: list[str], directory: Path) -> dict[str, str]:
    """sha256 of every output a record lists; a missing or empty output is an error."""
    hashes = {}
    for name in outputs:
        target = directory / name  # an absolute name replaces the directory
        if not target.is_file():
            raise FileNotFoundError(f"output {name} was not written")
        if target.stat().st_size == 0:
            raise ValueError(f"output {name} is empty")
        hashes[name] = _hash_file(None)
    return hashes

mutants_x__hash_outputs__mutmut['_mutmut_orig'] = x__hash_outputs__mutmut_orig # type: ignore # mutmut generated
mutants_x__hash_outputs__mutmut['x__hash_outputs__mutmut_1'] = x__hash_outputs__mutmut_1 # type: ignore # mutmut generated
mutants_x__hash_outputs__mutmut['x__hash_outputs__mutmut_2'] = x__hash_outputs__mutmut_2 # type: ignore # mutmut generated
mutants_x__hash_outputs__mutmut['x__hash_outputs__mutmut_3'] = x__hash_outputs__mutmut_3 # type: ignore # mutmut generated
mutants_x__hash_outputs__mutmut['x__hash_outputs__mutmut_4'] = x__hash_outputs__mutmut_4 # type: ignore # mutmut generated
mutants_x__hash_outputs__mutmut['x__hash_outputs__mutmut_5'] = x__hash_outputs__mutmut_5 # type: ignore # mutmut generated
mutants_x__hash_outputs__mutmut['x__hash_outputs__mutmut_6'] = x__hash_outputs__mutmut_6 # type: ignore # mutmut generated
mutants_x__hash_outputs__mutmut['x__hash_outputs__mutmut_7'] = x__hash_outputs__mutmut_7 # type: ignore # mutmut generated
mutants_x__hash_outputs__mutmut['x__hash_outputs__mutmut_8'] = x__hash_outputs__mutmut_8 # type: ignore # mutmut generated
mutants_x__hash_outputs__mutmut['x__hash_outputs__mutmut_9'] = x__hash_outputs__mutmut_9 # type: ignore # mutmut generated
mutants_x__hash_outputs__mutmut['x__hash_outputs__mutmut_10'] = x__hash_outputs__mutmut_10 # type: ignore # mutmut generated
mutants_x_write_record__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_write_record__mutmut)
def write_record(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_orig(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_1(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = None
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_2(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git(None, "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_3(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", None)
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_4(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_5(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", )
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_6(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("XXrev-parseXX", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_7(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("REV-PARSE", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_8(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "XXHEADXX")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_9(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "head")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_10(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = None
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_11(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("XXnumpyXX", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_12(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("NUMPY", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_13(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "XXpandasXX", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_14(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "PANDAS", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_15(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "XXscikit-learnXX", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_16(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "SCIKIT-LEARN", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_17(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "XXpyodXX", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_18(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "PYOD", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_19(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "XXgreat-expectationsXX"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_20(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "GREAT-EXPECTATIONS"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_21(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = None
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_22(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(None)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_23(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = ""
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_24(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = None
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_25(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"XXidentityXX": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_26(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"IDENTITY": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_27(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_28(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            None
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_29(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "XXpathXX": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_30(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "PATH": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_31(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(None),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_32(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "XXsha256XX": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_33(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "SHA256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_34(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(None),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_35(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "XXbytesXX": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_36(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "BYTES": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_37(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = None
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_38(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(None, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_39(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, None)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_40(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_41(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, )
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_42(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = None
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_43(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "XXschema_versionXX": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_44(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "SCHEMA_VERSION": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_45(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 2,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_46(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "XXexperimentXX": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_47(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "EXPERIMENT": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_48(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "XXcaptured_atXX": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_49(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "CAPTURED_AT": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_50(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(None).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_51(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "XXsource_revisionXX": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_52(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "SOURCE_REVISION": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_53(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "XXsource_fingerprintXX": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_54(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "SOURCE_FINGERPRINT": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_55(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "XXfingerprint_recipeXX": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_56(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "FINGERPRINT_RECIPE": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_57(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "XXscientific_fingerprintXX": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_58(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "SCIENTIFIC_FINGERPRINT": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_59(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "XXmeasurement_recipeXX": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_60(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "MEASUREMENT_RECIPE": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_61(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "XXmeasurement_fingerprintXX": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_62(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "MEASUREMENT_FINGERPRINT": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_63(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "XXworktree_dirtyXX": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_64(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "WORKTREE_DIRTY": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_65(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(None),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_66(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git(None, "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_67(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", None)),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_68(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_69(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", )),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_70(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("XXstatusXX", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_71(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("STATUS", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_72(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "XX--porcelainXX")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_73(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--PORCELAIN")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_74(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "XXpythonXX": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_75(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "PYTHON": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_76(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[1],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_77(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "XXplatformXX": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_78(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "PLATFORM": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_79(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "XXpackagesXX": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_80(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "PACKAGES": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_81(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "XXenvironment_lockXX": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_82(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "ENVIRONMENT_LOCK": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_83(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "XXdatasetXX": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_84(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "DATASET": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_85(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "XXseedsXX": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_86(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "SEEDS": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_87(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "XXsettingsXX": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_88(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "SETTINGS": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_89(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "XXoutputsXX": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_90(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "OUTPUTS": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_91(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "XXoutput_sha256XX": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_92(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "OUTPUT_SHA256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_93(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = None
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_94(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) - "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_95(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(None, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_96(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=None, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_97(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=None) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_98(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_99(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_100(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, ) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_101(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=3, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_102(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=False) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_103(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "XX\nXX"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_104(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=None, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_105(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=None)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_106(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_107(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, )
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_108(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=False, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_109(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=False)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_110(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_111(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(None)
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_112(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open(None) as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_113(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("XXwXX") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_114(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("W") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_115(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(None)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_116(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(None)
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_117(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(None, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_118(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, None)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_119(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_120(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, )
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def x_write_record__mutmut_121(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=None)
        raise
    return path


def x_write_record__mutmut_122(
    path: Path,
    *,
    experiment: str,
    seeds: list[int],
    dataset: str,
    data_path: Path | None,
    settings: dict,
    outputs: list[str],
) -> Path:
    """Write the code, data and protocol identity beside experiment outputs."""
    revision = _git("rev-parse", "HEAD")
    packages = {}
    for name in ("numpy", "pandas", "scikit-learn", "pyod", "great-expectations"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    source = {"identity": dataset}
    if data_path is not None:
        source.update(
            {
                "path": str(data_path),
                "sha256": _hash_file(data_path),
                "bytes": data_path.stat().st_size,
            }
        )
    # The record is written last and says which outputs it covers, with their hashes: a
    # run that stopped before this point has no record and cannot be taken for finished.
    output_sha256 = _hash_outputs(outputs, path.parent)
    record = {
        "schema_version": 1,
        "experiment": experiment,
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": revision,
        "source_fingerprint": _source_fingerprint(),
        "fingerprint_recipe": SCIENTIFIC_RECIPE,
        "scientific_fingerprint": scientific_fingerprint(),
        "measurement_recipe": MEASUREMENT_RECIPE,
        "measurement_fingerprint": measurement_fingerprint(),
        "worktree_dirty": bool(_git("status", "--porcelain")),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "environment_lock": _environment_lock(),
        "dataset": source,
        "seeds": seeds,
        "settings": settings,
        "outputs": outputs,
        "output_sha256": output_sha256,
    }
    text = json.dumps(record, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=False)
        raise
    return path

mutants_x_write_record__mutmut['_mutmut_orig'] = x_write_record__mutmut_orig # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_1'] = x_write_record__mutmut_1 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_2'] = x_write_record__mutmut_2 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_3'] = x_write_record__mutmut_3 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_4'] = x_write_record__mutmut_4 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_5'] = x_write_record__mutmut_5 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_6'] = x_write_record__mutmut_6 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_7'] = x_write_record__mutmut_7 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_8'] = x_write_record__mutmut_8 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_9'] = x_write_record__mutmut_9 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_10'] = x_write_record__mutmut_10 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_11'] = x_write_record__mutmut_11 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_12'] = x_write_record__mutmut_12 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_13'] = x_write_record__mutmut_13 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_14'] = x_write_record__mutmut_14 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_15'] = x_write_record__mutmut_15 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_16'] = x_write_record__mutmut_16 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_17'] = x_write_record__mutmut_17 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_18'] = x_write_record__mutmut_18 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_19'] = x_write_record__mutmut_19 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_20'] = x_write_record__mutmut_20 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_21'] = x_write_record__mutmut_21 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_22'] = x_write_record__mutmut_22 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_23'] = x_write_record__mutmut_23 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_24'] = x_write_record__mutmut_24 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_25'] = x_write_record__mutmut_25 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_26'] = x_write_record__mutmut_26 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_27'] = x_write_record__mutmut_27 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_28'] = x_write_record__mutmut_28 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_29'] = x_write_record__mutmut_29 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_30'] = x_write_record__mutmut_30 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_31'] = x_write_record__mutmut_31 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_32'] = x_write_record__mutmut_32 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_33'] = x_write_record__mutmut_33 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_34'] = x_write_record__mutmut_34 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_35'] = x_write_record__mutmut_35 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_36'] = x_write_record__mutmut_36 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_37'] = x_write_record__mutmut_37 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_38'] = x_write_record__mutmut_38 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_39'] = x_write_record__mutmut_39 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_40'] = x_write_record__mutmut_40 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_41'] = x_write_record__mutmut_41 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_42'] = x_write_record__mutmut_42 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_43'] = x_write_record__mutmut_43 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_44'] = x_write_record__mutmut_44 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_45'] = x_write_record__mutmut_45 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_46'] = x_write_record__mutmut_46 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_47'] = x_write_record__mutmut_47 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_48'] = x_write_record__mutmut_48 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_49'] = x_write_record__mutmut_49 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_50'] = x_write_record__mutmut_50 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_51'] = x_write_record__mutmut_51 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_52'] = x_write_record__mutmut_52 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_53'] = x_write_record__mutmut_53 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_54'] = x_write_record__mutmut_54 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_55'] = x_write_record__mutmut_55 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_56'] = x_write_record__mutmut_56 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_57'] = x_write_record__mutmut_57 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_58'] = x_write_record__mutmut_58 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_59'] = x_write_record__mutmut_59 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_60'] = x_write_record__mutmut_60 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_61'] = x_write_record__mutmut_61 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_62'] = x_write_record__mutmut_62 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_63'] = x_write_record__mutmut_63 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_64'] = x_write_record__mutmut_64 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_65'] = x_write_record__mutmut_65 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_66'] = x_write_record__mutmut_66 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_67'] = x_write_record__mutmut_67 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_68'] = x_write_record__mutmut_68 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_69'] = x_write_record__mutmut_69 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_70'] = x_write_record__mutmut_70 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_71'] = x_write_record__mutmut_71 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_72'] = x_write_record__mutmut_72 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_73'] = x_write_record__mutmut_73 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_74'] = x_write_record__mutmut_74 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_75'] = x_write_record__mutmut_75 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_76'] = x_write_record__mutmut_76 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_77'] = x_write_record__mutmut_77 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_78'] = x_write_record__mutmut_78 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_79'] = x_write_record__mutmut_79 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_80'] = x_write_record__mutmut_80 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_81'] = x_write_record__mutmut_81 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_82'] = x_write_record__mutmut_82 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_83'] = x_write_record__mutmut_83 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_84'] = x_write_record__mutmut_84 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_85'] = x_write_record__mutmut_85 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_86'] = x_write_record__mutmut_86 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_87'] = x_write_record__mutmut_87 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_88'] = x_write_record__mutmut_88 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_89'] = x_write_record__mutmut_89 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_90'] = x_write_record__mutmut_90 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_91'] = x_write_record__mutmut_91 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_92'] = x_write_record__mutmut_92 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_93'] = x_write_record__mutmut_93 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_94'] = x_write_record__mutmut_94 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_95'] = x_write_record__mutmut_95 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_96'] = x_write_record__mutmut_96 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_97'] = x_write_record__mutmut_97 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_98'] = x_write_record__mutmut_98 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_99'] = x_write_record__mutmut_99 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_100'] = x_write_record__mutmut_100 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_101'] = x_write_record__mutmut_101 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_102'] = x_write_record__mutmut_102 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_103'] = x_write_record__mutmut_103 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_104'] = x_write_record__mutmut_104 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_105'] = x_write_record__mutmut_105 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_106'] = x_write_record__mutmut_106 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_107'] = x_write_record__mutmut_107 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_108'] = x_write_record__mutmut_108 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_109'] = x_write_record__mutmut_109 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_110'] = x_write_record__mutmut_110 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_111'] = x_write_record__mutmut_111 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_112'] = x_write_record__mutmut_112 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_113'] = x_write_record__mutmut_113 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_114'] = x_write_record__mutmut_114 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_115'] = x_write_record__mutmut_115 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_116'] = x_write_record__mutmut_116 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_117'] = x_write_record__mutmut_117 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_118'] = x_write_record__mutmut_118 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_119'] = x_write_record__mutmut_119 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_120'] = x_write_record__mutmut_120 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_121'] = x_write_record__mutmut_121 # type: ignore # mutmut generated
mutants_x_write_record__mutmut['x_write_record__mutmut_122'] = x_write_record__mutmut_122 # type: ignore # mutmut generated
