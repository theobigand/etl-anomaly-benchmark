"""Check current per-module mutation thresholds and execution evidence."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

OUTCOMES = (
    "killed",
    "survived",
    "no_tests",
    "skipped",
    "suspicious",
    "timeout",
    "check_was_interrupted_by_user",
    "segfault",
)


THRESHOLD = 95
# A campaign with any of these outcomes did not measure what it claims to
# measure, whatever its score: it is invalid, not merely low.
UNRELIABLE = ("check_was_interrupted_by_user", "segfault", "no_tests", "skipped")


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_classify__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_classify__mutmut)
def classify(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_orig(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_1(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_2(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError(None)
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_3(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("XXincomplete mutation outcomes: not a mappingXX")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_4(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("INCOMPLETE MUTATION OUTCOMES: NOT A MAPPING")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_5(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats and any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_6(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "XXtotalXX" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_7(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "TOTAL" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_8(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_9(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(None):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_10(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_11(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError(None)
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_12(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("XXmissing mutation outcomesXX")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_13(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("MISSING MUTATION OUTCOMES")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_14(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("XXtotalXX", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_15(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("TOTAL", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_16(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = None
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_17(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int and value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_18(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(None) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_19(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_20(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value <= 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_21(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 1:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_22(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(None)
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_23(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = None
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_24(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["XXtotalXX"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_25(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["TOTAL"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_26(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 and sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_27(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total < 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_28(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 1 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_29(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(None) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_30(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) == total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_31(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError(None)
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_32(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("XXincomplete or inconsistent mutation outcomesXX")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_33(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("INCOMPLETE OR INCONSISTENT MUTATION OUTCOMES")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_34(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(None)
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_35(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = None
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_36(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] * total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_37(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 / stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_38(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 101.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_39(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["XXkilledXX"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_40(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["KILLED"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_41(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = None
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_42(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] / 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_43(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["XXkilledXX"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_44(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["KILLED"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_45(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 101 >= THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_46(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 > THRESHOLD * total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_47(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD / total
    return ("PASS" if passed else "FAIL", score)


def x_classify__mutmut_48(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if (passed) and False else "FAIL", score)


def x_classify__mutmut_49(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if (passed) or True else "FAIL", score)


def x_classify__mutmut_50(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("XXPASSXX" if passed else "FAIL", score)


def x_classify__mutmut_51(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("pass" if passed else "FAIL", score)


def x_classify__mutmut_52(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "XXFAILXX", score)


def x_classify__mutmut_53(stats: dict) -> tuple[str, float]:
    """Interpret a historical global-95% report without recertifying it.

    Raises ValueError when the counts are malformed or the campaign is
    unreliable (interrupted, crashed, mutants without tests, skipped mutants).
    """
    if not isinstance(stats, dict):
        raise ValueError("incomplete mutation outcomes: not a mapping")
    if "total" not in stats or any(key not in stats for key in OUTCOMES):
        raise ValueError("missing mutation outcomes")
    for key in ("total", *OUTCOMES):
        value = stats[key]
        if type(value) is not int or value < 0:
            raise ValueError(f"invalid mutation count for {key}: {value!r}")
    total = stats["total"]
    if total <= 0 or sum(stats[key] for key in OUTCOMES) != total:
        raise ValueError("incomplete or inconsistent mutation outcomes")
    for key in UNRELIABLE:
        if stats[key]:
            raise ValueError(f"unreliable campaign: {key}={stats[key]}")
    score = 100.0 * stats["killed"] / total
    # Compare in integers so the boundary involves no floating-point error.
    passed = stats["killed"] * 100 >= THRESHOLD * total
    return ("PASS" if passed else "fail", score)

mutants_x_classify__mutmut['_mutmut_orig'] = x_classify__mutmut_orig # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_1'] = x_classify__mutmut_1 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_2'] = x_classify__mutmut_2 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_3'] = x_classify__mutmut_3 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_4'] = x_classify__mutmut_4 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_5'] = x_classify__mutmut_5 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_6'] = x_classify__mutmut_6 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_7'] = x_classify__mutmut_7 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_8'] = x_classify__mutmut_8 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_9'] = x_classify__mutmut_9 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_10'] = x_classify__mutmut_10 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_11'] = x_classify__mutmut_11 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_12'] = x_classify__mutmut_12 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_13'] = x_classify__mutmut_13 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_14'] = x_classify__mutmut_14 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_15'] = x_classify__mutmut_15 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_16'] = x_classify__mutmut_16 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_17'] = x_classify__mutmut_17 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_18'] = x_classify__mutmut_18 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_19'] = x_classify__mutmut_19 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_20'] = x_classify__mutmut_20 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_21'] = x_classify__mutmut_21 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_22'] = x_classify__mutmut_22 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_23'] = x_classify__mutmut_23 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_24'] = x_classify__mutmut_24 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_25'] = x_classify__mutmut_25 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_26'] = x_classify__mutmut_26 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_27'] = x_classify__mutmut_27 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_28'] = x_classify__mutmut_28 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_29'] = x_classify__mutmut_29 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_30'] = x_classify__mutmut_30 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_31'] = x_classify__mutmut_31 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_32'] = x_classify__mutmut_32 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_33'] = x_classify__mutmut_33 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_34'] = x_classify__mutmut_34 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_35'] = x_classify__mutmut_35 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_36'] = x_classify__mutmut_36 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_37'] = x_classify__mutmut_37 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_38'] = x_classify__mutmut_38 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_39'] = x_classify__mutmut_39 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_40'] = x_classify__mutmut_40 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_41'] = x_classify__mutmut_41 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_42'] = x_classify__mutmut_42 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_43'] = x_classify__mutmut_43 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_44'] = x_classify__mutmut_44 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_45'] = x_classify__mutmut_45 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_46'] = x_classify__mutmut_46 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_47'] = x_classify__mutmut_47 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_48'] = x_classify__mutmut_48 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_49'] = x_classify__mutmut_49 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_50'] = x_classify__mutmut_50 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_51'] = x_classify__mutmut_51 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_52'] = x_classify__mutmut_52 # type: ignore # mutmut generated
mutants_x_classify__mutmut['x_classify__mutmut_53'] = x_classify__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=None)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", )
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XXstatsXX", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("STATS", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument(None, type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=None, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=None)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument(type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, )
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("XX--rootXX", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--ROOT", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument(None, type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=None, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument(type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, )
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("XX--resultsXX", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--RESULTS", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument(None, type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=None, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help=None)
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument(type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, )
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("XX--runXX", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--RUN", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="XXmanaged native controller resultXX")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="MANAGED NATIVE CONTROLLER RESULT")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = None
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(None)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(None, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, None)
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, )
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(1, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(None))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = None
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            None,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            None,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            None,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            None,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if (args.results is None) and False else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if (args.results is None) or True else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root * "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "XXmutants/results.txtXX" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "MUTANTS/RESULTS.TXT" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is not None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if (args.run is None) and False else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if (args.run is None) or True else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root * "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "XXmutants/controller-result.jsonXX" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "MUTANTS/CONTROLLER-RESULT.JSON" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is not None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = None
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(None)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(None)
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 2
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(None)
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['XXnative_exit_codeXX']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['NATIVE_EXIT_CODE']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["XXanalysisXX"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["ANALYSIS"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["XXmodulesXX"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["MODULES"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["XXstatusXX"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["STATUS"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] == "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "XXNO_MUTANTS_TECHNICALXX":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "no_mutants_technical":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                None
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['XXlevelXX']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['LEVEL']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['XXstatusXX']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['STATUS']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['XXkilledXX']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['KILLED']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['XXeligibleXX']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['ELIGIBLE']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['XXthresholdXX']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['THRESHOLD']}%)"
            )
    return 0 if status == "PASS" else 1


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if (status == "PASS") and False else 1


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if (status == "PASS") or True else 1


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 1 if status == "PASS" else 1


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status != "PASS" else 1


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "XXPASSXX" else 1


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "pass" else 1


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stats", type=Path)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--run", type=Path, default=None, help="managed native controller result")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(ROOT))
    from verification import mutation_campaign

    try:
        result, _ = mutation_campaign.load_campaign(
            args.root,
            args.stats,
            args.root / "mutants/results.txt" if args.results is None else args.results,
            args.root / "mutants/controller-result.json" if args.run is None else args.run,
        )
        status = mutation_campaign.status(result)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        print(f"mutation gate: INVALID ({exc})")
        return 1
    print(f"mutation gate: {status} (native exit {result['native_exit_code']})")
    for path, scope in result["analysis"]["modules"].items():
        if scope["status"] != "NO_MUTANTS_TECHNICAL":
            print(
                f"{path}: {scope['level']} {scope['status']} "
                f"({scope['killed']}/{scope['eligible']}; required {scope['threshold']}%)"
            )
    return 0 if status == "PASS" else 2

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
