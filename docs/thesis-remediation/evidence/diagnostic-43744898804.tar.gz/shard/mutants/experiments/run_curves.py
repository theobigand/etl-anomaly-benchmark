"""Precision-recall curves and a contamination-sensitivity table.

Every detector emits a graded score, so a single reported operating point
hides the whole precision-recall trade-off. This script fits each
detector on the train split, takes its continuous scores on the test
split, and draws the full precision-recall curve per detector and per
dataset. It also sweeps Isolation Forest's contamination on each dataset,
to show quantitatively how much that one number moves the operating
point.

    python experiments/run_curves.py
    python experiments/run_curves.py --seed 1
"""

from __future__ import annotations

import argparse
import logging
import os
from datetime import UTC, datetime
from pathlib import Path

os.environ.setdefault("TQDM_DISABLE", "1")

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from provenance import write_record  # noqa: E402
from run_synthetic_benchmark import _split_synthetic  # noqa: E402
from sklearn.metrics import average_precision_score, precision_recall_curve  # noqa: E402

from etl_benchmark import config  # noqa: E402
from etl_benchmark.atomic import atomic_path  # noqa: E402
from etl_benchmark.datasets import ANOMALY_COLUMN, DATASETS  # noqa: E402
from etl_benchmark.logging_setup import setup_logging  # noqa: E402
from etl_benchmark.pipeline import detect  # noqa: E402
from etl_benchmark.quality import IsolationForestDetector  # noqa: E402
from etl_benchmark.registry import all_detectors, clip_contamination  # noqa: E402
from etl_benchmark.split import stratified_split  # noqa: E402
from etl_benchmark.synthetic import FEATURE_COLUMNS, make_synthetic  # noqa: E402

log = logging.getLogger(__name__)

PAPER_FIGURE = config.PROJECT_ROOT / "paper" / "figures" / "pr_curves.png"
CONTAMINATION_GRID = [0.001, 0.01, 0.05, 0.10, 0.20]


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x__split_real__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__split_real__mutmut)
def _split_real(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_orig(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_1(name: str, seed: int):
    spec = None
    df = spec.load()
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_2(name: str, seed: int):
    spec = DATASETS[name]
    df = None
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_3(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = None
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_4(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(None, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_5(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, None, config.SPLIT_RATIOS, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_6(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, None, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_7(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, config.SPLIT_RATIOS, None)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_8(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_9(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, config.SPLIT_RATIOS, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_10(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_11(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, config.SPLIT_RATIOS, )
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_12(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)
    return (
        spec.features(None),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_13(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)
    return (
        spec.features(train),
        spec.features(None),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_14(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(None),
        spec.detector_names,
        float(df[ANOMALY_COLUMN].mean()),
    )


def x__split_real__mutmut_15(name: str, seed: int):
    spec = DATASETS[name]
    df = spec.load()
    train, _val, test = stratified_split(df, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)
    return (
        spec.features(train),
        spec.features(test),
        test[ANOMALY_COLUMN].to_numpy(),
        float(train[ANOMALY_COLUMN].mean()),
        spec.detector_names,
        float(None),
    )

mutants_x__split_real__mutmut['_mutmut_orig'] = x__split_real__mutmut_orig # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_1'] = x__split_real__mutmut_1 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_2'] = x__split_real__mutmut_2 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_3'] = x__split_real__mutmut_3 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_4'] = x__split_real__mutmut_4 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_5'] = x__split_real__mutmut_5 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_6'] = x__split_real__mutmut_6 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_7'] = x__split_real__mutmut_7 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_8'] = x__split_real__mutmut_8 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_9'] = x__split_real__mutmut_9 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_10'] = x__split_real__mutmut_10 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_11'] = x__split_real__mutmut_11 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_12'] = x__split_real__mutmut_12 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_13'] = x__split_real__mutmut_13 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_14'] = x__split_real__mutmut_14 # type: ignore # mutmut generated
mutants_x__split_real__mutmut['x__split_real__mutmut_15'] = x__split_real__mutmut_15 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__split_synth__mutmut)
def _split_synth(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_orig(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_1(seed: int, rows: int | None = None):
    options = None
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_2(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if (rows is not None) and False else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_3(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if (rows is not None) or True else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_4(seed: int, rows: int | None = None):
    options = {"XXn_rowsXX": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_5(seed: int, rows: int | None = None):
    options = {"N_ROWS": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_6(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_7(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = None
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_8(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=None, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_9(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(**options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_10(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, )
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_11(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = None
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_12(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(None, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_13(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, None)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_14(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_15(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, )
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_16(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = None
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_17(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(None)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_18(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["XXanomalyXX"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_19(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["ANOMALY"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_20(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(None),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_21(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["XXanomalyXX"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_22(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["ANOMALY"].mean()),
        DETECTOR_NAMES,
        float(df["anomaly"].mean()),
    )


def x__split_synth__mutmut_23(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(None),
    )


def x__split_synth__mutmut_24(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["XXanomalyXX"].mean()),
    )


def x__split_synth__mutmut_25(seed: int, rows: int | None = None):
    options = {"n_rows": rows} if rows is not None else {}
    df = make_synthetic(seed=seed, **options)
    train, _val, test = _split_synthetic(df, seed)
    y = test["anomaly"].to_numpy().astype(int)
    from etl_benchmark.registry import DETECTOR_NAMES

    return (
        train[FEATURE_COLUMNS],
        test[FEATURE_COLUMNS],
        y,
        float(train["anomaly"].mean()),
        DETECTOR_NAMES,
        float(df["ANOMALY"].mean()),
    )

mutants_x__split_synth__mutmut['_mutmut_orig'] = x__split_synth__mutmut_orig # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_1'] = x__split_synth__mutmut_1 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_2'] = x__split_synth__mutmut_2 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_3'] = x__split_synth__mutmut_3 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_4'] = x__split_synth__mutmut_4 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_5'] = x__split_synth__mutmut_5 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_6'] = x__split_synth__mutmut_6 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_7'] = x__split_synth__mutmut_7 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_8'] = x__split_synth__mutmut_8 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_9'] = x__split_synth__mutmut_9 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_10'] = x__split_synth__mutmut_10 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_11'] = x__split_synth__mutmut_11 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_12'] = x__split_synth__mutmut_12 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_13'] = x__split_synth__mutmut_13 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_14'] = x__split_synth__mutmut_14 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_15'] = x__split_synth__mutmut_15 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_16'] = x__split_synth__mutmut_16 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_17'] = x__split_synth__mutmut_17 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_18'] = x__split_synth__mutmut_18 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_19'] = x__split_synth__mutmut_19 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_20'] = x__split_synth__mutmut_20 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_21'] = x__split_synth__mutmut_21 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_22'] = x__split_synth__mutmut_22 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_23'] = x__split_synth__mutmut_23 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_24'] = x__split_synth__mutmut_24 # type: ignore # mutmut generated
mutants_x__split_synth__mutmut['x__split_synth__mutmut_25'] = x__split_synth__mutmut_25 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_scores_for__mutmut)
def scores_for(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_orig(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_1(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset != "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_2(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "XXsyntheticXX":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_3(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "SYNTHETIC":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_4(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = None
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_5(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(None, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_6(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, None)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_7(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_8(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, )
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_9(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = None

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_10(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(None, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_11(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, None)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_12(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_13(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, )

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_14(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = None
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_15(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"XXyXX": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_16(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"Y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_17(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "XXbase_rateXX": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_18(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "BASE_RATE": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_19(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "XXscoresXX": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_20(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "SCORES": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_21(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=None, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_22(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=None):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_23(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_24(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, ):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_25(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = None
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_26(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(None, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_27(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, None, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_28(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=None)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_29(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_30(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_31(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, )
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_32(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = None
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_33(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["XXscoresXX"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_34(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["SCORES"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_35(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(None, dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_36(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=None)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_37(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(dtype=float)
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_38(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, )
        log.info("%s: %s scored", dataset, det.name)
    return out


def x_scores_for__mutmut_39(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info(None, dataset, det.name)
    return out


def x_scores_for__mutmut_40(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", None, det.name)
    return out


def x_scores_for__mutmut_41(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, None)
    return out


def x_scores_for__mutmut_42(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info(dataset, det.name)
    return out


def x_scores_for__mutmut_43(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", det.name)
    return out


def x_scores_for__mutmut_44(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%s: %s scored", dataset, )
    return out


def x_scores_for__mutmut_45(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("XX%s: %s scoredXX", dataset, det.name)
    return out


def x_scores_for__mutmut_46(dataset: str, seed: int, rows: int | None = None) -> dict:
    if dataset == "synthetic":
        train_x, test_x, y, contamination, names, base = _split_synth(seed, rows)
    else:
        train_x, test_x, y, contamination, names, base = _split_real(dataset, seed)

    out = {"y": y, "base_rate": base, "scores": {}}
    for det in all_detectors(ml_contamination=contamination, names=names):
        res = detect(test_x, det, fit_df=train_x)
        out["scores"][det.name] = np.asarray(res.scores, dtype=float)
        log.info("%S: %S SCORED", dataset, det.name)
    return out

mutants_x_scores_for__mutmut['_mutmut_orig'] = x_scores_for__mutmut_orig # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_1'] = x_scores_for__mutmut_1 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_2'] = x_scores_for__mutmut_2 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_3'] = x_scores_for__mutmut_3 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_4'] = x_scores_for__mutmut_4 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_5'] = x_scores_for__mutmut_5 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_6'] = x_scores_for__mutmut_6 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_7'] = x_scores_for__mutmut_7 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_8'] = x_scores_for__mutmut_8 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_9'] = x_scores_for__mutmut_9 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_10'] = x_scores_for__mutmut_10 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_11'] = x_scores_for__mutmut_11 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_12'] = x_scores_for__mutmut_12 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_13'] = x_scores_for__mutmut_13 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_14'] = x_scores_for__mutmut_14 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_15'] = x_scores_for__mutmut_15 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_16'] = x_scores_for__mutmut_16 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_17'] = x_scores_for__mutmut_17 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_18'] = x_scores_for__mutmut_18 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_19'] = x_scores_for__mutmut_19 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_20'] = x_scores_for__mutmut_20 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_21'] = x_scores_for__mutmut_21 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_22'] = x_scores_for__mutmut_22 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_23'] = x_scores_for__mutmut_23 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_24'] = x_scores_for__mutmut_24 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_25'] = x_scores_for__mutmut_25 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_26'] = x_scores_for__mutmut_26 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_27'] = x_scores_for__mutmut_27 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_28'] = x_scores_for__mutmut_28 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_29'] = x_scores_for__mutmut_29 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_30'] = x_scores_for__mutmut_30 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_31'] = x_scores_for__mutmut_31 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_32'] = x_scores_for__mutmut_32 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_33'] = x_scores_for__mutmut_33 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_34'] = x_scores_for__mutmut_34 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_35'] = x_scores_for__mutmut_35 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_36'] = x_scores_for__mutmut_36 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_37'] = x_scores_for__mutmut_37 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_38'] = x_scores_for__mutmut_38 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_39'] = x_scores_for__mutmut_39 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_40'] = x_scores_for__mutmut_40 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_41'] = x_scores_for__mutmut_41 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_42'] = x_scores_for__mutmut_42 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_43'] = x_scores_for__mutmut_43 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_44'] = x_scores_for__mutmut_44 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_45'] = x_scores_for__mutmut_45 # type: ignore # mutmut generated
mutants_x_scores_for__mutmut['x_scores_for__mutmut_46'] = x_scores_for__mutmut_46 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_render_pr__mutmut)
def render_pr(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_orig(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_1(results: dict[str, dict], path: Path) -> Path:
    fig, axes = None
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_2(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(None, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_3(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, None, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_4(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=None)
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_5(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_6(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_7(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, )
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_8(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(3, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_9(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 3, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_10(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_11(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 9))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_12(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = None
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_13(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap(None)
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_14(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("XXtab10XX")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_15(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("TAB10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_16(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(None, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_17(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, None, strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_18(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=None):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_19(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_20(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_21(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), ):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_22(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=True):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_23(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(None):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_24(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["XXscoresXX"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_25(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["SCORES"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_26(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = None
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_27(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(None, s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_28(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], None)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_29(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_30(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], )
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_31(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["XXyXX"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_32(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["Y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_33(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = None
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_34(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(None, s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_35(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], None)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_36(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_37(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], )
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_38(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["XXyXX"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_39(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["Y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_40(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(None, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_41(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, None, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_42(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=None, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_43(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=None, label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_44(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=None)
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_45(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_46(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_47(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_48(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_49(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), )
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_50(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=2.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_51(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(None), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_52(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i / 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_53(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 11), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_54(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(None, color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_55(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color=None, linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_56(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=None, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_57(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle=None)
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_58(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_59(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_60(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_61(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, )
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_62(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["XXbase_rateXX"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_63(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["BASE_RATE"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_64(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="XX0.7XX", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_65(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=1.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_66(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="XX--XX")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_67(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(None)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_68(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel(None)
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_69(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("XXrecallXX")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_70(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("RECALL")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_71(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel(None)
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_72(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("XXprecisionXX")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_73(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("PRECISION")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_74(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(None, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_75(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, None)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_76(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_77(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, )
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_78(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(+0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_79(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-1.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_80(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 2.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_81(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(None, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_82(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, None)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_83(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_84(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, )
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_85(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(+0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_86(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-1.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_87(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 2.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_88(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=None, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_89(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc=None)
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_90(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_91(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, )
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_92(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=8, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_93(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="XXupper rightXX")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_94(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="UPPER RIGHT")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_95(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle(None)
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_96(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("XXPrecision-recall curves on the test split (AP in the legend)XX")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_97(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("precision-recall curves on the test split (ap in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_98(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("PRECISION-RECALL CURVES ON THE TEST SPLIT (AP IN THE LEGEND)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_99(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=None, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_100(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=None)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_101(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_102(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, )
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_103(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=False, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_104(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=False)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_105(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(None) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_106(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(None, dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_107(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=None)
    plt.close(fig)
    return path


def x_render_pr__mutmut_108(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(dpi=150)
    plt.close(fig)
    return path


def x_render_pr__mutmut_109(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, )
    plt.close(fig)
    return path


def x_render_pr__mutmut_110(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=151)
    plt.close(fig)
    return path


def x_render_pr__mutmut_111(results: dict[str, dict], path: Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    cmap = plt.get_cmap("tab10")
    for ax, (name, data) in zip(axes.flat, results.items(), strict=False):
        for i, (method, s) in enumerate(data["scores"].items()):
            prec, rec, _ = precision_recall_curve(data["y"], s)
            ap = average_precision_score(data["y"], s)
            ax.plot(rec, prec, linewidth=1.4, color=cmap(i % 10), label=f"{method} ({ap:.2f})")
        ax.axhline(data["base_rate"], color="0.7", linewidth=0.8, linestyle="--")
        ax.set_title(name)
        ax.set_xlabel("recall")
        ax.set_ylabel("precision")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=7, loc="upper right")
    fig.suptitle("Precision-recall curves on the test split (AP in the legend)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(path) as partial:
        fig.savefig(partial, dpi=150)
    plt.close(None)
    return path

mutants_x_render_pr__mutmut['_mutmut_orig'] = x_render_pr__mutmut_orig # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_1'] = x_render_pr__mutmut_1 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_2'] = x_render_pr__mutmut_2 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_3'] = x_render_pr__mutmut_3 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_4'] = x_render_pr__mutmut_4 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_5'] = x_render_pr__mutmut_5 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_6'] = x_render_pr__mutmut_6 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_7'] = x_render_pr__mutmut_7 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_8'] = x_render_pr__mutmut_8 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_9'] = x_render_pr__mutmut_9 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_10'] = x_render_pr__mutmut_10 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_11'] = x_render_pr__mutmut_11 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_12'] = x_render_pr__mutmut_12 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_13'] = x_render_pr__mutmut_13 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_14'] = x_render_pr__mutmut_14 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_15'] = x_render_pr__mutmut_15 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_16'] = x_render_pr__mutmut_16 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_17'] = x_render_pr__mutmut_17 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_18'] = x_render_pr__mutmut_18 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_19'] = x_render_pr__mutmut_19 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_20'] = x_render_pr__mutmut_20 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_21'] = x_render_pr__mutmut_21 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_22'] = x_render_pr__mutmut_22 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_23'] = x_render_pr__mutmut_23 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_24'] = x_render_pr__mutmut_24 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_25'] = x_render_pr__mutmut_25 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_26'] = x_render_pr__mutmut_26 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_27'] = x_render_pr__mutmut_27 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_28'] = x_render_pr__mutmut_28 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_29'] = x_render_pr__mutmut_29 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_30'] = x_render_pr__mutmut_30 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_31'] = x_render_pr__mutmut_31 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_32'] = x_render_pr__mutmut_32 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_33'] = x_render_pr__mutmut_33 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_34'] = x_render_pr__mutmut_34 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_35'] = x_render_pr__mutmut_35 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_36'] = x_render_pr__mutmut_36 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_37'] = x_render_pr__mutmut_37 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_38'] = x_render_pr__mutmut_38 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_39'] = x_render_pr__mutmut_39 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_40'] = x_render_pr__mutmut_40 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_41'] = x_render_pr__mutmut_41 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_42'] = x_render_pr__mutmut_42 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_43'] = x_render_pr__mutmut_43 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_44'] = x_render_pr__mutmut_44 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_45'] = x_render_pr__mutmut_45 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_46'] = x_render_pr__mutmut_46 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_47'] = x_render_pr__mutmut_47 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_48'] = x_render_pr__mutmut_48 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_49'] = x_render_pr__mutmut_49 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_50'] = x_render_pr__mutmut_50 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_51'] = x_render_pr__mutmut_51 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_52'] = x_render_pr__mutmut_52 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_53'] = x_render_pr__mutmut_53 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_54'] = x_render_pr__mutmut_54 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_55'] = x_render_pr__mutmut_55 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_56'] = x_render_pr__mutmut_56 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_57'] = x_render_pr__mutmut_57 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_58'] = x_render_pr__mutmut_58 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_59'] = x_render_pr__mutmut_59 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_60'] = x_render_pr__mutmut_60 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_61'] = x_render_pr__mutmut_61 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_62'] = x_render_pr__mutmut_62 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_63'] = x_render_pr__mutmut_63 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_64'] = x_render_pr__mutmut_64 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_65'] = x_render_pr__mutmut_65 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_66'] = x_render_pr__mutmut_66 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_67'] = x_render_pr__mutmut_67 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_68'] = x_render_pr__mutmut_68 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_69'] = x_render_pr__mutmut_69 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_70'] = x_render_pr__mutmut_70 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_71'] = x_render_pr__mutmut_71 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_72'] = x_render_pr__mutmut_72 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_73'] = x_render_pr__mutmut_73 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_74'] = x_render_pr__mutmut_74 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_75'] = x_render_pr__mutmut_75 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_76'] = x_render_pr__mutmut_76 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_77'] = x_render_pr__mutmut_77 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_78'] = x_render_pr__mutmut_78 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_79'] = x_render_pr__mutmut_79 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_80'] = x_render_pr__mutmut_80 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_81'] = x_render_pr__mutmut_81 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_82'] = x_render_pr__mutmut_82 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_83'] = x_render_pr__mutmut_83 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_84'] = x_render_pr__mutmut_84 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_85'] = x_render_pr__mutmut_85 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_86'] = x_render_pr__mutmut_86 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_87'] = x_render_pr__mutmut_87 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_88'] = x_render_pr__mutmut_88 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_89'] = x_render_pr__mutmut_89 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_90'] = x_render_pr__mutmut_90 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_91'] = x_render_pr__mutmut_91 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_92'] = x_render_pr__mutmut_92 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_93'] = x_render_pr__mutmut_93 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_94'] = x_render_pr__mutmut_94 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_95'] = x_render_pr__mutmut_95 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_96'] = x_render_pr__mutmut_96 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_97'] = x_render_pr__mutmut_97 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_98'] = x_render_pr__mutmut_98 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_99'] = x_render_pr__mutmut_99 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_100'] = x_render_pr__mutmut_100 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_101'] = x_render_pr__mutmut_101 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_102'] = x_render_pr__mutmut_102 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_103'] = x_render_pr__mutmut_103 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_104'] = x_render_pr__mutmut_104 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_105'] = x_render_pr__mutmut_105 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_106'] = x_render_pr__mutmut_106 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_107'] = x_render_pr__mutmut_107 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_108'] = x_render_pr__mutmut_108 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_109'] = x_render_pr__mutmut_109 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_110'] = x_render_pr__mutmut_110 # type: ignore # mutmut generated
mutants_x_render_pr__mutmut['x_render_pr__mutmut_111'] = x_render_pr__mutmut_111 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_contamination_sweep__mutmut)
def contamination_sweep(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_orig(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_1(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = None
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_2(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets and ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_3(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["XXcredit_cardXX", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_4(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["CREDIT_CARD", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_5(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "XXwater_qualityXX", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_6(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "WATER_QUALITY", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_7(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "XXcardioXX", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_8(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "CARDIO", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_9(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "XXsyntheticXX"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_10(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "SYNTHETIC"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_11(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset != "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_12(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "XXsyntheticXX":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_13(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "SYNTHETIC":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_14(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = None
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_15(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(None, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_16(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, None)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_17(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_18(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, )
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_19(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = None
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_20(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(None, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_21(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, None)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_22(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_23(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, )
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_24(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning(None, dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_25(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", None)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_26(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning(dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_27(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", )
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_28(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("XXskipping %s (dataset not present)XX", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_29(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("SKIPPING %S (DATASET NOT PRESENT)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_30(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            break
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_31(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = None
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_32(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=None)
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_33(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(None))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_34(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = None
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_35(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(None, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_36(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, None, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_37(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=None)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_38(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_39(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_40(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, )
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_41(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                None
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_42(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "XXdatasetXX": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_43(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "DATASET": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_44(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "XXcontaminationXX": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_45(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "CONTAMINATION": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_46(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(None, 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_47(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), None),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_48(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_49(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), ),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_50(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(None), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_51(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 5),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_52(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "XXis_prevalenceXX": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_53(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "IS_PREVALENCE": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_54(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(None) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_55(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c + prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_56(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) <= 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_57(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1.000000001,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_58(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "XXprecisionXX": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_59(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "PRECISION": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_60(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(None, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_61(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, None, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_62(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=None),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_63(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_64(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_65(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, ),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_66(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=1),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_67(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "XXrecallXX": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_68(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "RECALL": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_69(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(None, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_70(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, None),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_71(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_72(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, ),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_73(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "XXflagged_pctXX": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_74(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "FLAGGED_PCT": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_75(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 / float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_76(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 101.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_77(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(None),
                }
            )
    return pd.DataFrame(records)


def x_contamination_sweep__mutmut_78(
    seed: int, datasets: list[str] | None = None, rows: int | None = None
) -> pd.DataFrame:
    from sklearn.metrics import precision_score, recall_score

    records = []
    for dataset in datasets or ["credit_card", "water_quality", "cardio", "synthetic"]:
        try:
            if dataset == "synthetic":
                train_x, test_x, y, prevalence, _n, _b = _split_synth(seed, rows)
            else:
                train_x, test_x, y, prevalence, _n, _b = _split_real(dataset, seed)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)
            continue
        for c in [*CONTAMINATION_GRID, prevalence]:
            det = IsolationForestDetector(contamination=clip_contamination(c))
            res = detect(test_x, det, fit_df=train_x)
            records.append(
                {
                    "dataset": dataset,
                    "contamination": round(clip_contamination(c), 4),
                    "is_prevalence": abs(c - prevalence) < 1e-9,
                    "precision": precision_score(y, res.flags, zero_division=0),
                    "recall": recall_score(y, res.flags),
                    "flagged_pct": 100.0 * float(res.flags.mean()),
                }
            )
    return pd.DataFrame(None)

mutants_x_contamination_sweep__mutmut['_mutmut_orig'] = x_contamination_sweep__mutmut_orig # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_1'] = x_contamination_sweep__mutmut_1 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_2'] = x_contamination_sweep__mutmut_2 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_3'] = x_contamination_sweep__mutmut_3 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_4'] = x_contamination_sweep__mutmut_4 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_5'] = x_contamination_sweep__mutmut_5 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_6'] = x_contamination_sweep__mutmut_6 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_7'] = x_contamination_sweep__mutmut_7 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_8'] = x_contamination_sweep__mutmut_8 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_9'] = x_contamination_sweep__mutmut_9 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_10'] = x_contamination_sweep__mutmut_10 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_11'] = x_contamination_sweep__mutmut_11 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_12'] = x_contamination_sweep__mutmut_12 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_13'] = x_contamination_sweep__mutmut_13 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_14'] = x_contamination_sweep__mutmut_14 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_15'] = x_contamination_sweep__mutmut_15 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_16'] = x_contamination_sweep__mutmut_16 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_17'] = x_contamination_sweep__mutmut_17 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_18'] = x_contamination_sweep__mutmut_18 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_19'] = x_contamination_sweep__mutmut_19 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_20'] = x_contamination_sweep__mutmut_20 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_21'] = x_contamination_sweep__mutmut_21 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_22'] = x_contamination_sweep__mutmut_22 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_23'] = x_contamination_sweep__mutmut_23 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_24'] = x_contamination_sweep__mutmut_24 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_25'] = x_contamination_sweep__mutmut_25 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_26'] = x_contamination_sweep__mutmut_26 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_27'] = x_contamination_sweep__mutmut_27 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_28'] = x_contamination_sweep__mutmut_28 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_29'] = x_contamination_sweep__mutmut_29 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_30'] = x_contamination_sweep__mutmut_30 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_31'] = x_contamination_sweep__mutmut_31 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_32'] = x_contamination_sweep__mutmut_32 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_33'] = x_contamination_sweep__mutmut_33 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_34'] = x_contamination_sweep__mutmut_34 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_35'] = x_contamination_sweep__mutmut_35 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_36'] = x_contamination_sweep__mutmut_36 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_37'] = x_contamination_sweep__mutmut_37 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_38'] = x_contamination_sweep__mutmut_38 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_39'] = x_contamination_sweep__mutmut_39 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_40'] = x_contamination_sweep__mutmut_40 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_41'] = x_contamination_sweep__mutmut_41 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_42'] = x_contamination_sweep__mutmut_42 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_43'] = x_contamination_sweep__mutmut_43 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_44'] = x_contamination_sweep__mutmut_44 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_45'] = x_contamination_sweep__mutmut_45 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_46'] = x_contamination_sweep__mutmut_46 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_47'] = x_contamination_sweep__mutmut_47 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_48'] = x_contamination_sweep__mutmut_48 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_49'] = x_contamination_sweep__mutmut_49 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_50'] = x_contamination_sweep__mutmut_50 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_51'] = x_contamination_sweep__mutmut_51 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_52'] = x_contamination_sweep__mutmut_52 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_53'] = x_contamination_sweep__mutmut_53 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_54'] = x_contamination_sweep__mutmut_54 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_55'] = x_contamination_sweep__mutmut_55 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_56'] = x_contamination_sweep__mutmut_56 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_57'] = x_contamination_sweep__mutmut_57 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_58'] = x_contamination_sweep__mutmut_58 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_59'] = x_contamination_sweep__mutmut_59 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_60'] = x_contamination_sweep__mutmut_60 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_61'] = x_contamination_sweep__mutmut_61 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_62'] = x_contamination_sweep__mutmut_62 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_63'] = x_contamination_sweep__mutmut_63 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_64'] = x_contamination_sweep__mutmut_64 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_65'] = x_contamination_sweep__mutmut_65 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_66'] = x_contamination_sweep__mutmut_66 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_67'] = x_contamination_sweep__mutmut_67 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_68'] = x_contamination_sweep__mutmut_68 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_69'] = x_contamination_sweep__mutmut_69 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_70'] = x_contamination_sweep__mutmut_70 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_71'] = x_contamination_sweep__mutmut_71 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_72'] = x_contamination_sweep__mutmut_72 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_73'] = x_contamination_sweep__mutmut_73 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_74'] = x_contamination_sweep__mutmut_74 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_75'] = x_contamination_sweep__mutmut_75 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_76'] = x_contamination_sweep__mutmut_76 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_77'] = x_contamination_sweep__mutmut_77 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_78'] = x_contamination_sweep__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_orig() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_1() -> None:
    parser = None
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_2() -> None:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_3() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_4() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=None, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_5() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_6() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_7() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_8() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, )
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_9() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--seedXX", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_10() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--SEED", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_11() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument(None, type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_12() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=None, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_13() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=None)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_14() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument(type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_15() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_16() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, )
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_17() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("XX--figureXX", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_18() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--FIGURE", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_19() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        None,
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_20() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs=None,
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_21() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=None,
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_22() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=None,
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_23() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_24() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_25() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_26() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_27() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "XX--datasetsXX",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_28() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--DATASETS",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_29() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="XX+XX",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_30() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "XXsyntheticXX"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_31() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "SYNTHETIC"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_32() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["XXcredit_cardXX", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_33() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["CREDIT_CARD", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_34() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "XXwater_qualityXX", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_35() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "WATER_QUALITY", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_36() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "XXcardioXX", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_37() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "CARDIO", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_38() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "XXsyntheticXX"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_39() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "SYNTHETIC"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_40() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument(None, type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_41() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=None, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_42() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help=None)
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_43() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument(type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_44() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_45() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, )
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_46() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("XX--rowsXX", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_47() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--ROWS", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_48() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="XXsynthetic row count for an offline smoke runXX")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_49() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="SYNTHETIC ROW COUNT FOR AN OFFLINE SMOKE RUN")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_50() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument(None, type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_51() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=None, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_52() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=None)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_53() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument(type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_54() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_55() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, )
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_56() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("XX--results-dirXX", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_57() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--RESULTS-DIR", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_58() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = None

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_59() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(None)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_60() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger(None).setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_61() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("XXgreat_expectationsXX").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_62() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("GREAT_EXPECTATIONS").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_63() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(None)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_64() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger(None).setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_65() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("XXmatplotlibXX").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_66() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("MATPLOTLIB").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_67() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = None
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_68() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = None
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_69() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(None, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_70() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, None, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_71() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, None)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_72() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_73() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_74() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, )
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_75() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning(None, dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_76() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", None)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_77() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning(dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_78() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", )

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_79() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("XXskipping %s (dataset not present)XX", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_80() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("SKIPPING %S (DATASET NOT PRESENT)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_81() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_82() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError(None)

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_83() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("XXno datasets available for curve evaluationXX")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_84() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("NO DATASETS AVAILABLE FOR CURVE EVALUATION")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_85() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = None
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_86() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(None, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_87() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, None)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_88() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_89() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, )
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_90() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = None

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_91() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(None, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_92() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, None, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_93() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, None)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_94() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_95() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_96() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, )

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_97() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=None, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_98() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=None)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_99() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_100() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, )
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_101() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=False, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_102() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=False)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_103() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = None
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_104() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime(None)
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_105() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(None).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_106() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("XX%Y%m%d_%H%M%SXX")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_107() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%y%m%d_%h%m%s")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_108() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%M%D_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_109() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = None
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_110() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir * f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_111() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(None) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_112() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(None, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_113() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=None)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_114() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_115() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, )
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_116() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=True)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_117() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        None,
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_118() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment=None,
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_119() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=None,
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_120() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=None,
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_121() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings=None,
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_122() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=None,
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_123() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_124() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_125() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_126() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_127() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_128() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_129() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_130() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir * f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_131() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="XXprecision_recall_and_contaminationXX",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_132() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="PRECISION_RECALL_AND_CONTAMINATION",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_133() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(None),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_134() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset="XX,XX".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_135() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "XXdatasetsXX": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_136() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "DATASETS": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_137() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "XXskipped_datasetsXX": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_138() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "SKIPPED_DATASETS": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_139() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_140() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "XXsynthetic_rowsXX": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_141() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "SYNTHETIC_ROWS": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_142() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "XXsplit_ratiosXX": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_143() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "SPLIT_RATIOS": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_144() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(None),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_145() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "XXsynthetic_split_strategyXX": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_146() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "SYNTHETIC_SPLIT_STRATEGY": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_147() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "XXcustomer_identity_grouped_stratifiedXX",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_148() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "CUSTOMER_IDENTITY_GROUPED_STRATIFIED",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_149() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "XXreal_split_strategyXX": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_150() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "REAL_SPLIT_STRATEGY": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_151() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "XXstratifiedXX",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_152() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "STRATIFIED",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_153() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "XXcalibrationXX": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_154() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "CALIBRATION": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_155() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "XXtrain_label_prevalenceXX",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_156() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "TRAIN_LABEL_PREVALENCE",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_157() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "XXcontamination_gridXX": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_158() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "CONTAMINATION_GRID": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_159() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "XXpr_auc_definitionXX": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_160() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "PR_AUC_DEFINITION": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_161() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "XXaverage_precisionXX",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_162() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "AVERAGE_PRECISION",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_163() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(None)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_164() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print(None)
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_165() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("XX\nIsolation Forest, contamination sweep (test split):\nXX")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_166() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nisolation forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_167() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nISOLATION FOREST, CONTAMINATION SWEEP (TEST SPLIT):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", figure)


def x_main__mutmut_168() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(None)
    log.info("figure -> %s", figure)


def x_main__mutmut_169() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=None))
    log.info("figure -> %s", figure)


def x_main__mutmut_170() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=True))
    log.info("figure -> %s", figure)


def x_main__mutmut_171() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info(None, figure)


def x_main__mutmut_172() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", None)


def x_main__mutmut_173() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info(figure)


def x_main__mutmut_174() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("figure -> %s", )


def x_main__mutmut_175() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("XXfigure -> %sXX", figure)


def x_main__mutmut_176() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED)
    parser.add_argument("--figure", type=Path, default=PAPER_FIGURE)
    parser.add_argument(
        "--datasets",
        nargs="+",
        choices=[*DATASETS, "synthetic"],
        default=["credit_card", "water_quality", "cardio", "synthetic"],
    )
    parser.add_argument("--rows", type=int, help="synthetic row count for an offline smoke run")
    parser.add_argument("--results-dir", type=Path, default=config.RESULTS_DIR)
    args = parser.parse_args()

    setup_logging()
    logging.getLogger("great_expectations").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    results: dict[str, dict] = {}
    for dataset in args.datasets:
        try:
            results[dataset] = scores_for(dataset, args.seed, args.rows)
        except FileNotFoundError:
            log.warning("skipping %s (dataset not present)", dataset)

    if not results:
        raise RuntimeError("no datasets available for curve evaluation")

    figure = render_pr(results, args.figure)
    sweep = contamination_sweep(args.seed, args.datasets, args.rows)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    csv_out = args.results_dir / f"contamination_sweep_{stamp}.csv"
    with atomic_path(csv_out) as partial:
        sweep.to_csv(partial, index=False)
    write_record(
        args.results_dir / f"run_curves_{stamp}.json",
        experiment="precision_recall_and_contamination",
        seeds=[args.seed],
        dataset=",".join(args.datasets),
        data_path=None,
        settings={
            "datasets": args.datasets,
            "skipped_datasets": [name for name in args.datasets if name not in results],
            "synthetic_rows": args.rows,
            "split_ratios": list(config.SPLIT_RATIOS),
            "synthetic_split_strategy": "customer_identity_grouped_stratified",
            "real_split_strategy": "stratified",
            "calibration": "train_label_prevalence",
            "contamination_grid": CONTAMINATION_GRID,
            "pr_auc_definition": "average_precision",
        },
        outputs=[csv_out.name, str(figure)],
    )

    print("\nIsolation Forest, contamination sweep (test split):\n")
    print(sweep.to_string(index=False))
    log.info("FIGURE -> %S", figure)

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_157'] = x_main__mutmut_157 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_158'] = x_main__mutmut_158 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_159'] = x_main__mutmut_159 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_160'] = x_main__mutmut_160 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_161'] = x_main__mutmut_161 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_162'] = x_main__mutmut_162 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_163'] = x_main__mutmut_163 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_164'] = x_main__mutmut_164 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_165'] = x_main__mutmut_165 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_166'] = x_main__mutmut_166 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_167'] = x_main__mutmut_167 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_168'] = x_main__mutmut_168 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_169'] = x_main__mutmut_169 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_170'] = x_main__mutmut_170 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_171'] = x_main__mutmut_171 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_172'] = x_main__mutmut_172 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_173'] = x_main__mutmut_173 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_174'] = x_main__mutmut_174 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_175'] = x_main__mutmut_175 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_176'] = x_main__mutmut_176 # type: ignore # mutmut generated


if __name__ == "__main__":
    main()
