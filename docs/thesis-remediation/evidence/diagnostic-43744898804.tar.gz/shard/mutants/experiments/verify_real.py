"""Inspect available real datasets and record provenance without copying raw data."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

import pandas as pd

from etl_benchmark import config
from etl_benchmark.atomic import atomic_path
from etl_benchmark.datasets import ANOMALY_COLUMN, DATASETS, DatasetSpec

MANIFEST = config.PROJECT_ROOT / "verification" / "evidence" / "manifest.json"
# The research files REAL must verify. A registry that lists fewer, more or
# other datasets cannot produce a PASS.
REQUIRED_DATASETS = ("credit_card", "water_quality", "cardio")


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_inspect_dataset__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_inspect_dataset__mutmut)
def inspect_dataset(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_orig(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_1(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_2(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "XXdatasetXX": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_3(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "DATASET": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_4(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "XXstatusXX": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_5(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "STATUS": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_6(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "XXNOT_RUNXX",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_7(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "not_run",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_8(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "XXreasonXX": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_9(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "REASON": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_10(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "XXdataset file absentXX",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_11(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "DATASET FILE ABSENT",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_12(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "XXpathXX": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_13(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "PATH": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_14(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(None),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_15(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open(None) as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_16(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("XXrbXX") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_17(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("RB") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_18(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = None
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_19(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(None, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_20(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, None)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_21(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_22(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, )
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_23(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = None
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_24(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(None)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_25(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = None
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_26(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = None
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_27(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(None)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_28(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty and frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_29(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty and features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_30(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() == 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_31(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 3:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_32(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError(None)
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_33(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("XXdataset must have rows, features and both label classesXX")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_34(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("DATASET MUST HAVE ROWS, FEATURES AND BOTH LABEL CLASSES")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_35(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = None
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_36(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "XXdatasetXX": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_37(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "DATASET": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_38(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "XXstatusXX": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_39(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "STATUS": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_40(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "XXPASSXX",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_41(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "pass",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_42(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "XXpathXX": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_43(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "PATH": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_44(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(None),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_45(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "XXsha256XX": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_46(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "SHA256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_47(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "XXbytesXX": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_48(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "BYTES": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_49(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "XXraw_rowsXX": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_50(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "RAW_ROWS": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_51(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "XXrows_after_transformXX": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_52(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "ROWS_AFTER_TRANSFORM": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_53(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "XXdeduplicated_rowsXX": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_54(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "DEDUPLICATED_ROWS": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_55(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) + len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_56(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "XXanomaliesXX": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_57(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "ANOMALIES": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_58(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(None),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_59(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "XXpositive_valueXX": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_60(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "POSITIVE_VALUE": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_61(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "XXlabel_columnXX": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_62(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "LABEL_COLUMN": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_63(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "XXfeaturesXX": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_64(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "FEATURES": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_65(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(None),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_66(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "XXmissing_by_featureXX": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_67(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "MISSING_BY_FEATURE": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_68(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(None) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_69(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_70(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_71(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(None)
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_72(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] == value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_73(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = None
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_74(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if (field == "sha256") and False else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_75(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if (field == "sha256") or True else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_76(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "XXchecksumXX" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_77(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "CHECKSUM" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_78(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field != "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_79(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "XXsha256XX" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_80(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "SHA256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_81(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(None)
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_82(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"XXdatasetXX": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_83(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"DATASET": spec.name, "status": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_84(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "XXstatusXX": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_85(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "STATUS": "FAIL", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_86(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "XXFAILXX", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_87(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "fail", "reason": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_88(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "XXreasonXX": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_89(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "REASON": str(exc), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_90(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(None), "path": str(spec.csv)}


def x_inspect_dataset__mutmut_91(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "XXpathXX": str(spec.csv)}


def x_inspect_dataset__mutmut_92(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "PATH": str(spec.csv)}


def x_inspect_dataset__mutmut_93(spec: DatasetSpec, expected: dict | None = None) -> dict:
    """Record file identity, label convention and the post-transform population."""
    if not spec.csv.is_file():
        return {
            "dataset": spec.name,
            "status": "NOT_RUN",
            "reason": "dataset file absent",
            "path": str(spec.csv),
        }
    try:
        with spec.csv.open("rb") as stream:
            digest = hashlib.file_digest(stream, hashlib.sha256)
        raw = pd.read_csv(spec.csv)
        frame = spec.load()
        features = spec.features(frame)
        if frame.empty or features.empty or frame[ANOMALY_COLUMN].nunique() != 2:
            raise ValueError("dataset must have rows, features and both label classes")
        record = {
            "dataset": spec.name,
            "status": "PASS",
            "path": str(spec.csv),
            "sha256": digest.hexdigest(),
            "bytes": spec.csv.stat().st_size,
            "raw_rows": len(raw),
            "rows_after_transform": len(frame),
            "deduplicated_rows": len(raw) - len(frame),
            "anomalies": int(frame[ANOMALY_COLUMN].sum()),
            "positive_value": spec.positive_value,
            "label_column": spec.label_column,
            "features": list(features.columns),
            "missing_by_feature": {key: int(value) for key, value in features.isna().sum().items()},
        }
        if expected is not None:
            for field, value in expected.items():
                if field not in record:
                    raise ValueError(f"unknown reference field {field}")
                if record[field] != value:
                    label = "checksum" if field == "sha256" else field
                    raise ValueError(f"{label} differs from the reference")
        return record
    except (OSError, ValueError, KeyError, pd.errors.ParserError) as exc:
        return {"dataset": spec.name, "status": "FAIL", "reason": str(exc), "path": str(None)}

mutants_x_inspect_dataset__mutmut['_mutmut_orig'] = x_inspect_dataset__mutmut_orig # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_1'] = x_inspect_dataset__mutmut_1 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_2'] = x_inspect_dataset__mutmut_2 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_3'] = x_inspect_dataset__mutmut_3 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_4'] = x_inspect_dataset__mutmut_4 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_5'] = x_inspect_dataset__mutmut_5 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_6'] = x_inspect_dataset__mutmut_6 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_7'] = x_inspect_dataset__mutmut_7 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_8'] = x_inspect_dataset__mutmut_8 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_9'] = x_inspect_dataset__mutmut_9 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_10'] = x_inspect_dataset__mutmut_10 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_11'] = x_inspect_dataset__mutmut_11 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_12'] = x_inspect_dataset__mutmut_12 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_13'] = x_inspect_dataset__mutmut_13 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_14'] = x_inspect_dataset__mutmut_14 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_15'] = x_inspect_dataset__mutmut_15 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_16'] = x_inspect_dataset__mutmut_16 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_17'] = x_inspect_dataset__mutmut_17 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_18'] = x_inspect_dataset__mutmut_18 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_19'] = x_inspect_dataset__mutmut_19 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_20'] = x_inspect_dataset__mutmut_20 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_21'] = x_inspect_dataset__mutmut_21 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_22'] = x_inspect_dataset__mutmut_22 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_23'] = x_inspect_dataset__mutmut_23 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_24'] = x_inspect_dataset__mutmut_24 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_25'] = x_inspect_dataset__mutmut_25 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_26'] = x_inspect_dataset__mutmut_26 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_27'] = x_inspect_dataset__mutmut_27 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_28'] = x_inspect_dataset__mutmut_28 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_29'] = x_inspect_dataset__mutmut_29 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_30'] = x_inspect_dataset__mutmut_30 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_31'] = x_inspect_dataset__mutmut_31 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_32'] = x_inspect_dataset__mutmut_32 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_33'] = x_inspect_dataset__mutmut_33 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_34'] = x_inspect_dataset__mutmut_34 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_35'] = x_inspect_dataset__mutmut_35 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_36'] = x_inspect_dataset__mutmut_36 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_37'] = x_inspect_dataset__mutmut_37 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_38'] = x_inspect_dataset__mutmut_38 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_39'] = x_inspect_dataset__mutmut_39 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_40'] = x_inspect_dataset__mutmut_40 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_41'] = x_inspect_dataset__mutmut_41 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_42'] = x_inspect_dataset__mutmut_42 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_43'] = x_inspect_dataset__mutmut_43 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_44'] = x_inspect_dataset__mutmut_44 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_45'] = x_inspect_dataset__mutmut_45 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_46'] = x_inspect_dataset__mutmut_46 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_47'] = x_inspect_dataset__mutmut_47 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_48'] = x_inspect_dataset__mutmut_48 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_49'] = x_inspect_dataset__mutmut_49 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_50'] = x_inspect_dataset__mutmut_50 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_51'] = x_inspect_dataset__mutmut_51 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_52'] = x_inspect_dataset__mutmut_52 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_53'] = x_inspect_dataset__mutmut_53 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_54'] = x_inspect_dataset__mutmut_54 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_55'] = x_inspect_dataset__mutmut_55 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_56'] = x_inspect_dataset__mutmut_56 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_57'] = x_inspect_dataset__mutmut_57 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_58'] = x_inspect_dataset__mutmut_58 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_59'] = x_inspect_dataset__mutmut_59 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_60'] = x_inspect_dataset__mutmut_60 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_61'] = x_inspect_dataset__mutmut_61 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_62'] = x_inspect_dataset__mutmut_62 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_63'] = x_inspect_dataset__mutmut_63 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_64'] = x_inspect_dataset__mutmut_64 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_65'] = x_inspect_dataset__mutmut_65 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_66'] = x_inspect_dataset__mutmut_66 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_67'] = x_inspect_dataset__mutmut_67 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_68'] = x_inspect_dataset__mutmut_68 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_69'] = x_inspect_dataset__mutmut_69 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_70'] = x_inspect_dataset__mutmut_70 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_71'] = x_inspect_dataset__mutmut_71 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_72'] = x_inspect_dataset__mutmut_72 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_73'] = x_inspect_dataset__mutmut_73 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_74'] = x_inspect_dataset__mutmut_74 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_75'] = x_inspect_dataset__mutmut_75 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_76'] = x_inspect_dataset__mutmut_76 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_77'] = x_inspect_dataset__mutmut_77 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_78'] = x_inspect_dataset__mutmut_78 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_79'] = x_inspect_dataset__mutmut_79 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_80'] = x_inspect_dataset__mutmut_80 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_81'] = x_inspect_dataset__mutmut_81 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_82'] = x_inspect_dataset__mutmut_82 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_83'] = x_inspect_dataset__mutmut_83 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_84'] = x_inspect_dataset__mutmut_84 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_85'] = x_inspect_dataset__mutmut_85 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_86'] = x_inspect_dataset__mutmut_86 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_87'] = x_inspect_dataset__mutmut_87 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_88'] = x_inspect_dataset__mutmut_88 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_89'] = x_inspect_dataset__mutmut_89 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_90'] = x_inspect_dataset__mutmut_90 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_91'] = x_inspect_dataset__mutmut_91 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_92'] = x_inspect_dataset__mutmut_92 # type: ignore # mutmut generated
mutants_x_inspect_dataset__mutmut['x_inspect_dataset__mutmut_93'] = x_inspect_dataset__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_orig() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_1() -> int:
    parser = None
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_2() -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_3() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        None, type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_4() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=None, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_5() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=None
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_6() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_7() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_8() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_9() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "XX--outputXX", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_10() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--OUTPUT", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_11() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR * "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_12() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "XXreal_verification.jsonXX"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_13() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "REAL_VERIFICATION.JSON"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_14() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = None
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_15() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = ""
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_16() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(None) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_17() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) == set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_18() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(None):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_19() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = None
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_20() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(None)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_21() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(None)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_22() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = None
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_23() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = None
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_24() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(None)["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_25() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["XXdatasetsXX"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_26() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["DATASETS"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_27() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = None
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_28() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"XXsha256XX", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_29() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"SHA256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_30() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "XXraw_rowsXX", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_31() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "RAW_ROWS", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_32() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "XXrows_after_transformXX", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_33() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "ROWS_AFTER_TRANSFORM", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_34() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "XXanomaliesXX", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_35() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "ANOMALIES", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_36() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "XXpositive_valueXX"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_37() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "POSITIVE_VALUE"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_38() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = None
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_39() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required + reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_40() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(None)
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_41() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(None)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_42() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = None
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_43() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(None, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_44() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected=None)
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_45() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_46() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, )
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_47() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = None
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_48() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"XXdatasetXX": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_49() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"DATASET": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_50() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "XXstatusXX": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_51() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "STATUS": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_52() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "XXFAILXX", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_53() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "fail", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_54() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "XXreasonXX": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_55() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "REASON": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_56() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = None
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_57() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["XXdatasetXX"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_58() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["DATASET"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_59() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["XXstatusXX"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_60() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["STATUS"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_61() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] != "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_62() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "XXPASSXX"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_63() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "pass"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_64() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = None
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_65() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None or sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_66() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is not None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_67() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(None) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_68() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) != sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_69() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(None)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_70() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = None
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_71() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "XXcaptured_atXX": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_72() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "CAPTURED_AT": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_73() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(None).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_74() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "XXrequiredXX": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_75() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "REQUIRED": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_76() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(None),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_77() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "XXstatusXX": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_78() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "STATUS": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_79() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if (ok) and False else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_80() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if (ok) or True else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_81() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "XXPASSXX" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_82() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "pass" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_83() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "XXFAILXX",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_84() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "fail",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_85() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "XXdatasetsXX": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_86() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "DATASETS": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_87() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_88() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = None
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_89() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["XXreasonXX"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_90() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["REASON"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_91() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=None, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_92() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=None)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_93() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_94() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, )
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_95() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=False, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_96() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=False)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_97() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(None) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_98() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(None)
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_99() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) - "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_100() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(None, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_101() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=None, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_102() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=None) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_103() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_104() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_105() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, ) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_106() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=3, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_107() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=False) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_108() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "XX\nXX")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_109() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(None)
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_110() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['XXdatasetXX']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_111() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['DATASET']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_112() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['XXstatusXX']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_113() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['STATUS']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_114() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 1


def x_main__mutmut_115() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(None)
    return 0 if ok else 1


def x_main__mutmut_116() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if (ok) and False else 1


def x_main__mutmut_117() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if (ok) or True else 1


def x_main__mutmut_118() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 1 if ok else 1


def x_main__mutmut_119() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=config.RESULTS_DIR / "real_verification.json"
    )
    args = parser.parse_args()
    reason = None
    if set(DATASETS) != set(REQUIRED_DATASETS):
        reason = (
            f"registry {sorted(DATASETS)} differs from the required {sorted(REQUIRED_DATASETS)}"
        )
        records = []
    else:
        try:
            reference = json.loads(MANIFEST.read_text())["datasets"]
            required = {"sha256", "raw_rows", "rows_after_transform", "anomalies", "positive_value"}
            for spec in DATASETS.values():
                missing = required - reference[spec.name].keys()
                if missing:
                    raise ValueError(f"{spec.name}: reference missing {sorted(missing)}")
            records = [
                inspect_dataset(spec, expected={key: reference[spec.name][key] for key in required})
                for spec in DATASETS.values()
            ]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            records = [
                {"dataset": spec.name, "status": "FAIL", "reason": f"reference unavailable: {exc}"}
                for spec in DATASETS.values()
            ]
    passed = [item["dataset"] for item in records if item["status"] == "PASS"]
    ok = reason is None and sorted(passed) == sorted(REQUIRED_DATASETS)
    report = {
        "captured_at": datetime.now(UTC).isoformat(),
        "required": list(REQUIRED_DATASETS),
        "status": "PASS" if ok else "FAIL",
        "datasets": records,
    }
    if reason is not None:
        report["reason"] = reason
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for item in records:
        print(f"{item['dataset']}: {item['status']}")
    if reason is not None:
        print(f"REAL: FAIL ({reason})")
    return 0 if ok else 2

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
