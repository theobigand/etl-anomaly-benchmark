"""The proposed protection of ``main``: build it, check it, compare it. Never apply it.

The required status-check contexts are the display names of the jobs in
``ci.yml``. A context that two jobs share is ambiguous, so every job name must be
unique across workflows. ``check`` only reads (``gh api`` GET); applying the
protection is the owner's decision and is described in
``branch_protection_proposal.md``.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOWS = ROOT / ".github" / "workflows"
REPO = "theobigand/etl-anomaly-benchmark"
REQUIRED_CONTEXTS = ("test", "faults")
_JOB = re.compile(r"^  ([A-Za-z0-9_-]+):\s*$")
_NAME = re.compile(r"^    name:\s*(.+?)\s*$")


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_job_names__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_job_names__mutmut)
def job_names(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_orig(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_1(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = None
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_2(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(None):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_3(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob(None)):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_4(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("XX*.ymlXX")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_5(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.YML")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_6(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = None
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_7(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = None
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_8(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = True
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_9(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith(None):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_10(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("XXjobs:XX"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_11(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("JOBS:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_12(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = None
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_13(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = False
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_14(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs or (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_15(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(None)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_16(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(None)
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_17(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(None))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_18(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(2))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_19(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names or (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_20(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs or names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_21(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(None)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_22(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = None
        found[path.name] = names
    return found


def x_job_names__mutmut_23(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[+1] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_24(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-2] = match.group(1).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_25(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip(None)
        found[path.name] = names
    return found


def x_job_names__mutmut_26(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(None).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_27(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(2).strip("\"'")
        found[path.name] = names
    return found


def x_job_names__mutmut_28(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("XX\"'XX")
        found[path.name] = names
    return found


def x_job_names__mutmut_29(directory: Path = WORKFLOWS) -> dict[str, list[str]]:
    """Display name of every job, per workflow file: ``name:`` when given, else the key."""
    found: dict[str, list[str]] = {}
    for path in sorted(directory.glob("*.yml")):
        names: list[str] = []
        in_jobs = False
        for line in path.read_text().splitlines():
            if line.startswith("jobs:"):
                in_jobs = True
            elif in_jobs and (match := _JOB.match(line)):
                names.append(match.group(1))
            elif in_jobs and names and (match := _NAME.match(line)):
                names[-1] = match.group(1).strip("\"'")
        found[path.name] = None
    return found

mutants_x_job_names__mutmut['_mutmut_orig'] = x_job_names__mutmut_orig # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_1'] = x_job_names__mutmut_1 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_2'] = x_job_names__mutmut_2 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_3'] = x_job_names__mutmut_3 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_4'] = x_job_names__mutmut_4 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_5'] = x_job_names__mutmut_5 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_6'] = x_job_names__mutmut_6 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_7'] = x_job_names__mutmut_7 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_8'] = x_job_names__mutmut_8 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_9'] = x_job_names__mutmut_9 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_10'] = x_job_names__mutmut_10 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_11'] = x_job_names__mutmut_11 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_12'] = x_job_names__mutmut_12 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_13'] = x_job_names__mutmut_13 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_14'] = x_job_names__mutmut_14 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_15'] = x_job_names__mutmut_15 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_16'] = x_job_names__mutmut_16 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_17'] = x_job_names__mutmut_17 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_18'] = x_job_names__mutmut_18 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_19'] = x_job_names__mutmut_19 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_20'] = x_job_names__mutmut_20 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_21'] = x_job_names__mutmut_21 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_22'] = x_job_names__mutmut_22 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_23'] = x_job_names__mutmut_23 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_24'] = x_job_names__mutmut_24 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_25'] = x_job_names__mutmut_25 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_26'] = x_job_names__mutmut_26 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_27'] = x_job_names__mutmut_27 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_28'] = x_job_names__mutmut_28 # type: ignore # mutmut generated
mutants_x_job_names__mutmut['x_job_names__mutmut_29'] = x_job_names__mutmut_29 # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_problems_for_contexts__mutmut)
def problems_for_contexts(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(directory).values() for n in listed]
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(context)
        if count == 0:
            problems.append(f"required context {context!r}: no job provides it")
        elif count > 1:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_orig(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(directory).values() for n in listed]
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(context)
        if count == 0:
            problems.append(f"required context {context!r}: no job provides it")
        elif count > 1:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_1(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = None
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(context)
        if count == 0:
            problems.append(f"required context {context!r}: no job provides it")
        elif count > 1:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_2(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(None).values() for n in listed]
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(context)
        if count == 0:
            problems.append(f"required context {context!r}: no job provides it")
        elif count > 1:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_3(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(directory).values() for n in listed]
    problems = None
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(context)
        if count == 0:
            problems.append(f"required context {context!r}: no job provides it")
        elif count > 1:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_4(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(directory).values() for n in listed]
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = None
        if count == 0:
            problems.append(f"required context {context!r}: no job provides it")
        elif count > 1:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_5(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(directory).values() for n in listed]
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(None)
        if count == 0:
            problems.append(f"required context {context!r}: no job provides it")
        elif count > 1:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_6(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(directory).values() for n in listed]
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(context)
        if count != 0:
            problems.append(f"required context {context!r}: no job provides it")
        elif count > 1:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_7(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(directory).values() for n in listed]
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(context)
        if count == 1:
            problems.append(f"required context {context!r}: no job provides it")
        elif count > 1:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_8(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(directory).values() for n in listed]
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(context)
        if count == 0:
            problems.append(None)
        elif count > 1:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_9(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(directory).values() for n in listed]
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(context)
        if count == 0:
            problems.append(f"required context {context!r}: no job provides it")
        elif count >= 1:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_10(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(directory).values() for n in listed]
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(context)
        if count == 0:
            problems.append(f"required context {context!r}: no job provides it")
        elif count > 2:
            problems.append(f"required context {context!r} is provided by more than one job")
    return problems


def x_problems_for_contexts__mutmut_11(directory: Path = WORKFLOWS) -> list[str]:
    everywhere = [n for listed in job_names(directory).values() for n in listed]
    problems = []
    for context in REQUIRED_CONTEXTS:
        count = everywhere.count(context)
        if count == 0:
            problems.append(f"required context {context!r}: no job provides it")
        elif count > 1:
            problems.append(None)
    return problems

mutants_x_problems_for_contexts__mutmut['_mutmut_orig'] = x_problems_for_contexts__mutmut_orig # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut['x_problems_for_contexts__mutmut_1'] = x_problems_for_contexts__mutmut_1 # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut['x_problems_for_contexts__mutmut_2'] = x_problems_for_contexts__mutmut_2 # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut['x_problems_for_contexts__mutmut_3'] = x_problems_for_contexts__mutmut_3 # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut['x_problems_for_contexts__mutmut_4'] = x_problems_for_contexts__mutmut_4 # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut['x_problems_for_contexts__mutmut_5'] = x_problems_for_contexts__mutmut_5 # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut['x_problems_for_contexts__mutmut_6'] = x_problems_for_contexts__mutmut_6 # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut['x_problems_for_contexts__mutmut_7'] = x_problems_for_contexts__mutmut_7 # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut['x_problems_for_contexts__mutmut_8'] = x_problems_for_contexts__mutmut_8 # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut['x_problems_for_contexts__mutmut_9'] = x_problems_for_contexts__mutmut_9 # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut['x_problems_for_contexts__mutmut_10'] = x_problems_for_contexts__mutmut_10 # type: ignore # mutmut generated
mutants_x_problems_for_contexts__mutmut['x_problems_for_contexts__mutmut_11'] = x_problems_for_contexts__mutmut_11 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_proposed_payload__mutmut)
def proposed_payload() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_orig() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_1() -> dict:
    return {
        "XXrequired_status_checksXX": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_2() -> dict:
    return {
        "REQUIRED_STATUS_CHECKS": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_3() -> dict:
    return {
        "required_status_checks": {"XXstrictXX": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_4() -> dict:
    return {
        "required_status_checks": {"STRICT": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_5() -> dict:
    return {
        "required_status_checks": {"strict": False, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_6() -> dict:
    return {
        "required_status_checks": {"strict": True, "XXcontextsXX": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_7() -> dict:
    return {
        "required_status_checks": {"strict": True, "CONTEXTS": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_8() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(None)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_9() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "XXenforce_adminsXX": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_10() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "ENFORCE_ADMINS": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_11() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": True,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_12() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "XXrequired_pull_request_reviewsXX": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_13() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "REQUIRED_PULL_REQUEST_REVIEWS": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_14() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "XXrequired_approving_review_countXX": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_15() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "REQUIRED_APPROVING_REVIEW_COUNT": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_16() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 1,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_17() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "XXdismiss_stale_reviewsXX": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_18() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "DISMISS_STALE_REVIEWS": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_19() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": False,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_20() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "XXrestrictionsXX": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_21() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "RESTRICTIONS": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_22() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "XXrequired_conversation_resolutionXX": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_23() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "REQUIRED_CONVERSATION_RESOLUTION": True,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_24() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": False,
        "allow_force_pushes": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_25() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "XXallow_force_pushesXX": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_26() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "ALLOW_FORCE_PUSHES": False,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_27() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": True,
        "allow_deletions": False,
    }


def x_proposed_payload__mutmut_28() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "XXallow_deletionsXX": False,
    }


def x_proposed_payload__mutmut_29() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "ALLOW_DELETIONS": False,
    }


def x_proposed_payload__mutmut_30() -> dict:
    return {
        "required_status_checks": {"strict": True, "contexts": list(REQUIRED_CONTEXTS)},
        "enforce_admins": False,
        "required_pull_request_reviews": {
            "required_approving_review_count": 0,
            "dismiss_stale_reviews": True,
        },
        "restrictions": None,
        "required_conversation_resolution": True,
        "allow_force_pushes": False,
        "allow_deletions": True,
    }

mutants_x_proposed_payload__mutmut['_mutmut_orig'] = x_proposed_payload__mutmut_orig # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_1'] = x_proposed_payload__mutmut_1 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_2'] = x_proposed_payload__mutmut_2 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_3'] = x_proposed_payload__mutmut_3 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_4'] = x_proposed_payload__mutmut_4 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_5'] = x_proposed_payload__mutmut_5 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_6'] = x_proposed_payload__mutmut_6 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_7'] = x_proposed_payload__mutmut_7 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_8'] = x_proposed_payload__mutmut_8 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_9'] = x_proposed_payload__mutmut_9 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_10'] = x_proposed_payload__mutmut_10 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_11'] = x_proposed_payload__mutmut_11 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_12'] = x_proposed_payload__mutmut_12 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_13'] = x_proposed_payload__mutmut_13 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_14'] = x_proposed_payload__mutmut_14 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_15'] = x_proposed_payload__mutmut_15 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_16'] = x_proposed_payload__mutmut_16 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_17'] = x_proposed_payload__mutmut_17 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_18'] = x_proposed_payload__mutmut_18 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_19'] = x_proposed_payload__mutmut_19 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_20'] = x_proposed_payload__mutmut_20 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_21'] = x_proposed_payload__mutmut_21 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_22'] = x_proposed_payload__mutmut_22 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_23'] = x_proposed_payload__mutmut_23 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_24'] = x_proposed_payload__mutmut_24 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_25'] = x_proposed_payload__mutmut_25 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_26'] = x_proposed_payload__mutmut_26 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_27'] = x_proposed_payload__mutmut_27 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_28'] = x_proposed_payload__mutmut_28 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_29'] = x_proposed_payload__mutmut_29 # type: ignore # mutmut generated
mutants_x_proposed_payload__mutmut['x_proposed_payload__mutmut_30'] = x_proposed_payload__mutmut_30 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_validate_payload__mutmut)
def validate_payload(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_orig(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_1(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = None
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_2(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "XXrequired_status_checksXX",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_3(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "REQUIRED_STATUS_CHECKS",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_4(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "XXenforce_adminsXX",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_5(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "ENFORCE_ADMINS",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_6(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "XXrequired_pull_request_reviewsXX",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_7(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "REQUIRED_PULL_REQUEST_REVIEWS",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_8(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "XXrestrictionsXX",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_9(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "RESTRICTIONS",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_10(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_11(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = None
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_12(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get(None)
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_13(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("XXrequired_status_checksXX")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_14(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("REQUIRED_STATUS_CHECKS")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_15(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = None
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_16(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get(None)
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_17(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("XXcontextsXX")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_18(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("CONTEXTS")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_19(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) and not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_20(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_21(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_22(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append(None)
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_23(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("XXrequired_status_checks.contexts must be a non-empty listXX")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_24(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("REQUIRED_STATUS_CHECKS.CONTEXTS MUST BE A NON-EMPTY LIST")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_25(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_26(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append(None)
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_27(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("XXrequired_status_checks.strict must be a booleanXX")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_28(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("REQUIRED_STATUS_CHECKS.STRICT MUST BE A BOOLEAN")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_29(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload or not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_30(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "XXenforce_adminsXX" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_31(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "ENFORCE_ADMINS" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_32(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" not in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_33(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_34(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append(None)
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_35(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("XXenforce_admins must be a boolean (null is refused)XX")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_36(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("ENFORCE_ADMINS MUST BE A BOOLEAN (NULL IS REFUSED)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_37(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = None
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_38(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get(None)
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_39(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("XXrequired_pull_request_reviewsXX")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_40(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("REQUIRED_PULL_REQUEST_REVIEWS")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_41(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = None
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_42(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get(None)
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_43(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("XXrequired_approving_review_countXX")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_44(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("REQUIRED_APPROVING_REVIEW_COUNT")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_45(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) and not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_46(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if isinstance(count, int) or not 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_47(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or 0 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_48(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 1 <= count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_49(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 < count <= 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_50(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count < 6:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_51(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 7:
            problems.append("required_approving_review_count must be between 0 and 6")
    return problems


def x_validate_payload__mutmut_52(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append(None)
    return problems


def x_validate_payload__mutmut_53(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("XXrequired_approving_review_count must be between 0 and 6XX")
    return problems


def x_validate_payload__mutmut_54(payload: dict) -> list[str]:
    """Reasons the REST API would refuse a branch-protection payload."""
    problems = [
        f"{key} is required"
        for key in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
        )
        if key not in payload
    ]
    checks = payload.get("required_status_checks")
    if isinstance(checks, dict):
        contexts = checks.get("contexts")
        if not isinstance(contexts, list) or not contexts:
            problems.append("required_status_checks.contexts must be a non-empty list")
        if not isinstance(checks.get("strict"), bool):
            problems.append("required_status_checks.strict must be a boolean")
    if "enforce_admins" in payload and not isinstance(payload["enforce_admins"], bool):
        problems.append("enforce_admins must be a boolean (null is refused)")
    reviews = payload.get("required_pull_request_reviews")
    if isinstance(reviews, dict):
        count = reviews.get("required_approving_review_count")
        if not isinstance(count, int) or not 0 <= count <= 6:
            problems.append("REQUIRED_APPROVING_REVIEW_COUNT MUST BE BETWEEN 0 AND 6")
    return problems

mutants_x_validate_payload__mutmut['_mutmut_orig'] = x_validate_payload__mutmut_orig # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_1'] = x_validate_payload__mutmut_1 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_2'] = x_validate_payload__mutmut_2 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_3'] = x_validate_payload__mutmut_3 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_4'] = x_validate_payload__mutmut_4 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_5'] = x_validate_payload__mutmut_5 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_6'] = x_validate_payload__mutmut_6 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_7'] = x_validate_payload__mutmut_7 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_8'] = x_validate_payload__mutmut_8 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_9'] = x_validate_payload__mutmut_9 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_10'] = x_validate_payload__mutmut_10 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_11'] = x_validate_payload__mutmut_11 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_12'] = x_validate_payload__mutmut_12 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_13'] = x_validate_payload__mutmut_13 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_14'] = x_validate_payload__mutmut_14 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_15'] = x_validate_payload__mutmut_15 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_16'] = x_validate_payload__mutmut_16 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_17'] = x_validate_payload__mutmut_17 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_18'] = x_validate_payload__mutmut_18 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_19'] = x_validate_payload__mutmut_19 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_20'] = x_validate_payload__mutmut_20 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_21'] = x_validate_payload__mutmut_21 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_22'] = x_validate_payload__mutmut_22 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_23'] = x_validate_payload__mutmut_23 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_24'] = x_validate_payload__mutmut_24 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_25'] = x_validate_payload__mutmut_25 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_26'] = x_validate_payload__mutmut_26 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_27'] = x_validate_payload__mutmut_27 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_28'] = x_validate_payload__mutmut_28 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_29'] = x_validate_payload__mutmut_29 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_30'] = x_validate_payload__mutmut_30 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_31'] = x_validate_payload__mutmut_31 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_32'] = x_validate_payload__mutmut_32 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_33'] = x_validate_payload__mutmut_33 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_34'] = x_validate_payload__mutmut_34 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_35'] = x_validate_payload__mutmut_35 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_36'] = x_validate_payload__mutmut_36 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_37'] = x_validate_payload__mutmut_37 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_38'] = x_validate_payload__mutmut_38 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_39'] = x_validate_payload__mutmut_39 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_40'] = x_validate_payload__mutmut_40 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_41'] = x_validate_payload__mutmut_41 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_42'] = x_validate_payload__mutmut_42 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_43'] = x_validate_payload__mutmut_43 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_44'] = x_validate_payload__mutmut_44 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_45'] = x_validate_payload__mutmut_45 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_46'] = x_validate_payload__mutmut_46 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_47'] = x_validate_payload__mutmut_47 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_48'] = x_validate_payload__mutmut_48 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_49'] = x_validate_payload__mutmut_49 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_50'] = x_validate_payload__mutmut_50 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_51'] = x_validate_payload__mutmut_51 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_52'] = x_validate_payload__mutmut_52 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_53'] = x_validate_payload__mutmut_53 # type: ignore # mutmut generated
mutants_x_validate_payload__mutmut['x_validate_payload__mutmut_54'] = x_validate_payload__mutmut_54 # type: ignore # mutmut generated
mutants_x_compare__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_compare__mutmut)
def compare(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_orig(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_1(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = None
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_2(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = None
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_3(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get(None, {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_4(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", None)
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_5(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get({})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_6(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", )
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_7(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("XXrequired_status_checksXX", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_8(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("REQUIRED_STATUS_CHECKS", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_9(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = None
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_10(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["XXrequired_status_checksXX"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_11(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["REQUIRED_STATUS_CHECKS"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_12(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(None) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_13(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get(None, [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_14(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", None)) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_15(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get([])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_16(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", )) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_17(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("XXcontextsXX", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_18(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("CONTEXTS", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_19(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) == sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_20(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(None):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_21(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["XXcontextsXX"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_22(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["CONTEXTS"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_23(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(None)
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_24(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get(None)}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_25(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('XXcontextsXX')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_26(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('CONTEXTS')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_27(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['XXcontextsXX']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_28(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['CONTEXTS']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_29(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get(None) != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_30(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("XXstrictXX") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_31(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("STRICT") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_32(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") == wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_33(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["XXstrictXX"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_34(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["STRICT"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_35(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append(None)
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_36(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("XXrequired_status_checks.strict differsXX")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_37(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("REQUIRED_STATUS_CHECKS.STRICT DIFFERS")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_38(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = None
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_39(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get(None)
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_40(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get(None, {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_41(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", None).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_42(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get({}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_43(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", ).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_44(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("XXrequired_pull_request_reviewsXX", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_45(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("REQUIRED_PULL_REQUEST_REVIEWS", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_46(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("XXrequired_approving_review_countXX")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_47(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("REQUIRED_APPROVING_REVIEW_COUNT")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_48(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count == payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_49(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["XXrequired_pull_request_reviewsXX"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_50(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["REQUIRED_PULL_REQUEST_REVIEWS"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_51(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["XXrequired_approving_review_countXX"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_52(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["REQUIRED_APPROVING_REVIEW_COUNT"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_53(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(None)
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_54(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("XXallow_force_pushesXX", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_55(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("ALLOW_FORCE_PUSHES", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_56(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "XXallow_deletionsXX", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_57(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "ALLOW_DELETIONS", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_58(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "XXrequired_conversation_resolutionXX"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_59(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "REQUIRED_CONVERSATION_RESOLUTION"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_60(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get(None) != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_61(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(None, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_62(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, None).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_63(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get({}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_64(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, ).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_65(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("XXenabledXX") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_66(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("ENABLED") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_67(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") == payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_68(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(None)
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_69(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get(None)}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_70(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(None, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_71(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, None).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_72(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get({}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_73(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, ).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_74(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('XXenabledXX')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_75(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('ENABLED')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_76(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get(None) != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_77(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get(None, {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_78(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", None).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_79(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get({}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_80(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", ).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_81(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("XXenforce_adminsXX", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_82(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("ENFORCE_ADMINS", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_83(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("XXenabledXX") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_84(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("ENABLED") != payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_85(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") == payload["enforce_admins"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_86(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["XXenforce_adminsXX"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_87(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["ENFORCE_ADMINS"]:
        problems.append("enforce_admins differs")
    return problems


def x_compare__mutmut_88(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append(None)
    return problems


def x_compare__mutmut_89(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("XXenforce_admins differsXX")
    return problems


def x_compare__mutmut_90(actual: dict, payload: dict) -> list[str]:
    """Differences between the protection GitHub reports and the proposal."""
    problems = []
    checks = actual.get("required_status_checks", {})
    wanted = payload["required_status_checks"]
    if sorted(checks.get("contexts", [])) != sorted(wanted["contexts"]):
        problems.append(f"required contexts are {checks.get('contexts')}, not {wanted['contexts']}")
    if checks.get("strict") != wanted["strict"]:
        problems.append("required_status_checks.strict differs")
    count = actual.get("required_pull_request_reviews", {}).get("required_approving_review_count")
    if count != payload["required_pull_request_reviews"]["required_approving_review_count"]:
        problems.append(f"required_approving_review_count is {count}")
    for key in ("allow_force_pushes", "allow_deletions", "required_conversation_resolution"):
        if actual.get(key, {}).get("enabled") != payload[key]:
            problems.append(f"{key} is {actual.get(key, {}).get('enabled')}, not {payload[key]}")
    if actual.get("enforce_admins", {}).get("enabled") != payload["enforce_admins"]:
        problems.append("ENFORCE_ADMINS DIFFERS")
    return problems

mutants_x_compare__mutmut['_mutmut_orig'] = x_compare__mutmut_orig # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_1'] = x_compare__mutmut_1 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_2'] = x_compare__mutmut_2 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_3'] = x_compare__mutmut_3 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_4'] = x_compare__mutmut_4 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_5'] = x_compare__mutmut_5 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_6'] = x_compare__mutmut_6 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_7'] = x_compare__mutmut_7 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_8'] = x_compare__mutmut_8 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_9'] = x_compare__mutmut_9 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_10'] = x_compare__mutmut_10 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_11'] = x_compare__mutmut_11 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_12'] = x_compare__mutmut_12 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_13'] = x_compare__mutmut_13 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_14'] = x_compare__mutmut_14 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_15'] = x_compare__mutmut_15 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_16'] = x_compare__mutmut_16 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_17'] = x_compare__mutmut_17 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_18'] = x_compare__mutmut_18 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_19'] = x_compare__mutmut_19 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_20'] = x_compare__mutmut_20 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_21'] = x_compare__mutmut_21 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_22'] = x_compare__mutmut_22 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_23'] = x_compare__mutmut_23 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_24'] = x_compare__mutmut_24 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_25'] = x_compare__mutmut_25 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_26'] = x_compare__mutmut_26 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_27'] = x_compare__mutmut_27 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_28'] = x_compare__mutmut_28 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_29'] = x_compare__mutmut_29 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_30'] = x_compare__mutmut_30 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_31'] = x_compare__mutmut_31 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_32'] = x_compare__mutmut_32 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_33'] = x_compare__mutmut_33 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_34'] = x_compare__mutmut_34 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_35'] = x_compare__mutmut_35 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_36'] = x_compare__mutmut_36 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_37'] = x_compare__mutmut_37 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_38'] = x_compare__mutmut_38 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_39'] = x_compare__mutmut_39 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_40'] = x_compare__mutmut_40 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_41'] = x_compare__mutmut_41 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_42'] = x_compare__mutmut_42 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_43'] = x_compare__mutmut_43 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_44'] = x_compare__mutmut_44 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_45'] = x_compare__mutmut_45 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_46'] = x_compare__mutmut_46 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_47'] = x_compare__mutmut_47 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_48'] = x_compare__mutmut_48 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_49'] = x_compare__mutmut_49 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_50'] = x_compare__mutmut_50 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_51'] = x_compare__mutmut_51 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_52'] = x_compare__mutmut_52 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_53'] = x_compare__mutmut_53 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_54'] = x_compare__mutmut_54 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_55'] = x_compare__mutmut_55 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_56'] = x_compare__mutmut_56 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_57'] = x_compare__mutmut_57 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_58'] = x_compare__mutmut_58 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_59'] = x_compare__mutmut_59 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_60'] = x_compare__mutmut_60 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_61'] = x_compare__mutmut_61 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_62'] = x_compare__mutmut_62 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_63'] = x_compare__mutmut_63 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_64'] = x_compare__mutmut_64 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_65'] = x_compare__mutmut_65 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_66'] = x_compare__mutmut_66 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_67'] = x_compare__mutmut_67 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_68'] = x_compare__mutmut_68 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_69'] = x_compare__mutmut_69 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_70'] = x_compare__mutmut_70 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_71'] = x_compare__mutmut_71 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_72'] = x_compare__mutmut_72 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_73'] = x_compare__mutmut_73 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_74'] = x_compare__mutmut_74 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_75'] = x_compare__mutmut_75 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_76'] = x_compare__mutmut_76 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_77'] = x_compare__mutmut_77 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_78'] = x_compare__mutmut_78 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_79'] = x_compare__mutmut_79 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_80'] = x_compare__mutmut_80 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_81'] = x_compare__mutmut_81 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_82'] = x_compare__mutmut_82 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_83'] = x_compare__mutmut_83 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_84'] = x_compare__mutmut_84 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_85'] = x_compare__mutmut_85 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_86'] = x_compare__mutmut_86 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_87'] = x_compare__mutmut_87 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_88'] = x_compare__mutmut_88 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_89'] = x_compare__mutmut_89 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_90'] = x_compare__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = None
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest=None, required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=None)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", )
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="XXcommandXX", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="COMMAND", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=False)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser(None, help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help=None)
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser(help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", )
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("XXprintXX", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("PRINT", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="XXprint the proposed payloadXX")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="PRINT THE PROPOSED PAYLOAD")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = None
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser(None, help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help=None)
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser(help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", )
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("XXcheckXX", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("CHECK", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="XXread the protection of main and compare it (read-only)XX")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="READ THE PROTECTION OF MAIN AND COMPARE IT (READ-ONLY)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument(None, default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=None)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument(default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", )
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("XX--repoXX", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--REPO", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = None
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(None)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command != "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "XXprintXX":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "PRINT":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(None)
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(None, indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=None))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), ))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=3))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 1
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = None  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        None,
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=None, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=None, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=None,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["XXghXX", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["GH", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "XXapiXX", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "API", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=False, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=False, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=True,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode == 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 1:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(None)
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 2
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = None
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(None, proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), None)
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), )
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(None), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(None)
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print(None)
    return 1 if problems else 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("XXprotection: the applied protection matches the proposalXX")
    return 1 if problems else 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("PROTECTION: THE APPLIED PROTECTION MATCHES THE PROPOSAL")
    return 1 if problems else 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if (problems) and False else 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if (problems) or True else 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 2 if problems else 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("print", help="print the proposed payload")
    check = sub.add_parser("check", help="read the protection of main and compare it (read-only)")
    check.add_argument("--repo", default=REPO)
    args = parser.parse_args(argv)
    if args.command == "print":
        print(json.dumps(proposed_payload(), indent=2))
        return 0
    done = subprocess.run(
        ["gh", "api", f"repos/{args.repo}/branches/main/protection"],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    if done.returncode != 0:
        print(f"main is not protected, or the API refused the read: {done.stderr.strip()}")
        return 1
    problems = compare(json.loads(done.stdout), proposed_payload())
    for problem in problems:
        print(f"protection: {problem}")
    if not problems:
        print("protection: the applied protection matches the proposal")
    return 1 if problems else 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
