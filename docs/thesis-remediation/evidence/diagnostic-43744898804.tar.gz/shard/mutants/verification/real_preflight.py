"""Read-only preflight of the machine that will run the REAL profile.

It reads the interpreter, the installed packages, the three dataset files
(by hash, never by content), the Git state and the workflow, then prints one
line per check. It does not run the benchmark, writes nothing and uploads
nothing. ``--check-registration LABEL`` also reads the repository's runner
list through the GitHub API (a refused read is reported as unknown, never as
proof that no runner exists).

Exit status 1 when any check is ``FAIL``; ``WARN`` is advisory.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from importlib import metadata
from pathlib import Path
from typing import Any

from verification import bundles, release

ROOT = Path(__file__).resolve().parents[1]
REPO = "theobigand/etl-anomaly-benchmark"
LINUX_LOCK = ROOT / "verification" / "environment" / "linux-x86_64-py311.lock.txt"
WORKFLOW = ROOT / ".github" / "workflows" / "verify-release.yml"
MANIFEST = ROOT / "verification" / "evidence" / "manifest.json"
PYTHON_MINOR = "3.11"
MIN_DISK = 5 * 2**30
MIN_CPUS = 2
MIN_RAM = 8 * 2**30
REAL_REPORTS = {
    "experiments/results/real_verification.json",
    "experiments/results/evidence/real.json",
}
HOSTED_REPORTS = REAL_REPORTS | {"experiments/results/real_acquisition.json"}


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict


@dataclass(frozen=True)
class Result:
    name: str
    status: str
    detail: str


@dataclass(frozen=True)
class Resources:
    free_bytes: int
    cpus: int
    ram_bytes: int
mutants_x_check_python__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_python__mutmut)
def check_python(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "FAIL"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_orig(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "FAIL"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_1(version_info: Sequence[int], expected: str) -> Result:
    found = None
    status = "PASS" if found == expected else "FAIL"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_2(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[1]}.{version_info[1]}"
    status = "PASS" if found == expected else "FAIL"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_3(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[2]}"
    status = "PASS" if found == expected else "FAIL"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_4(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = None
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_5(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if (found == expected) and False else "FAIL"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_6(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if (found == expected) or True else "FAIL"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_7(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "XXPASSXX" if found == expected else "FAIL"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_8(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "pass" if found == expected else "FAIL"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_9(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found != expected else "FAIL"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_10(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "XXFAILXX"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_11(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "fail"
    return Result("python", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_12(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "FAIL"
    return Result(None, status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_13(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "FAIL"
    return Result("python", None, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_14(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "FAIL"
    return Result("python", status, None)


def x_check_python__mutmut_15(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "FAIL"
    return Result(status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_16(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "FAIL"
    return Result("python", f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_17(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "FAIL"
    return Result("python", status, )


def x_check_python__mutmut_18(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "FAIL"
    return Result("XXpythonXX", status, f"{found} (locked environment uses {expected})")


def x_check_python__mutmut_19(version_info: Sequence[int], expected: str) -> Result:
    found = f"{version_info[0]}.{version_info[1]}"
    status = "PASS" if found == expected else "FAIL"
    return Result("PYTHON", status, f"{found} (locked environment uses {expected})")

mutants_x_check_python__mutmut['_mutmut_orig'] = x_check_python__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_1'] = x_check_python__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_2'] = x_check_python__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_3'] = x_check_python__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_4'] = x_check_python__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_5'] = x_check_python__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_6'] = x_check_python__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_7'] = x_check_python__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_8'] = x_check_python__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_9'] = x_check_python__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_10'] = x_check_python__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_11'] = x_check_python__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_12'] = x_check_python__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_13'] = x_check_python__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_14'] = x_check_python__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_15'] = x_check_python__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_16'] = x_check_python__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_17'] = x_check_python__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_18'] = x_check_python__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_python__mutmut['x_check_python__mutmut_19'] = x_check_python__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_platform__mutmut)
def check_platform(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_orig(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_1(system: str, machine: str) -> Result:
    if (system, machine) != ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_2(system: str, machine: str) -> Result:
    if (system, machine) == ("XXLinuxXX", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_3(system: str, machine: str) -> Result:
    if (system, machine) == ("linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_4(system: str, machine: str) -> Result:
    if (system, machine) == ("LINUX", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_5(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "XXx86_64XX"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_6(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "X86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_7(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            None, "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_8(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", None, "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_9(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", None
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_10(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_11(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_12(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_13(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "XXplatformXX", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_14(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "PLATFORM", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_15(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "XXPASSXX", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_16(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "pass", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_17(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "XXLinux x86_64, the platform of the hash-locked environmentXX"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_18(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_19(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "LINUX X86_64, THE PLATFORM OF THE HASH-LOCKED ENVIRONMENT"
        )
    return Result(
        "platform", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_20(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        None, "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_21(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", None,
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_22(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        None,
    )  # fmt: skip


def x_check_platform__mutmut_23(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_24(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_25(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "WARN",
        )  # fmt: skip


def x_check_platform__mutmut_26(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "XXplatformXX", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_27(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "PLATFORM", "WARN",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_28(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "XXWARNXX",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip


def x_check_platform__mutmut_29(system: str, machine: str) -> Result:
    if (system, machine) == ("Linux", "x86_64"):
        return Result(
            "platform", "PASS", "Linux x86_64, the platform of the hash-locked environment"
        )
    return Result(
        "platform", "warn",
        f"{system} {machine}: only a statistical match with the archive can be expected",
    )  # fmt: skip

mutants_x_check_platform__mutmut['_mutmut_orig'] = x_check_platform__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_1'] = x_check_platform__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_2'] = x_check_platform__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_3'] = x_check_platform__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_4'] = x_check_platform__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_5'] = x_check_platform__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_6'] = x_check_platform__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_7'] = x_check_platform__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_8'] = x_check_platform__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_9'] = x_check_platform__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_10'] = x_check_platform__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_11'] = x_check_platform__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_12'] = x_check_platform__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_13'] = x_check_platform__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_14'] = x_check_platform__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_15'] = x_check_platform__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_16'] = x_check_platform__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_17'] = x_check_platform__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_18'] = x_check_platform__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_19'] = x_check_platform__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_20'] = x_check_platform__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_21'] = x_check_platform__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_22'] = x_check_platform__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_23'] = x_check_platform__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_24'] = x_check_platform__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_25'] = x_check_platform__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_26'] = x_check_platform__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_27'] = x_check_platform__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_28'] = x_check_platform__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_platform__mutmut['x_check_platform__mutmut_29'] = x_check_platform__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_dependencies__mutmut)
def check_dependencies(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_orig(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_1(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = None
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_2(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = None
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_3(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(None)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_4(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is not None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_5(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(None)
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_6(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found == wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_7(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(None)
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_8(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result(None, "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_9(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", None, "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_10(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", None)
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_11(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_12(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_13(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", )
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_14(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("XXdependenciesXX", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_15(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("DEPENDENCIES", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_16(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "XXFAILXX", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_17(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "fail", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_18(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(None))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_19(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "XX; XX".join(problems))
    return Result("dependencies", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_20(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result(None, "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_21(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", None, ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_22(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", None)


def x_check_dependencies__mutmut_23(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_24(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_25(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", )


def x_check_dependencies__mutmut_26(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("XXdependenciesXX", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_27(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("DEPENDENCIES", "PASS", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_28(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "XXPASSXX", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_29(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "pass", ", ".join(f"{k} {v}" for k, v in locked.items()))


def x_check_dependencies__mutmut_30(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", ", ".join(None))


def x_check_dependencies__mutmut_31(installed: Mapping[str, str | None], locked: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in locked.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("dependencies", "FAIL", "; ".join(problems))
    return Result("dependencies", "PASS", "XX, XX".join(f"{k} {v}" for k, v in locked.items()))

mutants_x_check_dependencies__mutmut['_mutmut_orig'] = x_check_dependencies__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_1'] = x_check_dependencies__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_2'] = x_check_dependencies__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_3'] = x_check_dependencies__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_4'] = x_check_dependencies__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_5'] = x_check_dependencies__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_6'] = x_check_dependencies__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_7'] = x_check_dependencies__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_8'] = x_check_dependencies__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_9'] = x_check_dependencies__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_10'] = x_check_dependencies__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_11'] = x_check_dependencies__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_12'] = x_check_dependencies__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_13'] = x_check_dependencies__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_14'] = x_check_dependencies__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_15'] = x_check_dependencies__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_16'] = x_check_dependencies__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_17'] = x_check_dependencies__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_18'] = x_check_dependencies__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_19'] = x_check_dependencies__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_20'] = x_check_dependencies__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_21'] = x_check_dependencies__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_22'] = x_check_dependencies__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_23'] = x_check_dependencies__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_24'] = x_check_dependencies__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_25'] = x_check_dependencies__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_26'] = x_check_dependencies__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_27'] = x_check_dependencies__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_28'] = x_check_dependencies__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_29'] = x_check_dependencies__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_30'] = x_check_dependencies__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_dependencies__mutmut['x_check_dependencies__mutmut_31'] = x_check_dependencies__mutmut_31 # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_linux_lock_pins__mutmut)
def linux_lock_pins(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = line.partition("==")
        if sep and not line.startswith("#"):
            pins[name.strip()] = rest.split()[0]
    return pins


def x_linux_lock_pins__mutmut_orig(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = line.partition("==")
        if sep and not line.startswith("#"):
            pins[name.strip()] = rest.split()[0]
    return pins


def x_linux_lock_pins__mutmut_1(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = None
    for line in path.read_text().splitlines():
        name, sep, rest = line.partition("==")
        if sep and not line.startswith("#"):
            pins[name.strip()] = rest.split()[0]
    return pins


def x_linux_lock_pins__mutmut_2(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = None
        if sep and not line.startswith("#"):
            pins[name.strip()] = rest.split()[0]
    return pins


def x_linux_lock_pins__mutmut_3(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = line.partition(None)
        if sep and not line.startswith("#"):
            pins[name.strip()] = rest.split()[0]
    return pins


def x_linux_lock_pins__mutmut_4(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = line.rpartition("==")
        if sep and not line.startswith("#"):
            pins[name.strip()] = rest.split()[0]
    return pins


def x_linux_lock_pins__mutmut_5(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = line.partition("XX==XX")
        if sep and not line.startswith("#"):
            pins[name.strip()] = rest.split()[0]
    return pins


def x_linux_lock_pins__mutmut_6(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = line.partition("==")
        if sep or not line.startswith("#"):
            pins[name.strip()] = rest.split()[0]
    return pins


def x_linux_lock_pins__mutmut_7(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = line.partition("==")
        if sep and line.startswith("#"):
            pins[name.strip()] = rest.split()[0]
    return pins


def x_linux_lock_pins__mutmut_8(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = line.partition("==")
        if sep and not line.startswith(None):
            pins[name.strip()] = rest.split()[0]
    return pins


def x_linux_lock_pins__mutmut_9(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = line.partition("==")
        if sep and not line.startswith("XX#XX"):
            pins[name.strip()] = rest.split()[0]
    return pins


def x_linux_lock_pins__mutmut_10(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = line.partition("==")
        if sep and not line.startswith("#"):
            pins[name.strip()] = None
    return pins


def x_linux_lock_pins__mutmut_11(path: Path = LINUX_LOCK) -> dict[str, str]:
    """``{name: version}`` of every wheel the hash-pinned Linux lock installs."""
    pins = {}
    for line in path.read_text().splitlines():
        name, sep, rest = line.partition("==")
        if sep and not line.startswith("#"):
            pins[name.strip()] = rest.split()[1]
    return pins

mutants_x_linux_lock_pins__mutmut['_mutmut_orig'] = x_linux_lock_pins__mutmut_orig # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut['x_linux_lock_pins__mutmut_1'] = x_linux_lock_pins__mutmut_1 # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut['x_linux_lock_pins__mutmut_2'] = x_linux_lock_pins__mutmut_2 # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut['x_linux_lock_pins__mutmut_3'] = x_linux_lock_pins__mutmut_3 # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut['x_linux_lock_pins__mutmut_4'] = x_linux_lock_pins__mutmut_4 # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut['x_linux_lock_pins__mutmut_5'] = x_linux_lock_pins__mutmut_5 # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut['x_linux_lock_pins__mutmut_6'] = x_linux_lock_pins__mutmut_6 # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut['x_linux_lock_pins__mutmut_7'] = x_linux_lock_pins__mutmut_7 # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut['x_linux_lock_pins__mutmut_8'] = x_linux_lock_pins__mutmut_8 # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut['x_linux_lock_pins__mutmut_9'] = x_linux_lock_pins__mutmut_9 # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut['x_linux_lock_pins__mutmut_10'] = x_linux_lock_pins__mutmut_10 # type: ignore # mutmut generated
mutants_x_linux_lock_pins__mutmut['x_linux_lock_pins__mutmut_11'] = x_linux_lock_pins__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_lock__mutmut)
def check_lock(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_orig(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_1(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = None
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_2(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = None
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_3(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(None)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_4(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is not None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_5(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(None)
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_6(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found == wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_7(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(None)
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_8(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result(None, "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_9(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", None, "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_10(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", None)
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_11(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_12(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_13(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", )
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_14(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("XXenvironment lockXX", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_15(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("ENVIRONMENT LOCK", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_16(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "XXFAILXX", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_17(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "fail", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_18(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(None))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_19(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "XX; XX".join(problems[:10]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_20(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:11]))
    return Result("environment lock", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_21(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result(None, "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_22(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", None, f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_23(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", None)


def x_check_lock__mutmut_24(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_25(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_26(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "PASS", )


def x_check_lock__mutmut_27(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("XXenvironment lockXX", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_28(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("ENVIRONMENT LOCK", "PASS", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_29(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "XXPASSXX", f"all {len(pins)} pinned packages match")


def x_check_lock__mutmut_30(installed: Mapping[str, str | None], pins: Mapping[str, str]) -> Result:
    problems = []
    for name, wanted in pins.items():
        found = installed.get(name)
        if found is None:
            problems.append(f"{name} not installed")
        elif found != wanted:
            problems.append(f"{name} {found} != {wanted}")
    if problems:
        return Result("environment lock", "FAIL", "; ".join(problems[:10]))
    return Result("environment lock", "pass", f"all {len(pins)} pinned packages match")

mutants_x_check_lock__mutmut['_mutmut_orig'] = x_check_lock__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_1'] = x_check_lock__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_2'] = x_check_lock__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_3'] = x_check_lock__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_4'] = x_check_lock__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_5'] = x_check_lock__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_6'] = x_check_lock__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_7'] = x_check_lock__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_8'] = x_check_lock__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_9'] = x_check_lock__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_10'] = x_check_lock__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_11'] = x_check_lock__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_12'] = x_check_lock__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_13'] = x_check_lock__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_14'] = x_check_lock__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_15'] = x_check_lock__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_16'] = x_check_lock__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_17'] = x_check_lock__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_18'] = x_check_lock__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_19'] = x_check_lock__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_20'] = x_check_lock__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_21'] = x_check_lock__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_22'] = x_check_lock__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_23'] = x_check_lock__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_24'] = x_check_lock__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_25'] = x_check_lock__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_26'] = x_check_lock__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_27'] = x_check_lock__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_28'] = x_check_lock__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_29'] = x_check_lock__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_lock__mutmut['x_check_lock__mutmut_30'] = x_check_lock__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_lock_for__mutmut)
def check_lock_for(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_orig(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_1(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system == "Linux":
        return Result("environment lock", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_2(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "XXLinuxXX":
        return Result("environment lock", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_3(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "linux":
        return Result("environment lock", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_4(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "LINUX":
        return Result("environment lock", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_5(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result(None, "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_6(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", None, "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_7(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "WARN", None)
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_8(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_9(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_10(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "WARN", )
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_11(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("XXenvironment lockXX", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_12(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("ENVIRONMENT LOCK", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_13(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "XXWARNXX", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_14(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "warn", "the hash-pinned lock describes Linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_15(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "WARN", "XXthe hash-pinned lock describes Linux onlyXX")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_16(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "WARN", "the hash-pinned lock describes linux only")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_17(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "WARN", "THE HASH-PINNED LOCK DESCRIBES LINUX ONLY")
    return check_lock(installed, pins)


def x_check_lock_for__mutmut_18(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(None, pins)


def x_check_lock_for__mutmut_19(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, None)


def x_check_lock_for__mutmut_20(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(pins)


def x_check_lock_for__mutmut_21(
    system: str, installed: Mapping[str, str | None], pins: Mapping[str, str]
) -> Result:
    if system != "Linux":
        return Result("environment lock", "WARN", "the hash-pinned lock describes Linux only")
    return check_lock(installed, )

mutants_x_check_lock_for__mutmut['_mutmut_orig'] = x_check_lock_for__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_1'] = x_check_lock_for__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_2'] = x_check_lock_for__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_3'] = x_check_lock_for__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_4'] = x_check_lock_for__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_5'] = x_check_lock_for__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_6'] = x_check_lock_for__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_7'] = x_check_lock_for__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_8'] = x_check_lock_for__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_9'] = x_check_lock_for__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_10'] = x_check_lock_for__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_11'] = x_check_lock_for__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_12'] = x_check_lock_for__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_13'] = x_check_lock_for__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_14'] = x_check_lock_for__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_15'] = x_check_lock_for__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_16'] = x_check_lock_for__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_17'] = x_check_lock_for__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_18'] = x_check_lock_for__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_19'] = x_check_lock_for__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_20'] = x_check_lock_for__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_lock_for__mutmut['x_check_lock_for__mutmut_21'] = x_check_lock_for__mutmut_21 # type: ignore # mutmut generated
mutants_x__sha256__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__sha256__mutmut)
def _sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, hashlib.sha256).hexdigest()


def x__sha256__mutmut_orig(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, hashlib.sha256).hexdigest()


def x__sha256__mutmut_1(path: Path) -> str:
    with path.open(None) as stream:
        return hashlib.file_digest(stream, hashlib.sha256).hexdigest()


def x__sha256__mutmut_2(path: Path) -> str:
    with path.open("XXrbXX") as stream:
        return hashlib.file_digest(stream, hashlib.sha256).hexdigest()


def x__sha256__mutmut_3(path: Path) -> str:
    with path.open("RB") as stream:
        return hashlib.file_digest(stream, hashlib.sha256).hexdigest()


def x__sha256__mutmut_4(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(None, hashlib.sha256).hexdigest()


def x__sha256__mutmut_5(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, None).hexdigest()


def x__sha256__mutmut_6(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(hashlib.sha256).hexdigest()


def x__sha256__mutmut_7(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, ).hexdigest()

mutants_x__sha256__mutmut['_mutmut_orig'] = x__sha256__mutmut_orig # type: ignore # mutmut generated
mutants_x__sha256__mutmut['x__sha256__mutmut_1'] = x__sha256__mutmut_1 # type: ignore # mutmut generated
mutants_x__sha256__mutmut['x__sha256__mutmut_2'] = x__sha256__mutmut_2 # type: ignore # mutmut generated
mutants_x__sha256__mutmut['x__sha256__mutmut_3'] = x__sha256__mutmut_3 # type: ignore # mutmut generated
mutants_x__sha256__mutmut['x__sha256__mutmut_4'] = x__sha256__mutmut_4 # type: ignore # mutmut generated
mutants_x__sha256__mutmut['x__sha256__mutmut_5'] = x__sha256__mutmut_5 # type: ignore # mutmut generated
mutants_x__sha256__mutmut['x__sha256__mutmut_6'] = x__sha256__mutmut_6 # type: ignore # mutmut generated
mutants_x__sha256__mutmut['x__sha256__mutmut_7'] = x__sha256__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_datasets__mutmut)
def check_datasets(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_orig(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_1(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = None
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_2(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_3(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(None)
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_4(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(None, "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_5(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", None, "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_6(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", None))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_7(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result("FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_8(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_9(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", ))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_10(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "XXFAILXX", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_11(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "fail", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_12(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "XXfile absentXX"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_13(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "FILE ABSENT"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_14(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            break
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_15(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = None
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_16(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["XXsha256XX"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_17(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["SHA256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_18(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = None
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_19(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(None) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_20(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) != expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_21(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            None
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_22(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                None,
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_23(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                None,
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_24(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                None,
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_25(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_26(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_27(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_28(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if (same) and False else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_29(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if (same) or True else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_30(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "XXPASSXX" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_31(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "pass" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_32(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "XXFAILXX",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_33(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "fail",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_34(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if (same) and False else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_35(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if (same) or True else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_36(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "XXsha256 matches the referenceXX" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_37(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "SHA256 MATCHES THE REFERENCE" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_38(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "XXsha256 differs from the referenceXX",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_39(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "SHA256 DIFFERS FROM THE REFERENCE",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_40(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = None
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_41(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode | 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_42(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 512
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_43(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode | 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_44(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 19:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_45(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = None
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_46(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "XXFAILXX", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_47(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "fail", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_48(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode | 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_49(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 37:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_50(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = None
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_51(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "XXWARNXX", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_52(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "warn", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_53(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = None
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_54(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "XXPASSXX", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_55(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "pass", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, detail))
    return results


def x_check_datasets__mutmut_56(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(None)
    return results


def x_check_datasets__mutmut_57(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(None, status, detail))
    return results


def x_check_datasets__mutmut_58(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", None, detail))
    return results


def x_check_datasets__mutmut_59(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, None))
    return results


def x_check_datasets__mutmut_60(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(status, detail))
    return results


def x_check_datasets__mutmut_61(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", detail))
    return results


def x_check_datasets__mutmut_62(paths: Mapping[str, Path], reference: Mapping[str, Any]) -> list[Result]:
    """Presence, SHA-256 against the reference manifest, and file mode. No content is read out."""
    results = []
    for name, path in paths.items():
        if not path.is_file():
            results.append(Result(f"dataset {name}", "FAIL", "file absent"))
            continue
        expected = reference[name]["sha256"]
        same = _sha256(path) == expected
        results.append(
            Result(
                f"dataset {name}",
                "PASS" if same else "FAIL",
                "sha256 matches the reference" if same else "sha256 differs from the reference",
            )
        )
        mode = path.stat().st_mode & 0o777
        if mode & 0o022:
            status, detail = "FAIL", f"mode {mode:o} is writable beyond the owner"
        elif mode & 0o044:
            status, detail = "WARN", f"mode {mode:o} is readable beyond the owner"
        else:
            status, detail = "PASS", f"mode {mode:o}"
        results.append(Result(f"dataset permissions {name}", status, ))
    return results

mutants_x_check_datasets__mutmut['_mutmut_orig'] = x_check_datasets__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_1'] = x_check_datasets__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_2'] = x_check_datasets__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_3'] = x_check_datasets__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_4'] = x_check_datasets__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_5'] = x_check_datasets__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_6'] = x_check_datasets__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_7'] = x_check_datasets__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_8'] = x_check_datasets__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_9'] = x_check_datasets__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_10'] = x_check_datasets__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_11'] = x_check_datasets__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_12'] = x_check_datasets__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_13'] = x_check_datasets__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_14'] = x_check_datasets__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_15'] = x_check_datasets__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_16'] = x_check_datasets__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_17'] = x_check_datasets__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_18'] = x_check_datasets__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_19'] = x_check_datasets__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_20'] = x_check_datasets__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_21'] = x_check_datasets__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_22'] = x_check_datasets__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_23'] = x_check_datasets__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_24'] = x_check_datasets__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_25'] = x_check_datasets__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_26'] = x_check_datasets__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_27'] = x_check_datasets__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_28'] = x_check_datasets__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_29'] = x_check_datasets__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_30'] = x_check_datasets__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_31'] = x_check_datasets__mutmut_31 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_32'] = x_check_datasets__mutmut_32 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_33'] = x_check_datasets__mutmut_33 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_34'] = x_check_datasets__mutmut_34 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_35'] = x_check_datasets__mutmut_35 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_36'] = x_check_datasets__mutmut_36 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_37'] = x_check_datasets__mutmut_37 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_38'] = x_check_datasets__mutmut_38 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_39'] = x_check_datasets__mutmut_39 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_40'] = x_check_datasets__mutmut_40 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_41'] = x_check_datasets__mutmut_41 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_42'] = x_check_datasets__mutmut_42 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_43'] = x_check_datasets__mutmut_43 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_44'] = x_check_datasets__mutmut_44 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_45'] = x_check_datasets__mutmut_45 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_46'] = x_check_datasets__mutmut_46 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_47'] = x_check_datasets__mutmut_47 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_48'] = x_check_datasets__mutmut_48 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_49'] = x_check_datasets__mutmut_49 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_50'] = x_check_datasets__mutmut_50 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_51'] = x_check_datasets__mutmut_51 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_52'] = x_check_datasets__mutmut_52 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_53'] = x_check_datasets__mutmut_53 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_54'] = x_check_datasets__mutmut_54 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_55'] = x_check_datasets__mutmut_55 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_56'] = x_check_datasets__mutmut_56 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_57'] = x_check_datasets__mutmut_57 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_58'] = x_check_datasets__mutmut_58 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_59'] = x_check_datasets__mutmut_59 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_60'] = x_check_datasets__mutmut_60 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_61'] = x_check_datasets__mutmut_61 # type: ignore # mutmut generated
mutants_x_check_datasets__mutmut['x_check_datasets__mutmut_62'] = x_check_datasets__mutmut_62 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_measure_resources__mutmut)
def measure_resources(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_orig(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_1(where: Path) -> Resources:
    ram = None
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_2(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") / os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_3(where: Path) -> Resources:
    ram = os.sysconf(None) * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_4(where: Path) -> Resources:
    ram = os.sysconf("XXSC_PAGE_SIZEXX") * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_5(where: Path) -> Resources:
    ram = os.sysconf("sc_page_size") * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_6(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf(None)
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_7(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("XXSC_PHYS_PAGESXX")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_8(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("sc_phys_pages")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_9(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return Resources(None, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_10(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, None, ram)


def x_measure_resources__mutmut_11(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, None)


def x_measure_resources__mutmut_12(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return Resources(os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_13(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, ram)


def x_measure_resources__mutmut_14(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 1, )


def x_measure_resources__mutmut_15(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(None).free, os.cpu_count() or 1, ram)


def x_measure_resources__mutmut_16(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() and 1, ram)


def x_measure_resources__mutmut_17(where: Path) -> Resources:
    ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return Resources(shutil.disk_usage(where).free, os.cpu_count() or 2, ram)

mutants_x_measure_resources__mutmut['_mutmut_orig'] = x_measure_resources__mutmut_orig # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_1'] = x_measure_resources__mutmut_1 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_2'] = x_measure_resources__mutmut_2 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_3'] = x_measure_resources__mutmut_3 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_4'] = x_measure_resources__mutmut_4 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_5'] = x_measure_resources__mutmut_5 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_6'] = x_measure_resources__mutmut_6 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_7'] = x_measure_resources__mutmut_7 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_8'] = x_measure_resources__mutmut_8 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_9'] = x_measure_resources__mutmut_9 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_10'] = x_measure_resources__mutmut_10 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_11'] = x_measure_resources__mutmut_11 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_12'] = x_measure_resources__mutmut_12 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_13'] = x_measure_resources__mutmut_13 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_14'] = x_measure_resources__mutmut_14 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_15'] = x_measure_resources__mutmut_15 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_16'] = x_measure_resources__mutmut_16 # type: ignore # mutmut generated
mutants_x_measure_resources__mutmut['x_measure_resources__mutmut_17'] = x_measure_resources__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_resources__mutmut)
def check_resources(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_orig(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_1(found: Resources) -> Result:
    short = None
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_2(found: Resources) -> Result:
    short = []
    if found.free_bytes <= MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_3(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(None)
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_4(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes / 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_5(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2 * 30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_6(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 3**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_7(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**31} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_8(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK / 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_9(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2 * 30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_10(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 3**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_11(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**31} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_12(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus <= MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_13(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(None)
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_14(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes <= MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_15(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(None)
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_16(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes / 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_17(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2 * 30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_18(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 3**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_19(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**31} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_20(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM / 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_21(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2 * 30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_22(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 3**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_23(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**31} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_24(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result(None, "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_25(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", None, "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_26(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", None)
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_27(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_28(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_29(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", )
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_30(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("XXresourcesXX", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_31(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("RESOURCES", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_32(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "XXFAILXX", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_33(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "fail", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_34(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(None))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_35(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "XX; XX".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_36(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = None
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_37(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes / 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_38(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2 * 30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_39(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 3**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_40(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**31, found.ram_bytes // 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_41(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes / 2**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_42(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2 * 30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_43(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 3**30
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_44(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**31
    return Result("resources", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_45(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result(None, "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_46(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", None, f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_47(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", None)


def x_check_resources__mutmut_48(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_49(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_50(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "PASS", )


def x_check_resources__mutmut_51(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("XXresourcesXX", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_52(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("RESOURCES", "PASS", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_53(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "XXPASSXX", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")


def x_check_resources__mutmut_54(found: Resources) -> Result:
    short = []
    if found.free_bytes < MIN_DISK:
        short.append(f"disk {found.free_bytes // 2**30} GiB free, {MIN_DISK // 2**30} needed")
    if found.cpus < MIN_CPUS:
        short.append(f"cpu {found.cpus}, {MIN_CPUS} needed")
    if found.ram_bytes < MIN_RAM:
        short.append(f"memory {found.ram_bytes // 2**30} GiB, {MIN_RAM // 2**30} needed")
    if short:
        return Result("resources", "FAIL", "; ".join(short))
    free, ram = found.free_bytes // 2**30, found.ram_bytes // 2**30
    return Result("resources", "pass", f"{free} GiB free, {found.cpus} cpu, {ram} GiB memory")

mutants_x_check_resources__mutmut['_mutmut_orig'] = x_check_resources__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_1'] = x_check_resources__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_2'] = x_check_resources__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_3'] = x_check_resources__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_4'] = x_check_resources__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_5'] = x_check_resources__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_6'] = x_check_resources__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_7'] = x_check_resources__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_8'] = x_check_resources__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_9'] = x_check_resources__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_10'] = x_check_resources__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_11'] = x_check_resources__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_12'] = x_check_resources__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_13'] = x_check_resources__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_14'] = x_check_resources__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_15'] = x_check_resources__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_16'] = x_check_resources__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_17'] = x_check_resources__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_18'] = x_check_resources__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_19'] = x_check_resources__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_20'] = x_check_resources__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_21'] = x_check_resources__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_22'] = x_check_resources__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_23'] = x_check_resources__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_24'] = x_check_resources__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_25'] = x_check_resources__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_26'] = x_check_resources__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_27'] = x_check_resources__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_28'] = x_check_resources__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_29'] = x_check_resources__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_30'] = x_check_resources__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_31'] = x_check_resources__mutmut_31 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_32'] = x_check_resources__mutmut_32 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_33'] = x_check_resources__mutmut_33 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_34'] = x_check_resources__mutmut_34 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_35'] = x_check_resources__mutmut_35 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_36'] = x_check_resources__mutmut_36 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_37'] = x_check_resources__mutmut_37 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_38'] = x_check_resources__mutmut_38 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_39'] = x_check_resources__mutmut_39 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_40'] = x_check_resources__mutmut_40 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_41'] = x_check_resources__mutmut_41 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_42'] = x_check_resources__mutmut_42 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_43'] = x_check_resources__mutmut_43 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_44'] = x_check_resources__mutmut_44 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_45'] = x_check_resources__mutmut_45 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_46'] = x_check_resources__mutmut_46 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_47'] = x_check_resources__mutmut_47 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_48'] = x_check_resources__mutmut_48 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_49'] = x_check_resources__mutmut_49 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_50'] = x_check_resources__mutmut_50 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_51'] = x_check_resources__mutmut_51 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_52'] = x_check_resources__mutmut_52 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_53'] = x_check_resources__mutmut_53 # type: ignore # mutmut generated
mutants_x_check_resources__mutmut['x_check_resources__mutmut_54'] = x_check_resources__mutmut_54 # type: ignore # mutmut generated
mutants_x_git_state__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_git_state__mutmut)
def git_state(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_orig(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_1(root: Path) -> tuple[str, bool]:
    head = None
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_2(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        None, cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_3(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=None, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_4(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=None, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_5(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=None, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_6(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=None
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_7(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_8(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_9(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_10(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_11(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_12(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["XXgitXX", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_13(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["GIT", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_14(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "XXrev-parseXX", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_15(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "REV-PARSE", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_16(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "XXHEADXX"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_17(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "head"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_18(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=False, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_19(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=False, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_20(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=False
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_21(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = None
    return head, bool(dirty)


def x_git_state__mutmut_22(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        None, cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_23(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=None, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_24(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=None, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_25(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=None, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_26(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=None
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_27(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_28(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_29(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_30(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_31(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_32(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["XXgitXX", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_33(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["GIT", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_34(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "XXstatusXX", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_35(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "STATUS", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_36(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "XX--porcelainXX"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_37(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--PORCELAIN"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_38(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=False, text=True, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_39(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=False, check=True
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_40(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=False
    ).stdout.strip()
    return head, bool(dirty)


def x_git_state__mutmut_41(root: Path) -> tuple[str, bool]:
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    dirty = subprocess.run(
        ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, check=True
    ).stdout.strip()
    return head, bool(None)

mutants_x_git_state__mutmut['_mutmut_orig'] = x_git_state__mutmut_orig # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_1'] = x_git_state__mutmut_1 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_2'] = x_git_state__mutmut_2 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_3'] = x_git_state__mutmut_3 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_4'] = x_git_state__mutmut_4 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_5'] = x_git_state__mutmut_5 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_6'] = x_git_state__mutmut_6 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_7'] = x_git_state__mutmut_7 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_8'] = x_git_state__mutmut_8 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_9'] = x_git_state__mutmut_9 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_10'] = x_git_state__mutmut_10 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_11'] = x_git_state__mutmut_11 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_12'] = x_git_state__mutmut_12 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_13'] = x_git_state__mutmut_13 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_14'] = x_git_state__mutmut_14 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_15'] = x_git_state__mutmut_15 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_16'] = x_git_state__mutmut_16 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_17'] = x_git_state__mutmut_17 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_18'] = x_git_state__mutmut_18 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_19'] = x_git_state__mutmut_19 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_20'] = x_git_state__mutmut_20 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_21'] = x_git_state__mutmut_21 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_22'] = x_git_state__mutmut_22 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_23'] = x_git_state__mutmut_23 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_24'] = x_git_state__mutmut_24 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_25'] = x_git_state__mutmut_25 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_26'] = x_git_state__mutmut_26 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_27'] = x_git_state__mutmut_27 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_28'] = x_git_state__mutmut_28 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_29'] = x_git_state__mutmut_29 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_30'] = x_git_state__mutmut_30 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_31'] = x_git_state__mutmut_31 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_32'] = x_git_state__mutmut_32 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_33'] = x_git_state__mutmut_33 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_34'] = x_git_state__mutmut_34 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_35'] = x_git_state__mutmut_35 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_36'] = x_git_state__mutmut_36 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_37'] = x_git_state__mutmut_37 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_38'] = x_git_state__mutmut_38 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_39'] = x_git_state__mutmut_39 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_40'] = x_git_state__mutmut_40 # type: ignore # mutmut generated
mutants_x_git_state__mutmut['x_git_state__mutmut_41'] = x_git_state__mutmut_41 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_revision__mutmut)
def check_revision(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_orig(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_1(head: str, expected: str, dirty: bool) -> Result:
    if expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_2(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result(None, "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_3(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", None, "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_4(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", None)
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_5(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_6(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_7(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", )
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_8(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("XXrevisionXX", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_9(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("REVISION", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_10(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "XXFAILXX", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_11(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "fail", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_12(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "XXno approved revision given (--expect-sha)XX")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_13(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "NO APPROVED REVISION GIVEN (--EXPECT-SHA)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_14(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head == expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_15(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result(None, "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_16(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", None, f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_17(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", None)
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_18(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_19(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_20(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", )
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_21(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("XXrevisionXX", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_22(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("REVISION", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_23(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "XXFAILXX", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_24(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "fail", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_25(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:13]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_26(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:13]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_27(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result(None, "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_28(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", None, "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_29(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", None)
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_30(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_31(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_32(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", )
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_33(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("XXrevisionXX", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_34(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("REVISION", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_35(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "XXFAILXX", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_36(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "fail", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_37(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "XXthe worktree is not cleanXX")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_38(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "THE WORKTREE IS NOT CLEAN")
    return Result("revision", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_39(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result(None, "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_40(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", None, f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_41(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", None)


def x_check_revision__mutmut_42(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_43(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_44(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", )


def x_check_revision__mutmut_45(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("XXrevisionXX", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_46(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("REVISION", "PASS", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_47(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "XXPASSXX", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_48(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "pass", f"{head[:12]}, clean worktree")


def x_check_revision__mutmut_49(head: str, expected: str, dirty: bool) -> Result:
    if not expected:
        return Result("revision", "FAIL", "no approved revision given (--expect-sha)")
    if head != expected:
        return Result("revision", "FAIL", f"HEAD {head[:12]} is not the approved {expected[:12]}")
    if dirty:
        return Result("revision", "FAIL", "the worktree is not clean")
    return Result("revision", "PASS", f"{head[:13]}, clean worktree")

mutants_x_check_revision__mutmut['_mutmut_orig'] = x_check_revision__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_1'] = x_check_revision__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_2'] = x_check_revision__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_3'] = x_check_revision__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_4'] = x_check_revision__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_5'] = x_check_revision__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_6'] = x_check_revision__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_7'] = x_check_revision__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_8'] = x_check_revision__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_9'] = x_check_revision__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_10'] = x_check_revision__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_11'] = x_check_revision__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_12'] = x_check_revision__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_13'] = x_check_revision__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_14'] = x_check_revision__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_15'] = x_check_revision__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_16'] = x_check_revision__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_17'] = x_check_revision__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_18'] = x_check_revision__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_19'] = x_check_revision__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_20'] = x_check_revision__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_21'] = x_check_revision__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_22'] = x_check_revision__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_23'] = x_check_revision__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_24'] = x_check_revision__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_25'] = x_check_revision__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_26'] = x_check_revision__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_27'] = x_check_revision__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_28'] = x_check_revision__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_29'] = x_check_revision__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_30'] = x_check_revision__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_31'] = x_check_revision__mutmut_31 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_32'] = x_check_revision__mutmut_32 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_33'] = x_check_revision__mutmut_33 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_34'] = x_check_revision__mutmut_34 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_35'] = x_check_revision__mutmut_35 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_36'] = x_check_revision__mutmut_36 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_37'] = x_check_revision__mutmut_37 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_38'] = x_check_revision__mutmut_38 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_39'] = x_check_revision__mutmut_39 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_40'] = x_check_revision__mutmut_40 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_41'] = x_check_revision__mutmut_41 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_42'] = x_check_revision__mutmut_42 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_43'] = x_check_revision__mutmut_43 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_44'] = x_check_revision__mutmut_44 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_45'] = x_check_revision__mutmut_45 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_46'] = x_check_revision__mutmut_46 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_47'] = x_check_revision__mutmut_47 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_48'] = x_check_revision__mutmut_48 # type: ignore # mutmut generated
mutants_x_check_revision__mutmut['x_check_revision__mutmut_49'] = x_check_revision__mutmut_49 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_bundle_allowlist__mutmut)
def check_bundle_allowlist(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_orig(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_1(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = None
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_2(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if (kinds is not None) and False else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_3(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if (kinds is not None) or True else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_4(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_5(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("XXrealXX", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_6(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("REAL", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_7(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("XXreal-hostedXX", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_8(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("REAL-HOSTED", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_9(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = None
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_10(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(None)
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_11(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(None, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_12(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, None))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_13(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_14(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_15(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members == expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_16(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result(None, "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_17(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", None, f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_18(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", None)
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_19(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_20(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_21(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", )
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_22(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("XXbundle allowlistXX", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_23(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("BUNDLE ALLOWLIST", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_24(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "XXFAILXX", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_25(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "fail", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_26(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(None)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_27(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result(None, "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_28(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", None, "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_29(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", None)


def x_check_bundle_allowlist__mutmut_30(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_31(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_32(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", )


def x_check_bundle_allowlist__mutmut_33(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("XXbundle allowlistXX", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_34(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("BUNDLE ALLOWLIST", "PASS", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_35(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "XXPASSXX", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_36(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "pass", "the real bundles allow their JSON reports only")


def x_check_bundle_allowlist__mutmut_37(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "XXthe real bundles allow their JSON reports onlyXX")


def x_check_bundle_allowlist__mutmut_38(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "the real bundles allow their json reports only")


def x_check_bundle_allowlist__mutmut_39(kinds: Mapping[str, Sequence[str]] | None = None) -> Result:
    found = kinds if kinds is not None else bundles.KINDS
    for kind, expected in (("real", REAL_REPORTS), ("real-hosted", HOSTED_REPORTS)):
        members = set(found.get(kind, ()))
        if members != expected:
            return Result("bundle allowlist", "FAIL", f"the {kind} bundle allows {sorted(members)}")
    return Result("bundle allowlist", "PASS", "THE REAL BUNDLES ALLOW THEIR JSON REPORTS ONLY")

mutants_x_check_bundle_allowlist__mutmut['_mutmut_orig'] = x_check_bundle_allowlist__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_1'] = x_check_bundle_allowlist__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_2'] = x_check_bundle_allowlist__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_3'] = x_check_bundle_allowlist__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_4'] = x_check_bundle_allowlist__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_5'] = x_check_bundle_allowlist__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_6'] = x_check_bundle_allowlist__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_7'] = x_check_bundle_allowlist__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_8'] = x_check_bundle_allowlist__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_9'] = x_check_bundle_allowlist__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_10'] = x_check_bundle_allowlist__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_11'] = x_check_bundle_allowlist__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_12'] = x_check_bundle_allowlist__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_13'] = x_check_bundle_allowlist__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_14'] = x_check_bundle_allowlist__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_15'] = x_check_bundle_allowlist__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_16'] = x_check_bundle_allowlist__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_17'] = x_check_bundle_allowlist__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_18'] = x_check_bundle_allowlist__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_19'] = x_check_bundle_allowlist__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_20'] = x_check_bundle_allowlist__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_21'] = x_check_bundle_allowlist__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_22'] = x_check_bundle_allowlist__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_23'] = x_check_bundle_allowlist__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_24'] = x_check_bundle_allowlist__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_25'] = x_check_bundle_allowlist__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_26'] = x_check_bundle_allowlist__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_27'] = x_check_bundle_allowlist__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_28'] = x_check_bundle_allowlist__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_29'] = x_check_bundle_allowlist__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_30'] = x_check_bundle_allowlist__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_31'] = x_check_bundle_allowlist__mutmut_31 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_32'] = x_check_bundle_allowlist__mutmut_32 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_33'] = x_check_bundle_allowlist__mutmut_33 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_34'] = x_check_bundle_allowlist__mutmut_34 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_35'] = x_check_bundle_allowlist__mutmut_35 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_36'] = x_check_bundle_allowlist__mutmut_36 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_37'] = x_check_bundle_allowlist__mutmut_37 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_38'] = x_check_bundle_allowlist__mutmut_38 # type: ignore # mutmut generated
mutants_x_check_bundle_allowlist__mutmut['x_check_bundle_allowlist__mutmut_39'] = x_check_bundle_allowlist__mutmut_39 # type: ignore # mutmut generated
mutants_x__job_text__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__job_text__mutmut)
def _job_text(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(name)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", workflow, re.M | re.S
    )
    return match.group(1) if match else None


def x__job_text__mutmut_orig(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(name)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", workflow, re.M | re.S
    )
    return match.group(1) if match else None


def x__job_text__mutmut_1(workflow: str, name: str) -> str | None:
    match = None
    return match.group(1) if match else None


def x__job_text__mutmut_2(workflow: str, name: str) -> str | None:
    match = re.search(
        None, workflow, re.M | re.S
    )
    return match.group(1) if match else None


def x__job_text__mutmut_3(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(name)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", None, re.M | re.S
    )
    return match.group(1) if match else None


def x__job_text__mutmut_4(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(name)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", workflow, None
    )
    return match.group(1) if match else None


def x__job_text__mutmut_5(workflow: str, name: str) -> str | None:
    match = re.search(
        workflow, re.M | re.S
    )
    return match.group(1) if match else None


def x__job_text__mutmut_6(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(name)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", re.M | re.S
    )
    return match.group(1) if match else None


def x__job_text__mutmut_7(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(name)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", workflow, )
    return match.group(1) if match else None


def x__job_text__mutmut_8(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(None)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", workflow, re.M | re.S
    )
    return match.group(1) if match else None


def x__job_text__mutmut_9(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(name)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", workflow, re.M & re.S
    )
    return match.group(1) if match else None


def x__job_text__mutmut_10(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(name)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", workflow, re.M | re.S
    )
    return match.group(1) if (match) and False else None


def x__job_text__mutmut_11(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(name)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", workflow, re.M | re.S
    )
    return match.group(1) if (match) or True else None


def x__job_text__mutmut_12(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(name)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", workflow, re.M | re.S
    )
    return match.group(None) if match else None


def x__job_text__mutmut_13(workflow: str, name: str) -> str | None:
    match = re.search(
        rf"^  {re.escape(name)}:\n(.*?)(?=^  [a-z][a-z-]*:\n|\Z)", workflow, re.M | re.S
    )
    return match.group(2) if match else None

mutants_x__job_text__mutmut['_mutmut_orig'] = x__job_text__mutmut_orig # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_1'] = x__job_text__mutmut_1 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_2'] = x__job_text__mutmut_2 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_3'] = x__job_text__mutmut_3 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_4'] = x__job_text__mutmut_4 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_5'] = x__job_text__mutmut_5 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_6'] = x__job_text__mutmut_6 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_7'] = x__job_text__mutmut_7 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_8'] = x__job_text__mutmut_8 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_9'] = x__job_text__mutmut_9 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_10'] = x__job_text__mutmut_10 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_11'] = x__job_text__mutmut_11 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_12'] = x__job_text__mutmut_12 # type: ignore # mutmut generated
mutants_x__job_text__mutmut['x__job_text__mutmut_13'] = x__job_text__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_upload_paths__mutmut)
def check_upload_paths(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_orig(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_1(workflow: str) -> Result:
    for name, expected in (
        ("XXrealXX", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_2(workflow: str) -> Result:
    for name, expected in (
        ("REAL", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_3(workflow: str) -> Result:
    for name, expected in (
        ("real", "XXevidence-real.tgzXX"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_4(workflow: str) -> Result:
    for name, expected in (
        ("real", "EVIDENCE-REAL.TGZ"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_5(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("XXreal-hostedXX", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_6(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("REAL-HOSTED", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_7(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "XXevidence-real-hosted.tgzXX"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_8(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "EVIDENCE-REAL-HOSTED.TGZ"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_9(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = None
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_10(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(None, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_11(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, None)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_12(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_13(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, )
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_14(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is not None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_15(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result(None, "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_16(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", None, f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_17(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", None)
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_18(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_19(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_20(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", )
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_21(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("XXupload pathsXX", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_22(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("UPLOAD PATHS", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_23(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "XXFAILXX", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_24(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "fail", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_25(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = None
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_26(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split(None, 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_27(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", None)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_28(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split(1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_29(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", )[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_30(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.rsplit("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_31(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("XXpath:XX", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_32(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("PATH:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_33(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 2)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_34(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[2].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_35(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith(None)
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_36(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("XXpath:XX")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_37(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("PATH:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_38(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths == [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_39(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result(None, "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_40(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", None, f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_41(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", None)
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_42(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_43(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_44(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", )
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_45(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("XXupload pathsXX", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_46(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("UPLOAD PATHS", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_47(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "XXFAILXX", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_48(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "fail", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_49(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result(None, "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_50(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", None, "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_51(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", None)


def x_check_upload_paths__mutmut_52(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_53(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_54(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", )


def x_check_upload_paths__mutmut_55(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("XXupload pathsXX", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_56(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("UPLOAD PATHS", "PASS", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_57(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "XXPASSXX", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_58(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "pass", "the real jobs upload their evidence bundle only")


def x_check_upload_paths__mutmut_59(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "XXthe real jobs upload their evidence bundle onlyXX")


def x_check_upload_paths__mutmut_60(workflow: str) -> Result:
    for name, expected in (
        ("real", "evidence-real.tgz"),
        ("real-hosted", "evidence-real-hosted.tgz"),
    ):
        job = _job_text(workflow, name)
        if job is None:
            return Result("upload paths", "FAIL", f"no {name} job in the workflow")
        paths = [
            line.split("path:", 1)[1].strip()
            for line in job.splitlines()
            if line.strip().startswith("path:")
        ]
        if paths != [expected]:
            return Result("upload paths", "FAIL", f"the {name} job uploads {paths}")
    return Result("upload paths", "PASS", "THE REAL JOBS UPLOAD THEIR EVIDENCE BUNDLE ONLY")

mutants_x_check_upload_paths__mutmut['_mutmut_orig'] = x_check_upload_paths__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_1'] = x_check_upload_paths__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_2'] = x_check_upload_paths__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_3'] = x_check_upload_paths__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_4'] = x_check_upload_paths__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_5'] = x_check_upload_paths__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_6'] = x_check_upload_paths__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_7'] = x_check_upload_paths__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_8'] = x_check_upload_paths__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_9'] = x_check_upload_paths__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_10'] = x_check_upload_paths__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_11'] = x_check_upload_paths__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_12'] = x_check_upload_paths__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_13'] = x_check_upload_paths__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_14'] = x_check_upload_paths__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_15'] = x_check_upload_paths__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_16'] = x_check_upload_paths__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_17'] = x_check_upload_paths__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_18'] = x_check_upload_paths__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_19'] = x_check_upload_paths__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_20'] = x_check_upload_paths__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_21'] = x_check_upload_paths__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_22'] = x_check_upload_paths__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_23'] = x_check_upload_paths__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_24'] = x_check_upload_paths__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_25'] = x_check_upload_paths__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_26'] = x_check_upload_paths__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_27'] = x_check_upload_paths__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_28'] = x_check_upload_paths__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_29'] = x_check_upload_paths__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_30'] = x_check_upload_paths__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_31'] = x_check_upload_paths__mutmut_31 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_32'] = x_check_upload_paths__mutmut_32 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_33'] = x_check_upload_paths__mutmut_33 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_34'] = x_check_upload_paths__mutmut_34 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_35'] = x_check_upload_paths__mutmut_35 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_36'] = x_check_upload_paths__mutmut_36 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_37'] = x_check_upload_paths__mutmut_37 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_38'] = x_check_upload_paths__mutmut_38 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_39'] = x_check_upload_paths__mutmut_39 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_40'] = x_check_upload_paths__mutmut_40 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_41'] = x_check_upload_paths__mutmut_41 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_42'] = x_check_upload_paths__mutmut_42 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_43'] = x_check_upload_paths__mutmut_43 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_44'] = x_check_upload_paths__mutmut_44 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_45'] = x_check_upload_paths__mutmut_45 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_46'] = x_check_upload_paths__mutmut_46 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_47'] = x_check_upload_paths__mutmut_47 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_48'] = x_check_upload_paths__mutmut_48 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_49'] = x_check_upload_paths__mutmut_49 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_50'] = x_check_upload_paths__mutmut_50 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_51'] = x_check_upload_paths__mutmut_51 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_52'] = x_check_upload_paths__mutmut_52 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_53'] = x_check_upload_paths__mutmut_53 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_54'] = x_check_upload_paths__mutmut_54 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_55'] = x_check_upload_paths__mutmut_55 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_56'] = x_check_upload_paths__mutmut_56 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_57'] = x_check_upload_paths__mutmut_57 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_58'] = x_check_upload_paths__mutmut_58 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_59'] = x_check_upload_paths__mutmut_59 # type: ignore # mutmut generated
mutants_x_check_upload_paths__mutmut['x_check_upload_paths__mutmut_60'] = x_check_upload_paths__mutmut_60 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_runner__mutmut)
def check_runner(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_orig(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_1(env: Mapping[str, str]) -> Result:
    kind = None
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_2(env: Mapping[str, str]) -> Result:
    kind = env.get(None)
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_3(env: Mapping[str, str]) -> Result:
    kind = env.get("XXRUNNER_ENVIRONMENTXX")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_4(env: Mapping[str, str]) -> Result:
    kind = env.get("runner_environment")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_5(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is not None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_6(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result(None, "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_7(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", None, "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_8(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", None)
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_9(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_10(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_11(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", )
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_12(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("XXrunnerXX", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_13(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("RUNNER", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_14(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "XXWARNXX", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_15(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "warn", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_16(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "XXnot inside a GitHub Actions job (advisory)XX")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_17(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a github actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_18(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "NOT INSIDE A GITHUB ACTIONS JOB (ADVISORY)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_19(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind == "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_20(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "XXself-hostedXX":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_21(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "SELF-HOSTED":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_22(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result(None, "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_23(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", None, f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_24(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", None)
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_25(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_26(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_27(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", )
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_28(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("XXrunnerXX", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_29(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("RUNNER", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_30(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "XXFAILXX", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_31(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "fail", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "self-hosted")


def x_check_runner__mutmut_32(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result(None, "PASS", "self-hosted")


def x_check_runner__mutmut_33(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", None, "self-hosted")


def x_check_runner__mutmut_34(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", None)


def x_check_runner__mutmut_35(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("PASS", "self-hosted")


def x_check_runner__mutmut_36(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "self-hosted")


def x_check_runner__mutmut_37(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", )


def x_check_runner__mutmut_38(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("XXrunnerXX", "PASS", "self-hosted")


def x_check_runner__mutmut_39(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("RUNNER", "PASS", "self-hosted")


def x_check_runner__mutmut_40(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "XXPASSXX", "self-hosted")


def x_check_runner__mutmut_41(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "pass", "self-hosted")


def x_check_runner__mutmut_42(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "XXself-hostedXX")


def x_check_runner__mutmut_43(env: Mapping[str, str]) -> Result:
    kind = env.get("RUNNER_ENVIRONMENT")
    if kind is None:
        return Result("runner", "WARN", "not inside a GitHub Actions job (advisory)")
    if kind != "self-hosted":
        return Result("runner", "FAIL", f"RUNNER_ENVIRONMENT is {kind}, not self-hosted")
    return Result("runner", "PASS", "SELF-HOSTED")

mutants_x_check_runner__mutmut['_mutmut_orig'] = x_check_runner__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_1'] = x_check_runner__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_2'] = x_check_runner__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_3'] = x_check_runner__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_4'] = x_check_runner__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_5'] = x_check_runner__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_6'] = x_check_runner__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_7'] = x_check_runner__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_8'] = x_check_runner__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_9'] = x_check_runner__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_10'] = x_check_runner__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_11'] = x_check_runner__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_12'] = x_check_runner__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_13'] = x_check_runner__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_14'] = x_check_runner__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_15'] = x_check_runner__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_16'] = x_check_runner__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_17'] = x_check_runner__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_18'] = x_check_runner__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_19'] = x_check_runner__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_20'] = x_check_runner__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_21'] = x_check_runner__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_22'] = x_check_runner__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_23'] = x_check_runner__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_24'] = x_check_runner__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_25'] = x_check_runner__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_26'] = x_check_runner__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_27'] = x_check_runner__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_28'] = x_check_runner__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_29'] = x_check_runner__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_30'] = x_check_runner__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_31'] = x_check_runner__mutmut_31 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_32'] = x_check_runner__mutmut_32 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_33'] = x_check_runner__mutmut_33 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_34'] = x_check_runner__mutmut_34 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_35'] = x_check_runner__mutmut_35 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_36'] = x_check_runner__mutmut_36 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_37'] = x_check_runner__mutmut_37 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_38'] = x_check_runner__mutmut_38 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_39'] = x_check_runner__mutmut_39 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_40'] = x_check_runner__mutmut_40 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_41'] = x_check_runner__mutmut_41 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_42'] = x_check_runner__mutmut_42 # type: ignore # mutmut generated
mutants_x_check_runner__mutmut['x_check_runner__mutmut_43'] = x_check_runner__mutmut_43 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_registration__mutmut)
def check_registration(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_orig(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_1(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = None
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_2(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is not None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_3(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(None, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_4(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, None, "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_5(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", None)
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_6(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result("WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_7(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_8(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", )
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_9(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "XXWARNXX", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_10(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "warn", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_11(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "XXthe runner list could not be read; registration is unknownXX")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_12(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "THE RUNNER LIST COULD NOT BE READ; REGISTRATION IS UNKNOWN")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_13(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get(None, []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_14(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", None):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_15(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get([]):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_16(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", ):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_17(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("XXrunnersXX", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_18(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("RUNNERS", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_19(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = None
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_20(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["XXnameXX"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_21(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["NAME"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_22(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get(None, [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_23(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", None)}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_24(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get([])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_25(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", )}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_26(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("XXlabelsXX", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_27(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("LABELS", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_28(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" or {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_29(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get(None) == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_30(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("XXstatusXX") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_31(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("STATUS") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_32(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") != "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_33(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "XXonlineXX" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_34(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "ONLINE" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_35(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"XXself-hostedXX", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_36(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"SELF-HOSTED", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_37(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} < labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_38(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(None, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_39(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, None, "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_40(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", None)
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_41(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result("PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_42(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_43(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", )
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_44(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "XXPASSXX", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_45(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "pass", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_46(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "XXan online self-hosted runner carries the labelXX")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_47(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "AN ONLINE SELF-HOSTED RUNNER CARRIES THE LABEL")
    return Result(name, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_48(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(None, "FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_49(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, None, "no online self-hosted runner carries the label")


def x_check_registration__mutmut_50(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", None)


def x_check_registration__mutmut_51(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result("FAIL", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_52(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "no online self-hosted runner carries the label")


def x_check_registration__mutmut_53(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", )


def x_check_registration__mutmut_54(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "XXFAILXX", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_55(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "fail", "no online self-hosted runner carries the label")


def x_check_registration__mutmut_56(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "XXno online self-hosted runner carries the labelXX")


def x_check_registration__mutmut_57(label: str, listing: Mapping[str, Any] | None) -> Result:
    name = f"registration {label}"
    if listing is None:
        return Result(name, "WARN", "the runner list could not be read; registration is unknown")
    for runner in listing.get("runners", []):
        labels = {entry["name"] for entry in runner.get("labels", [])}
        if runner.get("status") == "online" and {"self-hosted", label} <= labels:
            return Result(name, "PASS", "an online self-hosted runner carries the label")
    return Result(name, "FAIL", "NO ONLINE SELF-HOSTED RUNNER CARRIES THE LABEL")

mutants_x_check_registration__mutmut['_mutmut_orig'] = x_check_registration__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_1'] = x_check_registration__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_2'] = x_check_registration__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_3'] = x_check_registration__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_4'] = x_check_registration__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_5'] = x_check_registration__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_6'] = x_check_registration__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_7'] = x_check_registration__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_8'] = x_check_registration__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_9'] = x_check_registration__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_10'] = x_check_registration__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_11'] = x_check_registration__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_12'] = x_check_registration__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_13'] = x_check_registration__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_14'] = x_check_registration__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_15'] = x_check_registration__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_16'] = x_check_registration__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_17'] = x_check_registration__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_18'] = x_check_registration__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_19'] = x_check_registration__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_20'] = x_check_registration__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_21'] = x_check_registration__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_22'] = x_check_registration__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_23'] = x_check_registration__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_24'] = x_check_registration__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_25'] = x_check_registration__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_26'] = x_check_registration__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_27'] = x_check_registration__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_28'] = x_check_registration__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_29'] = x_check_registration__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_30'] = x_check_registration__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_31'] = x_check_registration__mutmut_31 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_32'] = x_check_registration__mutmut_32 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_33'] = x_check_registration__mutmut_33 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_34'] = x_check_registration__mutmut_34 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_35'] = x_check_registration__mutmut_35 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_36'] = x_check_registration__mutmut_36 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_37'] = x_check_registration__mutmut_37 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_38'] = x_check_registration__mutmut_38 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_39'] = x_check_registration__mutmut_39 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_40'] = x_check_registration__mutmut_40 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_41'] = x_check_registration__mutmut_41 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_42'] = x_check_registration__mutmut_42 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_43'] = x_check_registration__mutmut_43 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_44'] = x_check_registration__mutmut_44 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_45'] = x_check_registration__mutmut_45 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_46'] = x_check_registration__mutmut_46 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_47'] = x_check_registration__mutmut_47 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_48'] = x_check_registration__mutmut_48 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_49'] = x_check_registration__mutmut_49 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_50'] = x_check_registration__mutmut_50 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_51'] = x_check_registration__mutmut_51 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_52'] = x_check_registration__mutmut_52 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_53'] = x_check_registration__mutmut_53 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_54'] = x_check_registration__mutmut_54 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_55'] = x_check_registration__mutmut_55 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_56'] = x_check_registration__mutmut_56 # type: ignore # mutmut generated
mutants_x_check_registration__mutmut['x_check_registration__mutmut_57'] = x_check_registration__mutmut_57 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_fetch_registrations__mutmut)
def fetch_registrations(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_orig(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_1(repo: str) -> dict[str, Any] | None:
    done = None
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_2(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        None, capture_output=True, text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_3(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=None, text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_4(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=None, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_5(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=True, check=None
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_6(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        capture_output=True, text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_7(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_8(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_9(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=True, )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_10(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["XXghXX", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_11(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["GH", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_12(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "XXapiXX", f"repos/{repo}/actions/runners"], capture_output=True, text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_13(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "API", f"repos/{repo}/actions/runners"], capture_output=True, text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_14(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=False, text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_15(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=False, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_16(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=True, check=True
    )
    if done.returncode != 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_17(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=True, check=False
    )
    if done.returncode == 0:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_18(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=True, check=False
    )
    if done.returncode != 1:
        return None
    return json.loads(done.stdout)


def x_fetch_registrations__mutmut_19(repo: str) -> dict[str, Any] | None:
    done = subprocess.run(
        ["gh", "api", f"repos/{repo}/actions/runners"], capture_output=True, text=True, check=False
    )
    if done.returncode != 0:
        return None
    return json.loads(None)

mutants_x_fetch_registrations__mutmut['_mutmut_orig'] = x_fetch_registrations__mutmut_orig # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_1'] = x_fetch_registrations__mutmut_1 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_2'] = x_fetch_registrations__mutmut_2 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_3'] = x_fetch_registrations__mutmut_3 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_4'] = x_fetch_registrations__mutmut_4 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_5'] = x_fetch_registrations__mutmut_5 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_6'] = x_fetch_registrations__mutmut_6 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_7'] = x_fetch_registrations__mutmut_7 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_8'] = x_fetch_registrations__mutmut_8 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_9'] = x_fetch_registrations__mutmut_9 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_10'] = x_fetch_registrations__mutmut_10 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_11'] = x_fetch_registrations__mutmut_11 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_12'] = x_fetch_registrations__mutmut_12 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_13'] = x_fetch_registrations__mutmut_13 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_14'] = x_fetch_registrations__mutmut_14 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_15'] = x_fetch_registrations__mutmut_15 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_16'] = x_fetch_registrations__mutmut_16 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_17'] = x_fetch_registrations__mutmut_17 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_18'] = x_fetch_registrations__mutmut_18 # type: ignore # mutmut generated
mutants_x_fetch_registrations__mutmut['x_fetch_registrations__mutmut_19'] = x_fetch_registrations__mutmut_19 # type: ignore # mutmut generated
mutants_x__installed__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__installed__mutmut)
def _installed(names: Sequence[str]) -> dict[str, str | None]:
    found: dict[str, str | None] = {}
    for name in names:
        try:
            found[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            found[name] = None
    return found


def x__installed__mutmut_orig(names: Sequence[str]) -> dict[str, str | None]:
    found: dict[str, str | None] = {}
    for name in names:
        try:
            found[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            found[name] = None
    return found


def x__installed__mutmut_1(names: Sequence[str]) -> dict[str, str | None]:
    found: dict[str, str | None] = None
    for name in names:
        try:
            found[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            found[name] = None
    return found


def x__installed__mutmut_2(names: Sequence[str]) -> dict[str, str | None]:
    found: dict[str, str | None] = {}
    for name in names:
        try:
            found[name] = None
        except metadata.PackageNotFoundError:
            found[name] = None
    return found


def x__installed__mutmut_3(names: Sequence[str]) -> dict[str, str | None]:
    found: dict[str, str | None] = {}
    for name in names:
        try:
            found[name] = metadata.version(None)
        except metadata.PackageNotFoundError:
            found[name] = None
    return found


def x__installed__mutmut_4(names: Sequence[str]) -> dict[str, str | None]:
    found: dict[str, str | None] = {}
    for name in names:
        try:
            found[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            found[name] = ""
    return found

mutants_x__installed__mutmut['_mutmut_orig'] = x__installed__mutmut_orig # type: ignore # mutmut generated
mutants_x__installed__mutmut['x__installed__mutmut_1'] = x__installed__mutmut_1 # type: ignore # mutmut generated
mutants_x__installed__mutmut['x__installed__mutmut_2'] = x__installed__mutmut_2 # type: ignore # mutmut generated
mutants_x__installed__mutmut['x__installed__mutmut_3'] = x__installed__mutmut_3 # type: ignore # mutmut generated
mutants_x__installed__mutmut['x__installed__mutmut_4'] = x__installed__mutmut_4 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_parse_args__mutmut)
def parse_args(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_orig(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_1(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = None
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_2(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_3(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_4(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default=None, help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_5(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help=None)
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_6(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_7(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_8(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", )
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_9(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--expect-shaXX", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_10(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--EXPECT-SHA", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_11(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="XXXX", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_12(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="XXcommit the operator approvedXX")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_13(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="COMMIT THE OPERATOR APPROVED")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_14(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument(None, metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_15(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar=None, help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_16(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help=None)
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_17(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument(metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_18(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_19(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", )
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_20(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("XX--check-registrationXX", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_21(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--CHECK-REGISTRATION", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_22(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="XXLABELXX", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_23(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="label", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_24(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="XXread the runner listXX")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_25(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="READ THE RUNNER LIST")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_26(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        None,
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_27(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action=None,
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_28(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help=None,
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_29(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_30(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_31(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_32(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "XX--install-onlyXX",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_33(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--INSTALL-ONLY",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_34(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="XXstore_trueXX",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_35(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="STORE_TRUE",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_36(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="XXinstall check on a machine without datasets (dataset, runner checks skipped)XX",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_37(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="INSTALL CHECK ON A MACHINE WITHOUT DATASETS (DATASET, RUNNER CHECKS SKIPPED)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_38(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        None,
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_39(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action=None,
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_40(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help=None,
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_41(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_42(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_43(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_44(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "XX--hosted-downloadXX",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_45(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--HOSTED-DOWNLOAD",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_46(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="XXstore_trueXX",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_47(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="STORE_TRUE",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_48(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="XXthe datasets were just downloaded on a GitHub-hosted runner (no runner check)XX",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_49(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a github-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_50(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="THE DATASETS WERE JUST DOWNLOADED ON A GITHUB-HOSTED RUNNER (NO RUNNER CHECK)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_51(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument(None, default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_52(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=None)
    return parser.parse_args(argv)


def x_parse_args__mutmut_53(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument(default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_54(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", )
    return parser.parse_args(argv)


def x_parse_args__mutmut_55(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("XX--repoXX", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_56(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--REPO", default=REPO)
    return parser.parse_args(argv)


def x_parse_args__mutmut_57(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expect-sha", default="", help="commit the operator approved")
    parser.add_argument("--check-registration", metavar="LABEL", help="read the runner list")
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="install check on a machine without datasets (dataset, runner checks skipped)",
    )
    parser.add_argument(
        "--hosted-download",
        action="store_true",
        help="the datasets were just downloaded on a GitHub-hosted runner (no runner check)",
    )
    parser.add_argument("--repo", default=REPO)
    return parser.parse_args(None)

mutants_x_parse_args__mutmut['_mutmut_orig'] = x_parse_args__mutmut_orig # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_1'] = x_parse_args__mutmut_1 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_2'] = x_parse_args__mutmut_2 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_3'] = x_parse_args__mutmut_3 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_4'] = x_parse_args__mutmut_4 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_5'] = x_parse_args__mutmut_5 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_6'] = x_parse_args__mutmut_6 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_7'] = x_parse_args__mutmut_7 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_8'] = x_parse_args__mutmut_8 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_9'] = x_parse_args__mutmut_9 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_10'] = x_parse_args__mutmut_10 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_11'] = x_parse_args__mutmut_11 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_12'] = x_parse_args__mutmut_12 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_13'] = x_parse_args__mutmut_13 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_14'] = x_parse_args__mutmut_14 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_15'] = x_parse_args__mutmut_15 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_16'] = x_parse_args__mutmut_16 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_17'] = x_parse_args__mutmut_17 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_18'] = x_parse_args__mutmut_18 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_19'] = x_parse_args__mutmut_19 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_20'] = x_parse_args__mutmut_20 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_21'] = x_parse_args__mutmut_21 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_22'] = x_parse_args__mutmut_22 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_23'] = x_parse_args__mutmut_23 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_24'] = x_parse_args__mutmut_24 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_25'] = x_parse_args__mutmut_25 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_26'] = x_parse_args__mutmut_26 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_27'] = x_parse_args__mutmut_27 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_28'] = x_parse_args__mutmut_28 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_29'] = x_parse_args__mutmut_29 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_30'] = x_parse_args__mutmut_30 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_31'] = x_parse_args__mutmut_31 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_32'] = x_parse_args__mutmut_32 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_33'] = x_parse_args__mutmut_33 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_34'] = x_parse_args__mutmut_34 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_35'] = x_parse_args__mutmut_35 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_36'] = x_parse_args__mutmut_36 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_37'] = x_parse_args__mutmut_37 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_38'] = x_parse_args__mutmut_38 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_39'] = x_parse_args__mutmut_39 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_40'] = x_parse_args__mutmut_40 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_41'] = x_parse_args__mutmut_41 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_42'] = x_parse_args__mutmut_42 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_43'] = x_parse_args__mutmut_43 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_44'] = x_parse_args__mutmut_44 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_45'] = x_parse_args__mutmut_45 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_46'] = x_parse_args__mutmut_46 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_47'] = x_parse_args__mutmut_47 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_48'] = x_parse_args__mutmut_48 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_49'] = x_parse_args__mutmut_49 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_50'] = x_parse_args__mutmut_50 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_51'] = x_parse_args__mutmut_51 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_52'] = x_parse_args__mutmut_52 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_53'] = x_parse_args__mutmut_53 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_54'] = x_parse_args__mutmut_54 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_55'] = x_parse_args__mutmut_55 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_56'] = x_parse_args__mutmut_56 # type: ignore # mutmut generated
mutants_x_parse_args__mutmut['x_parse_args__mutmut_57'] = x_parse_args__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run_checks__mutmut)
def run_checks(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_orig(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_1(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = None
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_2(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(None)["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_3(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["XXdatasetsXX"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_4(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["DATASETS"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_5(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = None
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_6(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = None
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_7(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = None
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_8(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(None)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_9(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = None
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_10(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = None
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_11(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(None, PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_12(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), None),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_13(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_14(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), ),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_15(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(None), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_16(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:4]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_17(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(None, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_18(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, None),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_19(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_20(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, ),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_21(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(None, locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_22(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), None),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_23(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_24(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), ),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_25(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(None), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_26(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(None)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_27(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(None, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_28(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, None, pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_29(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), None),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_30(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(_installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_31(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_32(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), ),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_33(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(None), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_34(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(None)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_35(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(None)
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_36(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result(None, "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_37(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", None, "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_38(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", None))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_39(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_40(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_41(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", ))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_42(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("XXdatasetsXX", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_43(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("DATASETS", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_44(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "XXSKIPXX", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_45(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "skip", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_46(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "XX--install-only: no dataset is expected hereXX"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_47(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--INSTALL-ONLY: NO DATASET IS EXPECTED HERE"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_48(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = None
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_49(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name not in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_50(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results = check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_51(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results -= check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_52(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(None, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_53(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, None)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_54(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_55(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, )
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_56(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(None)
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_57(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result(None, "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_58(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", None, "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_59(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", None))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_60(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_61(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_62(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", ))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_63(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("XXresourcesXX", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_64(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("RESOURCES", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_65(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "XXSKIPXX", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_66(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "skip", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_67(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "XX--install-only: sized for the full datasetsXX"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_68(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--INSTALL-ONLY: SIZED FOR THE FULL DATASETS"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_69(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(None)
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_70(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(None))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_71(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(None)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_72(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results = [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_73(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results -= [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_74(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(None, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_75(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, None, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_76(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, None),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_77(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_78(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_79(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, ),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_80(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(None),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_81(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only and args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_82(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(None)
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_83(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result(None, "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_84(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", None, "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_85(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", None))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_86(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_87(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_88(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", ))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_89(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("XXrunnerXX", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_90(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("RUNNER", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_91(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "XXSKIPXX", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_92(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "skip", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_93(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "XXhosted run: no private runner is involvedXX"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_94(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "HOSTED RUN: NO PRIVATE RUNNER IS INVOLVED"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_95(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(None)
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_96(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(None))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_97(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(None)
    return results


def x_run_checks__mutmut_98(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(None, fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_99(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, None))
    return results


def x_run_checks__mutmut_100(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(fetch_registrations(args.repo)))
    return results


def x_run_checks__mutmut_101(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, ))
    return results


def x_run_checks__mutmut_102(args: argparse.Namespace) -> list[Result]:
    from etl_benchmark.datasets import DATASETS

    reference = json.loads(MANIFEST.read_text())["datasets"]
    locked = release.locked_versions()
    pins = linux_lock_pins()
    head, dirty = git_state(ROOT)
    system = platform.system()
    results = [
        check_python(tuple(sys.version_info[:3]), PYTHON_MINOR),
        check_platform(system, platform.machine()),
        check_dependencies(_installed(list(locked)), locked),
        check_lock_for(system, _installed(list(pins)), pins),
    ]
    if args.install_only:
        results.append(Result("datasets", "SKIP", "--install-only: no dataset is expected here"))
    else:
        paths = {name: spec.csv for name, spec in DATASETS.items() if name in reference}
        results += check_datasets(paths, reference)
    if args.install_only:
        results.append(Result("resources", "SKIP", "--install-only: sized for the full datasets"))
    else:
        results.append(check_resources(measure_resources(ROOT)))
    results += [
        check_revision(head, args.expect_sha, dirty),
        check_bundle_allowlist(),
        check_upload_paths(WORKFLOW.read_text()),
    ]
    if args.install_only or args.hosted_download:
        results.append(Result("runner", "SKIP", "hosted run: no private runner is involved"))
    else:
        results.append(check_runner(os.environ))
    if args.check_registration:
        results.append(check_registration(args.check_registration, fetch_registrations(None)))
    return results

mutants_x_run_checks__mutmut['_mutmut_orig'] = x_run_checks__mutmut_orig # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_1'] = x_run_checks__mutmut_1 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_2'] = x_run_checks__mutmut_2 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_3'] = x_run_checks__mutmut_3 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_4'] = x_run_checks__mutmut_4 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_5'] = x_run_checks__mutmut_5 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_6'] = x_run_checks__mutmut_6 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_7'] = x_run_checks__mutmut_7 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_8'] = x_run_checks__mutmut_8 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_9'] = x_run_checks__mutmut_9 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_10'] = x_run_checks__mutmut_10 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_11'] = x_run_checks__mutmut_11 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_12'] = x_run_checks__mutmut_12 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_13'] = x_run_checks__mutmut_13 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_14'] = x_run_checks__mutmut_14 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_15'] = x_run_checks__mutmut_15 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_16'] = x_run_checks__mutmut_16 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_17'] = x_run_checks__mutmut_17 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_18'] = x_run_checks__mutmut_18 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_19'] = x_run_checks__mutmut_19 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_20'] = x_run_checks__mutmut_20 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_21'] = x_run_checks__mutmut_21 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_22'] = x_run_checks__mutmut_22 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_23'] = x_run_checks__mutmut_23 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_24'] = x_run_checks__mutmut_24 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_25'] = x_run_checks__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_26'] = x_run_checks__mutmut_26 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_27'] = x_run_checks__mutmut_27 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_28'] = x_run_checks__mutmut_28 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_29'] = x_run_checks__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_30'] = x_run_checks__mutmut_30 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_31'] = x_run_checks__mutmut_31 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_32'] = x_run_checks__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_33'] = x_run_checks__mutmut_33 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_34'] = x_run_checks__mutmut_34 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_35'] = x_run_checks__mutmut_35 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_36'] = x_run_checks__mutmut_36 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_37'] = x_run_checks__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_38'] = x_run_checks__mutmut_38 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_39'] = x_run_checks__mutmut_39 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_40'] = x_run_checks__mutmut_40 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_41'] = x_run_checks__mutmut_41 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_42'] = x_run_checks__mutmut_42 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_43'] = x_run_checks__mutmut_43 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_44'] = x_run_checks__mutmut_44 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_45'] = x_run_checks__mutmut_45 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_46'] = x_run_checks__mutmut_46 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_47'] = x_run_checks__mutmut_47 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_48'] = x_run_checks__mutmut_48 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_49'] = x_run_checks__mutmut_49 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_50'] = x_run_checks__mutmut_50 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_51'] = x_run_checks__mutmut_51 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_52'] = x_run_checks__mutmut_52 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_53'] = x_run_checks__mutmut_53 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_54'] = x_run_checks__mutmut_54 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_55'] = x_run_checks__mutmut_55 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_56'] = x_run_checks__mutmut_56 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_57'] = x_run_checks__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_58'] = x_run_checks__mutmut_58 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_59'] = x_run_checks__mutmut_59 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_60'] = x_run_checks__mutmut_60 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_61'] = x_run_checks__mutmut_61 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_62'] = x_run_checks__mutmut_62 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_63'] = x_run_checks__mutmut_63 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_64'] = x_run_checks__mutmut_64 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_65'] = x_run_checks__mutmut_65 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_66'] = x_run_checks__mutmut_66 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_67'] = x_run_checks__mutmut_67 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_68'] = x_run_checks__mutmut_68 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_69'] = x_run_checks__mutmut_69 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_70'] = x_run_checks__mutmut_70 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_71'] = x_run_checks__mutmut_71 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_72'] = x_run_checks__mutmut_72 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_73'] = x_run_checks__mutmut_73 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_74'] = x_run_checks__mutmut_74 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_75'] = x_run_checks__mutmut_75 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_76'] = x_run_checks__mutmut_76 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_77'] = x_run_checks__mutmut_77 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_78'] = x_run_checks__mutmut_78 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_79'] = x_run_checks__mutmut_79 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_80'] = x_run_checks__mutmut_80 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_81'] = x_run_checks__mutmut_81 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_82'] = x_run_checks__mutmut_82 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_83'] = x_run_checks__mutmut_83 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_84'] = x_run_checks__mutmut_84 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_85'] = x_run_checks__mutmut_85 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_86'] = x_run_checks__mutmut_86 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_87'] = x_run_checks__mutmut_87 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_88'] = x_run_checks__mutmut_88 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_89'] = x_run_checks__mutmut_89 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_90'] = x_run_checks__mutmut_90 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_91'] = x_run_checks__mutmut_91 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_92'] = x_run_checks__mutmut_92 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_93'] = x_run_checks__mutmut_93 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_94'] = x_run_checks__mutmut_94 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_95'] = x_run_checks__mutmut_95 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_96'] = x_run_checks__mutmut_96 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_97'] = x_run_checks__mutmut_97 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_98'] = x_run_checks__mutmut_98 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_99'] = x_run_checks__mutmut_99 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_100'] = x_run_checks__mutmut_100 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_101'] = x_run_checks__mutmut_101 # type: ignore # mutmut generated
mutants_x_run_checks__mutmut['x_run_checks__mutmut_102'] = x_run_checks__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_orig(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_1(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = None
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_2(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(None)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_3(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = None
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_4(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(None)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_5(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks and run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_6(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(None)
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_7(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = None
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_8(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status != "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_9(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "XXFAILXX"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_10(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "fail"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_11(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = None
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_12(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status != "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_13(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "XXWARNXX"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_14(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "warn"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_15(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(None)
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_16(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 2
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_17(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(None)
    return 0


def x_main__mutmut_18(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if (len(warned) == 1) and False else 's'})")
    return 0


def x_main__mutmut_19(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if (len(warned) == 1) or True else 's'})")
    return 0


def x_main__mutmut_20(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'XXXX' if len(warned) == 1 else 's'})")
    return 0


def x_main__mutmut_21(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) != 1 else 's'})")
    return 0


def x_main__mutmut_22(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 2 else 's'})")
    return 0


def x_main__mutmut_23(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 'XXsXX'})")
    return 0


def x_main__mutmut_24(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 'S'})")
    return 0


def x_main__mutmut_25(
    argv: Sequence[str] | None = None, checks: Callable[..., list[Result]] | None = None
) -> int:
    args = parse_args(argv)
    results = (checks or run_checks)(args)
    for result in results:
        print(f"{result.status} {result.name}: {result.detail}")
    failed = [r for r in results if r.status == "FAIL"]
    warned = [r for r in results if r.status == "WARN"]
    if failed:
        print(f"preflight: FAIL ({len(failed)} failed)")
        return 1
    print(f"preflight: PASS ({len(warned)} warning{'' if len(warned) == 1 else 's'})")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
