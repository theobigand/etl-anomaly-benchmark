"""Independent inventory of the code the mutation campaign must cover.

``pyproject.toml`` decides what mutmut mutates. A configuration that quietly
drops a module can keep a high score, so the eligible files are discovered here
from the tree (``mutation_scope.json`` names the roots and every justified
exclusion) and compared with the configured patterns and, in the DEEP
evidence, with the files that really received mutants.
"""

from __future__ import annotations

import fnmatch
import json
import os
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "verification" / "mutation_scope.json"
VERSION = 2


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_load__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_load__mutmut)
def load(path: Path = CONFIG) -> dict:
    config = json.loads(path.read_text())
    if config.get("version") != VERSION:
        raise ValueError(f"mutation scope version must be {VERSION}")
    return config


def x_load__mutmut_orig(path: Path = CONFIG) -> dict:
    config = json.loads(path.read_text())
    if config.get("version") != VERSION:
        raise ValueError(f"mutation scope version must be {VERSION}")
    return config


def x_load__mutmut_1(path: Path = CONFIG) -> dict:
    config = None
    if config.get("version") != VERSION:
        raise ValueError(f"mutation scope version must be {VERSION}")
    return config


def x_load__mutmut_2(path: Path = CONFIG) -> dict:
    config = json.loads(None)
    if config.get("version") != VERSION:
        raise ValueError(f"mutation scope version must be {VERSION}")
    return config


def x_load__mutmut_3(path: Path = CONFIG) -> dict:
    config = json.loads(path.read_text())
    if config.get(None) != VERSION:
        raise ValueError(f"mutation scope version must be {VERSION}")
    return config


def x_load__mutmut_4(path: Path = CONFIG) -> dict:
    config = json.loads(path.read_text())
    if config.get("XXversionXX") != VERSION:
        raise ValueError(f"mutation scope version must be {VERSION}")
    return config


def x_load__mutmut_5(path: Path = CONFIG) -> dict:
    config = json.loads(path.read_text())
    if config.get("VERSION") != VERSION:
        raise ValueError(f"mutation scope version must be {VERSION}")
    return config


def x_load__mutmut_6(path: Path = CONFIG) -> dict:
    config = json.loads(path.read_text())
    if config.get("version") == VERSION:
        raise ValueError(f"mutation scope version must be {VERSION}")
    return config


def x_load__mutmut_7(path: Path = CONFIG) -> dict:
    config = json.loads(path.read_text())
    if config.get("version") != VERSION:
        raise ValueError(None)
    return config

mutants_x_load__mutmut['_mutmut_orig'] = x_load__mutmut_orig # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_1'] = x_load__mutmut_1 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_2'] = x_load__mutmut_2 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_3'] = x_load__mutmut_3 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_4'] = x_load__mutmut_4 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_5'] = x_load__mutmut_5 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_6'] = x_load__mutmut_6 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_7'] = x_load__mutmut_7 # type: ignore # mutmut generated
mutants_x_configured_patterns__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_configured_patterns__mutmut)
def configured_patterns(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"]["only_mutate"])


def x_configured_patterns__mutmut_orig(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"]["only_mutate"])


def x_configured_patterns__mutmut_1(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(None)


def x_configured_patterns__mutmut_2(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(None)["tool"]["mutmut"]["only_mutate"])


def x_configured_patterns__mutmut_3(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["XXtoolXX"]["mutmut"]["only_mutate"])


def x_configured_patterns__mutmut_4(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["TOOL"]["mutmut"]["only_mutate"])


def x_configured_patterns__mutmut_5(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["XXmutmutXX"]["only_mutate"])


def x_configured_patterns__mutmut_6(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["MUTMUT"]["only_mutate"])


def x_configured_patterns__mutmut_7(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"]["XXonly_mutateXX"])


def x_configured_patterns__mutmut_8(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"]["ONLY_MUTATE"])

mutants_x_configured_patterns__mutmut['_mutmut_orig'] = x_configured_patterns__mutmut_orig # type: ignore # mutmut generated
mutants_x_configured_patterns__mutmut['x_configured_patterns__mutmut_1'] = x_configured_patterns__mutmut_1 # type: ignore # mutmut generated
mutants_x_configured_patterns__mutmut['x_configured_patterns__mutmut_2'] = x_configured_patterns__mutmut_2 # type: ignore # mutmut generated
mutants_x_configured_patterns__mutmut['x_configured_patterns__mutmut_3'] = x_configured_patterns__mutmut_3 # type: ignore # mutmut generated
mutants_x_configured_patterns__mutmut['x_configured_patterns__mutmut_4'] = x_configured_patterns__mutmut_4 # type: ignore # mutmut generated
mutants_x_configured_patterns__mutmut['x_configured_patterns__mutmut_5'] = x_configured_patterns__mutmut_5 # type: ignore # mutmut generated
mutants_x_configured_patterns__mutmut['x_configured_patterns__mutmut_6'] = x_configured_patterns__mutmut_6 # type: ignore # mutmut generated
mutants_x_configured_patterns__mutmut['x_configured_patterns__mutmut_7'] = x_configured_patterns__mutmut_7 # type: ignore # mutmut generated
mutants_x_configured_patterns__mutmut['x_configured_patterns__mutmut_8'] = x_configured_patterns__mutmut_8 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_configured_exclusions__mutmut)
def configured_exclusions(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"].get("do_not_mutate", []))


def x_configured_exclusions__mutmut_orig(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"].get("do_not_mutate", []))


def x_configured_exclusions__mutmut_1(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(None)


def x_configured_exclusions__mutmut_2(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"].get(None, []))


def x_configured_exclusions__mutmut_3(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"].get("do_not_mutate", None))


def x_configured_exclusions__mutmut_4(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"].get([]))


def x_configured_exclusions__mutmut_5(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"].get("do_not_mutate", ))


def x_configured_exclusions__mutmut_6(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(None)["tool"]["mutmut"].get("do_not_mutate", []))


def x_configured_exclusions__mutmut_7(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["XXtoolXX"]["mutmut"].get("do_not_mutate", []))


def x_configured_exclusions__mutmut_8(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["TOOL"]["mutmut"].get("do_not_mutate", []))


def x_configured_exclusions__mutmut_9(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["XXmutmutXX"].get("do_not_mutate", []))


def x_configured_exclusions__mutmut_10(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["MUTMUT"].get("do_not_mutate", []))


def x_configured_exclusions__mutmut_11(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"].get("XXdo_not_mutateXX", []))


def x_configured_exclusions__mutmut_12(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    return list(tomllib.loads(pyproject.read_text())["tool"]["mutmut"].get("DO_NOT_MUTATE", []))

mutants_x_configured_exclusions__mutmut['_mutmut_orig'] = x_configured_exclusions__mutmut_orig # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_1'] = x_configured_exclusions__mutmut_1 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_2'] = x_configured_exclusions__mutmut_2 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_3'] = x_configured_exclusions__mutmut_3 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_4'] = x_configured_exclusions__mutmut_4 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_5'] = x_configured_exclusions__mutmut_5 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_6'] = x_configured_exclusions__mutmut_6 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_7'] = x_configured_exclusions__mutmut_7 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_8'] = x_configured_exclusions__mutmut_8 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_9'] = x_configured_exclusions__mutmut_9 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_10'] = x_configured_exclusions__mutmut_10 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_11'] = x_configured_exclusions__mutmut_11 # type: ignore # mutmut generated
mutants_x_configured_exclusions__mutmut['x_configured_exclusions__mutmut_12'] = x_configured_exclusions__mutmut_12 # type: ignore # mutmut generated
mutants_x__python_files__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__python_files__mutmut)
def _python_files(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.py")
        if "__pycache__" not in path.parts and "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_orig(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.py")
        if "__pycache__" not in path.parts and "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_1(root: Path, base: str) -> list[str]:
    return sorted(
        None
    )


def x__python_files__mutmut_2(root: Path, base: str) -> list[str]:
    return sorted(
        str(None)
        for path in (root / base).rglob("*.py")
        if "__pycache__" not in path.parts and "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_3(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(None))
        for path in (root / base).rglob("*.py")
        if "__pycache__" not in path.parts and "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_4(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob(None)
        if "__pycache__" not in path.parts and "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_5(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root * base).rglob("*.py")
        if "__pycache__" not in path.parts and "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_6(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("XX*.pyXX")
        if "__pycache__" not in path.parts and "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_7(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.PY")
        if "__pycache__" not in path.parts and "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_8(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.py")
        if "__pycache__" not in path.parts or "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_9(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.py")
        if "XX__pycache__XX" not in path.parts and "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_10(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.py")
        if "__PYCACHE__" not in path.parts and "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_11(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.py")
        if "__pycache__" in path.parts and "tests" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_12(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.py")
        if "__pycache__" not in path.parts and "XXtestsXX" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_13(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.py")
        if "__pycache__" not in path.parts and "TESTS" not in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_14(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.py")
        if "__pycache__" not in path.parts and "tests" in path.relative_to(root / base).parts
    )


def x__python_files__mutmut_15(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.py")
        if "__pycache__" not in path.parts and "tests" not in path.relative_to(None).parts
    )


def x__python_files__mutmut_16(root: Path, base: str) -> list[str]:
    return sorted(
        str(path.relative_to(root))
        for path in (root / base).rglob("*.py")
        if "__pycache__" not in path.parts and "tests" not in path.relative_to(root * base).parts
    )

mutants_x__python_files__mutmut['_mutmut_orig'] = x__python_files__mutmut_orig # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_1'] = x__python_files__mutmut_1 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_2'] = x__python_files__mutmut_2 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_3'] = x__python_files__mutmut_3 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_4'] = x__python_files__mutmut_4 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_5'] = x__python_files__mutmut_5 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_6'] = x__python_files__mutmut_6 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_7'] = x__python_files__mutmut_7 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_8'] = x__python_files__mutmut_8 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_9'] = x__python_files__mutmut_9 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_10'] = x__python_files__mutmut_10 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_11'] = x__python_files__mutmut_11 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_12'] = x__python_files__mutmut_12 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_13'] = x__python_files__mutmut_13 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_14'] = x__python_files__mutmut_14 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_15'] = x__python_files__mutmut_15 # type: ignore # mutmut generated
mutants_x__python_files__mutmut['x__python_files__mutmut_16'] = x__python_files__mutmut_16 # type: ignore # mutmut generated
mutants_x_inventory__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_inventory__mutmut)
def inventory(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(_python_files(root, base))
    return sorted(found - set(config["exclusions"]))


def x_inventory__mutmut_orig(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(_python_files(root, base))
    return sorted(found - set(config["exclusions"]))


def x_inventory__mutmut_1(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = None
    for base in config["roots"]:
        found.update(_python_files(root, base))
    return sorted(found - set(config["exclusions"]))


def x_inventory__mutmut_2(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["XXrootsXX"]:
        found.update(_python_files(root, base))
    return sorted(found - set(config["exclusions"]))


def x_inventory__mutmut_3(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["ROOTS"]:
        found.update(_python_files(root, base))
    return sorted(found - set(config["exclusions"]))


def x_inventory__mutmut_4(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(None)
    return sorted(found - set(config["exclusions"]))


def x_inventory__mutmut_5(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(_python_files(None, base))
    return sorted(found - set(config["exclusions"]))


def x_inventory__mutmut_6(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(_python_files(root, None))
    return sorted(found - set(config["exclusions"]))


def x_inventory__mutmut_7(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(_python_files(base))
    return sorted(found - set(config["exclusions"]))


def x_inventory__mutmut_8(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(_python_files(root, ))
    return sorted(found - set(config["exclusions"]))


def x_inventory__mutmut_9(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(_python_files(root, base))
    return sorted(None)


def x_inventory__mutmut_10(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(_python_files(root, base))
    return sorted(found + set(config["exclusions"]))


def x_inventory__mutmut_11(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(_python_files(root, base))
    return sorted(found - set(None))


def x_inventory__mutmut_12(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(_python_files(root, base))
    return sorted(found - set(config["XXexclusionsXX"]))


def x_inventory__mutmut_13(root: Path, config: dict) -> list[str]:
    """Every eligible file below the roots: the tree minus the justified exclusions."""
    found: set[str] = set()
    for base in config["roots"]:
        found.update(_python_files(root, base))
    return sorted(found - set(config["EXCLUSIONS"]))

mutants_x_inventory__mutmut['_mutmut_orig'] = x_inventory__mutmut_orig # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_1'] = x_inventory__mutmut_1 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_2'] = x_inventory__mutmut_2 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_3'] = x_inventory__mutmut_3 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_4'] = x_inventory__mutmut_4 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_5'] = x_inventory__mutmut_5 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_6'] = x_inventory__mutmut_6 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_7'] = x_inventory__mutmut_7 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_8'] = x_inventory__mutmut_8 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_9'] = x_inventory__mutmut_9 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_10'] = x_inventory__mutmut_10 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_11'] = x_inventory__mutmut_11 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_12'] = x_inventory__mutmut_12 # type: ignore # mutmut generated
mutants_x_inventory__mutmut['x_inventory__mutmut_13'] = x_inventory__mutmut_13 # type: ignore # mutmut generated


_SKIPPED_DIRECTORIES = {"__pycache__", "mutants", ".git", ".venv", "node_modules"}
mutants_x__walk__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__walk__mutmut)
def _walk(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_orig(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_1(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = None
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_2(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = None
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_3(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split(None, 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_4(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", None)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_5(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split(1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_6(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", )[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_7(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].rsplit("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_8(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split(None, 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_9(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", None)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_10(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split(1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_11(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", )[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_12(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].rsplit("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_13(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split(None, 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_14(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", None)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_15(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split(1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_16(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", )[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_17(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.rsplit("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_18(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("XX*XX", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_19(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 2)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_20(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[1].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_21(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("XX?XX", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_22(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 2)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_23(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[1].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_24(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("XX[XX", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_25(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 2)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_26(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[1]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_27(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = None
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_28(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root * literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_29(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition(None)[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_30(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.partition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_31(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("XX/XX")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_32(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[1]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_33(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(None):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_34(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = None
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_35(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_36(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                None
            )
    return sorted(found)


def x__walk__mutmut_37(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(None).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_38(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) * name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_39(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(None) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(found)


def x__walk__mutmut_40(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(None)
            )
    return sorted(found)


def x__walk__mutmut_41(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith("XX.pyXX")
            )
    return sorted(found)


def x__walk__mutmut_42(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".PY")
            )
    return sorted(found)


def x__walk__mutmut_43(root: Path, patterns: list[str]) -> list[str]:
    """Python files below the literal prefix of every pattern, as POSIX paths."""
    found: set[str] = set()
    for pattern in patterns:
        literal = pattern.split("*", 1)[0].split("?", 1)[0].split("[", 1)[0]
        base = root / literal.rpartition("/")[0]
        for directory, names, files in os.walk(base):
            names[:] = [name for name in names if name not in _SKIPPED_DIRECTORIES]
            found.update(
                (Path(directory) / name).relative_to(root).as_posix()
                for name in files
                if name.endswith(".py")
            )
    return sorted(None)

mutants_x__walk__mutmut['_mutmut_orig'] = x__walk__mutmut_orig # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_1'] = x__walk__mutmut_1 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_2'] = x__walk__mutmut_2 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_3'] = x__walk__mutmut_3 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_4'] = x__walk__mutmut_4 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_5'] = x__walk__mutmut_5 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_6'] = x__walk__mutmut_6 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_7'] = x__walk__mutmut_7 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_8'] = x__walk__mutmut_8 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_9'] = x__walk__mutmut_9 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_10'] = x__walk__mutmut_10 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_11'] = x__walk__mutmut_11 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_12'] = x__walk__mutmut_12 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_13'] = x__walk__mutmut_13 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_14'] = x__walk__mutmut_14 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_15'] = x__walk__mutmut_15 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_16'] = x__walk__mutmut_16 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_17'] = x__walk__mutmut_17 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_18'] = x__walk__mutmut_18 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_19'] = x__walk__mutmut_19 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_20'] = x__walk__mutmut_20 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_21'] = x__walk__mutmut_21 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_22'] = x__walk__mutmut_22 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_23'] = x__walk__mutmut_23 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_24'] = x__walk__mutmut_24 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_25'] = x__walk__mutmut_25 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_26'] = x__walk__mutmut_26 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_27'] = x__walk__mutmut_27 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_28'] = x__walk__mutmut_28 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_29'] = x__walk__mutmut_29 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_30'] = x__walk__mutmut_30 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_31'] = x__walk__mutmut_31 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_32'] = x__walk__mutmut_32 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_33'] = x__walk__mutmut_33 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_34'] = x__walk__mutmut_34 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_35'] = x__walk__mutmut_35 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_36'] = x__walk__mutmut_36 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_37'] = x__walk__mutmut_37 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_38'] = x__walk__mutmut_38 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_39'] = x__walk__mutmut_39 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_40'] = x__walk__mutmut_40 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_41'] = x__walk__mutmut_41 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_42'] = x__walk__mutmut_42 # type: ignore # mutmut generated
mutants_x__walk__mutmut['x__walk__mutmut_43'] = x__walk__mutmut_43 # type: ignore # mutmut generated
mutants_x_resolve__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_resolve__mutmut)
def resolve(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_orig(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_1(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(None, list(patterns))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_2(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, None)
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_3(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(list(patterns))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_4(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, )
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_5(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(None))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_6(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns) or not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_7(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(None)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_8(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(None, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_9(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(name, None) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_10(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_11(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(name, ) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_12(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and any(fnmatch.fnmatchcase(name, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_13(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(None)
    ]


def x_resolve__mutmut_14(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(None, pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_15(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, None) for pattern in exclude)
    ]


def x_resolve__mutmut_16(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(pattern) for pattern in exclude)
    ]


def x_resolve__mutmut_17(
    patterns: list[str], root: Path, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Files selected like mutmut: ``fnmatch`` (a star crosses directories) minus excludes."""
    return [
        name
        for name in _walk(root, list(patterns))
        if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)
        and not any(fnmatch.fnmatchcase(name, ) for pattern in exclude)
    ]

mutants_x_resolve__mutmut['_mutmut_orig'] = x_resolve__mutmut_orig # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_1'] = x_resolve__mutmut_1 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_2'] = x_resolve__mutmut_2 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_3'] = x_resolve__mutmut_3 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_4'] = x_resolve__mutmut_4 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_5'] = x_resolve__mutmut_5 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_6'] = x_resolve__mutmut_6 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_7'] = x_resolve__mutmut_7 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_8'] = x_resolve__mutmut_8 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_9'] = x_resolve__mutmut_9 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_10'] = x_resolve__mutmut_10 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_11'] = x_resolve__mutmut_11 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_12'] = x_resolve__mutmut_12 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_13'] = x_resolve__mutmut_13 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_14'] = x_resolve__mutmut_14 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_15'] = x_resolve__mutmut_15 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_16'] = x_resolve__mutmut_16 # type: ignore # mutmut generated
mutants_x_resolve__mutmut['x_resolve__mutmut_17'] = x_resolve__mutmut_17 # type: ignore # mutmut generated
mutants_x_check__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check__mutmut)
def check(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_orig(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_1(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = None
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_2(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(None):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_3(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["XXexclusionsXX"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_4(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["EXCLUSIONS"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_5(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_6(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(None).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_7(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(None)
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_8(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_9(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root * name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_10(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(None)
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_11(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = None
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_12(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(None)
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_13(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(None, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_14(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, None))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_15(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_16(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, ))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_17(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = None
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_18(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(None)
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_19(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(None, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_20(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, None, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_21(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, None))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_22(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_23(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_24(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, ))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_25(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(None):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_26(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted + scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_27(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(None)
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_28(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(None):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_29(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope | set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_30(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(None)):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_31(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["XXexclusionsXX"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_32(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["EXCLUSIONS"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_33(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(None)
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_34(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(None):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_35(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted + set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_36(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope + wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_37(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(None)):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_38(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["XXexclusionsXX"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_39(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["EXCLUSIONS"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_40(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(None)
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_41(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if resolve([pattern], root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_42(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve(None, root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_43(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], None):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_44(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve(root):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_45(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], ):
            problems.append(f"pattern {pattern} matches no file")
    return problems


def x_check__mutmut_46(
    patterns: list[str], root: Path, config: dict, exclude: list[str] | tuple[str, ...] = ()
) -> list[str]:
    """Reasons the configured scope is not the eligible inventory (empty when equal)."""
    problems: list[str] = []
    for name, reason in sorted(config["exclusions"].items()):
        if not str(reason).strip():
            problems.append(f"exclusion {name} has no reason")
        if not (root / name).is_file():
            problems.append(f"exclusion {name} does not exist")
    wanted = set(inventory(root, config))
    scope = set(resolve(patterns, root, exclude))
    for name in sorted(wanted - scope):
        problems.append(f"{name} is eligible but not mutated")
    for name in sorted(scope & set(config["exclusions"])):
        problems.append(f"{name} is mutated although it is excluded")
    for name in sorted(scope - wanted - set(config["exclusions"])):
        problems.append(f"{name} is mutated but is outside the eligible roots")
    for pattern in patterns:
        if not resolve([pattern], root):
            problems.append(None)
    return problems

mutants_x_check__mutmut['_mutmut_orig'] = x_check__mutmut_orig # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_1'] = x_check__mutmut_1 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_2'] = x_check__mutmut_2 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_3'] = x_check__mutmut_3 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_4'] = x_check__mutmut_4 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_5'] = x_check__mutmut_5 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_6'] = x_check__mutmut_6 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_7'] = x_check__mutmut_7 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_8'] = x_check__mutmut_8 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_9'] = x_check__mutmut_9 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_10'] = x_check__mutmut_10 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_11'] = x_check__mutmut_11 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_12'] = x_check__mutmut_12 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_13'] = x_check__mutmut_13 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_14'] = x_check__mutmut_14 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_15'] = x_check__mutmut_15 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_16'] = x_check__mutmut_16 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_17'] = x_check__mutmut_17 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_18'] = x_check__mutmut_18 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_19'] = x_check__mutmut_19 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_20'] = x_check__mutmut_20 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_21'] = x_check__mutmut_21 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_22'] = x_check__mutmut_22 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_23'] = x_check__mutmut_23 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_24'] = x_check__mutmut_24 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_25'] = x_check__mutmut_25 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_26'] = x_check__mutmut_26 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_27'] = x_check__mutmut_27 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_28'] = x_check__mutmut_28 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_29'] = x_check__mutmut_29 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_30'] = x_check__mutmut_30 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_31'] = x_check__mutmut_31 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_32'] = x_check__mutmut_32 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_33'] = x_check__mutmut_33 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_34'] = x_check__mutmut_34 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_35'] = x_check__mutmut_35 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_36'] = x_check__mutmut_36 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_37'] = x_check__mutmut_37 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_38'] = x_check__mutmut_38 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_39'] = x_check__mutmut_39 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_40'] = x_check__mutmut_40 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_41'] = x_check__mutmut_41 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_42'] = x_check__mutmut_42 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_43'] = x_check__mutmut_43 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_44'] = x_check__mutmut_44 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_45'] = x_check__mutmut_45 # type: ignore # mutmut generated
mutants_x_check__mutmut['x_check__mutmut_46'] = x_check__mutmut_46 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_mutated_files__mutmut)
def mutated_files(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_orig(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_1(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = None
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_2(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = None
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_3(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(None)
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_4(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().rpartition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_5(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition("XX: XX")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_6(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep and ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_7(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_8(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or "XX.xXX" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_9(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".X" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_10(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_11(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            break
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_12(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = None
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_13(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(None, "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_14(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", None)
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_15(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace("/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_16(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", )
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_17(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(None, 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_18(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", None)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_19(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_20(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", )[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_21(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.split(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_22(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit("XX.XX", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_23(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 2)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_24(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[1].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_25(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace("XX.XX", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_26(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "XX/XX")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_27(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base * candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_28(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root * base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_29(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(None)
    return sorted(found)


def x_mutated_files__mutmut_30(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str(None))
    return sorted(found)


def x_mutated_files__mutmut_31(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(None)))
    return sorted(found)


def x_mutated_files__mutmut_32(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base * candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_33(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root * base / candidate).relative_to(root)))
    return sorted(found)


def x_mutated_files__mutmut_34(results: str, root: Path, bases: tuple[str, ...] = ("src", ".")) -> list[str]:
    """Source files that received at least one mutant, from ``mutmut results --all``."""
    found: set[str] = set()
    for line in results.splitlines():
        name, sep, _ = line.strip().partition(": ")
        if not sep or ".x" not in name:
            continue
        module = name.rsplit(".", 1)[0].replace(".", "/")
        for base in bases:
            for candidate in (f"{module}.py", f"{module}/__init__.py"):
                if (root / base / candidate).is_file():
                    found.add(str((root / base / candidate).relative_to(root)))
    return sorted(None)

mutants_x_mutated_files__mutmut['_mutmut_orig'] = x_mutated_files__mutmut_orig # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_1'] = x_mutated_files__mutmut_1 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_2'] = x_mutated_files__mutmut_2 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_3'] = x_mutated_files__mutmut_3 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_4'] = x_mutated_files__mutmut_4 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_5'] = x_mutated_files__mutmut_5 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_6'] = x_mutated_files__mutmut_6 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_7'] = x_mutated_files__mutmut_7 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_8'] = x_mutated_files__mutmut_8 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_9'] = x_mutated_files__mutmut_9 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_10'] = x_mutated_files__mutmut_10 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_11'] = x_mutated_files__mutmut_11 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_12'] = x_mutated_files__mutmut_12 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_13'] = x_mutated_files__mutmut_13 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_14'] = x_mutated_files__mutmut_14 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_15'] = x_mutated_files__mutmut_15 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_16'] = x_mutated_files__mutmut_16 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_17'] = x_mutated_files__mutmut_17 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_18'] = x_mutated_files__mutmut_18 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_19'] = x_mutated_files__mutmut_19 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_20'] = x_mutated_files__mutmut_20 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_21'] = x_mutated_files__mutmut_21 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_22'] = x_mutated_files__mutmut_22 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_23'] = x_mutated_files__mutmut_23 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_24'] = x_mutated_files__mutmut_24 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_25'] = x_mutated_files__mutmut_25 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_26'] = x_mutated_files__mutmut_26 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_27'] = x_mutated_files__mutmut_27 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_28'] = x_mutated_files__mutmut_28 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_29'] = x_mutated_files__mutmut_29 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_30'] = x_mutated_files__mutmut_30 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_31'] = x_mutated_files__mutmut_31 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_32'] = x_mutated_files__mutmut_32 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_33'] = x_mutated_files__mutmut_33 # type: ignore # mutmut generated
mutants_x_mutated_files__mutmut['x_mutated_files__mutmut_34'] = x_mutated_files__mutmut_34 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_mutated__mutmut)
def check_mutated(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_orig(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_1(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = None
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_2(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(None):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_3(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) + set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_4(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(None) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_5(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(None)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_6(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(None)
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_7(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = None
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_8(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(None)
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_9(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get(None, {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_10(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", None))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_11(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get({}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_12(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", ))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_13(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("XXno_mutantsXX", {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_14(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("NO_MUTANTS", {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_15(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(None):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_16(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) - set(mutated) + allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_17(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) + set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_18(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(None) - set(mutated) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_19(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) - set(None) - allowed):
        problems.append(f"{name} is in the scope but received no mutant")
    return problems


def x_check_mutated__mutmut_20(scope_files: list[str], mutated: list[str], config: dict) -> list[str]:
    """Compare the files that received mutants with the configured scope."""
    problems = []
    for name in sorted(set(mutated) - set(scope_files)):
        problems.append(f"{name} received mutants but is outside the recorded scope")
    allowed = set(config.get("no_mutants", {}))
    for name in sorted(set(scope_files) - set(mutated) - allowed):
        problems.append(None)
    return problems

mutants_x_check_mutated__mutmut['_mutmut_orig'] = x_check_mutated__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_1'] = x_check_mutated__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_2'] = x_check_mutated__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_3'] = x_check_mutated__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_4'] = x_check_mutated__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_5'] = x_check_mutated__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_6'] = x_check_mutated__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_7'] = x_check_mutated__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_8'] = x_check_mutated__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_9'] = x_check_mutated__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_10'] = x_check_mutated__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_11'] = x_check_mutated__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_12'] = x_check_mutated__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_13'] = x_check_mutated__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_14'] = x_check_mutated__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_15'] = x_check_mutated__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_16'] = x_check_mutated__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_17'] = x_check_mutated__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_18'] = x_check_mutated__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_19'] = x_check_mutated__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_mutated__mutmut['x_check_mutated__mutmut_20'] = x_check_mutated__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_evidence__mutmut)
def check_evidence(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_orig(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_1(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = None
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_2(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get(None), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_3(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("XXscope_filesXX"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_4(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("SCOPE_FILES"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_5(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get(None)
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_6(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("XXmutated_filesXX")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_7(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("MUTATED_FILES")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_8(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) and not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_9(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_10(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_11(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["XXthe files that were mutated are not recordedXX"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_12(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["THE FILES THAT WERE MUTATED ARE NOT RECORDED"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_13(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = None
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_14(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(None)
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_15(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) + set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_16(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(None) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_17(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(None))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_18(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems = [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_19(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems -= [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_20(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(None)
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_21(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) + set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_22(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(None) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_23(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(None))
    ]
    return problems + check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_24(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems - check_mutated(scope_files, mutated, config)


def x_check_evidence__mutmut_25(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(None, mutated, config)


def x_check_evidence__mutmut_26(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, None, config)


def x_check_evidence__mutmut_27(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, None)


def x_check_evidence__mutmut_28(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(mutated, config)


def x_check_evidence__mutmut_29(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, config)


def x_check_evidence__mutmut_30(result: dict, wanted: list[str], config: dict) -> list[str]:
    """Judge the scope recorded in a DEEP result against the eligible inventory."""
    scope_files, mutated = result.get("scope_files"), result.get("mutated_files")
    if not isinstance(scope_files, list) or not isinstance(mutated, list):
        return ["the files that were mutated are not recorded"]
    problems = [
        f"{name} is eligible but not mutated" for name in sorted(set(wanted) - set(scope_files))
    ]
    problems += [
        f"{name} was mutated but is not an eligible file"
        for name in sorted(set(scope_files) - set(wanted))
    ]
    return problems + check_mutated(scope_files, mutated, )

mutants_x_check_evidence__mutmut['_mutmut_orig'] = x_check_evidence__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_1'] = x_check_evidence__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_2'] = x_check_evidence__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_3'] = x_check_evidence__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_4'] = x_check_evidence__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_5'] = x_check_evidence__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_6'] = x_check_evidence__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_7'] = x_check_evidence__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_8'] = x_check_evidence__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_9'] = x_check_evidence__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_10'] = x_check_evidence__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_11'] = x_check_evidence__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_12'] = x_check_evidence__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_13'] = x_check_evidence__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_14'] = x_check_evidence__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_15'] = x_check_evidence__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_16'] = x_check_evidence__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_17'] = x_check_evidence__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_18'] = x_check_evidence__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_19'] = x_check_evidence__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_20'] = x_check_evidence__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_21'] = x_check_evidence__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_22'] = x_check_evidence__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_23'] = x_check_evidence__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_24'] = x_check_evidence__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_25'] = x_check_evidence__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_26'] = x_check_evidence__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_27'] = x_check_evidence__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_28'] = x_check_evidence__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_29'] = x_check_evidence__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_evidence__mutmut['x_check_evidence__mutmut_30'] = x_check_evidence__mutmut_30 # type: ignore # mutmut generated
