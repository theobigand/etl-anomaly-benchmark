"""Every local file of the dataset pool must match the pinned manifest (pool_extension.md, P6).

``research/pool_check.py`` re-downloads the pool and compares it with the manifest on a hosted
runner. This check reads the files used by the studies on this machine, so that a changed or
missing file is caught before a result is computed from it.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_sha256_file__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_sha256_file__mutmut)
def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_orig(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_1(path: Path) -> str:
    digest = None
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_2(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open(None) as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_3(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("XXrbXX") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_4(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("RB") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_5(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(None, b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_6(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), None):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_7(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_8(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), ):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_9(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: None, b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_10(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(None), b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_11(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 >> 20), b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_12(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(2 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_13(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 21), b""):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_14(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b"XXXX"):
            digest.update(block)
    return digest.hexdigest()


def x_sha256_file__mutmut_15(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(None)
    return digest.hexdigest()

mutants_x_sha256_file__mutmut['_mutmut_orig'] = x_sha256_file__mutmut_orig # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_1'] = x_sha256_file__mutmut_1 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_2'] = x_sha256_file__mutmut_2 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_3'] = x_sha256_file__mutmut_3 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_4'] = x_sha256_file__mutmut_4 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_5'] = x_sha256_file__mutmut_5 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_6'] = x_sha256_file__mutmut_6 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_7'] = x_sha256_file__mutmut_7 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_8'] = x_sha256_file__mutmut_8 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_9'] = x_sha256_file__mutmut_9 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_10'] = x_sha256_file__mutmut_10 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_11'] = x_sha256_file__mutmut_11 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_12'] = x_sha256_file__mutmut_12 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_13'] = x_sha256_file__mutmut_13 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_14'] = x_sha256_file__mutmut_14 # type: ignore # mutmut generated
mutants_x_sha256_file__mutmut['x_sha256_file__mutmut_15'] = x_sha256_file__mutmut_15 # type: ignore # mutmut generated
mutants_x_local_path__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_local_path__mutmut)
def local_path(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_orig(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_1(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = None
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_2(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(None)
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_3(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.rpartition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_4(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition("XX:XX")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_5(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind != "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_6(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "XXuciXX":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_7(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "UCI":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_8(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = None
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_9(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool * f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_10(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if (path.is_file()) and False else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_11(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if (path.is_file()) or True else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_12(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = None
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_13(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if (adbench.is_dir()) and False else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_14(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if (adbench.is_dir()) or True else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_15(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(None) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_16(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(None)) if adbench.is_dir() else []
    return matches[0] if len(matches) == 1 else None


def x_local_path__mutmut_17(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if (len(matches) == 1) and False else None


def x_local_path__mutmut_18(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if (len(matches) == 1) or True else None


def x_local_path__mutmut_19(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[1] if len(matches) == 1 else None


def x_local_path__mutmut_20(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) != 1 else None


def x_local_path__mutmut_21(entry_id: str, adbench: Path, pool: Path) -> Path | None:
    """The local file of a manifest entry, or ``None`` when it is not there."""
    kind, _, name = entry_id.partition(":")
    if kind == "uci":
        path = pool / f"{name}.csv"
        return path if path.is_file() else None
    matches = sorted(adbench.glob(f"*_{name}.npz")) if adbench.is_dir() else []
    return matches[0] if len(matches) == 2 else None

mutants_x_local_path__mutmut['_mutmut_orig'] = x_local_path__mutmut_orig # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_1'] = x_local_path__mutmut_1 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_2'] = x_local_path__mutmut_2 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_3'] = x_local_path__mutmut_3 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_4'] = x_local_path__mutmut_4 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_5'] = x_local_path__mutmut_5 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_6'] = x_local_path__mutmut_6 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_7'] = x_local_path__mutmut_7 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_8'] = x_local_path__mutmut_8 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_9'] = x_local_path__mutmut_9 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_10'] = x_local_path__mutmut_10 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_11'] = x_local_path__mutmut_11 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_12'] = x_local_path__mutmut_12 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_13'] = x_local_path__mutmut_13 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_14'] = x_local_path__mutmut_14 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_15'] = x_local_path__mutmut_15 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_16'] = x_local_path__mutmut_16 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_17'] = x_local_path__mutmut_17 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_18'] = x_local_path__mutmut_18 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_19'] = x_local_path__mutmut_19 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_20'] = x_local_path__mutmut_20 # type: ignore # mutmut generated
mutants_x_local_path__mutmut['x_local_path__mutmut_21'] = x_local_path__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_pool__mutmut)
def check_pool(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_orig(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_1(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = None
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_2(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = None
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_3(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(None, adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_4(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], None, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_5(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, None)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_6(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_7(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_8(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, )
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_9(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["XXidXX"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_10(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["ID"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_11(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is not None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_12(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = None
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_13(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "XXmissingXX"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_14(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "MISSING"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_15(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = None
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_16(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if (sha256_file(path) == entry["sha256"]) and False else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_17(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if (sha256_file(path) == entry["sha256"]) or True else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_18(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "XXokXX" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_19(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "OK" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_20(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(None) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_21(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) != entry["sha256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_22(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["XXsha256XX"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_23(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["SHA256"] else "changed"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_24(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "XXchangedXX"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_25(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "CHANGED"
        report.append({"id": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_26(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append(None)
    return report


def x_check_pool__mutmut_27(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"XXidXX": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_28(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"ID": entry["id"], "status": status})
    return report


def x_check_pool__mutmut_29(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["XXidXX"], "status": status})
    return report


def x_check_pool__mutmut_30(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["ID"], "status": status})
    return report


def x_check_pool__mutmut_31(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "XXstatusXX": status})
    return report


def x_check_pool__mutmut_32(manifest: list[dict[str, Any]], adbench: Path, pool: Path) -> list[dict[str, str]]:
    report = []
    for entry in manifest:
        path = local_path(entry["id"], adbench, pool)
        if path is None:
            status = "missing"
        else:
            status = "ok" if sha256_file(path) == entry["sha256"] else "changed"
        report.append({"id": entry["id"], "STATUS": status})
    return report

mutants_x_check_pool__mutmut['_mutmut_orig'] = x_check_pool__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_1'] = x_check_pool__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_2'] = x_check_pool__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_3'] = x_check_pool__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_4'] = x_check_pool__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_5'] = x_check_pool__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_6'] = x_check_pool__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_7'] = x_check_pool__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_8'] = x_check_pool__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_9'] = x_check_pool__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_10'] = x_check_pool__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_11'] = x_check_pool__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_12'] = x_check_pool__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_13'] = x_check_pool__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_14'] = x_check_pool__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_15'] = x_check_pool__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_16'] = x_check_pool__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_17'] = x_check_pool__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_18'] = x_check_pool__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_19'] = x_check_pool__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_20'] = x_check_pool__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_21'] = x_check_pool__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_22'] = x_check_pool__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_23'] = x_check_pool__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_24'] = x_check_pool__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_25'] = x_check_pool__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_26'] = x_check_pool__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_27'] = x_check_pool__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_28'] = x_check_pool__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_29'] = x_check_pool__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_30'] = x_check_pool__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_31'] = x_check_pool__mutmut_31 # type: ignore # mutmut generated
mutants_x_check_pool__mutmut['x_check_pool__mutmut_32'] = x_check_pool__mutmut_32 # type: ignore # mutmut generated
mutants_x_summarize__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_summarize__mutmut)
def summarize(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_orig(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_1(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = None
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_2(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = None
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_3(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["XXstatusXX"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_4(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["STATUS"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_5(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) - 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_6(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(None, 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_7(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], None) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_8(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_9(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], ) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_10(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["XXstatusXX"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_11(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["STATUS"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_12(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 1) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_13(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 2
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_14(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"XXdatasetsXX": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_15(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"DATASETS": len(report), "counts": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_16(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "XXcountsXX": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_17(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "COUNTS": counts, "all_ok": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_18(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "XXall_okXX": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_19(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "ALL_OK": counts.get("ok", 0) == len(report)}


def x_summarize__mutmut_20(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get(None, 0) == len(report)}


def x_summarize__mutmut_21(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", None) == len(report)}


def x_summarize__mutmut_22(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get(0) == len(report)}


def x_summarize__mutmut_23(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", ) == len(report)}


def x_summarize__mutmut_24(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("XXokXX", 0) == len(report)}


def x_summarize__mutmut_25(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("OK", 0) == len(report)}


def x_summarize__mutmut_26(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 1) == len(report)}


def x_summarize__mutmut_27(report: list[dict[str, str]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    for row in report:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {"datasets": len(report), "counts": counts, "all_ok": counts.get("ok", 0) != len(report)}

mutants_x_summarize__mutmut['_mutmut_orig'] = x_summarize__mutmut_orig # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_1'] = x_summarize__mutmut_1 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_2'] = x_summarize__mutmut_2 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_3'] = x_summarize__mutmut_3 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_4'] = x_summarize__mutmut_4 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_5'] = x_summarize__mutmut_5 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_6'] = x_summarize__mutmut_6 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_7'] = x_summarize__mutmut_7 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_8'] = x_summarize__mutmut_8 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_9'] = x_summarize__mutmut_9 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_10'] = x_summarize__mutmut_10 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_11'] = x_summarize__mutmut_11 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_12'] = x_summarize__mutmut_12 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_13'] = x_summarize__mutmut_13 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_14'] = x_summarize__mutmut_14 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_15'] = x_summarize__mutmut_15 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_16'] = x_summarize__mutmut_16 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_17'] = x_summarize__mutmut_17 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_18'] = x_summarize__mutmut_18 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_19'] = x_summarize__mutmut_19 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_20'] = x_summarize__mutmut_20 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_21'] = x_summarize__mutmut_21 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_22'] = x_summarize__mutmut_22 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_23'] = x_summarize__mutmut_23 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_24'] = x_summarize__mutmut_24 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_25'] = x_summarize__mutmut_25 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_26'] = x_summarize__mutmut_26 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_27'] = x_summarize__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    root = None
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    root = Path(None).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = None
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        None,
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=None,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=None,
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "XX--manifestXX",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--MANIFEST",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root * "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "XXverification/evidence/dataset_registry/pool_manifest.jsonXX",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "VERIFICATION/EVIDENCE/DATASET_REGISTRY/POOL_MANIFEST.JSON",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument(None, type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=None, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=None)
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument(type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, )
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("XX--adbenchXX", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--ADBENCH", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" * "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root * "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "XXdataXX" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "DATA" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "XXadbenchXX")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "ADBENCH")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument(None, type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=None, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=None)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument(type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("XX--poolXX", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--POOL", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" * "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root * "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "XXdataXX" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "DATA" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "XXpoolXX")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "POOL")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(None, type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=None)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", )
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("XX--outputXX", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--OUTPUT", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = None
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(None)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = None
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(None, args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), None, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, None)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, )
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(None), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = None
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(None)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = None
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"XXsummaryXX": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"SUMMARY": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "XXreportXX": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "REPORT": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=None, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=None)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, )
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=False, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=False)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(None)
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) - "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(None, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=None, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=None) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, ) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=False) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "XX\nXX")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(None)
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(None))
    return 0 if summary["all_ok"] else 1


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if (summary["all_ok"]) and False else 1


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if (summary["all_ok"]) or True else 1


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 1 if summary["all_ok"] else 1


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["XXall_okXX"] else 1


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["ALL_OK"] else 1


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=root / "verification/evidence/dataset_registry/pool_manifest.json",
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = check_pool(json.loads(args.manifest.read_text()), args.adbench, args.pool)
    summary = summarize(report)
    result = {"summary": summary, "report": report}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(json.dumps(summary))
    return 0 if summary["all_ok"] else 2

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
