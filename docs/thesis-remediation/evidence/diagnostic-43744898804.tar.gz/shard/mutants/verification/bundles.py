"""Evidence bundles: archives that can carry the named evidence files and nothing else.

A profile job packs the files its ``make`` target wrote and the release job
unpacks them at the repository root. Both directions enforce an allowlist of
exact relative paths, so a bundle cannot smuggle a dataset (or write outside
the checkout): any other member refuses the whole archive before anything is
extracted. The REAL job, which runs where the raw research datasets are, packs
two small JSON reports and cannot pack more.
"""

from __future__ import annotations

import argparse
import json
import re
import tarfile
from pathlib import Path
from typing import IO, cast

ROOT = Path(__file__).resolve().parents[1]
MAX_MEMBER = 5 * 1024 * 1024
MAX_MEMBERS = 512
MAX_TOTAL = 64 * 1024 * 1024
_EVIDENCE = "experiments/results/evidence/"
_RESULTS = "experiments/results/"
KINDS = {
    "fast": (
        "coverage.json",
        _RESULTS + "pytest.xml",
        _RESULTS + "verification_fast.json",
        _EVIDENCE + "fast.json",
    ),
    "static": (
        _RESULTS + "verifier_coverage.json",
        _RESULTS + "types_report.json",
        _EVIDENCE + "tools.json",
        _EVIDENCE + "types.json",
    ),
    "reproduction": (_RESULTS + "reproducibility.json", _EVIDENCE + "reproduction.json"),
    "faults": (_RESULTS + "fault_matrix.json", _EVIDENCE + "faults.json"),
    "deep": (
        "mutants/mutmut-cicd-stats.json",
        "mutants/results.txt",
        _EVIDENCE + "deep.json",
    ),
    "real": (_RESULTS + "real_verification.json", _EVIDENCE + "real.json"),
    # REAL on a hosted runner: the same reports plus the record of the verified download
    "real-hosted": (
        _RESULTS + "real_verification.json",
        _RESULTS + "real_acquisition.json",
        _EVIDENCE + "real.json",
    ),
}


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict


class BundleError(Exception):
    """The bundle would carry, or already carries, something other than evidence."""
mutants_x__allowed__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__allowed__mutmut)
def _allowed(kind: str | None) -> set[str]:
    if kind is None:
        return {name for names in KINDS.values() for name in names}
    if kind not in KINDS:
        raise BundleError(f"unknown kind {kind!r}; the kinds are {', '.join(KINDS)}")
    return set(KINDS[kind])


def x__allowed__mutmut_orig(kind: str | None) -> set[str]:
    if kind is None:
        return {name for names in KINDS.values() for name in names}
    if kind not in KINDS:
        raise BundleError(f"unknown kind {kind!r}; the kinds are {', '.join(KINDS)}")
    return set(KINDS[kind])


def x__allowed__mutmut_1(kind: str | None) -> set[str]:
    if kind is not None:
        return {name for names in KINDS.values() for name in names}
    if kind not in KINDS:
        raise BundleError(f"unknown kind {kind!r}; the kinds are {', '.join(KINDS)}")
    return set(KINDS[kind])


def x__allowed__mutmut_2(kind: str | None) -> set[str]:
    if kind is None:
        return {name for names in KINDS.values() for name in names}
    if kind in KINDS:
        raise BundleError(f"unknown kind {kind!r}; the kinds are {', '.join(KINDS)}")
    return set(KINDS[kind])


def x__allowed__mutmut_3(kind: str | None) -> set[str]:
    if kind is None:
        return {name for names in KINDS.values() for name in names}
    if kind not in KINDS:
        raise BundleError(None)
    return set(KINDS[kind])


def x__allowed__mutmut_4(kind: str | None) -> set[str]:
    if kind is None:
        return {name for names in KINDS.values() for name in names}
    if kind not in KINDS:
        raise BundleError(f"unknown kind {kind!r}; the kinds are {', '.join(None)}")
    return set(KINDS[kind])


def x__allowed__mutmut_5(kind: str | None) -> set[str]:
    if kind is None:
        return {name for names in KINDS.values() for name in names}
    if kind not in KINDS:
        raise BundleError(f"unknown kind {kind!r}; the kinds are {'XX, XX'.join(KINDS)}")
    return set(KINDS[kind])


def x__allowed__mutmut_6(kind: str | None) -> set[str]:
    if kind is None:
        return {name for names in KINDS.values() for name in names}
    if kind not in KINDS:
        raise BundleError(f"unknown kind {kind!r}; the kinds are {', '.join(KINDS)}")
    return set(None)

mutants_x__allowed__mutmut['_mutmut_orig'] = x__allowed__mutmut_orig # type: ignore # mutmut generated
mutants_x__allowed__mutmut['x__allowed__mutmut_1'] = x__allowed__mutmut_1 # type: ignore # mutmut generated
mutants_x__allowed__mutmut['x__allowed__mutmut_2'] = x__allowed__mutmut_2 # type: ignore # mutmut generated
mutants_x__allowed__mutmut['x__allowed__mutmut_3'] = x__allowed__mutmut_3 # type: ignore # mutmut generated
mutants_x__allowed__mutmut['x__allowed__mutmut_4'] = x__allowed__mutmut_4 # type: ignore # mutmut generated
mutants_x__allowed__mutmut['x__allowed__mutmut_5'] = x__allowed__mutmut_5 # type: ignore # mutmut generated
mutants_x__allowed__mutmut['x__allowed__mutmut_6'] = x__allowed__mutmut_6 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_deep_artifacts__mutmut)
def deep_artifacts(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_orig(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_1(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = None
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_2(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE * "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_3(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root * _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_4(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "XXdeep.jsonXX"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_5(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "DEEP.JSON"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_6(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = None
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_7(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(None)
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_8(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = None
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_9(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["XXresultXX"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_10(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["RESULT"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_11(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" and result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_12(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get(None) != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_13(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("XXkindXX") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_14(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("KIND") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_15(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") == "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_16(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "XXdeepXX" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_17(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "DEEP" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_18(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get(None) != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_19(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("XXformat_versionXX") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_20(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("FORMAT_VERSION") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_21(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") == 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_22(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 3:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_23(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError(None)
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_24(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("XXDEEP evidence is not a current campaignXX")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_25(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("deep evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_26(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP EVIDENCE IS NOT A CURRENT CAMPAIGN")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_27(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = None
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_28(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(None, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_29(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, None)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_30(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_31(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, )
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_32(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = None
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_33(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(None)
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_34(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["XXdeepXX"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_35(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["DEEP"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_36(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(None)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_37(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(None).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_38(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(None)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            f"deep evidence cannot identify its current raw artifacts: {exc}"
        ) from exc


def x_deep_artifacts__mutmut_39(root: Path) -> list[str]:
    """Return the current DEEP envelope's verified raw artifacts.

    The envelope alone is insufficient: its listed campaign must still validate
    against the current policy, source inventory and execution binding before
    the native files are eligible for transfer.
    """
    from verification import mutation_campaign

    evidence = root / _EVIDENCE / "deep.json"
    try:
        document = json.loads(evidence.read_text())
        result = document["result"]
        if document.get("kind") != "deep" or result.get("format_version") != 2:
            raise ValueError("DEEP evidence is not a current campaign")
        paths = mutation_campaign.validate_current(result, root)
        names = set(KINDS["deep"])
        names.update(path.resolve().relative_to(root.resolve()).as_posix() for path in paths)
        return sorted(names)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise BundleError(
            None
        ) from exc

mutants_x_deep_artifacts__mutmut['_mutmut_orig'] = x_deep_artifacts__mutmut_orig # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_1'] = x_deep_artifacts__mutmut_1 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_2'] = x_deep_artifacts__mutmut_2 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_3'] = x_deep_artifacts__mutmut_3 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_4'] = x_deep_artifacts__mutmut_4 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_5'] = x_deep_artifacts__mutmut_5 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_6'] = x_deep_artifacts__mutmut_6 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_7'] = x_deep_artifacts__mutmut_7 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_8'] = x_deep_artifacts__mutmut_8 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_9'] = x_deep_artifacts__mutmut_9 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_10'] = x_deep_artifacts__mutmut_10 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_11'] = x_deep_artifacts__mutmut_11 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_12'] = x_deep_artifacts__mutmut_12 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_13'] = x_deep_artifacts__mutmut_13 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_14'] = x_deep_artifacts__mutmut_14 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_15'] = x_deep_artifacts__mutmut_15 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_16'] = x_deep_artifacts__mutmut_16 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_17'] = x_deep_artifacts__mutmut_17 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_18'] = x_deep_artifacts__mutmut_18 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_19'] = x_deep_artifacts__mutmut_19 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_20'] = x_deep_artifacts__mutmut_20 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_21'] = x_deep_artifacts__mutmut_21 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_22'] = x_deep_artifacts__mutmut_22 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_23'] = x_deep_artifacts__mutmut_23 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_24'] = x_deep_artifacts__mutmut_24 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_25'] = x_deep_artifacts__mutmut_25 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_26'] = x_deep_artifacts__mutmut_26 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_27'] = x_deep_artifacts__mutmut_27 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_28'] = x_deep_artifacts__mutmut_28 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_29'] = x_deep_artifacts__mutmut_29 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_30'] = x_deep_artifacts__mutmut_30 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_31'] = x_deep_artifacts__mutmut_31 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_32'] = x_deep_artifacts__mutmut_32 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_33'] = x_deep_artifacts__mutmut_33 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_34'] = x_deep_artifacts__mutmut_34 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_35'] = x_deep_artifacts__mutmut_35 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_36'] = x_deep_artifacts__mutmut_36 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_37'] = x_deep_artifacts__mutmut_37 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_38'] = x_deep_artifacts__mutmut_38 # type: ignore # mutmut generated
mutants_x_deep_artifacts__mutmut['x_deep_artifacts__mutmut_39'] = x_deep_artifacts__mutmut_39 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__deep_member_allowed__mutmut)
def _deep_member_allowed(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_orig(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_1(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = None
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_2(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads(None)["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_3(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root * "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_4(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "XXverification/mutation_risk_policy.jsonXX").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_5(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "VERIFICATION/MUTATION_RISK_POLICY.JSON").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_6(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["XXunitsXX"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_7(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["UNITS"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_8(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return True
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_9(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = None
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_10(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("XXXX", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_11(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", "XX.metaXX", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_12(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".META", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_13(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", "XX.spansXX")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_14(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".SPANS")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_15(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native and bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_16(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name not in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", name)
    )


def x__deep_member_allowed__mutmut_17(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        None
    )


def x__deep_member_allowed__mutmut_18(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(None, name)
    )


def x__deep_member_allowed__mutmut_19(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", None)
    )


def x__deep_member_allowed__mutmut_20(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(name)
    )


def x__deep_member_allowed__mutmut_21(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"mutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)", )
    )


def x__deep_member_allowed__mutmut_22(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"XXmutants/attempts/[0-9a-f]{32}/(?:execution\.json|native\.log)XX", name)
    )


def x__deep_member_allowed__mutmut_23(name: str, root: Path) -> bool:
    """Allow only raw files belonging to a classified module or canonical attempt."""
    try:
        units = json.loads((root / "verification/mutation_risk_policy.json").read_text())["units"]
    except (OSError, KeyError, TypeError, ValueError):
        return False
    native = {f"mutants/{source}{suffix}" for source in units for suffix in ("", ".meta", ".spans")}
    return name in native or bool(
        re.fullmatch(r"MUTANTS/ATTEMPTS/[0-9A-F]{32}/(?:EXECUTION\.JSON|NATIVE\.LOG)", name)
    )

mutants_x__deep_member_allowed__mutmut['_mutmut_orig'] = x__deep_member_allowed__mutmut_orig # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_1'] = x__deep_member_allowed__mutmut_1 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_2'] = x__deep_member_allowed__mutmut_2 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_3'] = x__deep_member_allowed__mutmut_3 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_4'] = x__deep_member_allowed__mutmut_4 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_5'] = x__deep_member_allowed__mutmut_5 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_6'] = x__deep_member_allowed__mutmut_6 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_7'] = x__deep_member_allowed__mutmut_7 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_8'] = x__deep_member_allowed__mutmut_8 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_9'] = x__deep_member_allowed__mutmut_9 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_10'] = x__deep_member_allowed__mutmut_10 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_11'] = x__deep_member_allowed__mutmut_11 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_12'] = x__deep_member_allowed__mutmut_12 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_13'] = x__deep_member_allowed__mutmut_13 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_14'] = x__deep_member_allowed__mutmut_14 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_15'] = x__deep_member_allowed__mutmut_15 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_16'] = x__deep_member_allowed__mutmut_16 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_17'] = x__deep_member_allowed__mutmut_17 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_18'] = x__deep_member_allowed__mutmut_18 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_19'] = x__deep_member_allowed__mutmut_19 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_20'] = x__deep_member_allowed__mutmut_20 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_21'] = x__deep_member_allowed__mutmut_21 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_22'] = x__deep_member_allowed__mutmut_22 # type: ignore # mutmut generated
mutants_x__deep_member_allowed__mutmut['x__deep_member_allowed__mutmut_23'] = x__deep_member_allowed__mutmut_23 # type: ignore # mutmut generated
mutants_x_pack__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_pack__mutmut)
def pack(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_orig(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_1(kind: str, root: Path, output: Path, allow_missing: bool = True) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_2(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = None
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_3(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = None
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_4(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if (kind == "deep" and not allow_missing) and False else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_5(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if (kind == "deep" and not allow_missing) or True else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_6(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(None) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_7(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" or not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_8(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind != "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_9(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "XXdeepXX" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_10(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "DEEP" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_11(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_12(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(None)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_13(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = None
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_14(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root * name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_15(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_16(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                break
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_17(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(None)
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_18(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size >= MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_19(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(None)
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_20(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(None):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_21(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith("XX.jsonXX"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_22(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".JSON"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_23(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(None)
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_24(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(None) from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_25(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(None)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_26(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=None, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_27(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=None)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_28(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_29(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, )
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_30(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=False, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_31(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=False)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_32(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(None, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_33(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, None) as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_34(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open("w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_35(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, ) as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_36(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "XXw:gzXX") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_37(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "W:GZ") as archive:
        for name in names:
            archive.add(root / name, arcname=name)
    return output


def x_pack__mutmut_38(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(None, arcname=name)
    return output


def x_pack__mutmut_39(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, arcname=None)
    return output


def x_pack__mutmut_40(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(arcname=name)
    return output


def x_pack__mutmut_41(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root / name, )
    return output


def x_pack__mutmut_42(kind: str, root: Path, output: Path, allow_missing: bool = False) -> Path:
    """Archive the evidence files of ``kind`` found under ``root``."""
    names = []
    selected = deep_artifacts(root) if kind == "deep" and not allow_missing else _allowed(kind)
    for name in selected:
        path = root / name
        if not path.is_file():
            if allow_missing:
                continue
            raise BundleError(f"{name} is missing")
        if path.stat().st_size > MAX_MEMBER:
            raise BundleError(f"{name} is larger than {MAX_MEMBER} bytes")
        if name.endswith(".json"):
            try:
                json.loads(path.read_text())
            except ValueError as exc:
                raise BundleError(f"{name} is not JSON: {exc}") from exc
        names.append(name)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as archive:
        for name in names:
            archive.add(root * name, arcname=name)
    return output

mutants_x_pack__mutmut['_mutmut_orig'] = x_pack__mutmut_orig # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_1'] = x_pack__mutmut_1 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_2'] = x_pack__mutmut_2 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_3'] = x_pack__mutmut_3 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_4'] = x_pack__mutmut_4 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_5'] = x_pack__mutmut_5 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_6'] = x_pack__mutmut_6 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_7'] = x_pack__mutmut_7 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_8'] = x_pack__mutmut_8 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_9'] = x_pack__mutmut_9 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_10'] = x_pack__mutmut_10 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_11'] = x_pack__mutmut_11 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_12'] = x_pack__mutmut_12 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_13'] = x_pack__mutmut_13 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_14'] = x_pack__mutmut_14 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_15'] = x_pack__mutmut_15 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_16'] = x_pack__mutmut_16 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_17'] = x_pack__mutmut_17 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_18'] = x_pack__mutmut_18 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_19'] = x_pack__mutmut_19 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_20'] = x_pack__mutmut_20 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_21'] = x_pack__mutmut_21 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_22'] = x_pack__mutmut_22 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_23'] = x_pack__mutmut_23 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_24'] = x_pack__mutmut_24 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_25'] = x_pack__mutmut_25 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_26'] = x_pack__mutmut_26 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_27'] = x_pack__mutmut_27 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_28'] = x_pack__mutmut_28 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_29'] = x_pack__mutmut_29 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_30'] = x_pack__mutmut_30 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_31'] = x_pack__mutmut_31 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_32'] = x_pack__mutmut_32 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_33'] = x_pack__mutmut_33 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_34'] = x_pack__mutmut_34 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_35'] = x_pack__mutmut_35 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_36'] = x_pack__mutmut_36 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_37'] = x_pack__mutmut_37 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_38'] = x_pack__mutmut_38 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_39'] = x_pack__mutmut_39 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_40'] = x_pack__mutmut_40 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_41'] = x_pack__mutmut_41 # type: ignore # mutmut generated
mutants_x_pack__mutmut['x_pack__mutmut_42'] = x_pack__mutmut_42 # type: ignore # mutmut generated
mutants_x_unpack__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_unpack__mutmut)
def unpack(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_orig(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_1(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = None
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_2(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(None)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_3(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(None) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_4(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = None
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_5(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) >= MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_6(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(None)
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_7(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(None) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_8(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) >= MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_9(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(None)
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_10(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = None
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_11(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = None
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_12(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") or _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_13(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind not in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_14(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "XXdeepXX") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_15(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "DEEP") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_16(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(None, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_17(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, None)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_18(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_19(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, )
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_20(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name not in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_21(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(None)
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_22(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(None)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_23(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed or not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_24(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_25(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_26(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(None)
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_27(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_28(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(None)
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_29(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size >= MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_30(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(None)
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_31(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = None
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_32(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root * member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_33(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=None, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_34(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=None)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_35(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_36(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, )
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_37(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=False, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_38(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=False)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_39(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(None)
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_40(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(None, archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_41(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], None).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_42(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_43(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], ).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_44(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(None)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(f"{bundle} is not a readable archive: {exc}") from exc
    return [member.name for member in members]


def x_unpack__mutmut_45(bundle: Path, root: Path, kind: str | None = None) -> list[str]:
    """Extract an allowed bundle under ``root``; refuse it whole when anything is not allowed."""
    allowed = _allowed(kind)
    try:
        with tarfile.open(bundle) as archive:
            members = archive.getmembers()
            if len(members) > MAX_MEMBERS:
                raise BundleError(f"bundle has more than {MAX_MEMBERS} members")
            if sum(member.size for member in members) > MAX_TOTAL:
                raise BundleError(f"bundle is larger than {MAX_TOTAL} bytes")
            seen: set[str] = set()
            for member in members:
                dynamic_deep = kind in (None, "deep") and _deep_member_allowed(member.name, root)
                if member.name in seen:
                    raise BundleError(f"{member.name!r} occurs more than once")
                seen.add(member.name)
                if member.name not in allowed and not dynamic_deep:
                    raise BundleError(f"{member.name!r} is not an allowed evidence file")
                if not member.isreg():
                    raise BundleError(f"{member.name} is not a regular file")
                if member.size > MAX_MEMBER:
                    raise BundleError(f"{member.name} is larger than {MAX_MEMBER} bytes")
            for member in members:
                target = root / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cast(IO[bytes], archive.extractfile(member)).read())
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise BundleError(None) from exc
    return [member.name for member in members]

mutants_x_unpack__mutmut['_mutmut_orig'] = x_unpack__mutmut_orig # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_1'] = x_unpack__mutmut_1 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_2'] = x_unpack__mutmut_2 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_3'] = x_unpack__mutmut_3 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_4'] = x_unpack__mutmut_4 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_5'] = x_unpack__mutmut_5 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_6'] = x_unpack__mutmut_6 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_7'] = x_unpack__mutmut_7 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_8'] = x_unpack__mutmut_8 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_9'] = x_unpack__mutmut_9 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_10'] = x_unpack__mutmut_10 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_11'] = x_unpack__mutmut_11 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_12'] = x_unpack__mutmut_12 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_13'] = x_unpack__mutmut_13 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_14'] = x_unpack__mutmut_14 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_15'] = x_unpack__mutmut_15 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_16'] = x_unpack__mutmut_16 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_17'] = x_unpack__mutmut_17 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_18'] = x_unpack__mutmut_18 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_19'] = x_unpack__mutmut_19 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_20'] = x_unpack__mutmut_20 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_21'] = x_unpack__mutmut_21 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_22'] = x_unpack__mutmut_22 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_23'] = x_unpack__mutmut_23 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_24'] = x_unpack__mutmut_24 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_25'] = x_unpack__mutmut_25 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_26'] = x_unpack__mutmut_26 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_27'] = x_unpack__mutmut_27 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_28'] = x_unpack__mutmut_28 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_29'] = x_unpack__mutmut_29 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_30'] = x_unpack__mutmut_30 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_31'] = x_unpack__mutmut_31 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_32'] = x_unpack__mutmut_32 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_33'] = x_unpack__mutmut_33 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_34'] = x_unpack__mutmut_34 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_35'] = x_unpack__mutmut_35 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_36'] = x_unpack__mutmut_36 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_37'] = x_unpack__mutmut_37 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_38'] = x_unpack__mutmut_38 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_39'] = x_unpack__mutmut_39 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_40'] = x_unpack__mutmut_40 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_41'] = x_unpack__mutmut_41 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_42'] = x_unpack__mutmut_42 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_43'] = x_unpack__mutmut_43 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_44'] = x_unpack__mutmut_44 # type: ignore # mutmut generated
mutants_x_unpack__mutmut['x_unpack__mutmut_45'] = x_unpack__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = None
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest=None, required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=None)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", )
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="XXcommandXX", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="COMMAND", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=False)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = None
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser(None, help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help=None)
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser(help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", )
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("XXpackXX", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("PACK", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="XXarchive the evidence files of one kindXX")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="ARCHIVE THE EVIDENCE FILES OF ONE KIND")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument(None, choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=None)
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument(choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", )
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("XXkindXX", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("KIND", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(None))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument(None, type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=None, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=None)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument(type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, )
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("XX--rootXX", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--ROOT", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument(None, type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=None, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=None)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument(type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, )
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("XX--outputXX", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--OUTPUT", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=False)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument(None, action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action=None, help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help=None)
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument(action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", )
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("XX--allow-missingXX", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--ALLOW-MISSING", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="XXstore_trueXX", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="STORE_TRUE", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="XXskip files a failed job lacksXX")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="SKIP FILES A FAILED JOB LACKS")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = None
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser(None, help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help=None)
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser(help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", )
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("XXunpackXX", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("UNPACK", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="XXextract an archive that holds only evidence filesXX")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="EXTRACT AN ARCHIVE THAT HOLDS ONLY EVIDENCE FILES")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument(None, type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=None)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument(type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", )
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("XXbundleXX", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("BUNDLE", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument(None, type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=None, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=None)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument(type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, )
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("XX--rootXX", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--ROOT", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument(None, choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=None)
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument(choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", )
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("XX--kindXX", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--KIND", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(None))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = None
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(None)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command != "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "XXpackXX":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "PACK":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(None, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, None, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, None, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, None)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, )
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(None)
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(None, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, None, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, None):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_105(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, ):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_106(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(None)
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 0


def x_main__mutmut_107(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(None)
        return 1
    return 0


def x_main__mutmut_108(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 2
    return 0


def x_main__mutmut_109(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("pack", help="archive the evidence files of one kind")
    make.add_argument("kind", choices=sorted(KINDS))
    make.add_argument("--root", type=Path, default=ROOT)
    make.add_argument("--output", type=Path, required=True)
    make.add_argument("--allow-missing", action="store_true", help="skip files a failed job lacks")
    take = sub.add_parser("unpack", help="extract an archive that holds only evidence files")
    take.add_argument("bundle", type=Path)
    take.add_argument("--root", type=Path, default=ROOT)
    take.add_argument("--kind", choices=sorted(KINDS))
    args = parser.parse_args(argv)
    try:
        if args.command == "pack":
            pack(args.kind, args.root, args.output, args.allow_missing)
            print(f"packed {args.kind} evidence into {args.output}")
        else:
            for name in unpack(args.bundle, args.root, args.kind):
                print(f"unpacked {name}")
    except BundleError as exc:
        print(f"REFUSED: {exc}")
        return 1
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
