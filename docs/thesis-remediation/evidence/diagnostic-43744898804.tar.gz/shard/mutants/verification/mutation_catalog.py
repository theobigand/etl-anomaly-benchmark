"""Reconcile mutmut 3.8 native catalogs without asserting execution provenance.

The generation index is independent of verdict counts. Parsing it cannot prove
that execution is current: the promotion layer must validate that separately.
"""

from __future__ import annotations

import ast
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

from verification.mutation_policy import _identity, _module, validate_policy

NATIVE_OUTCOMES = (
    "killed",
    "survived",
    "no_tests",
    "skipped",
    "suspicious",
    "timeout",
    "check_was_interrupted_by_user",
    "segfault",
)
META_FIELDS = {
    "exit_code_by_key",
    "hash_by_function_name",
    "type_check_error_by_key",
    "durations_by_key",
    "estimated_durations_by_key",
}
NATIVE_STATUS = {
    1: "killed",
    3: "killed",
    0: "survived",
    5: "no tests",
    33: "no tests",
    2: "check was interrupted by user",
    None: "not checked",
    34: "skipped",
    35: "suspicious",
    36: "timeout",
    37: "caught by type check",
    -24: "timeout",
    24: "timeout",
    152: "timeout",
    255: "timeout",
    -11: "segfault",
    -9: "segfault",
}


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x__pairs__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__pairs__mutmut)
def _pairs(items: list[tuple]) -> dict:
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError(f"duplicate native JSON field: {key}")
        result[key] = value
    return result


def x__pairs__mutmut_orig(items: list[tuple]) -> dict:
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError(f"duplicate native JSON field: {key}")
        result[key] = value
    return result


def x__pairs__mutmut_1(items: list[tuple]) -> dict:
    result = None
    for key, value in items:
        if key in result:
            raise ValueError(f"duplicate native JSON field: {key}")
        result[key] = value
    return result


def x__pairs__mutmut_2(items: list[tuple]) -> dict:
    result = {}
    for key, value in items:
        if key not in result:
            raise ValueError(f"duplicate native JSON field: {key}")
        result[key] = value
    return result


def x__pairs__mutmut_3(items: list[tuple]) -> dict:
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError(None)
        result[key] = value
    return result


def x__pairs__mutmut_4(items: list[tuple]) -> dict:
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError(f"duplicate native JSON field: {key}")
        result[key] = None
    return result

mutants_x__pairs__mutmut['_mutmut_orig'] = x__pairs__mutmut_orig # type: ignore # mutmut generated
mutants_x__pairs__mutmut['x__pairs__mutmut_1'] = x__pairs__mutmut_1 # type: ignore # mutmut generated
mutants_x__pairs__mutmut['x__pairs__mutmut_2'] = x__pairs__mutmut_2 # type: ignore # mutmut generated
mutants_x__pairs__mutmut['x__pairs__mutmut_3'] = x__pairs__mutmut_3 # type: ignore # mutmut generated
mutants_x__pairs__mutmut['x__pairs__mutmut_4'] = x__pairs__mutmut_4 # type: ignore # mutmut generated
mutants_x__read__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__read__mutmut)
def _read(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_orig(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_1(cache: Path, relative: str, artifacts: dict) -> dict:
    path = None
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_2(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache * relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_3(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() and not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_4(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_5(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(None):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_6(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError(None)
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_7(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("XXnative catalog paths must stay inside the cacheXX")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_8(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("NATIVE CATALOG PATHS MUST STAY INSIDE THE CACHE")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_9(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = None
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_10(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(None) from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_11(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = None
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_12(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(None, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_13(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=None)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_14(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_15(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, )
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_16(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_17(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError(None)
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_18(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("XXnative catalog files must be JSON objectsXX")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_19(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be json objects")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_20(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("NATIVE CATALOG FILES MUST BE JSON OBJECTS")
    artifacts[relative] = hashlib.sha256(content).hexdigest()
    return data


def x__read__mutmut_21(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = None
    return data


def x__read__mutmut_22(cache: Path, relative: str, artifacts: dict) -> dict:
    path = cache / relative
    if path.is_symlink() or not path.resolve().is_relative_to(cache.resolve()):
        raise ValueError("native catalog paths must stay inside the cache")
    try:
        content = path.read_bytes()
    except OSError as error:
        raise ValueError(f"native catalog file unavailable: {relative}") from error
    data = json.loads(content, object_pairs_hook=_pairs)
    if not isinstance(data, dict):
        raise ValueError("native catalog files must be JSON objects")
    artifacts[relative] = hashlib.sha256(None).hexdigest()
    return data

mutants_x__read__mutmut['_mutmut_orig'] = x__read__mutmut_orig # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_1'] = x__read__mutmut_1 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_2'] = x__read__mutmut_2 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_3'] = x__read__mutmut_3 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_4'] = x__read__mutmut_4 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_5'] = x__read__mutmut_5 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_6'] = x__read__mutmut_6 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_7'] = x__read__mutmut_7 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_8'] = x__read__mutmut_8 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_9'] = x__read__mutmut_9 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_10'] = x__read__mutmut_10 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_11'] = x__read__mutmut_11 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_12'] = x__read__mutmut_12 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_13'] = x__read__mutmut_13 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_14'] = x__read__mutmut_14 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_15'] = x__read__mutmut_15 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_16'] = x__read__mutmut_16 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_17'] = x__read__mutmut_17 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_18'] = x__read__mutmut_18 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_19'] = x__read__mutmut_19 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_20'] = x__read__mutmut_20 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_21'] = x__read__mutmut_21 # type: ignore # mutmut generated
mutants_x__read__mutmut['x__read__mutmut_22'] = x__read__mutmut_22 # type: ignore # mutmut generated
mutants_x__index__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__index__mutmut)
def _index(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_orig(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_1(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int and data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_2(data: dict, path: str) -> set[str]:
    if type(None) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_3(data: dict, path: str) -> set[str]:
    if type(data.get(None)) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_4(data: dict, path: str) -> set[str]:
    if type(data.get("XXversionXX")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_5(data: dict, path: str) -> set[str]:
    if type(data.get("VERSION")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_6(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_7(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["XXversionXX"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_8(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["VERSION"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_9(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] == 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_10(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 2:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_11(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError(None)
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_12(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("XXunsupported native generation index versionXX")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_13(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("UNSUPPORTED NATIVE GENERATION INDEX VERSION")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_14(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = None
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_15(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get(None)
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_16(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("XXspansXX")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_17(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("SPANS")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_18(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_19(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError(None)
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_20(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("XXnative generation index must record spansXX")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_21(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("NATIVE GENERATION INDEX MUST RECORD SPANS")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_22(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = None
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_23(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span) and span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_24(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2 and any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_25(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list) and len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_26(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_27(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) == 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_28(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 3
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_29(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(None)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_30(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int and value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_31(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(None) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_32(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_33(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value < 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_34(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 1 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_35(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[2] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_36(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] <= span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_37(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[1]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_38(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError(None)
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_39(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("XXinvalid native source spanXX")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_40(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("INVALID NATIVE SOURCE SPAN")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_41(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_42(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(None, local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_43(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", None):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_44(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_45(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", ):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_46(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r"XX.+__mutmut_(?:orig|[1-9][0-9]*)XX", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_47(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__MUTMUT_(?:ORIG|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_48(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError(None)
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_49(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("XXunknown native generation index identityXX")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_50(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("UNKNOWN NATIVE GENERATION INDEX IDENTITY")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_51(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith(None):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_52(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("XX__mutmut_origXX"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_53(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__MUTMUT_ORIG"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_54(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            break
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_55(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = None
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_56(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." - local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_57(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) - "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_58(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(None) + "." + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_59(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "XX.XX" + local
        _identity(key, path)
        keys.add(key)
    return keys


def x__index__mutmut_60(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(None, path)
        keys.add(key)
    return keys


def x__index__mutmut_61(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, None)
        keys.add(key)
    return keys


def x__index__mutmut_62(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(path)
        keys.add(key)
    return keys


def x__index__mutmut_63(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, )
        keys.add(key)
    return keys


def x__index__mutmut_64(data: dict, path: str) -> set[str]:
    if type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("unsupported native generation index version")
    spans = data.get("spans")
    if not isinstance(spans, dict):
        raise ValueError("native generation index must record spans")
    keys = set()
    for local, span in spans.items():
        if (
            not isinstance(span, list)
            or len(span) != 2
            or any(type(value) is not int or value <= 0 for value in span)
            or span[1] < span[0]
        ):
            raise ValueError("invalid native source span")
        if not re.fullmatch(r".+__mutmut_(?:orig|[1-9][0-9]*)", local):
            raise ValueError("unknown native generation index identity")
        if local.endswith("__mutmut_orig"):
            continue
        key = _module(path) + "." + local
        _identity(key, path)
        keys.add(None)
    return keys

mutants_x__index__mutmut['_mutmut_orig'] = x__index__mutmut_orig # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_1'] = x__index__mutmut_1 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_2'] = x__index__mutmut_2 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_3'] = x__index__mutmut_3 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_4'] = x__index__mutmut_4 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_5'] = x__index__mutmut_5 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_6'] = x__index__mutmut_6 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_7'] = x__index__mutmut_7 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_8'] = x__index__mutmut_8 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_9'] = x__index__mutmut_9 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_10'] = x__index__mutmut_10 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_11'] = x__index__mutmut_11 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_12'] = x__index__mutmut_12 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_13'] = x__index__mutmut_13 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_14'] = x__index__mutmut_14 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_15'] = x__index__mutmut_15 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_16'] = x__index__mutmut_16 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_17'] = x__index__mutmut_17 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_18'] = x__index__mutmut_18 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_19'] = x__index__mutmut_19 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_20'] = x__index__mutmut_20 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_21'] = x__index__mutmut_21 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_22'] = x__index__mutmut_22 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_23'] = x__index__mutmut_23 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_24'] = x__index__mutmut_24 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_25'] = x__index__mutmut_25 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_26'] = x__index__mutmut_26 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_27'] = x__index__mutmut_27 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_28'] = x__index__mutmut_28 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_29'] = x__index__mutmut_29 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_30'] = x__index__mutmut_30 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_31'] = x__index__mutmut_31 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_32'] = x__index__mutmut_32 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_33'] = x__index__mutmut_33 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_34'] = x__index__mutmut_34 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_35'] = x__index__mutmut_35 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_36'] = x__index__mutmut_36 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_37'] = x__index__mutmut_37 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_38'] = x__index__mutmut_38 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_39'] = x__index__mutmut_39 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_40'] = x__index__mutmut_40 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_41'] = x__index__mutmut_41 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_42'] = x__index__mutmut_42 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_43'] = x__index__mutmut_43 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_44'] = x__index__mutmut_44 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_45'] = x__index__mutmut_45 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_46'] = x__index__mutmut_46 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_47'] = x__index__mutmut_47 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_48'] = x__index__mutmut_48 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_49'] = x__index__mutmut_49 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_50'] = x__index__mutmut_50 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_51'] = x__index__mutmut_51 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_52'] = x__index__mutmut_52 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_53'] = x__index__mutmut_53 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_54'] = x__index__mutmut_54 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_55'] = x__index__mutmut_55 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_56'] = x__index__mutmut_56 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_57'] = x__index__mutmut_57 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_58'] = x__index__mutmut_58 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_59'] = x__index__mutmut_59 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_60'] = x__index__mutmut_60 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_61'] = x__index__mutmut_61 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_62'] = x__index__mutmut_62 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_63'] = x__index__mutmut_63 # type: ignore # mutmut generated
mutants_x__index__mutmut['x__index__mutmut_64'] = x__index__mutmut_64 # type: ignore # mutmut generated
mutants_x__listing__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__listing__mutmut)
def _listing(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_orig(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_1(text: str) -> dict:
    if isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_2(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError(None)
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_3(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("XXnative result listing must be textXX")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_4(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("NATIVE RESULT LISTING MUST BE TEXT")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_5(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = None
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_6(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_7(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            break
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_8(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = None
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_9(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(None)
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_10(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().rpartition(": ")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_11(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition("XX: XX")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_12(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator and key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_13(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_14(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key not in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = outcome
    return result


def x__listing__mutmut_15(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError(None)
        result[key] = outcome
    return result


def x__listing__mutmut_16(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("XXinvalid or duplicated native result listingXX")
        result[key] = outcome
    return result


def x__listing__mutmut_17(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("INVALID OR DUPLICATED NATIVE RESULT LISTING")
        result[key] = outcome
    return result


def x__listing__mutmut_18(text: str) -> dict:
    if not isinstance(text, str):
        raise ValueError("native result listing must be text")
    result = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        key, separator, outcome = line.strip().partition(": ")
        if not separator or key in result:
            raise ValueError("invalid or duplicated native result listing")
        result[key] = None
    return result

mutants_x__listing__mutmut['_mutmut_orig'] = x__listing__mutmut_orig # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_1'] = x__listing__mutmut_1 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_2'] = x__listing__mutmut_2 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_3'] = x__listing__mutmut_3 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_4'] = x__listing__mutmut_4 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_5'] = x__listing__mutmut_5 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_6'] = x__listing__mutmut_6 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_7'] = x__listing__mutmut_7 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_8'] = x__listing__mutmut_8 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_9'] = x__listing__mutmut_9 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_10'] = x__listing__mutmut_10 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_11'] = x__listing__mutmut_11 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_12'] = x__listing__mutmut_12 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_13'] = x__listing__mutmut_13 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_14'] = x__listing__mutmut_14 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_15'] = x__listing__mutmut_15 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_16'] = x__listing__mutmut_16 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_17'] = x__listing__mutmut_17 # type: ignore # mutmut generated
mutants_x__listing__mutmut['x__listing__mutmut_18'] = x__listing__mutmut_18 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__function_hashes__mutmut)
def _function_hashes(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_orig(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_1(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = None

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_2(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = None
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_3(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if (owners) and False else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_4(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if (owners) or True else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_5(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) - "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_6(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" - ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_7(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "XXxǁXX" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_8(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "Xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_9(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(None) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_10(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + "XX.XX".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_11(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "XXǁXX" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_12(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "XXx_XX"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_13(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "X_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_14(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = None
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_15(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix - node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_16(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    None
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_17(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(None, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_18(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=None).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_19(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_20(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, ).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_21(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=True).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_22(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:13]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_23(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(None, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_24(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, None)

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_25(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit((*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_26(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, )

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_27(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = None
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_28(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(None)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_29(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError(None) from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_30(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("XXcurrent source is not parseableXX") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_31(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("CURRENT SOURCE IS NOT PARSEABLE") from error
    visit(tree.body, ())
    return hashes


def x__function_hashes__mutmut_32(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(None, ())
    return hashes


def x__function_hashes__mutmut_33(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, None)
    return hashes


def x__function_hashes__mutmut_34(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(())
    return hashes


def x__function_hashes__mutmut_35(source: str) -> dict[str, str]:
    """Independent check of mutmut 3.8's function-AST fingerprint format.

    This binds generated functions, not module globals or past test execution.
    Full-file and execution-context binding remains a promotion requirement.
    """
    hashes = {}

    def visit(nodes: list[ast.stmt], owners: tuple[str, ...]) -> None:
        for node in nodes:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                prefix = "xǁ" + ".".join(owners) + "ǁ" if owners else "x_"
                hashes[prefix + node.name] = hashlib.sha256(
                    ast.dump(node, annotate_fields=False).encode()
                ).hexdigest()[:12]
            elif isinstance(node, ast.ClassDef):
                visit(node.body, (*owners, node.name))

    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        raise ValueError("current source is not parseable") from error
    visit(tree.body, )
    return hashes

mutants_x__function_hashes__mutmut['_mutmut_orig'] = x__function_hashes__mutmut_orig # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_1'] = x__function_hashes__mutmut_1 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_2'] = x__function_hashes__mutmut_2 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_3'] = x__function_hashes__mutmut_3 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_4'] = x__function_hashes__mutmut_4 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_5'] = x__function_hashes__mutmut_5 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_6'] = x__function_hashes__mutmut_6 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_7'] = x__function_hashes__mutmut_7 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_8'] = x__function_hashes__mutmut_8 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_9'] = x__function_hashes__mutmut_9 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_10'] = x__function_hashes__mutmut_10 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_11'] = x__function_hashes__mutmut_11 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_12'] = x__function_hashes__mutmut_12 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_13'] = x__function_hashes__mutmut_13 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_14'] = x__function_hashes__mutmut_14 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_15'] = x__function_hashes__mutmut_15 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_16'] = x__function_hashes__mutmut_16 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_17'] = x__function_hashes__mutmut_17 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_18'] = x__function_hashes__mutmut_18 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_19'] = x__function_hashes__mutmut_19 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_20'] = x__function_hashes__mutmut_20 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_21'] = x__function_hashes__mutmut_21 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_22'] = x__function_hashes__mutmut_22 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_23'] = x__function_hashes__mutmut_23 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_24'] = x__function_hashes__mutmut_24 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_25'] = x__function_hashes__mutmut_25 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_26'] = x__function_hashes__mutmut_26 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_27'] = x__function_hashes__mutmut_27 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_28'] = x__function_hashes__mutmut_28 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_29'] = x__function_hashes__mutmut_29 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_30'] = x__function_hashes__mutmut_30 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_31'] = x__function_hashes__mutmut_31 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_32'] = x__function_hashes__mutmut_32 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_33'] = x__function_hashes__mutmut_33 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_34'] = x__function_hashes__mutmut_34 # type: ignore # mutmut generated
mutants_x__function_hashes__mutmut['x__function_hashes__mutmut_35'] = x__function_hashes__mutmut_35 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_metadata_digest__mutmut)
def metadata_digest(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_orig(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_1(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = None
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_2(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("XXexit_code_by_keyXX", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_3(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("EXIT_CODE_BY_KEY", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_4(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "XXhash_by_function_nameXX")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_5(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "HASH_BY_FUNCTION_NAME")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_6(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        None
    ).hexdigest()


def x_metadata_digest__mutmut_7(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(None, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_8(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=None, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_9(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=None, allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_10(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=None).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_11(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_12(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_13(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_14(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_15(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=False, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_16(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=("XX,XX", ":"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_17(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", "XX:XX"), allow_nan=False).encode()
    ).hexdigest()


def x_metadata_digest__mutmut_18(data: dict) -> str:
    """Bind verdicts and original function hashes, excluding timing telemetry."""
    payload = {name: data[name] for name in ("exit_code_by_key", "hash_by_function_name")}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=True).encode()
    ).hexdigest()

mutants_x_metadata_digest__mutmut['_mutmut_orig'] = x_metadata_digest__mutmut_orig # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_1'] = x_metadata_digest__mutmut_1 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_2'] = x_metadata_digest__mutmut_2 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_3'] = x_metadata_digest__mutmut_3 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_4'] = x_metadata_digest__mutmut_4 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_5'] = x_metadata_digest__mutmut_5 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_6'] = x_metadata_digest__mutmut_6 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_7'] = x_metadata_digest__mutmut_7 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_8'] = x_metadata_digest__mutmut_8 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_9'] = x_metadata_digest__mutmut_9 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_10'] = x_metadata_digest__mutmut_10 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_11'] = x_metadata_digest__mutmut_11 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_12'] = x_metadata_digest__mutmut_12 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_13'] = x_metadata_digest__mutmut_13 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_14'] = x_metadata_digest__mutmut_14 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_15'] = x_metadata_digest__mutmut_15 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_16'] = x_metadata_digest__mutmut_16 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_17'] = x_metadata_digest__mutmut_17 # type: ignore # mutmut generated
mutants_x_metadata_digest__mutmut['x_metadata_digest__mutmut_18'] = x_metadata_digest__mutmut_18 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_read_modules__mutmut)
def read_modules(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_orig(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_1(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = None
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_2(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = None
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_3(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = None
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_4(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = None
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_5(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(None):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_6(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["XXunitsXX"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_7(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["UNITS"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_8(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None or path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_9(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_10(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_11(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            break
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_12(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = None
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_13(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = None
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_14(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache * f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_15(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() or not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_16(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_17(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_18(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "XXno_mutantsXX" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_19(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "NO_MUTANTS" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_20(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_21(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(None)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_22(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            break
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_23(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = None
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_24(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(None, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_25(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, None, artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_26(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", None)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_27(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_28(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_29(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", )
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_30(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS and any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_31(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(None) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_32(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) == META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_33(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(None):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_34(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_35(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError(None)
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_36(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("XXinvalid native metadata structureXX")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_37(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("INVALID NATIVE METADATA STRUCTURE")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_38(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = None
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_39(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(None)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_40(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = None
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_41(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["XXexit_code_by_keyXX"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_42(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["EXIT_CODE_BY_KEY"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_43(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = None
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_44(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(None, path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_45(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), None)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_46(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_47(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), )
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_48(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(None, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_49(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, None, artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_50(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", None), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_51(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_52(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_53(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", ), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_54(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(None) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_55(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) == generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_56(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError(None)
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_57(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("XXverdict population differs from native generation indexXX")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_58(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("VERDICT POPULATION DIFFERS FROM NATIVE GENERATION INDEX")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_59(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = None
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_60(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(None) for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_61(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removesuffix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_62(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit(None, 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_63(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", None)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_64(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit(1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_65(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", )[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_66(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.split("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_67(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("XX__mutmut_XX", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_68(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__MUTMUT_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_69(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 2)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_70(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[1].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_71(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) - ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_72(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(None) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_73(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + "XX.XX") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_74(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = None
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_75(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["XXhash_by_function_nameXX"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_76(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["HASH_BY_FUNCTION_NAME"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_77(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions and any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_78(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(None) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_79(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) == functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_80(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            None
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_81(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) and not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_82(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_83(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_84(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(None, value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_85(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", None)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_86(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_87(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", )
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_88(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"XX[0-9a-f]{12}XX", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_89(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9A-F]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_90(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError(None)
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_91(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("XXnative function hashes do not bind the generated catalogXX")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_92(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("NATIVE FUNCTION HASHES DO NOT BIND THE GENERATED CATALOG")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_93(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit or verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_94(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "XXno_mutantsXX" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_95(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "NO_MUTANTS" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_96(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" not in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_97(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError(None)
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_98(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("XXtechnical no-mutant scope received mutantsXX")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_99(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("TECHNICAL NO-MUTANT SCOPE RECEIVED MUTANTS")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_100(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = None
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_101(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes(None)
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_102(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root * path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_103(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(None):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_104(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(None) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_105(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) == value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_106(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError(None)
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_107(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("XXnative function hashes differ from current sourceXX")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_108(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("NATIVE FUNCTION HASHES DIFFER FROM CURRENT SOURCE")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_109(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = None
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_110(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(None)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_111(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(None):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_112(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None or type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_113(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_114(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(None) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_115(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_116(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError(None)
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_117(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("XXnative exit codes must be integers or nullXX")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_118(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("NATIVE EXIT CODES MUST BE INTEGERS OR NULL")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_119(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = None
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_120(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(None, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_121(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, None)
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_122(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get("suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_123(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, )
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_124(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "XXsuspiciousXX")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_125(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "SUSPICIOUS")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_126(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = None
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_127(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = None
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_128(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if (code == 3 or code not in NATIVE_STATUS) and False else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_129(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if (code == 3 or code not in NATIVE_STATUS) or True else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_130(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "XXerrorXX" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_131(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "ERROR" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_132(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 and code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_133(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code != 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_134(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 4 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_135(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_136(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append(None)
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_137(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"XXidXX": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_138(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"ID": key, "path": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_139(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "XXpathXX": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_140(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "PATH": path, "outcome": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_141(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "XXoutcomeXX": outcome})
    return catalog, records, native, missing, artifacts, metadata


def x_read_modules__mutmut_142(
    policy: dict, root: Path, cache: Path, only: set[str] | None = None
) -> tuple[dict, list, dict, list, dict, dict]:
    """Read the generation index and verdict metadata of the selected modules."""
    catalog: dict[str, list[str]] = {}
    artifacts: dict[str, str] = {}
    metadata: dict[str, str] = {}
    records, native, missing = [], {}, []
    for path, unit in sorted(policy["units"].items()):
        if only is not None and path not in only:
            continue
        catalog[path] = []
        meta_path = cache / f"{path}.meta"
        if not meta_path.exists() and not meta_path.is_symlink():
            if "no_mutants" not in unit:
                missing.append(path)
            continue
        meta = _read(cache, f"{path}.meta", artifacts)
        if set(meta) != META_FIELDS or any(not isinstance(value, dict) for value in meta.values()):
            raise ValueError("invalid native metadata structure")
        metadata[f"{path}.meta"] = metadata_digest(meta)
        verdicts = meta["exit_code_by_key"]
        generated = _index(_read(cache, f"{path}.spans", artifacts), path)
        if set(verdicts) != generated:
            raise ValueError("verdict population differs from native generation index")
        functions = {
            key.rsplit("__mutmut_", 1)[0].removeprefix(_module(path) + ".") for key in generated
        }
        hashes = meta["hash_by_function_name"]
        if set(hashes) != functions or any(
            not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{12}", value)
            for value in hashes.values()
        ):
            raise ValueError("native function hashes do not bind the generated catalog")
        if "no_mutants" in unit and verdicts:
            raise ValueError("technical no-mutant scope received mutants")
        current = _function_hashes((root / path).read_text())
        if any(current.get(name) != value for name, value in hashes.items()):
            raise ValueError("native function hashes differ from current source")
        catalog[path] = sorted(generated)
        for key, code in sorted(verdicts.items()):
            if code is not None and type(code) is not int:
                raise ValueError("native exit codes must be integers or null")
            native_status = NATIVE_STATUS.get(code, "suspicious")
            native[key] = native_status
            outcome = "error" if code == 3 or code not in NATIVE_STATUS else native_status
            records.append({"id": key, "path": path, "OUTCOME": outcome})
    return catalog, records, native, missing, artifacts, metadata

mutants_x_read_modules__mutmut['_mutmut_orig'] = x_read_modules__mutmut_orig # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_1'] = x_read_modules__mutmut_1 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_2'] = x_read_modules__mutmut_2 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_3'] = x_read_modules__mutmut_3 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_4'] = x_read_modules__mutmut_4 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_5'] = x_read_modules__mutmut_5 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_6'] = x_read_modules__mutmut_6 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_7'] = x_read_modules__mutmut_7 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_8'] = x_read_modules__mutmut_8 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_9'] = x_read_modules__mutmut_9 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_10'] = x_read_modules__mutmut_10 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_11'] = x_read_modules__mutmut_11 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_12'] = x_read_modules__mutmut_12 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_13'] = x_read_modules__mutmut_13 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_14'] = x_read_modules__mutmut_14 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_15'] = x_read_modules__mutmut_15 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_16'] = x_read_modules__mutmut_16 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_17'] = x_read_modules__mutmut_17 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_18'] = x_read_modules__mutmut_18 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_19'] = x_read_modules__mutmut_19 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_20'] = x_read_modules__mutmut_20 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_21'] = x_read_modules__mutmut_21 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_22'] = x_read_modules__mutmut_22 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_23'] = x_read_modules__mutmut_23 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_24'] = x_read_modules__mutmut_24 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_25'] = x_read_modules__mutmut_25 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_26'] = x_read_modules__mutmut_26 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_27'] = x_read_modules__mutmut_27 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_28'] = x_read_modules__mutmut_28 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_29'] = x_read_modules__mutmut_29 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_30'] = x_read_modules__mutmut_30 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_31'] = x_read_modules__mutmut_31 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_32'] = x_read_modules__mutmut_32 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_33'] = x_read_modules__mutmut_33 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_34'] = x_read_modules__mutmut_34 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_35'] = x_read_modules__mutmut_35 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_36'] = x_read_modules__mutmut_36 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_37'] = x_read_modules__mutmut_37 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_38'] = x_read_modules__mutmut_38 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_39'] = x_read_modules__mutmut_39 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_40'] = x_read_modules__mutmut_40 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_41'] = x_read_modules__mutmut_41 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_42'] = x_read_modules__mutmut_42 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_43'] = x_read_modules__mutmut_43 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_44'] = x_read_modules__mutmut_44 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_45'] = x_read_modules__mutmut_45 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_46'] = x_read_modules__mutmut_46 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_47'] = x_read_modules__mutmut_47 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_48'] = x_read_modules__mutmut_48 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_49'] = x_read_modules__mutmut_49 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_50'] = x_read_modules__mutmut_50 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_51'] = x_read_modules__mutmut_51 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_52'] = x_read_modules__mutmut_52 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_53'] = x_read_modules__mutmut_53 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_54'] = x_read_modules__mutmut_54 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_55'] = x_read_modules__mutmut_55 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_56'] = x_read_modules__mutmut_56 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_57'] = x_read_modules__mutmut_57 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_58'] = x_read_modules__mutmut_58 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_59'] = x_read_modules__mutmut_59 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_60'] = x_read_modules__mutmut_60 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_61'] = x_read_modules__mutmut_61 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_62'] = x_read_modules__mutmut_62 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_63'] = x_read_modules__mutmut_63 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_64'] = x_read_modules__mutmut_64 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_65'] = x_read_modules__mutmut_65 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_66'] = x_read_modules__mutmut_66 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_67'] = x_read_modules__mutmut_67 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_68'] = x_read_modules__mutmut_68 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_69'] = x_read_modules__mutmut_69 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_70'] = x_read_modules__mutmut_70 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_71'] = x_read_modules__mutmut_71 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_72'] = x_read_modules__mutmut_72 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_73'] = x_read_modules__mutmut_73 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_74'] = x_read_modules__mutmut_74 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_75'] = x_read_modules__mutmut_75 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_76'] = x_read_modules__mutmut_76 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_77'] = x_read_modules__mutmut_77 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_78'] = x_read_modules__mutmut_78 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_79'] = x_read_modules__mutmut_79 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_80'] = x_read_modules__mutmut_80 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_81'] = x_read_modules__mutmut_81 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_82'] = x_read_modules__mutmut_82 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_83'] = x_read_modules__mutmut_83 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_84'] = x_read_modules__mutmut_84 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_85'] = x_read_modules__mutmut_85 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_86'] = x_read_modules__mutmut_86 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_87'] = x_read_modules__mutmut_87 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_88'] = x_read_modules__mutmut_88 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_89'] = x_read_modules__mutmut_89 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_90'] = x_read_modules__mutmut_90 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_91'] = x_read_modules__mutmut_91 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_92'] = x_read_modules__mutmut_92 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_93'] = x_read_modules__mutmut_93 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_94'] = x_read_modules__mutmut_94 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_95'] = x_read_modules__mutmut_95 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_96'] = x_read_modules__mutmut_96 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_97'] = x_read_modules__mutmut_97 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_98'] = x_read_modules__mutmut_98 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_99'] = x_read_modules__mutmut_99 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_100'] = x_read_modules__mutmut_100 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_101'] = x_read_modules__mutmut_101 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_102'] = x_read_modules__mutmut_102 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_103'] = x_read_modules__mutmut_103 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_104'] = x_read_modules__mutmut_104 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_105'] = x_read_modules__mutmut_105 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_106'] = x_read_modules__mutmut_106 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_107'] = x_read_modules__mutmut_107 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_108'] = x_read_modules__mutmut_108 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_109'] = x_read_modules__mutmut_109 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_110'] = x_read_modules__mutmut_110 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_111'] = x_read_modules__mutmut_111 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_112'] = x_read_modules__mutmut_112 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_113'] = x_read_modules__mutmut_113 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_114'] = x_read_modules__mutmut_114 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_115'] = x_read_modules__mutmut_115 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_116'] = x_read_modules__mutmut_116 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_117'] = x_read_modules__mutmut_117 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_118'] = x_read_modules__mutmut_118 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_119'] = x_read_modules__mutmut_119 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_120'] = x_read_modules__mutmut_120 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_121'] = x_read_modules__mutmut_121 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_122'] = x_read_modules__mutmut_122 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_123'] = x_read_modules__mutmut_123 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_124'] = x_read_modules__mutmut_124 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_125'] = x_read_modules__mutmut_125 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_126'] = x_read_modules__mutmut_126 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_127'] = x_read_modules__mutmut_127 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_128'] = x_read_modules__mutmut_128 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_129'] = x_read_modules__mutmut_129 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_130'] = x_read_modules__mutmut_130 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_131'] = x_read_modules__mutmut_131 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_132'] = x_read_modules__mutmut_132 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_133'] = x_read_modules__mutmut_133 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_134'] = x_read_modules__mutmut_134 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_135'] = x_read_modules__mutmut_135 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_136'] = x_read_modules__mutmut_136 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_137'] = x_read_modules__mutmut_137 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_138'] = x_read_modules__mutmut_138 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_139'] = x_read_modules__mutmut_139 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_140'] = x_read_modules__mutmut_140 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_141'] = x_read_modules__mutmut_141 # type: ignore # mutmut generated
mutants_x_read_modules__mutmut['x_read_modules__mutmut_142'] = x_read_modules__mutmut_142 # type: ignore # mutmut generated
mutants_x_read_native__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_read_native__mutmut)
def read_native(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_orig(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_1(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(None, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_2(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, None)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_3(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_4(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, )
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_5(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES} and any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_6(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict) and set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_7(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_8(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(None) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_9(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) == {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_10(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"XXtotalXX", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_11(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"TOTAL", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_12(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(None)
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_13(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int and value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_14(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(None) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_15(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_16(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value <= 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_17(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 1 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_18(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError(None)
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_19(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("XXinvalid native mutation statisticsXX")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_20(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("INVALID NATIVE MUTATION STATISTICS")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_21(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = None
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_22(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(None, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_23(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, None, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_24(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, None)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_25(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_26(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_27(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, )
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_28(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(None) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_29(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) == native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_30(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError(None)
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_31(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("XXfull native listing differs from verdict metadataXX")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_32(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("FULL NATIVE LISTING DIFFERS FROM VERDICT METADATA")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_33(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = None
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_34(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(None)
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_35(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(None, "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_36(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", None) for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_37(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace("_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_38(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", ) for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_39(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace("XX XX", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_40(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "XX_XX") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_41(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = None
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_42(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"XXtotalXX": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_43(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"TOTAL": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_44(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats == expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_45(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError(None)
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_46(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("XXnative statistics differ from catalog outcomesXX")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_47(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("NATIVE STATISTICS DIFFER FROM CATALOG OUTCOMES")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_48(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "XXcatalogXX": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_49(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "CATALOG": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_50(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "XXrecordsXX": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_51(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "RECORDS": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_52(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "XXmissingXX": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_53(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "MISSING": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_54(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "XXnative_statsXX": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_55(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "NATIVE_STATS": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_56(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(None),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_57(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "XXartifactsXX": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_58(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "ARTIFACTS": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_59(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "XXmetadata_sha256XX": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_60(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "METADATA_SHA256": metadata,
        "execution_provenance_verified": False,
    }


def x_read_native__mutmut_61(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "XXexecution_provenance_verifiedXX": False,
    }


def x_read_native__mutmut_62(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "EXECUTION_PROVENANCE_VERIFIED": False,
    }


def x_read_native__mutmut_63(policy: dict, root: Path, cache: Path, stats: dict, listing: str) -> dict:
    """Require agreement of generation index, verdict metadata, counts and listing.

    Native pytest-internal-error code 3 and unknown exit codes are error outcomes,
    never successful kills. Preserve native counts separately for reconciliation.
    """
    validate_policy(policy, root)
    if (
        not isinstance(stats, dict)
        or set(stats) != {"total", *NATIVE_OUTCOMES}
        or any(type(value) is not int or value < 0 for value in stats.values())
    ):
        raise ValueError("invalid native mutation statistics")
    catalog, records, native, missing, artifacts, metadata = read_modules(policy, root, cache)
    if _listing(listing) != native:
        raise ValueError("full native listing differs from verdict metadata")
    counts = Counter(value.replace(" ", "_") for value in native.values())
    expected = {"total": len(native), **{name: counts[name] for name in NATIVE_OUTCOMES}}
    if stats != expected:
        raise ValueError("native statistics differ from catalog outcomes")
    return {
        "catalog": catalog,
        "records": records,
        "missing": missing,
        "native_stats": dict(stats),
        "artifacts": artifacts,
        "metadata_sha256": metadata,
        "execution_provenance_verified": True,
    }

mutants_x_read_native__mutmut['_mutmut_orig'] = x_read_native__mutmut_orig # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_1'] = x_read_native__mutmut_1 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_2'] = x_read_native__mutmut_2 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_3'] = x_read_native__mutmut_3 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_4'] = x_read_native__mutmut_4 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_5'] = x_read_native__mutmut_5 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_6'] = x_read_native__mutmut_6 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_7'] = x_read_native__mutmut_7 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_8'] = x_read_native__mutmut_8 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_9'] = x_read_native__mutmut_9 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_10'] = x_read_native__mutmut_10 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_11'] = x_read_native__mutmut_11 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_12'] = x_read_native__mutmut_12 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_13'] = x_read_native__mutmut_13 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_14'] = x_read_native__mutmut_14 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_15'] = x_read_native__mutmut_15 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_16'] = x_read_native__mutmut_16 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_17'] = x_read_native__mutmut_17 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_18'] = x_read_native__mutmut_18 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_19'] = x_read_native__mutmut_19 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_20'] = x_read_native__mutmut_20 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_21'] = x_read_native__mutmut_21 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_22'] = x_read_native__mutmut_22 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_23'] = x_read_native__mutmut_23 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_24'] = x_read_native__mutmut_24 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_25'] = x_read_native__mutmut_25 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_26'] = x_read_native__mutmut_26 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_27'] = x_read_native__mutmut_27 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_28'] = x_read_native__mutmut_28 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_29'] = x_read_native__mutmut_29 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_30'] = x_read_native__mutmut_30 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_31'] = x_read_native__mutmut_31 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_32'] = x_read_native__mutmut_32 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_33'] = x_read_native__mutmut_33 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_34'] = x_read_native__mutmut_34 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_35'] = x_read_native__mutmut_35 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_36'] = x_read_native__mutmut_36 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_37'] = x_read_native__mutmut_37 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_38'] = x_read_native__mutmut_38 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_39'] = x_read_native__mutmut_39 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_40'] = x_read_native__mutmut_40 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_41'] = x_read_native__mutmut_41 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_42'] = x_read_native__mutmut_42 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_43'] = x_read_native__mutmut_43 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_44'] = x_read_native__mutmut_44 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_45'] = x_read_native__mutmut_45 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_46'] = x_read_native__mutmut_46 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_47'] = x_read_native__mutmut_47 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_48'] = x_read_native__mutmut_48 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_49'] = x_read_native__mutmut_49 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_50'] = x_read_native__mutmut_50 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_51'] = x_read_native__mutmut_51 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_52'] = x_read_native__mutmut_52 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_53'] = x_read_native__mutmut_53 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_54'] = x_read_native__mutmut_54 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_55'] = x_read_native__mutmut_55 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_56'] = x_read_native__mutmut_56 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_57'] = x_read_native__mutmut_57 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_58'] = x_read_native__mutmut_58 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_59'] = x_read_native__mutmut_59 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_60'] = x_read_native__mutmut_60 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_61'] = x_read_native__mutmut_61 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_62'] = x_read_native__mutmut_62 # type: ignore # mutmut generated
mutants_x_read_native__mutmut['x_read_native__mutmut_63'] = x_read_native__mutmut_63 # type: ignore # mutmut generated
