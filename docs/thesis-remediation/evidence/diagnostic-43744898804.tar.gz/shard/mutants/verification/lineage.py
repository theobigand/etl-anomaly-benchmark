"""Check that archived experiment records still describe the current scientific code.

Two questions are kept apart:

* historical integrity: can the fingerprint stored in a record be reproduced
  from a committed tree? Recipe-1 records (made before the verification gates
  were excluded) are checked against the anchor revision named in
  ``evidence/lineage.json``. They are never restamped.
* current-source reproducibility: is the result-affecting code at HEAD the same
  as the code the record is bound to? Compared with the recipe-2 fingerprint.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))
import provenance  # noqa: E402

LINEAGE = ROOT / "verification" / "evidence" / "lineage.json"


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_fingerprint_v1_of__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_fingerprint_v1_of__mutmut)
def fingerprint_v1_of(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_orig(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_1(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = None
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_2(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(None):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_3(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = None
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_4(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split(None)
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_5(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("XX/XX")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_6(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = None
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_7(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py")) and path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_8(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py")) and (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_9(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" or path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_10(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[1] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_11(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] != "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_12(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "XXsrcXX" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_13(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "SRC" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_14(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(None))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_15(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith("XX.pyXX"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_16(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".PY"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_17(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 or path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_18(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" or len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_19(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[1] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_20(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] != "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_21(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "XXexperimentsXX" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_22(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "EXPERIMENTS" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_23(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) != 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_24(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 3 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_25(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(None))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_26(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith("XX.pyXX"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_27(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".PY"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_28(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path != "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_29(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "XXenvironment.ymlXX"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_30(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "ENVIRONMENT.YML"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_31(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(None)
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_32(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(None)
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_33(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = None
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_34(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(None)["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_35(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["XXpyproject.tomlXX"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_36(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["PYPROJECT.TOML"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_37(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["XXprojectXX"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_38(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["PROJECT"]
    digest.update(json.dumps(project, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_39(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(None)
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_40(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(None, sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_41(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=None).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_42(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(sort_keys=True).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_43(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, ).encode())
    return digest.hexdigest()


def x_fingerprint_v1_of__mutmut_44(files: dict[str, bytes]) -> str:
    """Recipe 1 over a source mapping; equals ``provenance._source_fingerprint``."""
    digest = hashlib.sha256()
    for path in sorted(files):
        parts = path.split("/")
        recipe_1 = (
            (parts[0] == "src" and path.endswith(".py"))
            or (parts[0] == "experiments" and len(parts) == 2 and path.endswith(".py"))
            or path == "environment.yml"
        )
        if recipe_1:
            digest.update(path.encode())
            digest.update(files[path])
    project = tomllib.loads(files["pyproject.toml"].decode())["project"]
    digest.update(json.dumps(project, sort_keys=False).encode())
    return digest.hexdigest()

mutants_x_fingerprint_v1_of__mutmut['_mutmut_orig'] = x_fingerprint_v1_of__mutmut_orig # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_1'] = x_fingerprint_v1_of__mutmut_1 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_2'] = x_fingerprint_v1_of__mutmut_2 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_3'] = x_fingerprint_v1_of__mutmut_3 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_4'] = x_fingerprint_v1_of__mutmut_4 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_5'] = x_fingerprint_v1_of__mutmut_5 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_6'] = x_fingerprint_v1_of__mutmut_6 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_7'] = x_fingerprint_v1_of__mutmut_7 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_8'] = x_fingerprint_v1_of__mutmut_8 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_9'] = x_fingerprint_v1_of__mutmut_9 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_10'] = x_fingerprint_v1_of__mutmut_10 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_11'] = x_fingerprint_v1_of__mutmut_11 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_12'] = x_fingerprint_v1_of__mutmut_12 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_13'] = x_fingerprint_v1_of__mutmut_13 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_14'] = x_fingerprint_v1_of__mutmut_14 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_15'] = x_fingerprint_v1_of__mutmut_15 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_16'] = x_fingerprint_v1_of__mutmut_16 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_17'] = x_fingerprint_v1_of__mutmut_17 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_18'] = x_fingerprint_v1_of__mutmut_18 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_19'] = x_fingerprint_v1_of__mutmut_19 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_20'] = x_fingerprint_v1_of__mutmut_20 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_21'] = x_fingerprint_v1_of__mutmut_21 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_22'] = x_fingerprint_v1_of__mutmut_22 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_23'] = x_fingerprint_v1_of__mutmut_23 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_24'] = x_fingerprint_v1_of__mutmut_24 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_25'] = x_fingerprint_v1_of__mutmut_25 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_26'] = x_fingerprint_v1_of__mutmut_26 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_27'] = x_fingerprint_v1_of__mutmut_27 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_28'] = x_fingerprint_v1_of__mutmut_28 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_29'] = x_fingerprint_v1_of__mutmut_29 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_30'] = x_fingerprint_v1_of__mutmut_30 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_31'] = x_fingerprint_v1_of__mutmut_31 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_32'] = x_fingerprint_v1_of__mutmut_32 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_33'] = x_fingerprint_v1_of__mutmut_33 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_34'] = x_fingerprint_v1_of__mutmut_34 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_35'] = x_fingerprint_v1_of__mutmut_35 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_36'] = x_fingerprint_v1_of__mutmut_36 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_37'] = x_fingerprint_v1_of__mutmut_37 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_38'] = x_fingerprint_v1_of__mutmut_38 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_39'] = x_fingerprint_v1_of__mutmut_39 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_40'] = x_fingerprint_v1_of__mutmut_40 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_41'] = x_fingerprint_v1_of__mutmut_41 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_42'] = x_fingerprint_v1_of__mutmut_42 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_43'] = x_fingerprint_v1_of__mutmut_43 # type: ignore # mutmut generated
mutants_x_fingerprint_v1_of__mutmut['x_fingerprint_v1_of__mutmut_44'] = x_fingerprint_v1_of__mutmut_44 # type: ignore # mutmut generated
mutants_x_files_at__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_files_at__mutmut)
def files_at(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_orig(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_1(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(None, cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_2(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=None)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_3(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_4(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], )

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_5(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["XXgitXX", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_6(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["GIT", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_7(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = None
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_8(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git(None, "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_9(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", None, "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_10(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", None, revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_11(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", None).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_12(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_13(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_14(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_15(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", ).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_16(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("XXls-treeXX", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_17(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("LS-TREE", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_18(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "XX-rXX", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_19(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-R", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_20(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "XX--name-onlyXX", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_21(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--NAME-ONLY", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_22(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = None
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_23(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") or n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_24(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(None) and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_25(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith("XX.pyXX") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_26(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".PY") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_27(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split(None)[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_28(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("XX/XX")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_29(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[1] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_30(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] not in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_31(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("XXsrcXX", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_32(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("SRC", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_33(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "XXexperimentsXX")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_34(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "EXPERIMENTS")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_35(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted = [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_36(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted -= [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_37(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n not in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_38(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("XXenvironment.ymlXX", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_39(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("ENVIRONMENT.YML", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_40(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "XXpyproject.tomlXX")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_41(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "PYPROJECT.TOML")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_42(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted = [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_43(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted -= [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_44(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n not in provenance.MEASUREMENT_FILES]
    return {name: git("show", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_45(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git(None, f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_46(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", None) for name in wanted}


def x_files_at__mutmut_47(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git(f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_48(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("show", ) for name in wanted}


def x_files_at__mutmut_49(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("XXshowXX", f"{revision}:{name}") for name in wanted}


def x_files_at__mutmut_50(revision: str, root: Path = ROOT) -> dict[str, bytes]:
    """Source files of a committed tree, as ``{relative path: content}``."""

    def git(*args: str) -> bytes:
        return subprocess.check_output(["git", *args], cwd=root)

    names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    wanted = [n for n in names if n.endswith(".py") and n.split("/")[0] in ("src", "experiments")]
    wanted += [n for n in names if n in ("environment.yml", "pyproject.toml")]
    wanted += [n for n in names if n in provenance.MEASUREMENT_FILES]
    return {name: git("SHOW", f"{revision}:{name}") for name in wanted}

mutants_x_files_at__mutmut['_mutmut_orig'] = x_files_at__mutmut_orig # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_1'] = x_files_at__mutmut_1 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_2'] = x_files_at__mutmut_2 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_3'] = x_files_at__mutmut_3 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_4'] = x_files_at__mutmut_4 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_5'] = x_files_at__mutmut_5 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_6'] = x_files_at__mutmut_6 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_7'] = x_files_at__mutmut_7 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_8'] = x_files_at__mutmut_8 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_9'] = x_files_at__mutmut_9 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_10'] = x_files_at__mutmut_10 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_11'] = x_files_at__mutmut_11 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_12'] = x_files_at__mutmut_12 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_13'] = x_files_at__mutmut_13 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_14'] = x_files_at__mutmut_14 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_15'] = x_files_at__mutmut_15 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_16'] = x_files_at__mutmut_16 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_17'] = x_files_at__mutmut_17 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_18'] = x_files_at__mutmut_18 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_19'] = x_files_at__mutmut_19 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_20'] = x_files_at__mutmut_20 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_21'] = x_files_at__mutmut_21 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_22'] = x_files_at__mutmut_22 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_23'] = x_files_at__mutmut_23 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_24'] = x_files_at__mutmut_24 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_25'] = x_files_at__mutmut_25 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_26'] = x_files_at__mutmut_26 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_27'] = x_files_at__mutmut_27 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_28'] = x_files_at__mutmut_28 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_29'] = x_files_at__mutmut_29 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_30'] = x_files_at__mutmut_30 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_31'] = x_files_at__mutmut_31 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_32'] = x_files_at__mutmut_32 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_33'] = x_files_at__mutmut_33 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_34'] = x_files_at__mutmut_34 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_35'] = x_files_at__mutmut_35 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_36'] = x_files_at__mutmut_36 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_37'] = x_files_at__mutmut_37 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_38'] = x_files_at__mutmut_38 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_39'] = x_files_at__mutmut_39 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_40'] = x_files_at__mutmut_40 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_41'] = x_files_at__mutmut_41 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_42'] = x_files_at__mutmut_42 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_43'] = x_files_at__mutmut_43 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_44'] = x_files_at__mutmut_44 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_45'] = x_files_at__mutmut_45 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_46'] = x_files_at__mutmut_46 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_47'] = x_files_at__mutmut_47 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_48'] = x_files_at__mutmut_48 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_49'] = x_files_at__mutmut_49 # type: ignore # mutmut generated
mutants_x_files_at__mutmut['x_files_at__mutmut_50'] = x_files_at__mutmut_50 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_worktree_files__mutmut)
def worktree_files(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_orig(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_1(root: Path = ROOT) -> dict[str, bytes]:
    paths = None
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_2(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob(None), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_3(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("XXsrc/**/*.pyXX"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_4(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("SRC/**/*.PY"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_5(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob(None)]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_6(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("XXexperiments/*.pyXX")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_7(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("EXPERIMENTS/*.PY")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_8(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths = [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_9(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths -= [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_10(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root * "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_11(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "XXenvironment.ymlXX", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_12(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "ENVIRONMENT.YML", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_13(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root * "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_14(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "XXpyproject.tomlXX"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_15(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "PYPROJECT.TOML"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_16(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths = [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_17(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths -= [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_18(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root * n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_19(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root * n).is_file()]
    return {str(path.relative_to(root)): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_20(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(None): path.read_bytes() for path in paths}


def x_worktree_files__mutmut_21(root: Path = ROOT) -> dict[str, bytes]:
    paths = [*root.glob("src/**/*.py"), *root.glob("experiments/*.py")]
    paths += [root / "environment.yml", root / "pyproject.toml"]
    paths += [root / n for n in provenance.MEASUREMENT_FILES if (root / n).is_file()]
    return {str(path.relative_to(None)): path.read_bytes() for path in paths}

mutants_x_worktree_files__mutmut['_mutmut_orig'] = x_worktree_files__mutmut_orig # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_1'] = x_worktree_files__mutmut_1 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_2'] = x_worktree_files__mutmut_2 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_3'] = x_worktree_files__mutmut_3 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_4'] = x_worktree_files__mutmut_4 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_5'] = x_worktree_files__mutmut_5 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_6'] = x_worktree_files__mutmut_6 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_7'] = x_worktree_files__mutmut_7 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_8'] = x_worktree_files__mutmut_8 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_9'] = x_worktree_files__mutmut_9 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_10'] = x_worktree_files__mutmut_10 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_11'] = x_worktree_files__mutmut_11 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_12'] = x_worktree_files__mutmut_12 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_13'] = x_worktree_files__mutmut_13 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_14'] = x_worktree_files__mutmut_14 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_15'] = x_worktree_files__mutmut_15 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_16'] = x_worktree_files__mutmut_16 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_17'] = x_worktree_files__mutmut_17 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_18'] = x_worktree_files__mutmut_18 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_19'] = x_worktree_files__mutmut_19 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_20'] = x_worktree_files__mutmut_20 # type: ignore # mutmut generated
mutants_x_worktree_files__mutmut['x_worktree_files__mutmut_21'] = x_worktree_files__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_record__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_record__mutmut)
def check_record(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_orig(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_1(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = None
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_2(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get(None, 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_3(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", None)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_4(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get(1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_5(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", )
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_6(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("XXfingerprint_recipeXX", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_7(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("FINGERPRINT_RECIPE", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_8(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 2)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_9(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe != 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_10(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 2:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_11(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = None
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_12(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get(None) != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_13(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("XXsource_fingerprintXX") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_14(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("SOURCE_FINGERPRINT") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_15(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") == fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_16(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(None):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_17(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append(None)
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_18(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("XXthe anchor tree does not reproduce the recipe-1 fingerprintXX")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_19(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("THE ANCHOR TREE DOES NOT REPRODUCE THE RECIPE-1 FINGERPRINT")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_20(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(None) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_21(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) == (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_22(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(None)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_23(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append(None)
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_24(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("XXresult-affecting source changed since the anchor revisionXX")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_25(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("RESULT-AFFECTING SOURCE CHANGED SINCE THE ANCHOR REVISION")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_26(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe != provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_27(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = None
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_28(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get(None)
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_29(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("XXscientific_fingerprintXX")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_30(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("SCIENTIFIC_FINGERPRINT")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_31(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored == provenance.scientific_fingerprint_of(current):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_32(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(None):
            return ["scientific fingerprint differs from the current source"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_33(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["XXscientific fingerprint differs from the current sourceXX"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]


def x_check_record__mutmut_34(record: dict, anchor: dict[str, bytes], current: dict[str, bytes]) -> list[str]:
    """Return the reasons a record's lineage is not valid (empty when valid)."""
    recipe = record.get("fingerprint_recipe", 1)
    if recipe == 1:
        problems = []
        if record.get("source_fingerprint") != fingerprint_v1_of(anchor):
            problems.append("the anchor tree does not reproduce the recipe-1 fingerprint")
        if provenance.scientific_fingerprint_of(anchor) != (
            provenance.scientific_fingerprint_of(current)
        ):
            problems.append("result-affecting source changed since the anchor revision")
        return problems
    if recipe == provenance.SCIENTIFIC_RECIPE:
        stored = record.get("scientific_fingerprint")
        if stored != provenance.scientific_fingerprint_of(current):
            return ["SCIENTIFIC FINGERPRINT DIFFERS FROM THE CURRENT SOURCE"]
        return []
    return [f"unknown fingerprint recipe {recipe!r}"]

mutants_x_check_record__mutmut['_mutmut_orig'] = x_check_record__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_1'] = x_check_record__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_2'] = x_check_record__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_3'] = x_check_record__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_4'] = x_check_record__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_5'] = x_check_record__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_6'] = x_check_record__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_7'] = x_check_record__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_8'] = x_check_record__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_9'] = x_check_record__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_10'] = x_check_record__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_11'] = x_check_record__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_12'] = x_check_record__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_13'] = x_check_record__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_14'] = x_check_record__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_15'] = x_check_record__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_16'] = x_check_record__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_17'] = x_check_record__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_18'] = x_check_record__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_19'] = x_check_record__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_20'] = x_check_record__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_21'] = x_check_record__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_22'] = x_check_record__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_23'] = x_check_record__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_24'] = x_check_record__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_25'] = x_check_record__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_26'] = x_check_record__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_27'] = x_check_record__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_28'] = x_check_record__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_29'] = x_check_record__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_30'] = x_check_record__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_31'] = x_check_record__mutmut_31 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_32'] = x_check_record__mutmut_32 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_33'] = x_check_record__mutmut_33 # type: ignore # mutmut generated
mutants_x_check_record__mutmut['x_check_record__mutmut_34'] = x_check_record__mutmut_34 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_check_measurement__mutmut)
def check_measurement(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_orig(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_1(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record or "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_2(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "XXmeasurement_fingerprintXX" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_3(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "MEASUREMENT_FINGERPRINT" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_4(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_5(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "XXmeasurement_recipeXX" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_6(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "MEASUREMENT_RECIPE" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_7(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_8(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "XXLEGACYXX", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_9(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "legacy", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_10(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get(None) != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_11(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("XXmeasurement_recipeXX") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_12(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("MEASUREMENT_RECIPE") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_13(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") == provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_14(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "XXSTALEXX", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_15(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "stale", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_16(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get(None)!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_17(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('XXmeasurement_recipeXX')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_18(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('MEASUREMENT_RECIPE')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_19(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = None
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_20(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get(None)
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_21(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("XXmeasurement_fingerprintXX")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_22(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("MEASUREMENT_FINGERPRINT")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_23(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) and not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_24(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_25(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_26(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "XXSTALEXX", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_27(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "stale", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_28(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["XXthe measurement fingerprint is missing or malformedXX"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_29(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["THE MEASUREMENT FINGERPRINT IS MISSING OR MALFORMED"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_30(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored == provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_31(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(None):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_32(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "XXSTALEXX", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_33(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "stale", ["the measurement method changed since this record was produced"]
    return "BOUND", []


def x_check_measurement__mutmut_34(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["XXthe measurement method changed since this record was producedXX"]
    return "BOUND", []


def x_check_measurement__mutmut_35(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["THE MEASUREMENT METHOD CHANGED SINCE THIS RECORD WAS PRODUCED"]
    return "BOUND", []


def x_check_measurement__mutmut_36(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "XXBOUNDXX", []


def x_check_measurement__mutmut_37(record: dict, current: dict[str, bytes]) -> tuple[str, list[str]]:
    """State of a performance record against the current measurement method.

    ``BOUND``: the record carries a measurement fingerprint equal to the current
    one. ``STALE``: it carries one that differs, or one that cannot be read.
    ``LEGACY``: it predates the measurement fingerprint; it is reported as such
    and never restamped, because the method it used cannot be recovered from
    the record.
    """
    if "measurement_fingerprint" not in record and "measurement_recipe" not in record:
        return "LEGACY", []
    if record.get("measurement_recipe") != provenance.MEASUREMENT_RECIPE:
        return "STALE", [f"unknown measurement recipe {record.get('measurement_recipe')!r}"]
    stored = record.get("measurement_fingerprint")
    if not isinstance(stored, str) or not stored:
        return "STALE", ["the measurement fingerprint is missing or malformed"]
    if stored != provenance.measurement_fingerprint_of(current):
        return "STALE", ["the measurement method changed since this record was produced"]
    return "bound", []

mutants_x_check_measurement__mutmut['_mutmut_orig'] = x_check_measurement__mutmut_orig # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_1'] = x_check_measurement__mutmut_1 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_2'] = x_check_measurement__mutmut_2 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_3'] = x_check_measurement__mutmut_3 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_4'] = x_check_measurement__mutmut_4 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_5'] = x_check_measurement__mutmut_5 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_6'] = x_check_measurement__mutmut_6 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_7'] = x_check_measurement__mutmut_7 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_8'] = x_check_measurement__mutmut_8 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_9'] = x_check_measurement__mutmut_9 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_10'] = x_check_measurement__mutmut_10 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_11'] = x_check_measurement__mutmut_11 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_12'] = x_check_measurement__mutmut_12 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_13'] = x_check_measurement__mutmut_13 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_14'] = x_check_measurement__mutmut_14 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_15'] = x_check_measurement__mutmut_15 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_16'] = x_check_measurement__mutmut_16 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_17'] = x_check_measurement__mutmut_17 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_18'] = x_check_measurement__mutmut_18 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_19'] = x_check_measurement__mutmut_19 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_20'] = x_check_measurement__mutmut_20 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_21'] = x_check_measurement__mutmut_21 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_22'] = x_check_measurement__mutmut_22 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_23'] = x_check_measurement__mutmut_23 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_24'] = x_check_measurement__mutmut_24 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_25'] = x_check_measurement__mutmut_25 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_26'] = x_check_measurement__mutmut_26 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_27'] = x_check_measurement__mutmut_27 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_28'] = x_check_measurement__mutmut_28 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_29'] = x_check_measurement__mutmut_29 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_30'] = x_check_measurement__mutmut_30 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_31'] = x_check_measurement__mutmut_31 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_32'] = x_check_measurement__mutmut_32 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_33'] = x_check_measurement__mutmut_33 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_34'] = x_check_measurement__mutmut_34 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_35'] = x_check_measurement__mutmut_35 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_36'] = x_check_measurement__mutmut_36 # type: ignore # mutmut generated
mutants_x_check_measurement__mutmut['x_check_measurement__mutmut_37'] = x_check_measurement__mutmut_37 # type: ignore # mutmut generated
mutants_x_anchor_revision__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_anchor_revision__mutmut)
def anchor_revision() -> str:
    return json.loads(LINEAGE.read_text())["legacy_anchor"]["revision"]


def x_anchor_revision__mutmut_orig() -> str:
    return json.loads(LINEAGE.read_text())["legacy_anchor"]["revision"]


def x_anchor_revision__mutmut_1() -> str:
    return json.loads(None)["legacy_anchor"]["revision"]


def x_anchor_revision__mutmut_2() -> str:
    return json.loads(LINEAGE.read_text())["XXlegacy_anchorXX"]["revision"]


def x_anchor_revision__mutmut_3() -> str:
    return json.loads(LINEAGE.read_text())["LEGACY_ANCHOR"]["revision"]


def x_anchor_revision__mutmut_4() -> str:
    return json.loads(LINEAGE.read_text())["legacy_anchor"]["XXrevisionXX"]


def x_anchor_revision__mutmut_5() -> str:
    return json.loads(LINEAGE.read_text())["legacy_anchor"]["REVISION"]

mutants_x_anchor_revision__mutmut['_mutmut_orig'] = x_anchor_revision__mutmut_orig # type: ignore # mutmut generated
mutants_x_anchor_revision__mutmut['x_anchor_revision__mutmut_1'] = x_anchor_revision__mutmut_1 # type: ignore # mutmut generated
mutants_x_anchor_revision__mutmut['x_anchor_revision__mutmut_2'] = x_anchor_revision__mutmut_2 # type: ignore # mutmut generated
mutants_x_anchor_revision__mutmut['x_anchor_revision__mutmut_3'] = x_anchor_revision__mutmut_3 # type: ignore # mutmut generated
mutants_x_anchor_revision__mutmut['x_anchor_revision__mutmut_4'] = x_anchor_revision__mutmut_4 # type: ignore # mutmut generated
mutants_x_anchor_revision__mutmut['x_anchor_revision__mutmut_5'] = x_anchor_revision__mutmut_5 # type: ignore # mutmut generated
