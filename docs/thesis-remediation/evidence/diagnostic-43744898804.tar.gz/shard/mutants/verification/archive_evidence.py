"""Copy the latest experiment outputs into ``evidence/`` and refresh the manifest.

Experiments write timestamped files to ``experiments/results``. After a replay,
this script keeps the newest run of each kind under its fixed name and
recomputes the checksums listed in ``evidence/manifest.json``.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STAMP = re.compile(r"_\d{8}_\d{6}")

# (pattern of the timestamped file, name kept in evidence/)
SINGLE_RUNS = [
    ("run_synthetic_*.json", "run_synthetic.json"),
    ("synthetic_metrics_*.csv", "synthetic_metrics.csv"),
    ("synthetic_recall_*.csv", "synthetic_recall.csv"),
    ("synthetic_precision_*.csv", "synthetic_precision.csv"),
    ("synthetic_[0-9]*.md", "synthetic.md"),
    ("run_severity_*.json", "run_severity.json"),
    ("severity_*.csv", "severity.csv"),
    ("run_curves_*.json", "run_curves.json"),
    ("contamination_sweep_*.csv", "contamination_sweep.csv"),
]


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict


class IncompleteRun(Exception):
    """A run whose record does not prove that all its outputs were written intact."""
mutants_x_verify_run__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_verify_run__mutmut)
def verify_run(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_orig(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_1(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = None
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_2(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(None)
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_3(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = None
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_4(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get(None)
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_5(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("XXoutput_sha256XX")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_6(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("OUTPUT_SHA256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_7(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_8(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            None
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_9(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["XXoutputsXX"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_10(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["OUTPUTS"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_11(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_12(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(None)
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_13(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = None
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_14(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results * name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_15(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_16(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(None)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_17(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(None).hexdigest() != hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_18(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() == hashes[name]:
            raise IncompleteRun(f"{name} hash differs from {record_path.name}: partial or changed")
    return record


def x_verify_run__mutmut_19(record_path: Path, results: Path) -> dict:
    """Load a run record and check that every output it lists matches its recorded hash."""
    record = json.loads(record_path.read_text())
    hashes = record.get("output_sha256")
    if not isinstance(hashes, dict):
        raise IncompleteRun(
            f"{record_path.name} has no output_sha256: the run is not proven complete"
        )
    for name in record["outputs"]:
        if name not in hashes:
            raise IncompleteRun(f"{record_path.name} has no output_sha256 entry for {name}")
        source = results / name
        if not source.is_file():
            raise FileNotFoundError(source)
        if hashlib.sha256(source.read_bytes()).hexdigest() != hashes[name]:
            raise IncompleteRun(None)
    return record

mutants_x_verify_run__mutmut['_mutmut_orig'] = x_verify_run__mutmut_orig # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_1'] = x_verify_run__mutmut_1 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_2'] = x_verify_run__mutmut_2 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_3'] = x_verify_run__mutmut_3 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_4'] = x_verify_run__mutmut_4 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_5'] = x_verify_run__mutmut_5 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_6'] = x_verify_run__mutmut_6 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_7'] = x_verify_run__mutmut_7 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_8'] = x_verify_run__mutmut_8 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_9'] = x_verify_run__mutmut_9 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_10'] = x_verify_run__mutmut_10 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_11'] = x_verify_run__mutmut_11 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_12'] = x_verify_run__mutmut_12 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_13'] = x_verify_run__mutmut_13 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_14'] = x_verify_run__mutmut_14 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_15'] = x_verify_run__mutmut_15 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_16'] = x_verify_run__mutmut_16 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_17'] = x_verify_run__mutmut_17 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_18'] = x_verify_run__mutmut_18 # type: ignore # mutmut generated
mutants_x_verify_run__mutmut['x_verify_run__mutmut_19'] = x_verify_run__mutmut_19 # type: ignore # mutmut generated
mutants_x__stable__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__stable__mutmut)
def _stable(name: str) -> str:
    return STAMP.sub("", name)


def x__stable__mutmut_orig(name: str) -> str:
    return STAMP.sub("", name)


def x__stable__mutmut_1(name: str) -> str:
    return STAMP.sub(None, name)


def x__stable__mutmut_2(name: str) -> str:
    return STAMP.sub("", None)


def x__stable__mutmut_3(name: str) -> str:
    return STAMP.sub(name)


def x__stable__mutmut_4(name: str) -> str:
    return STAMP.sub("", )


def x__stable__mutmut_5(name: str) -> str:
    return STAMP.sub("XXXX", name)

mutants_x__stable__mutmut['_mutmut_orig'] = x__stable__mutmut_orig # type: ignore # mutmut generated
mutants_x__stable__mutmut['x__stable__mutmut_1'] = x__stable__mutmut_1 # type: ignore # mutmut generated
mutants_x__stable__mutmut['x__stable__mutmut_2'] = x__stable__mutmut_2 # type: ignore # mutmut generated
mutants_x__stable__mutmut['x__stable__mutmut_3'] = x__stable__mutmut_3 # type: ignore # mutmut generated
mutants_x__stable__mutmut['x__stable__mutmut_4'] = x__stable__mutmut_4 # type: ignore # mutmut generated
mutants_x__stable__mutmut['x__stable__mutmut_5'] = x__stable__mutmut_5 # type: ignore # mutmut generated
mutants_x__newest__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__newest__mutmut)
def _newest(results: Path, pattern: str) -> Path:
    candidates = sorted(results.glob(pattern))
    if not candidates:
        raise FileNotFoundError(f"no file matches {pattern} in {results}")
    return candidates[-1]


def x__newest__mutmut_orig(results: Path, pattern: str) -> Path:
    candidates = sorted(results.glob(pattern))
    if not candidates:
        raise FileNotFoundError(f"no file matches {pattern} in {results}")
    return candidates[-1]


def x__newest__mutmut_1(results: Path, pattern: str) -> Path:
    candidates = None
    if not candidates:
        raise FileNotFoundError(f"no file matches {pattern} in {results}")
    return candidates[-1]


def x__newest__mutmut_2(results: Path, pattern: str) -> Path:
    candidates = sorted(None)
    if not candidates:
        raise FileNotFoundError(f"no file matches {pattern} in {results}")
    return candidates[-1]


def x__newest__mutmut_3(results: Path, pattern: str) -> Path:
    candidates = sorted(results.glob(None))
    if not candidates:
        raise FileNotFoundError(f"no file matches {pattern} in {results}")
    return candidates[-1]


def x__newest__mutmut_4(results: Path, pattern: str) -> Path:
    candidates = sorted(results.glob(pattern))
    if candidates:
        raise FileNotFoundError(f"no file matches {pattern} in {results}")
    return candidates[-1]


def x__newest__mutmut_5(results: Path, pattern: str) -> Path:
    candidates = sorted(results.glob(pattern))
    if not candidates:
        raise FileNotFoundError(None)
    return candidates[-1]


def x__newest__mutmut_6(results: Path, pattern: str) -> Path:
    candidates = sorted(results.glob(pattern))
    if not candidates:
        raise FileNotFoundError(f"no file matches {pattern} in {results}")
    return candidates[+1]


def x__newest__mutmut_7(results: Path, pattern: str) -> Path:
    candidates = sorted(results.glob(pattern))
    if not candidates:
        raise FileNotFoundError(f"no file matches {pattern} in {results}")
    return candidates[-2]

mutants_x__newest__mutmut['_mutmut_orig'] = x__newest__mutmut_orig # type: ignore # mutmut generated
mutants_x__newest__mutmut['x__newest__mutmut_1'] = x__newest__mutmut_1 # type: ignore # mutmut generated
mutants_x__newest__mutmut['x__newest__mutmut_2'] = x__newest__mutmut_2 # type: ignore # mutmut generated
mutants_x__newest__mutmut['x__newest__mutmut_3'] = x__newest__mutmut_3 # type: ignore # mutmut generated
mutants_x__newest__mutmut['x__newest__mutmut_4'] = x__newest__mutmut_4 # type: ignore # mutmut generated
mutants_x__newest__mutmut['x__newest__mutmut_5'] = x__newest__mutmut_5 # type: ignore # mutmut generated
mutants_x__newest__mutmut['x__newest__mutmut_6'] = x__newest__mutmut_6 # type: ignore # mutmut generated
mutants_x__newest__mutmut['x__newest__mutmut_7'] = x__newest__mutmut_7 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__copy_all__mutmut)
def _copy_all(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_orig(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_1(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_2(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(None)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_3(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = None
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_4(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = None
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_5(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(None)
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_6(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append(None)
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_7(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(None, temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_8(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, None)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_9(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_10(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, )
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_11(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(None, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_12(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, None)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_13(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_14(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, )
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)


def x__copy_all__mutmut_15(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=None)


def x__copy_all__mutmut_16(pairs: list[tuple[Path, Path]]) -> None:
    """Stage every copy next to its target, then replace; a failure leaves the archive as it was."""
    for source, _ in pairs:
        if not source.is_file():
            raise FileNotFoundError(source)
    staged = []
    try:
        for source, target in pairs:
            temporary = target.with_name(f"{target.name}.tmp-{os.getpid()}")
            staged.append((temporary, target))
            shutil.copyfile(source, temporary)
        for temporary, target in staged:
            os.replace(temporary, target)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=False)

mutants_x__copy_all__mutmut['_mutmut_orig'] = x__copy_all__mutmut_orig # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_1'] = x__copy_all__mutmut_1 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_2'] = x__copy_all__mutmut_2 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_3'] = x__copy_all__mutmut_3 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_4'] = x__copy_all__mutmut_4 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_5'] = x__copy_all__mutmut_5 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_6'] = x__copy_all__mutmut_6 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_7'] = x__copy_all__mutmut_7 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_8'] = x__copy_all__mutmut_8 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_9'] = x__copy_all__mutmut_9 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_10'] = x__copy_all__mutmut_10 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_11'] = x__copy_all__mutmut_11 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_12'] = x__copy_all__mutmut_12 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_13'] = x__copy_all__mutmut_13 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_14'] = x__copy_all__mutmut_14 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_15'] = x__copy_all__mutmut_15 # type: ignore # mutmut generated
mutants_x__copy_all__mutmut['x__copy_all__mutmut_16'] = x__copy_all__mutmut_16 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_archive_real_runs__mutmut)
def archive_real_runs(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_orig(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_1(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = None
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_2(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(None):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_3(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob(None)):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_4(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("XXrun_benchmark_*.jsonXX")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_5(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("RUN_BENCHMARK_*.JSON")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_6(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = None
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_7(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(None, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_8(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, None)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_9(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_10(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, )
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_11(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = None
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_12(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["XXdatasetXX"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_13(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["DATASET"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_14(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["XXidentityXX"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_15(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["IDENTITY"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_16(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["XXsettingsXX"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_17(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["SETTINGS"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_18(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["XXcalibrationXX"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_19(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["CALIBRATION"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_20(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = None
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_21(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_22(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(None)
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_23(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = None
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_24(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = None
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_25(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if (calibration == "fixed") and False else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_26(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if (calibration == "fixed") or True else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_27(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "XXfixed_XX" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_28(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "FIXED_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_29(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration != "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_30(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "XXfixedXX" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_31(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "FIXED" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_32(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else "XXXX"
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_33(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = None
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_34(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(None)
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_35(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["XXoutputsXX"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_36(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["OUTPUTS"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_37(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append(None)
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_38(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results * name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_39(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence * f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_40(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(None)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_41(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append(None)
    _copy_all(pairs)


def x_archive_real_runs__mutmut_42(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence * f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(pairs)


def x_archive_real_runs__mutmut_43(results: Path, evidence: Path) -> None:
    """Keep the newest baseline and fixed-calibration run of each real dataset."""
    newest: dict[tuple[str, str], Path] = {}
    for path in sorted(results.glob("run_benchmark_*.json")):
        record = verify_run(path, results)
        key = (record["dataset"]["identity"], record["settings"]["calibration"])
        newest[key] = path
    if not newest:
        raise IncompleteRun(f"no run record in {results}: nothing proves a run finished")
    pairs = []
    for (dataset, calibration), record_path in newest.items():
        prefix = "fixed_" if calibration == "fixed" else ""
        record = json.loads(record_path.read_text())
        for name in record["outputs"]:
            pairs.append((results / name, evidence / f"{prefix}{_stable(name)}"))
        pairs.append((record_path, evidence / f"run_{prefix}benchmark_{dataset}.json"))
    _copy_all(None)

mutants_x_archive_real_runs__mutmut['_mutmut_orig'] = x_archive_real_runs__mutmut_orig # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_1'] = x_archive_real_runs__mutmut_1 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_2'] = x_archive_real_runs__mutmut_2 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_3'] = x_archive_real_runs__mutmut_3 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_4'] = x_archive_real_runs__mutmut_4 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_5'] = x_archive_real_runs__mutmut_5 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_6'] = x_archive_real_runs__mutmut_6 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_7'] = x_archive_real_runs__mutmut_7 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_8'] = x_archive_real_runs__mutmut_8 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_9'] = x_archive_real_runs__mutmut_9 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_10'] = x_archive_real_runs__mutmut_10 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_11'] = x_archive_real_runs__mutmut_11 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_12'] = x_archive_real_runs__mutmut_12 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_13'] = x_archive_real_runs__mutmut_13 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_14'] = x_archive_real_runs__mutmut_14 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_15'] = x_archive_real_runs__mutmut_15 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_16'] = x_archive_real_runs__mutmut_16 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_17'] = x_archive_real_runs__mutmut_17 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_18'] = x_archive_real_runs__mutmut_18 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_19'] = x_archive_real_runs__mutmut_19 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_20'] = x_archive_real_runs__mutmut_20 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_21'] = x_archive_real_runs__mutmut_21 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_22'] = x_archive_real_runs__mutmut_22 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_23'] = x_archive_real_runs__mutmut_23 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_24'] = x_archive_real_runs__mutmut_24 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_25'] = x_archive_real_runs__mutmut_25 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_26'] = x_archive_real_runs__mutmut_26 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_27'] = x_archive_real_runs__mutmut_27 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_28'] = x_archive_real_runs__mutmut_28 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_29'] = x_archive_real_runs__mutmut_29 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_30'] = x_archive_real_runs__mutmut_30 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_31'] = x_archive_real_runs__mutmut_31 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_32'] = x_archive_real_runs__mutmut_32 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_33'] = x_archive_real_runs__mutmut_33 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_34'] = x_archive_real_runs__mutmut_34 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_35'] = x_archive_real_runs__mutmut_35 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_36'] = x_archive_real_runs__mutmut_36 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_37'] = x_archive_real_runs__mutmut_37 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_38'] = x_archive_real_runs__mutmut_38 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_39'] = x_archive_real_runs__mutmut_39 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_40'] = x_archive_real_runs__mutmut_40 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_41'] = x_archive_real_runs__mutmut_41 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_42'] = x_archive_real_runs__mutmut_42 # type: ignore # mutmut generated
mutants_x_archive_real_runs__mutmut['x_archive_real_runs__mutmut_43'] = x_archive_real_runs__mutmut_43 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_archive_single_runs__mutmut)
def archive_single_runs(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_orig(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_1(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = None
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_2(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(None, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_3(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, None), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_4(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_5(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, ), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_6(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = None
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_7(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(None, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_8(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, None)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_9(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_10(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, )
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_11(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") or source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_12(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith(None) and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_13(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("XXrun_XX") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_14(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("RUN_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_15(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix != ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_16(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == "XX.jsonXX"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_17(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".JSON"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_18(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = None
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_19(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(None).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_20(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["XXoutputsXX"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_21(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["OUTPUTS"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_22(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = None
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_23(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" or source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_24(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix != ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_25(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == "XX.jsonXX" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_26(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".JSON" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_27(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith(None)
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_28(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("XXrun_XX")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_29(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("RUN_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_30(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record or source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_31(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_32(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_33(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(None)
    _copy_all([(source, evidence / name) for source, name in chosen])


def x_archive_single_runs__mutmut_34(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all(None)


def x_archive_single_runs__mutmut_35(results: Path, evidence: Path, runs=SINGLE_RUNS) -> None:
    """Archive the newest file of each kind, provided a verified record lists it."""
    chosen = [(_newest(results, pattern), name) for pattern, name in runs]
    records = [
        verify_run(source, results)
        for source, _ in chosen
        if source.name.startswith("run_") and source.suffix == ".json"
    ]
    listed = {Path(output).name for record in records for output in record["outputs"]}
    for source, _ in chosen:
        is_record = source.suffix == ".json" and source.name.startswith("run_")
        if not is_record and source.name not in listed:
            raise IncompleteRun(f"{source.name} is not listed by the newest run record")
    _copy_all([(source, evidence * name) for source, name in chosen])

mutants_x_archive_single_runs__mutmut['_mutmut_orig'] = x_archive_single_runs__mutmut_orig # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_1'] = x_archive_single_runs__mutmut_1 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_2'] = x_archive_single_runs__mutmut_2 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_3'] = x_archive_single_runs__mutmut_3 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_4'] = x_archive_single_runs__mutmut_4 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_5'] = x_archive_single_runs__mutmut_5 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_6'] = x_archive_single_runs__mutmut_6 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_7'] = x_archive_single_runs__mutmut_7 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_8'] = x_archive_single_runs__mutmut_8 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_9'] = x_archive_single_runs__mutmut_9 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_10'] = x_archive_single_runs__mutmut_10 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_11'] = x_archive_single_runs__mutmut_11 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_12'] = x_archive_single_runs__mutmut_12 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_13'] = x_archive_single_runs__mutmut_13 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_14'] = x_archive_single_runs__mutmut_14 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_15'] = x_archive_single_runs__mutmut_15 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_16'] = x_archive_single_runs__mutmut_16 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_17'] = x_archive_single_runs__mutmut_17 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_18'] = x_archive_single_runs__mutmut_18 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_19'] = x_archive_single_runs__mutmut_19 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_20'] = x_archive_single_runs__mutmut_20 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_21'] = x_archive_single_runs__mutmut_21 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_22'] = x_archive_single_runs__mutmut_22 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_23'] = x_archive_single_runs__mutmut_23 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_24'] = x_archive_single_runs__mutmut_24 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_25'] = x_archive_single_runs__mutmut_25 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_26'] = x_archive_single_runs__mutmut_26 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_27'] = x_archive_single_runs__mutmut_27 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_28'] = x_archive_single_runs__mutmut_28 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_29'] = x_archive_single_runs__mutmut_29 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_30'] = x_archive_single_runs__mutmut_30 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_31'] = x_archive_single_runs__mutmut_31 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_32'] = x_archive_single_runs__mutmut_32 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_33'] = x_archive_single_runs__mutmut_33 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_34'] = x_archive_single_runs__mutmut_34 # type: ignore # mutmut generated
mutants_x_archive_single_runs__mutmut['x_archive_single_runs__mutmut_35'] = x_archive_single_runs__mutmut_35 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_refresh_manifest__mutmut)
def refresh_manifest(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_orig(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_1(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = None
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_2(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(None)
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_3(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = None
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_4(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["XXartifactsXX"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_5(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["ARTIFACTS"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_6(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256(None).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_7(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root * name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_8(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["XXartifactsXX"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_9(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["ARTIFACTS"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_10(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = None
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_11(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["XXsource_revisionXX"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_12(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["SOURCE_REVISION"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_13(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = None
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_14(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["XXworktree_dirtyXX"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_15(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["WORKTREE_DIRTY"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_16(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = None
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_17(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) - "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_18(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(None, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_19(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=None, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_20(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=None, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_21(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=None) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_22(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_23(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_24(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_25(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_26(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=3, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_27(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=False, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_28(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=True) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_29(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "XX\nXX"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_30(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = None
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_31(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(None)
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_32(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(None)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_33(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(None, manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_34(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, None)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_35(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(manifest)
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_36(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, )
    finally:
        temporary.unlink(missing_ok=True)


def x_refresh_manifest__mutmut_37(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=None)


def x_refresh_manifest__mutmut_38(manifest: Path, root: Path, *, revision: str, dirty: bool) -> None:
    """Recompute every listed checksum; a missing artifact is an error."""
    data = json.loads(manifest.read_text())
    data["artifacts"] = {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in data["artifacts"]
    }
    data["source_revision"] = revision
    data["worktree_dirty"] = dirty
    text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    temporary = manifest.with_name(f"{manifest.name}.tmp-{os.getpid()}")
    try:
        temporary.write_text(text)
        os.replace(temporary, manifest)
    finally:
        temporary.unlink(missing_ok=False)

mutants_x_refresh_manifest__mutmut['_mutmut_orig'] = x_refresh_manifest__mutmut_orig # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_1'] = x_refresh_manifest__mutmut_1 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_2'] = x_refresh_manifest__mutmut_2 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_3'] = x_refresh_manifest__mutmut_3 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_4'] = x_refresh_manifest__mutmut_4 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_5'] = x_refresh_manifest__mutmut_5 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_6'] = x_refresh_manifest__mutmut_6 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_7'] = x_refresh_manifest__mutmut_7 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_8'] = x_refresh_manifest__mutmut_8 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_9'] = x_refresh_manifest__mutmut_9 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_10'] = x_refresh_manifest__mutmut_10 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_11'] = x_refresh_manifest__mutmut_11 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_12'] = x_refresh_manifest__mutmut_12 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_13'] = x_refresh_manifest__mutmut_13 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_14'] = x_refresh_manifest__mutmut_14 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_15'] = x_refresh_manifest__mutmut_15 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_16'] = x_refresh_manifest__mutmut_16 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_17'] = x_refresh_manifest__mutmut_17 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_18'] = x_refresh_manifest__mutmut_18 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_19'] = x_refresh_manifest__mutmut_19 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_20'] = x_refresh_manifest__mutmut_20 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_21'] = x_refresh_manifest__mutmut_21 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_22'] = x_refresh_manifest__mutmut_22 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_23'] = x_refresh_manifest__mutmut_23 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_24'] = x_refresh_manifest__mutmut_24 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_25'] = x_refresh_manifest__mutmut_25 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_26'] = x_refresh_manifest__mutmut_26 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_27'] = x_refresh_manifest__mutmut_27 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_28'] = x_refresh_manifest__mutmut_28 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_29'] = x_refresh_manifest__mutmut_29 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_30'] = x_refresh_manifest__mutmut_30 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_31'] = x_refresh_manifest__mutmut_31 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_32'] = x_refresh_manifest__mutmut_32 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_33'] = x_refresh_manifest__mutmut_33 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_34'] = x_refresh_manifest__mutmut_34 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_35'] = x_refresh_manifest__mutmut_35 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_36'] = x_refresh_manifest__mutmut_36 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_37'] = x_refresh_manifest__mutmut_37 # type: ignore # mutmut generated
mutants_x_refresh_manifest__mutmut['x_refresh_manifest__mutmut_38'] = x_refresh_manifest__mutmut_38 # type: ignore # mutmut generated
mutants_x__git__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__git__mutmut)
def _git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def x__git__mutmut_orig(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def x__git__mutmut_1(*args: str) -> str:
    return subprocess.check_output(None, cwd=ROOT, text=True).strip()


def x__git__mutmut_2(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=None, text=True).strip()


def x__git__mutmut_3(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=None).strip()


def x__git__mutmut_4(*args: str) -> str:
    return subprocess.check_output(cwd=ROOT, text=True).strip()


def x__git__mutmut_5(*args: str) -> str:
    return subprocess.check_output(["git", *args], text=True).strip()


def x__git__mutmut_6(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, ).strip()


def x__git__mutmut_7(*args: str) -> str:
    return subprocess.check_output(["XXgitXX", *args], cwd=ROOT, text=True).strip()


def x__git__mutmut_8(*args: str) -> str:
    return subprocess.check_output(["GIT", *args], cwd=ROOT, text=True).strip()


def x__git__mutmut_9(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=False).strip()

mutants_x__git__mutmut['_mutmut_orig'] = x__git__mutmut_orig # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_1'] = x__git__mutmut_1 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_2'] = x__git__mutmut_2 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_3'] = x__git__mutmut_3 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_4'] = x__git__mutmut_4 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_5'] = x__git__mutmut_5 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_6'] = x__git__mutmut_6 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_7'] = x__git__mutmut_7 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_8'] = x__git__mutmut_8 # type: ignore # mutmut generated
mutants_x__git__mutmut['x__git__mutmut_9'] = x__git__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_orig() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_1() -> int:
    parser = None
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_2() -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_3() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_4() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=None, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_5() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=None)
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_6() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_7() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_8() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, )
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_9() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--resultsXX", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_10() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--RESULTS", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_11() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" * "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_12() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT * "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_13() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "XXexperimentsXX" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_14() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "EXPERIMENTS" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_15() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "XXresultsXX")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_16() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "RESULTS")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_17() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument(None, type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_18() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=None, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_19() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=None)
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_20() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument(type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_21() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_22() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, )
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_23() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("XX--evidenceXX", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_24() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--EVIDENCE", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_25() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" * "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_26() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT * "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_27() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "XXverificationXX" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_28() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "VERIFICATION" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_29() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "XXevidenceXX")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_30() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "EVIDENCE")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_31() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument(None, action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_32() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action=None)
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_33() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument(action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_34() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", )
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_35() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("XX--manifest-onlyXX", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_36() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--MANIFEST-ONLY", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_37() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="XXstore_trueXX")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_38() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="STORE_TRUE")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_39() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = None
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_40() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_41() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(None, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_42() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, None)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_43() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_44() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, )
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_45() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(None, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_46() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, None)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_47() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_48() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, )
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_49() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        None,
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_50() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        None,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_51() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=None,
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_52() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=None,
    )
    return 0


def x_main__mutmut_53() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_54() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_55() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_56() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        )
    return 0


def x_main__mutmut_57() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence * "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_58() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "XXmanifest.jsonXX",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_59() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "MANIFEST.JSON",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_60() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git(None, "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_61() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", None),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_62() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_63() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", ),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_64() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("XXrev-parseXX", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_65() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("REV-PARSE", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_66() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "XXHEADXX"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_67() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "head"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 0


def x_main__mutmut_68() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(None),
    )
    return 0


def x_main__mutmut_69() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git(None, "--porcelain")),
    )
    return 0


def x_main__mutmut_70() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", None)),
    )
    return 0


def x_main__mutmut_71() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("--porcelain")),
    )
    return 0


def x_main__mutmut_72() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", )),
    )
    return 0


def x_main__mutmut_73() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("XXstatusXX", "--porcelain")),
    )
    return 0


def x_main__mutmut_74() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("STATUS", "--porcelain")),
    )
    return 0


def x_main__mutmut_75() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "XX--porcelainXX")),
    )
    return 0


def x_main__mutmut_76() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--PORCELAIN")),
    )
    return 0


def x_main__mutmut_77() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "experiments" / "results")
    parser.add_argument("--evidence", type=Path, default=ROOT / "verification" / "evidence")
    parser.add_argument("--manifest-only", action="store_true")
    args = parser.parse_args()
    if not args.manifest_only:
        archive_real_runs(args.results, args.evidence)
        archive_single_runs(args.results, args.evidence)
    refresh_manifest(
        args.evidence / "manifest.json",
        ROOT,
        revision=_git("rev-parse", "HEAD"),
        dirty=bool(_git("status", "--porcelain")),
    )
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
