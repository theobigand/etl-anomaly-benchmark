"""Bounded detector cost study; never used as a FAST timing threshold."""

from __future__ import annotations

import argparse
import json
import os
import platform
import subprocess
import sys
import tracemalloc
from collections.abc import Callable
from datetime import UTC, datetime
from importlib.metadata import version
from pathlib import Path

import numpy as np
import pandas as pd

from etl_benchmark.pipeline import detect
from etl_benchmark.quality.ml import (
    IsolationForestDetector,
    LOFDetector,
    OneClassSVMDetector,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))
import provenance  # noqa: E402

METHODS = {
    "isolation_forest": IsolationForestDetector,
    "lof": LOFDetector,
    "ocsvm": OneClassSVMDetector,
}


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_run_case__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run_case__mutmut)
def run_case(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_orig(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_1(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 and fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_2(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 and n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_3(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows <= 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_4(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 21 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_5(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features <= 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_6(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 2 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_7(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None or fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_8(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_9(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap <= 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_10(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 3:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_11(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError(None)
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_12(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("XXn_rows, n_features and fit_cap must be positive and usableXX")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_13(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("N_ROWS, N_FEATURES AND FIT_CAP MUST BE POSITIVE AND USABLE")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_14(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = None
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_15(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if (fit_cap is not None) and False else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_16(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if (fit_cap is not None) or True else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_17(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(None, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_18(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, None) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_19(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_20(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, ) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_21(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_22(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = None
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_23(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        None,
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_24(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=None,
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_25(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_26(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_27(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=None),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_28(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(None).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_29(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(None)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_30(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = None
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_31(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "XXstatusXX": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_32(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "STATUS": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_33(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "XXFAILXX",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_34(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "fail",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_35(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "XXreasonXX": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_36(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "REASON": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_37(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "XXXX",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_38(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "XXeval_rowsXX": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_39(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "EVAL_ROWS": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_40(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "XXfit_rowsXX": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_41(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "FIT_ROWS": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_42(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "XXn_featuresXX": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_43(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "N_FEATURES": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_44(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "XXseedXX": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_45(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "SEED": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_46(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "XXfit_sXX": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_47(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "FIT_S": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_48(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "XXpredict_sXX": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_49(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "PREDICT_S": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_50(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "XXscore_sXX": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_51(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "SCORE_S": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_52(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "XXdetect_sXX": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_53(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "DETECT_S": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_54(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "XXpeak_python_bytesXX": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_55(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "PEAK_PYTHON_BYTES": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_56(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = None
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_57(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(None, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_58(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, None, fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_59(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=None)
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_60(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_61(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_62(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), )
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_63(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            None
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_64(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "XXstatusXX": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_65(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "STATUS": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_66(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "XXPASSXX",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_67(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "pass",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_68(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "XXfit_sXX": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_69(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "FIT_S": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_70(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "XXpredict_sXX": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_71(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "PREDICT_S": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_72(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "XXscore_sXX": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_73(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "SCORE_S": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_74(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "XXdetect_sXX": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_75(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "DETECT_S": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_76(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = None
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_77(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["XXreasonXX"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_78(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["REASON"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_79(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(None).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_80(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = None
        tracemalloc.stop()
    return row


def x_run_case__mutmut_81(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["XXpeak_python_bytesXX"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_82(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["PEAK_PYTHON_BYTES"] = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
    return row


def x_run_case__mutmut_83(
    factory: Callable,
    *,
    n_rows: int,
    n_features: int,
    fit_cap: int | None,
    seed: int,
) -> dict:
    """Measure fit/predict/score on the same seeded numerical workload."""
    if n_rows < 20 or n_features < 1 or fit_cap is not None and fit_cap < 2:
        raise ValueError("n_rows, n_features and fit_cap must be positive and usable")
    fit_rows = min(n_rows, fit_cap) if fit_cap is not None else n_rows
    frame = pd.DataFrame(
        np.random.default_rng(seed).normal(size=(n_rows, n_features)),
        columns=[f"feature_{i}" for i in range(n_features)],
    )
    row = {
        "status": "FAIL",
        "reason": "",
        "eval_rows": n_rows,
        "fit_rows": fit_rows,
        "n_features": n_features,
        "seed": seed,
        "fit_s": None,
        "predict_s": None,
        "score_s": None,
        "detect_s": None,
        "peak_python_bytes": None,
    }
    tracemalloc.start()
    try:
        result = detect(frame, factory(), fit_df=frame.iloc[:fit_rows])
        row.update(
            {
                "status": "PASS",
                "fit_s": result.fit_s,
                "predict_s": result.predict_s,
                "score_s": result.score_s,
                "detect_s": result.detect_s,
            }
        )
    except Exception as exc:
        row["reason"] = f"{type(exc).__name__}: {exc}"
    finally:
        row["peak_python_bytes"] = tracemalloc.get_traced_memory()[2]
        tracemalloc.stop()
    return row

mutants_x_run_case__mutmut['_mutmut_orig'] = x_run_case__mutmut_orig # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_1'] = x_run_case__mutmut_1 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_2'] = x_run_case__mutmut_2 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_3'] = x_run_case__mutmut_3 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_4'] = x_run_case__mutmut_4 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_5'] = x_run_case__mutmut_5 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_6'] = x_run_case__mutmut_6 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_7'] = x_run_case__mutmut_7 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_8'] = x_run_case__mutmut_8 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_9'] = x_run_case__mutmut_9 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_10'] = x_run_case__mutmut_10 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_11'] = x_run_case__mutmut_11 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_12'] = x_run_case__mutmut_12 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_13'] = x_run_case__mutmut_13 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_14'] = x_run_case__mutmut_14 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_15'] = x_run_case__mutmut_15 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_16'] = x_run_case__mutmut_16 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_17'] = x_run_case__mutmut_17 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_18'] = x_run_case__mutmut_18 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_19'] = x_run_case__mutmut_19 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_20'] = x_run_case__mutmut_20 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_21'] = x_run_case__mutmut_21 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_22'] = x_run_case__mutmut_22 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_23'] = x_run_case__mutmut_23 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_24'] = x_run_case__mutmut_24 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_25'] = x_run_case__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_26'] = x_run_case__mutmut_26 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_27'] = x_run_case__mutmut_27 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_28'] = x_run_case__mutmut_28 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_29'] = x_run_case__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_30'] = x_run_case__mutmut_30 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_31'] = x_run_case__mutmut_31 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_32'] = x_run_case__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_33'] = x_run_case__mutmut_33 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_34'] = x_run_case__mutmut_34 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_35'] = x_run_case__mutmut_35 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_36'] = x_run_case__mutmut_36 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_37'] = x_run_case__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_38'] = x_run_case__mutmut_38 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_39'] = x_run_case__mutmut_39 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_40'] = x_run_case__mutmut_40 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_41'] = x_run_case__mutmut_41 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_42'] = x_run_case__mutmut_42 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_43'] = x_run_case__mutmut_43 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_44'] = x_run_case__mutmut_44 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_45'] = x_run_case__mutmut_45 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_46'] = x_run_case__mutmut_46 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_47'] = x_run_case__mutmut_47 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_48'] = x_run_case__mutmut_48 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_49'] = x_run_case__mutmut_49 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_50'] = x_run_case__mutmut_50 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_51'] = x_run_case__mutmut_51 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_52'] = x_run_case__mutmut_52 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_53'] = x_run_case__mutmut_53 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_54'] = x_run_case__mutmut_54 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_55'] = x_run_case__mutmut_55 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_56'] = x_run_case__mutmut_56 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_57'] = x_run_case__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_58'] = x_run_case__mutmut_58 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_59'] = x_run_case__mutmut_59 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_60'] = x_run_case__mutmut_60 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_61'] = x_run_case__mutmut_61 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_62'] = x_run_case__mutmut_62 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_63'] = x_run_case__mutmut_63 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_64'] = x_run_case__mutmut_64 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_65'] = x_run_case__mutmut_65 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_66'] = x_run_case__mutmut_66 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_67'] = x_run_case__mutmut_67 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_68'] = x_run_case__mutmut_68 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_69'] = x_run_case__mutmut_69 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_70'] = x_run_case__mutmut_70 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_71'] = x_run_case__mutmut_71 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_72'] = x_run_case__mutmut_72 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_73'] = x_run_case__mutmut_73 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_74'] = x_run_case__mutmut_74 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_75'] = x_run_case__mutmut_75 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_76'] = x_run_case__mutmut_76 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_77'] = x_run_case__mutmut_77 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_78'] = x_run_case__mutmut_78 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_79'] = x_run_case__mutmut_79 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_80'] = x_run_case__mutmut_80 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_81'] = x_run_case__mutmut_81 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_82'] = x_run_case__mutmut_82 # type: ignore # mutmut generated
mutants_x_run_case__mutmut['x_run_case__mutmut_83'] = x_run_case__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_orig() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_1() -> None:
    parser = None
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_2() -> None:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_3() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_4() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=None, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_5() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs=None, default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_6() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=None)
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_7() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_8() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_9() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_10() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", )
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_11() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--sizesXX", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_12() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--SIZES", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_13() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="XX+XX", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_14() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[101, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_15() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 301, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_16() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 901])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_17() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument(None, type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_18() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=None, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_19() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=None)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_20() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument(type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_21() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_22() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, )
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_23() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("XX--featuresXX", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_24() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--FEATURES", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_25() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=9)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_26() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument(None, type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_27() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=None, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_28() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=None)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_29() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument(type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_30() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_31() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, )
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_32() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("XX--repeatsXX", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_33() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--REPEATS", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_34() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=4)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_35() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument(None, type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_36() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=None)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_37() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument(type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_38() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", )
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_39() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("XX--fit-capXX", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_40() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--FIT-CAP", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_41() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument(None, choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_42() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=None, nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_43() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs=None, default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_44() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=None)
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_45() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument(choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_46() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_47() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_48() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", )
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_49() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("XX--methodsXX", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_50() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--METHODS", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_51() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(None), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_52() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="XX+XX", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_53() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(None))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_54() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument(None, type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_55() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=None, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_56() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=None)
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_57() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument(type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_58() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_59() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, )
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_60() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("XX--results-dirXX", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_61() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--RESULTS-DIR", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_62() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path(None))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_63() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("XXverification/evidenceXX"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_64() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("VERIFICATION/EVIDENCE"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_65() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = None
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_66() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 and any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_67() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 and args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_68() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats <= 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_69() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 2 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_70() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats >= 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_71() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 11 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_72() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(None):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_73() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 and n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_74() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n <= 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_75() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 21 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_76() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n >= 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_77() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5001 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_78() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error(None)

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_79() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("XXuse 1–10 repeats and dataset sizes between 20 and 5000XX")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_80() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("USE 1–10 REPEATS AND DATASET SIZES BETWEEN 20 AND 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_81() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = None
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_82() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(None):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_83() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = None
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_84() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    None,
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_85() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=None,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_86() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=None,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_87() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=None,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_88() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=None,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_89() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_90() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_91() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_92() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_93() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_94() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 - repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_95() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=43 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_96() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append(None)
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_97() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"XXmethodXX": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_98() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"METHOD": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_99() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "XXrepeatXX": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_100() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "REPEAT": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_101() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(None)

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_102() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['XXstatusXX']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_103() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['STATUS']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_104() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=None, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_105() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=None)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_106() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_107() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, )
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_108() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=False, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_109() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=False)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_110() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = None
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_111() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir * "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_112() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "XXscaling.csvXX"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_113() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "SCALING.CSV"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_114() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = None
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_115() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir * "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_116() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "XXscaling.jsonXX"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_117() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "SCALING.JSON"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_118() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(None, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_119() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=None)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_120() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_121() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, )
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_122() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(None).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_123() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=True)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_124() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = None
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_125() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "XXcaptured_atXX": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_126() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "CAPTURED_AT": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_127() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(None).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_128() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "XXsource_revisionXX": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_129() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "SOURCE_REVISION": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_130() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(None, text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_131() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=None).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_132() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_133() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], ).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_134() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["XXgitXX", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_135() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["GIT", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_136() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "XXrev-parseXX", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_137() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "REV-PARSE", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_138() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "XXHEADXX"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_139() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "head"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_140() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=False).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_141() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "XXworktree_dirtyXX": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_142() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "WORKTREE_DIRTY": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_143() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            None
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_144() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(None, text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_145() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=None).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_146() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_147() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], ).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_148() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["XXgitXX", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_149() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["GIT", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_150() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "XXstatusXX", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_151() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "STATUS", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_152() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "XX--porcelainXX"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_153() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--PORCELAIN"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_154() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=False).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_155() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "XXmeasurement_recipeXX": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_156() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "MEASUREMENT_RECIPE": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_157() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "XXmeasurement_fingerprintXX": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_158() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "MEASUREMENT_FINGERPRINT": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_159() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "XXplatformXX": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_160() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "PLATFORM": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_161() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "XXprocessorXX": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_162() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "PROCESSOR": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_163() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "XXlogical_cpusXX": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_164() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "LOGICAL_CPUS": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_165() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "XXpythonXX": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_166() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "PYTHON": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_167() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[1],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_168() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "XXpackagesXX": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_169() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "PACKAGES": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_170() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(None) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_171() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("XXnumpyXX", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_172() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("NUMPY", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_173() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "XXpandasXX", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_174() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "PANDAS", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_175() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "XXscikit-learnXX", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_176() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "SCIKIT-LEARN", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_177() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "XXpyodXX")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_178() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "PYOD")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_179() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "XXsizesXX": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_180() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "SIZES": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_181() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "XXn_featuresXX": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_182() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "N_FEATURES": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_183() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "XXrepeatsXX": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_184() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "REPEATS": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_185() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "XXfit_capXX": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_186() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "FIT_CAP": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_187() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "XXmethodsXX": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_188() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "METHODS": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_189() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "XXdata_loadingXX": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_190() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "DATA_LOADING": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_191() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "XXgenerated in memory; CSV reading and deduplication excludedXX",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_192() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; csv reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_193() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "GENERATED IN MEMORY; CSV READING AND DEDUPLICATION EXCLUDED",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_194() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "XXmemory_measureXX": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_195() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "MEMORY_MEASURE": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_196() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "XXtracemalloc peak Python allocations; native allocations excludedXX",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_197() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_198() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "TRACEMALLOC PEAK PYTHON ALLOCATIONS; NATIVE ALLOCATIONS EXCLUDED",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_199() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "XXtiming_measureXX": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_200() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "TIMING_MEASURE": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_201() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "XXfit_s + predict_s + score_s inside pipeline.detect; data generation excludedXX"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_202() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "FIT_S + PREDICT_S + SCORE_S INSIDE PIPELINE.DETECT; DATA GENERATION EXCLUDED"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_203() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "XXresultsXX": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_204() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "RESULTS": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_205() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(None)
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_206() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) - "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_207() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(None, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_208() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=None, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_209() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=None) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_210() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_211() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_212() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, ) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_213() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=3, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_214() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=False) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_215() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "XX\nXX")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_216() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(None):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_217() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["XXstatusXX"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_218() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["STATUS"] != "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_219() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] == "PASS" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_220() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "XXPASSXX" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_221() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "pass" for row in rows):
        raise SystemExit("one or more scaling cases failed; inspect scaling.json")


def x_main__mutmut_222() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit(None)


def x_main__mutmut_223() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("XXone or more scaling cases failed; inspect scaling.jsonXX")


def x_main__mutmut_224() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 300, 900])
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--fit-cap", type=int)
    parser.add_argument("--methods", choices=sorted(METHODS), nargs="+", default=list(METHODS))
    parser.add_argument("--results-dir", type=Path, default=Path("verification/evidence"))
    args = parser.parse_args()
    if args.repeats < 1 or args.repeats > 10 or any(n < 20 or n > 5000 for n in args.sizes):
        parser.error("use 1–10 repeats and dataset sizes between 20 and 5000")

    rows = []
    for method in args.methods:
        for n_rows in args.sizes:
            for repeat in range(args.repeats):
                row = run_case(
                    METHODS[method],
                    n_rows=n_rows,
                    n_features=args.features,
                    fit_cap=args.fit_cap,
                    seed=42 + repeat,
                )
                rows.append({"method": method, "repeat": repeat, **row})
                print(f"{method} rows={n_rows} repeat={repeat}: {row['status']}")

    args.results_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.results_dir / "scaling.csv"
    json_path = args.results_dir / "scaling.json"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    record = {
        "captured_at": datetime.now(UTC).isoformat(),
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "worktree_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "measurement_recipe": provenance.MEASUREMENT_RECIPE,
        "measurement_fingerprint": provenance.measurement_fingerprint(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "python": sys.version.split()[0],
        "packages": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "pyod")},
        "sizes": args.sizes,
        "n_features": args.features,
        "repeats": args.repeats,
        "fit_cap": args.fit_cap,
        "methods": args.methods,
        "data_loading": "generated in memory; CSV reading and deduplication excluded",
        "memory_measure": "tracemalloc peak Python allocations; native allocations excluded",
        "timing_measure": (
            "fit_s + predict_s + score_s inside pipeline.detect; data generation excluded"
        ),
        "results": rows,
    }
    json_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if any(row["status"] != "PASS" for row in rows):
        raise SystemExit("ONE OR MORE SCALING CASES FAILED; INSPECT SCALING.JSON")

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_157'] = x_main__mutmut_157 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_158'] = x_main__mutmut_158 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_159'] = x_main__mutmut_159 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_160'] = x_main__mutmut_160 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_161'] = x_main__mutmut_161 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_162'] = x_main__mutmut_162 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_163'] = x_main__mutmut_163 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_164'] = x_main__mutmut_164 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_165'] = x_main__mutmut_165 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_166'] = x_main__mutmut_166 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_167'] = x_main__mutmut_167 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_168'] = x_main__mutmut_168 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_169'] = x_main__mutmut_169 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_170'] = x_main__mutmut_170 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_171'] = x_main__mutmut_171 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_172'] = x_main__mutmut_172 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_173'] = x_main__mutmut_173 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_174'] = x_main__mutmut_174 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_175'] = x_main__mutmut_175 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_176'] = x_main__mutmut_176 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_177'] = x_main__mutmut_177 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_178'] = x_main__mutmut_178 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_179'] = x_main__mutmut_179 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_180'] = x_main__mutmut_180 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_181'] = x_main__mutmut_181 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_182'] = x_main__mutmut_182 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_183'] = x_main__mutmut_183 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_184'] = x_main__mutmut_184 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_185'] = x_main__mutmut_185 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_186'] = x_main__mutmut_186 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_187'] = x_main__mutmut_187 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_188'] = x_main__mutmut_188 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_189'] = x_main__mutmut_189 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_190'] = x_main__mutmut_190 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_191'] = x_main__mutmut_191 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_192'] = x_main__mutmut_192 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_193'] = x_main__mutmut_193 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_194'] = x_main__mutmut_194 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_195'] = x_main__mutmut_195 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_196'] = x_main__mutmut_196 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_197'] = x_main__mutmut_197 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_198'] = x_main__mutmut_198 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_199'] = x_main__mutmut_199 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_200'] = x_main__mutmut_200 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_201'] = x_main__mutmut_201 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_202'] = x_main__mutmut_202 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_203'] = x_main__mutmut_203 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_204'] = x_main__mutmut_204 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_205'] = x_main__mutmut_205 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_206'] = x_main__mutmut_206 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_207'] = x_main__mutmut_207 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_208'] = x_main__mutmut_208 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_209'] = x_main__mutmut_209 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_210'] = x_main__mutmut_210 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_211'] = x_main__mutmut_211 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_212'] = x_main__mutmut_212 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_213'] = x_main__mutmut_213 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_214'] = x_main__mutmut_214 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_215'] = x_main__mutmut_215 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_216'] = x_main__mutmut_216 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_217'] = x_main__mutmut_217 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_218'] = x_main__mutmut_218 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_219'] = x_main__mutmut_219 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_220'] = x_main__mutmut_220 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_221'] = x_main__mutmut_221 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_222'] = x_main__mutmut_222 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_223'] = x_main__mutmut_223 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_224'] = x_main__mutmut_224 # type: ignore # mutmut generated


if __name__ == "__main__":
    main()
