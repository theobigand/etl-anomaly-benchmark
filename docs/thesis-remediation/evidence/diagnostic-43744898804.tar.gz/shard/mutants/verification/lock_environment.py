"""Write the exact conda and pip package lists of the active environment.

``conda list --explicit --sha256`` pins every conda package by URL and hash;
the packages conda reports from PyPI are pinned by version (the editable
install of this project is left out). The lock is platform specific and is only a record of
the environment the results were produced in; it never changes ``environment.yml``.

``--linux`` writes the Linux lock. It is not read from a Linux machine: pip resolves
the project requirements for Linux x86_64 CPython 3.11 wheels (``--platform``,
``--abi``, ``--only-binary``) with the versions that affect results held to the ones
recorded in the macOS lock, and every wheel is pinned by version and sha256, so
``pip install --require-hashes --no-deps -r`` rebuilds it exactly.
"""

from __future__ import annotations

import argparse
import json
import platform
import re
import subprocess
import tempfile
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "verification" / "environment"
LINUX_LOCK = "linux-x86_64-py311.lock.txt"
LINUX_PYTHON = "3.11"
LINUX_PLATFORMS = ("manylinux2014_x86_64", "manylinux_2_17_x86_64", "manylinux_2_28_x86_64")


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_conda_lock__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_conda_lock__mutmut)
def conda_lock(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "list", "-n", name, "--explicit", "--sha256"], text=True
    )
    return out


def x_conda_lock__mutmut_orig(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "list", "-n", name, "--explicit", "--sha256"], text=True
    )
    return out


def x_conda_lock__mutmut_1(name: str) -> str:
    out = None
    return out


def x_conda_lock__mutmut_2(name: str) -> str:
    out = subprocess.check_output(
        None, text=True
    )
    return out


def x_conda_lock__mutmut_3(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "list", "-n", name, "--explicit", "--sha256"], text=None
    )
    return out


def x_conda_lock__mutmut_4(name: str) -> str:
    out = subprocess.check_output(
        text=True
    )
    return out


def x_conda_lock__mutmut_5(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "list", "-n", name, "--explicit", "--sha256"], )
    return out


def x_conda_lock__mutmut_6(name: str) -> str:
    out = subprocess.check_output(
        ["XXcondaXX", "list", "-n", name, "--explicit", "--sha256"], text=True
    )
    return out


def x_conda_lock__mutmut_7(name: str) -> str:
    out = subprocess.check_output(
        ["CONDA", "list", "-n", name, "--explicit", "--sha256"], text=True
    )
    return out


def x_conda_lock__mutmut_8(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "XXlistXX", "-n", name, "--explicit", "--sha256"], text=True
    )
    return out


def x_conda_lock__mutmut_9(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "LIST", "-n", name, "--explicit", "--sha256"], text=True
    )
    return out


def x_conda_lock__mutmut_10(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "list", "XX-nXX", name, "--explicit", "--sha256"], text=True
    )
    return out


def x_conda_lock__mutmut_11(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "list", "-N", name, "--explicit", "--sha256"], text=True
    )
    return out


def x_conda_lock__mutmut_12(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "list", "-n", name, "XX--explicitXX", "--sha256"], text=True
    )
    return out


def x_conda_lock__mutmut_13(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "list", "-n", name, "--EXPLICIT", "--sha256"], text=True
    )
    return out


def x_conda_lock__mutmut_14(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "list", "-n", name, "--explicit", "XX--sha256XX"], text=True
    )
    return out


def x_conda_lock__mutmut_15(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "list", "-n", name, "--explicit", "--SHA256"], text=True
    )
    return out


def x_conda_lock__mutmut_16(name: str) -> str:
    out = subprocess.check_output(
        ["conda", "list", "-n", name, "--explicit", "--sha256"], text=False
    )
    return out

mutants_x_conda_lock__mutmut['_mutmut_orig'] = x_conda_lock__mutmut_orig # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_1'] = x_conda_lock__mutmut_1 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_2'] = x_conda_lock__mutmut_2 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_3'] = x_conda_lock__mutmut_3 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_4'] = x_conda_lock__mutmut_4 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_5'] = x_conda_lock__mutmut_5 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_6'] = x_conda_lock__mutmut_6 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_7'] = x_conda_lock__mutmut_7 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_8'] = x_conda_lock__mutmut_8 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_9'] = x_conda_lock__mutmut_9 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_10'] = x_conda_lock__mutmut_10 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_11'] = x_conda_lock__mutmut_11 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_12'] = x_conda_lock__mutmut_12 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_13'] = x_conda_lock__mutmut_13 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_14'] = x_conda_lock__mutmut_14 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_15'] = x_conda_lock__mutmut_15 # type: ignore # mutmut generated
mutants_x_conda_lock__mutmut['x_conda_lock__mutmut_16'] = x_conda_lock__mutmut_16 # type: ignore # mutmut generated
mutants_x__norm__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__norm__mutmut)
def _norm(name: str) -> str:
    return name.lower().replace("_", "-")


def x__norm__mutmut_orig(name: str) -> str:
    return name.lower().replace("_", "-")


def x__norm__mutmut_1(name: str) -> str:
    return name.lower().replace(None, "-")


def x__norm__mutmut_2(name: str) -> str:
    return name.lower().replace("_", None)


def x__norm__mutmut_3(name: str) -> str:
    return name.lower().replace("-")


def x__norm__mutmut_4(name: str) -> str:
    return name.lower().replace("_", )


def x__norm__mutmut_5(name: str) -> str:
    return name.upper().replace("_", "-")


def x__norm__mutmut_6(name: str) -> str:
    return name.lower().replace("XX_XX", "-")


def x__norm__mutmut_7(name: str) -> str:
    return name.lower().replace("_", "XX-XX")

mutants_x__norm__mutmut['_mutmut_orig'] = x__norm__mutmut_orig # type: ignore # mutmut generated
mutants_x__norm__mutmut['x__norm__mutmut_1'] = x__norm__mutmut_1 # type: ignore # mutmut generated
mutants_x__norm__mutmut['x__norm__mutmut_2'] = x__norm__mutmut_2 # type: ignore # mutmut generated
mutants_x__norm__mutmut['x__norm__mutmut_3'] = x__norm__mutmut_3 # type: ignore # mutmut generated
mutants_x__norm__mutmut['x__norm__mutmut_4'] = x__norm__mutmut_4 # type: ignore # mutmut generated
mutants_x__norm__mutmut['x__norm__mutmut_5'] = x__norm__mutmut_5 # type: ignore # mutmut generated
mutants_x__norm__mutmut['x__norm__mutmut_6'] = x__norm__mutmut_6 # type: ignore # mutmut generated
mutants_x__norm__mutmut['x__norm__mutmut_7'] = x__norm__mutmut_7 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_conda_names__mutmut)
def conda_names(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_orig(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_1(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = None
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_2(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith(None):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_3(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("XXhttpXX"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_4(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("HTTP"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_5(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = None
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_6(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split(None)[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_7(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit(None, 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_8(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", None)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_9(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit(1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_10(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", )[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_11(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.split("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_12(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("XX/XX", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_13(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 2)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_14(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[2].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_15(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("XX#XX")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_16(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[1]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_17(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = None
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_18(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(None)
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_19(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit(None, 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_20(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", None)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_21(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit(2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_22(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", )[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_23(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.split("-", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_24(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("XX-XX", 2)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_25(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 3)[0])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_26(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[1])
            names |= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_27(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names = {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_28(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names &= {name, name.removesuffix("-base")}
    return names


def x_conda_names__mutmut_29(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix(None)}
    return names


def x_conda_names__mutmut_30(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removeprefix("-base")}
    return names


def x_conda_names__mutmut_31(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("XX-baseXX")}
    return names


def x_conda_names__mutmut_32(explicit: str) -> set[str]:
    """Package names in an explicit conda lock (``base`` builds count for their parent)."""
    names = set()
    for line in explicit.splitlines():
        if line.startswith("http"):
            filename = line.rsplit("/", 1)[1].split("#")[0]
            name = _norm(filename.rsplit("-", 2)[0])
            names |= {name, name.removesuffix("-BASE")}
    return names

mutants_x_conda_names__mutmut['_mutmut_orig'] = x_conda_names__mutmut_orig # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_1'] = x_conda_names__mutmut_1 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_2'] = x_conda_names__mutmut_2 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_3'] = x_conda_names__mutmut_3 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_4'] = x_conda_names__mutmut_4 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_5'] = x_conda_names__mutmut_5 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_6'] = x_conda_names__mutmut_6 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_7'] = x_conda_names__mutmut_7 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_8'] = x_conda_names__mutmut_8 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_9'] = x_conda_names__mutmut_9 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_10'] = x_conda_names__mutmut_10 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_11'] = x_conda_names__mutmut_11 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_12'] = x_conda_names__mutmut_12 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_13'] = x_conda_names__mutmut_13 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_14'] = x_conda_names__mutmut_14 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_15'] = x_conda_names__mutmut_15 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_16'] = x_conda_names__mutmut_16 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_17'] = x_conda_names__mutmut_17 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_18'] = x_conda_names__mutmut_18 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_19'] = x_conda_names__mutmut_19 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_20'] = x_conda_names__mutmut_20 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_21'] = x_conda_names__mutmut_21 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_22'] = x_conda_names__mutmut_22 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_23'] = x_conda_names__mutmut_23 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_24'] = x_conda_names__mutmut_24 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_25'] = x_conda_names__mutmut_25 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_26'] = x_conda_names__mutmut_26 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_27'] = x_conda_names__mutmut_27 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_28'] = x_conda_names__mutmut_28 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_29'] = x_conda_names__mutmut_29 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_30'] = x_conda_names__mutmut_30 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_31'] = x_conda_names__mutmut_31 # type: ignore # mutmut generated
mutants_x_conda_names__mutmut['x_conda_names__mutmut_32'] = x_conda_names__mutmut_32 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_pip_lock__mutmut)
def pip_lock(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_orig(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_1(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = None
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_2(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(None, text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_3(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=None)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_4(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_5(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], )
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_6(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["XXcondaXX", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_7(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["CONDA", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_8(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "XXlistXX", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_9(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "LIST", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_10(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "XX-nXX", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_11(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-N", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_12(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "XX--jsonXX"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_13(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--JSON"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_14(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=False)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_15(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = None
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_16(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(None)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_17(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = None
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_18(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["XXnameXX"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_19(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["NAME"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_20(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["XXversionXX"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_21(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["VERSION"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_22(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(None)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_23(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" or item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_24(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["XXchannelXX"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_25(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["CHANNEL"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_26(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] != "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_27(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "XXpypiXX" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_28(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "PYPI" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_29(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["XXnameXX"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_30(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["NAME"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_31(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] == "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_32(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "XXetl-benchmarkXX"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_33(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "ETL-BENCHMARK"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_34(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = None
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_35(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(None) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_36(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_37(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = None
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_38(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(None, key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_39(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=None)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_40(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_41(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), )
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_42(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) + set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_43(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(None) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_44(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(None), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_45(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = None
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_46(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(None)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_47(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {'XX, XX'.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_48(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header - "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_49(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(None)


def x_pip_lock__mutmut_50(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "XXXX".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=str.lower))


def x_pip_lock__mutmut_51(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(None, key=str.lower))


def x_pip_lock__mutmut_52(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, key=None))


def x_pip_lock__mutmut_53(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(key=str.lower))


def x_pip_lock__mutmut_54(name: str, explicit: str) -> str:
    """Packages installed from PyPI, pinned by version.

    A name that conda also installs is left out and listed in a comment: pip
    may keep a stale record of it, while the files on disk belong to the conda
    package.
    """
    out = subprocess.check_output(["conda", "list", "-n", name, "--json"], text=True)
    owned = conda_names(explicit)
    pypi = {
        item["name"]: item["version"]
        for item in json.loads(out)
        if item["channel"] == "pypi" and item["name"] != "etl-benchmark"
    }
    kept = {key: value for key, value in pypi.items() if _norm(key) not in owned}
    skipped = sorted(set(pypi) - set(kept), key=str.lower)
    header = f"# installed by conda as well, not pinned here: {', '.join(skipped)}\n"
    return header + "".join(f"{key}=={kept[key]}\n" for key in sorted(kept, ))

mutants_x_pip_lock__mutmut['_mutmut_orig'] = x_pip_lock__mutmut_orig # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_1'] = x_pip_lock__mutmut_1 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_2'] = x_pip_lock__mutmut_2 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_3'] = x_pip_lock__mutmut_3 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_4'] = x_pip_lock__mutmut_4 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_5'] = x_pip_lock__mutmut_5 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_6'] = x_pip_lock__mutmut_6 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_7'] = x_pip_lock__mutmut_7 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_8'] = x_pip_lock__mutmut_8 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_9'] = x_pip_lock__mutmut_9 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_10'] = x_pip_lock__mutmut_10 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_11'] = x_pip_lock__mutmut_11 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_12'] = x_pip_lock__mutmut_12 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_13'] = x_pip_lock__mutmut_13 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_14'] = x_pip_lock__mutmut_14 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_15'] = x_pip_lock__mutmut_15 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_16'] = x_pip_lock__mutmut_16 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_17'] = x_pip_lock__mutmut_17 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_18'] = x_pip_lock__mutmut_18 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_19'] = x_pip_lock__mutmut_19 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_20'] = x_pip_lock__mutmut_20 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_21'] = x_pip_lock__mutmut_21 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_22'] = x_pip_lock__mutmut_22 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_23'] = x_pip_lock__mutmut_23 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_24'] = x_pip_lock__mutmut_24 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_25'] = x_pip_lock__mutmut_25 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_26'] = x_pip_lock__mutmut_26 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_27'] = x_pip_lock__mutmut_27 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_28'] = x_pip_lock__mutmut_28 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_29'] = x_pip_lock__mutmut_29 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_30'] = x_pip_lock__mutmut_30 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_31'] = x_pip_lock__mutmut_31 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_32'] = x_pip_lock__mutmut_32 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_33'] = x_pip_lock__mutmut_33 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_34'] = x_pip_lock__mutmut_34 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_35'] = x_pip_lock__mutmut_35 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_36'] = x_pip_lock__mutmut_36 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_37'] = x_pip_lock__mutmut_37 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_38'] = x_pip_lock__mutmut_38 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_39'] = x_pip_lock__mutmut_39 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_40'] = x_pip_lock__mutmut_40 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_41'] = x_pip_lock__mutmut_41 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_42'] = x_pip_lock__mutmut_42 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_43'] = x_pip_lock__mutmut_43 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_44'] = x_pip_lock__mutmut_44 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_45'] = x_pip_lock__mutmut_45 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_46'] = x_pip_lock__mutmut_46 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_47'] = x_pip_lock__mutmut_47 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_48'] = x_pip_lock__mutmut_48 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_49'] = x_pip_lock__mutmut_49 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_50'] = x_pip_lock__mutmut_50 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_51'] = x_pip_lock__mutmut_51 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_52'] = x_pip_lock__mutmut_52 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_53'] = x_pip_lock__mutmut_53 # type: ignore # mutmut generated
mutants_x_pip_lock__mutmut['x_pip_lock__mutmut_54'] = x_pip_lock__mutmut_54 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_project_requirements__mutmut)
def project_requirements(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_orig(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_1(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = None
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_2(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(None)["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_3(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["XXprojectXX"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_4(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["PROJECT"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_5(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = None
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_6(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(None)
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_7(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["XXdependenciesXX"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_8(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["DEPENDENCIES"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_9(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get(None, {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_10(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", None).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_11(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get({}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_12(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", ).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_13(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("XXoptional-dependenciesXX", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_14(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("OPTIONAL-DEPENDENCIES", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_15(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found = extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_16(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found -= extra
    return [req for req in dict.fromkeys(found) if not req.startswith("torch")]


def x_project_requirements__mutmut_17(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(None) if not req.startswith("torch")]


def x_project_requirements__mutmut_18(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if req.startswith("torch")]


def x_project_requirements__mutmut_19(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith(None)]


def x_project_requirements__mutmut_20(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("XXtorchXX")]


def x_project_requirements__mutmut_21(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Runtime requirements and every extra, as declared (unpinned).

    PyTorch is left out: PyPI serves the CUDA build for Linux, with a long list of
    GPU libraries, while the archived runs and their reproduction use no neural
    detector. The Linux environment rebuilt from this lock runs them without it.
    """
    project = tomllib.loads(pyproject.read_text())["project"]
    found = list(project["dependencies"])
    for extra in project.get("optional-dependencies", {}).values():
        found += extra
    return [req for req in dict.fromkeys(found) if not req.startswith("TORCH")]

mutants_x_project_requirements__mutmut['_mutmut_orig'] = x_project_requirements__mutmut_orig # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_1'] = x_project_requirements__mutmut_1 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_2'] = x_project_requirements__mutmut_2 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_3'] = x_project_requirements__mutmut_3 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_4'] = x_project_requirements__mutmut_4 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_5'] = x_project_requirements__mutmut_5 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_6'] = x_project_requirements__mutmut_6 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_7'] = x_project_requirements__mutmut_7 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_8'] = x_project_requirements__mutmut_8 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_9'] = x_project_requirements__mutmut_9 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_10'] = x_project_requirements__mutmut_10 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_11'] = x_project_requirements__mutmut_11 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_12'] = x_project_requirements__mutmut_12 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_13'] = x_project_requirements__mutmut_13 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_14'] = x_project_requirements__mutmut_14 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_15'] = x_project_requirements__mutmut_15 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_16'] = x_project_requirements__mutmut_16 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_17'] = x_project_requirements__mutmut_17 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_18'] = x_project_requirements__mutmut_18 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_19'] = x_project_requirements__mutmut_19 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_20'] = x_project_requirements__mutmut_20 # type: ignore # mutmut generated
mutants_x_project_requirements__mutmut['x_project_requirements__mutmut_21'] = x_project_requirements__mutmut_21 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_resolve_linux__mutmut)
def resolve_linux(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_orig(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_1(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = None
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_2(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir * "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_3(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "XXconstraints.txtXX"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_4(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "CONSTRAINTS.TXT"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_5(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text(None)
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_6(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(None))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_7(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("XXXX".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_8(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(None)))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_9(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = None
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_10(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir * "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_11(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "XXreport.jsonXX"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_12(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "REPORT.JSON"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_13(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = None
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_14(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["XXpythonXX", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_15(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["PYTHON", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_16(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "XX-mXX", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_17(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-M", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_18(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "XXpipXX", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_19(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "PIP", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_20(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "XXinstallXX", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_21(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "INSTALL", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_22(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "XX--dry-runXX", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_23(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--DRY-RUN", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_24(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "XX--ignore-installedXX", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_25(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--IGNORE-INSTALLED", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_26(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "XX--quietXX"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_27(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--QUIET"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_28(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command = ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_29(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command -= ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_30(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["XX--reportXX", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_31(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--REPORT", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_32(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(None), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_33(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "XX--targetXX", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_34(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--TARGET", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_35(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(None)]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_36(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir * "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_37(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "XXtargetXX")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_38(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "TARGET")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_39(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command = ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_40(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command -= ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_41(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["XX--only-binary=:all:XX", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_42(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--ONLY-BINARY=:ALL:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_43(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "XX--python-versionXX", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_44(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--PYTHON-VERSION", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_45(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "XX--implementationXX", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_46(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--IMPLEMENTATION", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_47(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "XXcpXX"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_48(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "CP"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_49(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command = ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_50(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command -= ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_51(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["XX--abiXX", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_52(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--ABI", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_53(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" - LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_54(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "XXcpXX" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_55(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "CP" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_56(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(None, "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_57(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", None)]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_58(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace("")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_59(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", )]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_60(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace("XX.XX", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_61(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "XXXX")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_62(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command = ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_63(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command -= ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_64(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["XX--platformXX", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_65(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--PLATFORM", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_66(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command = ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_67(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command -= ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_68(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["XX-cXX", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_69(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-C", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_70(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(None), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_71(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(None, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_72(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=None, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_73(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=None, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_74(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=None, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_75(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=None)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_76(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(check=True, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_77(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_78(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_79(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_80(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, )
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_81(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=False, capture_output=True, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_82(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=False, text=True, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_83(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=False, timeout=900)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_84(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=901)
    return json.loads(report.read_text())


def x_resolve_linux__mutmut_85(requirements: list[str], held: dict[str, str], workdir: Path) -> dict:
    """pip's installation report for Linux wheels, without installing anything."""
    constraints = workdir / "constraints.txt"
    constraints.write_text("".join(f"{name}=={found}\n" for name, found in sorted(held.items())))
    report = workdir / "report.json"
    command = ["python", "-m", "pip", "install", "--dry-run", "--ignore-installed", "--quiet"]
    command += ["--report", str(report), "--target", str(workdir / "target")]
    command += ["--only-binary=:all:", "--python-version", LINUX_PYTHON, "--implementation", "cp"]
    command += ["--abi", "cp" + LINUX_PYTHON.replace(".", "")]
    for tag in LINUX_PLATFORMS:
        command += ["--platform", tag]
    command += ["-c", str(constraints), *requirements]
    subprocess.run(command, check=True, capture_output=True, text=True, timeout=900)
    return json.loads(None)

mutants_x_resolve_linux__mutmut['_mutmut_orig'] = x_resolve_linux__mutmut_orig # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_1'] = x_resolve_linux__mutmut_1 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_2'] = x_resolve_linux__mutmut_2 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_3'] = x_resolve_linux__mutmut_3 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_4'] = x_resolve_linux__mutmut_4 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_5'] = x_resolve_linux__mutmut_5 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_6'] = x_resolve_linux__mutmut_6 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_7'] = x_resolve_linux__mutmut_7 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_8'] = x_resolve_linux__mutmut_8 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_9'] = x_resolve_linux__mutmut_9 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_10'] = x_resolve_linux__mutmut_10 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_11'] = x_resolve_linux__mutmut_11 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_12'] = x_resolve_linux__mutmut_12 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_13'] = x_resolve_linux__mutmut_13 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_14'] = x_resolve_linux__mutmut_14 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_15'] = x_resolve_linux__mutmut_15 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_16'] = x_resolve_linux__mutmut_16 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_17'] = x_resolve_linux__mutmut_17 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_18'] = x_resolve_linux__mutmut_18 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_19'] = x_resolve_linux__mutmut_19 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_20'] = x_resolve_linux__mutmut_20 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_21'] = x_resolve_linux__mutmut_21 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_22'] = x_resolve_linux__mutmut_22 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_23'] = x_resolve_linux__mutmut_23 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_24'] = x_resolve_linux__mutmut_24 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_25'] = x_resolve_linux__mutmut_25 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_26'] = x_resolve_linux__mutmut_26 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_27'] = x_resolve_linux__mutmut_27 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_28'] = x_resolve_linux__mutmut_28 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_29'] = x_resolve_linux__mutmut_29 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_30'] = x_resolve_linux__mutmut_30 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_31'] = x_resolve_linux__mutmut_31 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_32'] = x_resolve_linux__mutmut_32 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_33'] = x_resolve_linux__mutmut_33 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_34'] = x_resolve_linux__mutmut_34 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_35'] = x_resolve_linux__mutmut_35 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_36'] = x_resolve_linux__mutmut_36 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_37'] = x_resolve_linux__mutmut_37 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_38'] = x_resolve_linux__mutmut_38 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_39'] = x_resolve_linux__mutmut_39 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_40'] = x_resolve_linux__mutmut_40 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_41'] = x_resolve_linux__mutmut_41 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_42'] = x_resolve_linux__mutmut_42 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_43'] = x_resolve_linux__mutmut_43 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_44'] = x_resolve_linux__mutmut_44 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_45'] = x_resolve_linux__mutmut_45 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_46'] = x_resolve_linux__mutmut_46 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_47'] = x_resolve_linux__mutmut_47 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_48'] = x_resolve_linux__mutmut_48 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_49'] = x_resolve_linux__mutmut_49 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_50'] = x_resolve_linux__mutmut_50 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_51'] = x_resolve_linux__mutmut_51 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_52'] = x_resolve_linux__mutmut_52 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_53'] = x_resolve_linux__mutmut_53 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_54'] = x_resolve_linux__mutmut_54 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_55'] = x_resolve_linux__mutmut_55 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_56'] = x_resolve_linux__mutmut_56 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_57'] = x_resolve_linux__mutmut_57 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_58'] = x_resolve_linux__mutmut_58 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_59'] = x_resolve_linux__mutmut_59 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_60'] = x_resolve_linux__mutmut_60 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_61'] = x_resolve_linux__mutmut_61 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_62'] = x_resolve_linux__mutmut_62 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_63'] = x_resolve_linux__mutmut_63 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_64'] = x_resolve_linux__mutmut_64 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_65'] = x_resolve_linux__mutmut_65 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_66'] = x_resolve_linux__mutmut_66 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_67'] = x_resolve_linux__mutmut_67 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_68'] = x_resolve_linux__mutmut_68 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_69'] = x_resolve_linux__mutmut_69 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_70'] = x_resolve_linux__mutmut_70 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_71'] = x_resolve_linux__mutmut_71 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_72'] = x_resolve_linux__mutmut_72 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_73'] = x_resolve_linux__mutmut_73 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_74'] = x_resolve_linux__mutmut_74 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_75'] = x_resolve_linux__mutmut_75 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_76'] = x_resolve_linux__mutmut_76 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_77'] = x_resolve_linux__mutmut_77 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_78'] = x_resolve_linux__mutmut_78 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_79'] = x_resolve_linux__mutmut_79 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_80'] = x_resolve_linux__mutmut_80 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_81'] = x_resolve_linux__mutmut_81 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_82'] = x_resolve_linux__mutmut_82 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_83'] = x_resolve_linux__mutmut_83 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_84'] = x_resolve_linux__mutmut_84 # type: ignore # mutmut generated
mutants_x_resolve_linux__mutmut['x_resolve_linux__mutmut_85'] = x_resolve_linux__mutmut_85 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_format_linux_lock__mutmut)
def format_linux_lock(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_orig(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_1(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = None
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_2(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["XXinstallXX"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_3(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["INSTALL"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_4(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = None
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_5(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["XXdownload_infoXX"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_6(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["DOWNLOAD_INFO"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_7(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["XXarchive_infoXX"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_8(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["ARCHIVE_INFO"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_9(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["XXhashesXX"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_10(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["HASHES"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_11(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["XXsha256XX"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_12(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["SHA256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_13(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(None) from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_14(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['XXmetadataXX']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_15(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['METADATA']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_16(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['XXnameXX']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_17(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['NAME']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_18(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = None
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_19(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).upper()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_20(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(None, "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_21(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", None, item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_22(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", None).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_23(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub("-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_24(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_25(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", ).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_26(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"XX[-_.]+XX", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_27(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "XX-XX", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_28(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["XXmetadataXX"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_29(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["METADATA"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_30(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["XXnameXX"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_31(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["NAME"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_32(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = None
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_33(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['XXmetadataXX']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_34(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['METADATA']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_35(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['XXversionXX']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_36(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['VERSION']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_37(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = None
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_38(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "XX# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.XX",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_39(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# linux x86_64, cpython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_40(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# LINUX X86_64, CPYTHON 3.11 (CP311), MANYLINUX WHEELS ONLY.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_41(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "XX# Resolved by pip for that platform, not on a Linux machine; install withXX",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_42(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# resolved by pip for that platform, not on a linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_43(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# RESOLVED BY PIP FOR THAT PLATFORM, NOT ON A LINUX MACHINE; INSTALL WITH",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_44(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "XX#   pip install --require-hashes --no-deps -r <this file>XX",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_45(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   PIP INSTALL --REQUIRE-HASHES --NO-DEPS -R <THIS FILE>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_46(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: " - ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_47(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "XX# Held to the versions recorded in the macOS lock: XX"
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_48(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# held to the versions recorded in the macos lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_49(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# HELD TO THE VERSIONS RECORDED IN THE MACOS LOCK: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_50(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(None),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_51(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + "XX, XX".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_52(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(None)),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_53(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) - "\n"


def x_format_linux_lock__mutmut_54(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(None) + "\n"


def x_format_linux_lock__mutmut_55(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "XX\nXX".join(header + [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_56(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header - [pins[name] for name in sorted(pins)]) + "\n"


def x_format_linux_lock__mutmut_57(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(None)]) + "\n"


def x_format_linux_lock__mutmut_58(report: dict, held: dict[str, str]) -> str:
    """One ``name==version --hash=sha256:...`` line per wheel, sorted by name."""
    pins = {}
    for item in report["install"]:
        try:
            digest = item["download_info"]["archive_info"]["hashes"]["sha256"]
        except KeyError as exc:
            raise ValueError(f"no sha256 hash for {item['metadata']['name']}") from exc
        name = re.sub(r"[-_.]+", "-", item["metadata"]["name"]).lower()
        pins[name] = f"{name}=={item['metadata']['version']} --hash=sha256:{digest}"
    header = [
        "# Linux x86_64, CPython 3.11 (cp311), manylinux wheels only.",
        "# Resolved by pip for that platform, not on a Linux machine; install with",
        "#   pip install --require-hashes --no-deps -r <this file>",
        "# Held to the versions recorded in the macOS lock: "
        + ", ".join(f"{name}=={found}" for name, found in sorted(held.items())),
    ]
    return "\n".join(header + [pins[name] for name in sorted(pins)]) + "XX\nXX"

mutants_x_format_linux_lock__mutmut['_mutmut_orig'] = x_format_linux_lock__mutmut_orig # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_1'] = x_format_linux_lock__mutmut_1 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_2'] = x_format_linux_lock__mutmut_2 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_3'] = x_format_linux_lock__mutmut_3 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_4'] = x_format_linux_lock__mutmut_4 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_5'] = x_format_linux_lock__mutmut_5 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_6'] = x_format_linux_lock__mutmut_6 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_7'] = x_format_linux_lock__mutmut_7 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_8'] = x_format_linux_lock__mutmut_8 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_9'] = x_format_linux_lock__mutmut_9 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_10'] = x_format_linux_lock__mutmut_10 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_11'] = x_format_linux_lock__mutmut_11 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_12'] = x_format_linux_lock__mutmut_12 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_13'] = x_format_linux_lock__mutmut_13 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_14'] = x_format_linux_lock__mutmut_14 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_15'] = x_format_linux_lock__mutmut_15 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_16'] = x_format_linux_lock__mutmut_16 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_17'] = x_format_linux_lock__mutmut_17 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_18'] = x_format_linux_lock__mutmut_18 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_19'] = x_format_linux_lock__mutmut_19 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_20'] = x_format_linux_lock__mutmut_20 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_21'] = x_format_linux_lock__mutmut_21 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_22'] = x_format_linux_lock__mutmut_22 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_23'] = x_format_linux_lock__mutmut_23 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_24'] = x_format_linux_lock__mutmut_24 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_25'] = x_format_linux_lock__mutmut_25 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_26'] = x_format_linux_lock__mutmut_26 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_27'] = x_format_linux_lock__mutmut_27 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_28'] = x_format_linux_lock__mutmut_28 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_29'] = x_format_linux_lock__mutmut_29 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_30'] = x_format_linux_lock__mutmut_30 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_31'] = x_format_linux_lock__mutmut_31 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_32'] = x_format_linux_lock__mutmut_32 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_33'] = x_format_linux_lock__mutmut_33 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_34'] = x_format_linux_lock__mutmut_34 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_35'] = x_format_linux_lock__mutmut_35 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_36'] = x_format_linux_lock__mutmut_36 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_37'] = x_format_linux_lock__mutmut_37 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_38'] = x_format_linux_lock__mutmut_38 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_39'] = x_format_linux_lock__mutmut_39 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_40'] = x_format_linux_lock__mutmut_40 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_41'] = x_format_linux_lock__mutmut_41 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_42'] = x_format_linux_lock__mutmut_42 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_43'] = x_format_linux_lock__mutmut_43 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_44'] = x_format_linux_lock__mutmut_44 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_45'] = x_format_linux_lock__mutmut_45 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_46'] = x_format_linux_lock__mutmut_46 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_47'] = x_format_linux_lock__mutmut_47 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_48'] = x_format_linux_lock__mutmut_48 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_49'] = x_format_linux_lock__mutmut_49 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_50'] = x_format_linux_lock__mutmut_50 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_51'] = x_format_linux_lock__mutmut_51 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_52'] = x_format_linux_lock__mutmut_52 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_53'] = x_format_linux_lock__mutmut_53 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_54'] = x_format_linux_lock__mutmut_54 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_55'] = x_format_linux_lock__mutmut_55 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_56'] = x_format_linux_lock__mutmut_56 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_57'] = x_format_linux_lock__mutmut_57 # type: ignore # mutmut generated
mutants_x_format_linux_lock__mutmut['x_format_linux_lock__mutmut_58'] = x_format_linux_lock__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default=None)
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", )
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--conda-envXX", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--CONDA-ENV", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="XXetl-benchmarkXX")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="ETL-BENCHMARK")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument(None, type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=None, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument(type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, )
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("XX--outputXX", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--OUTPUT", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument(None, action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action=None, help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help=None)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument(action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", )
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("XX--linuxXX", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--LINUX", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="XXstore_trueXX", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="STORE_TRUE", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="XXwrite the Linux lock insteadXX")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="WRITE THE LINUX LOCK INSTEAD")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = None
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(None)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=None, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=None)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, )
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=False, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=False)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = None
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = None
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(None, held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), None, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, None)
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, )
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(None))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(None)
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output * LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(None, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, None))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, ))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(None)
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output * LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 1
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = None
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().upper()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = None
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(None)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(None)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output * f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(None)
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output * "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "XXpip-freeze.txtXX").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "PIP-FREEZE.TXT").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(None, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, None))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, ))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(None)
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conda-env", default="etl-benchmark")
    parser.add_argument("--output", type=Path, default=TARGET)
    parser.add_argument("--linux", action="store_true", help="write the Linux lock instead")
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.linux:
        from verification import release

        held = release.locked_versions()
        with tempfile.TemporaryDirectory() as work:
            report = resolve_linux(project_requirements(), held, Path(work))
        (args.output / LINUX_LOCK).write_text(format_linux_lock(report, held))
        print(f"wrote the Linux lock to {args.output / LINUX_LOCK}")
        return 0
    system = f"{platform.system().lower()}-{platform.machine()}"
    explicit = conda_lock(args.conda_env)
    (args.output / f"conda-{system}.explicit.txt").write_text(explicit)
    (args.output / "pip-freeze.txt").write_text(pip_lock(args.conda_env, explicit))
    print(f"wrote the lock of {args.conda_env} to {args.output}")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
